#!/usr/bin/env python3
"""Upgrade/remove isolated archived adapters while retaining original authority.

This candidate lifecycle exercise does not establish public artifact publication.
No normal profile, unrelated consumer, owner database or protected volume is removed.
"""
import argparse,hashlib,json,os,shutil,signal,sqlite3,subprocess,tarfile,time,urllib.request,uuid,zipfile
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__)
for name in ['kernel','output','owner-root']:p.add_argument('--'+name,type=Path,required=True)
p.add_argument('--kernel-sha256',required=True);p.add_argument('--kernel-source',required=True);p.add_argument('--host',choices=['hermes','openclaw'],required=True)
a=p.parse_args()
ROOT=Path('/Users/connor/Medica/backbay/standalone/arc/.worktrees/required-agent-integrations-20260909')
BUNDLE=Path('/Users/connor/.local/share/chio-required-candidates/20260909')
AUTH=Path('/Users/connor/.local/share/chio-required-operators/native-subscription-auth-20260909/codex/profile/auth.json')
IMAGE='sha256:188cb84d5d0bb4063d4ce5a3b9c3832445a5acda5604911cda80a9136d1850a0'
OCIMAGE='sha256:7f925d68ced724f4a6314ab76dc117e9000515ba62149ee971a11c510be6637f'
OLDIMAGE='sha256:9aed9b78d3a0868c44e8960a72e821bfb5435eb8fe1b952be9c7667a3537d618'
OPBRIDGE=BUNDLE/'install/operator-bridge/node_modules/@chio/bridge'
BRIDGE=Path('/tmp/chio-kernel-rc-consumers-20260910/hermes/bridge/node_modules/@chio/bridge')
HOSTPY=Path('/tmp/chio-hermes-public-final-install-20260910/qualified-venv/bin/python');HOSTROOT=Path('/tmp/chio-hermes-public-final-install-20260910/source')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,obj):p.write_text(json.dumps(obj,indent=2)+'\n');p.chmod(0o600)
assert sha(a.kernel)==a.kernel_sha256
a.output.mkdir(mode=0o700,parents=True,exist_ok=False);a.owner_root.mkdir(mode=0o700,parents=True,exist_ok=False)
(a.output/'driver.py').write_bytes(Path(__file__).read_bytes());records=[]
def run(label,cmd,timeout=600,expected=0):
    started=time.monotonic();env=os.environ.copy();env.pop('NODE_OPTIONS',None);env['NPM_CONFIG_USERCONFIG']='/dev/null'
    hashes={str(Path(c)):sha(Path(c)) for c in cmd[:2] if Path(c).is_file()}
    timed=False;cleanup_errors=[]
    with (a.output/(label+'.stdout')).open('w') as out,(a.output/(label+'.stderr')).open('w') as err:
        child=subprocess.Popen([str(c) for c in cmd],stdout=out,stderr=err,env=env,start_new_session=True)
        try:code=child.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed=True
            for chosen_signal,grace in [(signal.SIGTERM,20),(signal.SIGKILL,10)]:
                try:os.killpg(child.pid,chosen_signal)
                except ProcessLookupError:pass
                except OSError as error:cleanup_errors.append({'signal':int(chosen_signal),'error':type(error).__name__})
                try:child.wait(timeout=grace);break
                except subprocess.TimeoutExpired:cleanup_errors.append({'signal':int(chosen_signal),'waitTimedOut':True})
            code=child.poll()
    timed |= 'subprocess.TimeoutExpired:' in (a.output/(label+'.stderr')).read_text()
    unchanged=all(sha(Path(path))==digest for path,digest in hashes.items())
    records.append({'label':label,'command':[str(c) for c in cmd],'exitCode':code,'timedOut':timed,'driverPid':child.pid,'scopedProcessGroup':child.pid,'cleanupErrors':cleanup_errors,'descendantCleanupVerified':False if timed else None,'elapsedSeconds':time.monotonic()-started,'driverHashesAtStart':hashes,'driversUnchangedDuringRun':unchanged});save(a.output/'runs.json',records)
    print(json.dumps({'host':a.host,'label':label,'exitCode':code,'timedOut':timed}),flush=True)
    assert not timed and code==expected and unchanged,label+' failed; all dependent work stopped, original state retained'
    return subprocess.CompletedProcess(cmd,code,(a.output/(label+'.stdout')).read_text(),(a.output/(label+'.stderr')).read_text())
owner=a.owner_root/'lifecycle';port=59267 if a.host=='hermes' else 59281
run('start-owner',['python3',ROOT/'integrations/required-agents/serve-filesystem.py','start','--state-dir',owner,'--kernel',a.kernel,'--kernel-sha256',a.kernel_sha256,'--image',IMAGE,'--volume','chio-required-final-'+a.host+'-20260910-lifecycle','--port',str(port)])
deadline=time.monotonic()+45
while not (owner/'sessions.sqlite.admission.kernel.pub').exists():
    if time.monotonic()>deadline:raise TimeoutError('owner signer unavailable')
    time.sleep(.1)
op=json.loads((owner/'operator.json').read_text())
def observe():
    js="const f=require('fs');let files={};for(const n of f.readdirSync('/observe'))if(f.lstatSync('/observe/'+n).isFile())files[n]=f.readFileSync('/observe/'+n,'utf8');const p='/audit/dispatch.jsonl';console.log(JSON.stringify({files,dispatch:f.existsSync(p)?f.readFileSync(p,'utf8').split('\\n').filter(Boolean).map(JSON.parse):[]}));"
    return json.loads(subprocess.check_output(['docker','run','--rm','--network','none','--read-only','--mount','type=volume,src='+op['volume']+',dst=/observe,readonly','--mount','type=volume,src='+op['auditVolume']+',dst=/audit,readonly','--entrypoint','node',IMAGE,'-e',js],text=True))

identity={'host':a.host,'kernelSource':a.kernel_source,'kernelSha256':a.kernel_sha256,'resourceImage':IMAGE,'owner':str(owner),'port':port,'scope':'isolated archived candidate installation and retained-authority removal; publication separately open'}
consumer=a.output/'consumer';consumer.mkdir(mode=0o700)
if a.host=='openclaw':
    old=Path('/tmp/chio-openclaw-subscription-r4-package-v5-20260909/chio-openclaw-kernel-0.1.0.tgz');current=Path('/tmp/chio-openclaw-subscription-r6-package-20260909/chio-openclaw-kernel-0.1.0.tgz')
    assert sha(old)=='10429af214dfd12f4383749e1c106babd876a1377d53d55125630a2054dcec2c'
    assert sha(current)=='a79dbffa8356a608f22db847e100d1989cb7ff322ab1315144774decb2b13ab4'
    identity.update(oldArchiveSha256=sha(old),archiveSha256=sha(current),oldImage=OLDIMAGE,hostImage=OCIMAGE)
    save(consumer/'package.json',{'private':True,'name':'chio-final-openclaw-lifecycle','version':'0.0.0'})
    def install(label,archive):
        cache=a.output/(label+'-empty-cache');cache.mkdir()
        run(label,['npm','install','--prefix',consumer,'--cache',cache,'--offline','--ignore-scripts','--no-audit','--no-fund','--registry=http://127.0.0.1:9',archive],120)
        pkg=consumer/'node_modules/@chio/openclaw-kernel'
        with tarfile.open(archive) as stream:
            files=[m for m in stream.getmembers() if m.isfile()]
            for m in files:
                assert m.name.startswith('package/')
                relative=Path(m.name.removeprefix('package/'));assert '..' not in relative.parts
                assert (pkg/relative).read_bytes()==stream.extractfile(m).read()
        save(a.output/(label+'-comparison.json'),{'archiveSha256':sha(archive),'regularFilesCompared':len(files),'mismatches':0})
        return pkg
    pkg=install('old-install',old)
    shared=['python3',ROOT/'scripts/acceptance/host-approvals.py','--host','openclaw','--operator-state',owner,'--package-dir',pkg,'--model-auth-file',AUTH]
    run('old-native-unknown',shared+['--image',OLDIMAGE,'--suite','evidence-wrong-signer','--output',a.output/'old-native-unknown'],900)
    config=Path(json.loads((a.output/'old-native-unknown/identity.json').read_text())['privateConfiguration']);digest=sha(config)
    snapshot={p.name:sha(p) for p in Path(json.loads(config.read_text())['journalDir']).glob('*.json')}
    original=observe();save(a.output/'before-upgrade.json',original)
    install('new-install',current)
    assert sha(config)==digest and {p.name:sha(p) for p in Path(json.loads(config.read_text())['journalDir']).glob('*.json')}==snapshot and observe()==original
    run('new-native-fence',shared+['--image',OCIMAGE,'--suite','resume-fence','--existing-config',config,'--output',a.output/'new-native-fence'],900)
    run('original-owner-recovery',shared+['--image',OCIMAGE,'--suite','recover-owner-result','--existing-config',config,'--operator-bridge',OPBRIDGE,'--output',a.output/'original-owner-recovery'],900)
else:
    uv=Path('/tmp/chio-hermes-20260909/install-tools/bin/uv');old=Path('/tmp/chio-hermes-supervisor-wheel-r11-20260909/chio_hermes-0.1.2-py3-none-any.whl');current=Path('/tmp/chio-hermes-subscription-wheel-r15-20260909/chio_hermes-0.1.2-py3-none-any.whl')
    assert sha(old)=='f2c3d0e79a04c496c80950dccaa5752177216e7d2d267deb78c6b5c3f953b4f3'
    assert sha(current)=='625979d5331796e7aef5906e69e3e2c746796aa570291af026c305ed4227c818'
    identity.update(oldArchiveSha256=sha(old),archiveSha256=sha(current),oldCandidateScope='installation-only; older candidate lacks qualified native subscription surface')
    run('create-consumer',[uv,'venv','--python','/Library/Frameworks/Python.framework/Versions/3.11/bin/python3.11',consumer])
    py=consumer/'bin/python'
    def compare_wheel(label,archive):
        site=consumer/'lib/python3.11/site-packages'
        with zipfile.ZipFile(archive) as z:
            names=[n for n in z.namelist() if n.startswith('chio_hermes/') and not n.endswith('/')]
            assert all((site/n).read_bytes()==z.read(n) for n in names)
        save(a.output/(label+'-comparison.json'),{'wheelSha256':sha(archive),'adapterFilesCompared':len(names),'mismatches':0})
    for label,archive in [('old-install',old),('new-install',current)]:
        run(label,[uv,'pip','install','--no-cache','--python',py,'--no-index','--find-links','/tmp/chio-hermes-20260909/final-wheelhouse','--reinstall-package','chio-hermes',archive])
        compare_wheel(label,archive)
        run(label+'-check',[uv,'pip','check','--python',py]);run(label+'-entrypoint',[consumer/'bin/chio-hermes-restricted','--help'])
    shared=['python3',ROOT/'scripts/acceptance/host-approvals.py','--host','hermes','--operator-state',owner,'--package-dir',BRIDGE,'--launcher-python',py,'--host-python',HOSTPY,'--host-root',HOSTROOT,'--model-auth-file',AUTH]
    run('native-unknown-before-reinstall',shared+['--suite','evidence-wrong-signer','--output',a.output/'native-unknown-before-reinstall'],900)
    config=Path(json.loads((a.output/'native-unknown-before-reinstall/identity.json').read_text())['privateConfiguration']);digest=sha(config)
    snapshot={p.name:sha(p) for p in Path(json.loads(config.read_text())['journalDir']).glob('*.json')};original=observe();save(a.output/'before-reinstall.json',original)
    run('reinstall-original-current',[uv,'pip','install','--no-cache','--python',py,'--no-index','--find-links','/tmp/chio-hermes-20260909/final-wheelhouse','--reinstall-package','chio-hermes',current])
    compare_wheel('reinstall-original-current',current)
    assert sha(config)==digest and {p.name:sha(p) for p in Path(json.loads(config.read_text())['journalDir']).glob('*.json')}==snapshot and observe()==original
    run('reinstalled-native-fence',shared+['--suite','resume-fence','--existing-config',config,'--output',a.output/'reinstalled-native-fence'],900)
    run('original-owner-recovery',shared+['--suite','recover-owner-result','--existing-config',config,'--operator-bridge',OPBRIDGE,'--output',a.output/'original-owner-recovery'],900)

conf=json.loads(config.read_text());assert sha(config)==digest
journal=Path(conf['journalDir']);before=observe();save(a.output/'before-removal.json',before)
entries=[json.loads(p.read_text()) for p in journal.glob('*.json')]
assert entries and all(r['state'] in ['completed','denied'] and (r['state']=='denied' or r.get('acknowledged')) for r in entries)
retained={str(p):sha(p) for p in [config,*journal.glob('*.json')]}
revocations=[]
for name,path,body in [('capability','/admin/revocations',{'capability_id':conf['execution']['capabilityId']}),('credential','/admin/sessions/'+conf['execution']['sessionId']+'/credential/revoke',{})]:
    request=urllib.request.Request(f'http://127.0.0.1:{port}'+path,data=json.dumps(body).encode(),headers={'Authorization':'Bearer '+op['adminToken'],'Content-Type':'application/json'},method='POST')
    with urllib.request.urlopen(request,timeout=15) as response:
        raw=response.read();revocations.append({'kind':name,'status':response.status,'responseSha256':hashlib.sha256(raw).hexdigest(),'resourceAndAuditUnchanged':observe()==before})
save(a.output/'revocations.json',revocations)
runtime=owner/'revoked-runtime'
if a.host=='openclaw':cmd=['node',pkg/'scripts/protected.mjs','--gateway-config',config,'--state-dir',runtime,'--image',OCIMAGE,'--model-auth-file',AUTH,'--prompt','Use chio_call to write /workspace/must-stay-absent.txt with content forbidden after removal. Stop after refusal.']
else:
    query=owner/'revoked-query.txt';query.write_text('Use mcp__chio__write_file for /workspace/must-stay-absent.txt with content forbidden after removal. Stop after refusal.')
    cmd=[py,'-m','chio_hermes.restricted','--host-python',HOSTPY,'--host-root',HOSTROOT,'--node',shutil.which('node'),'--gateway-script',BRIDGE/'dist/gateway-http.js','--gateway-config',config,'--state-dir',runtime,'--query-file',query,'--model','gpt-5.5','--model-auth','codex-subscription','--codex-auth-file',AUTH,'--max-turns','3']
run('revoked-launch',cmd,180,1 if a.host=='openclaw' else 2)
assert observe()==before and not (runtime/'launch.json').exists()
removed=[]
if a.host=='openclaw':
    histories=[];volumes=[]
    for launchfile in a.output.rglob('launch.json'):
        launch=json.loads(launchfile.read_text())
        assert launch['image'] in [OCIMAGE,OLDIMAGE]
        for key in ['volume','controlVolume']:
            volume=launch[key];assert volume.startswith('chio-required-openclaw-') and volume not in [op['volume'],op['auditVolume']]
            if volume not in volumes:volumes.append(volume)
        historycode="const f=require('fs');process.stdout.write(f.readFileSync('/state/openclaw/agents/main/sessions/"+launch['sessionId']+".jsonl','utf8'));"
        raw=subprocess.check_output(['docker','run','--rm','--network','none','--read-only','--mount','type=volume,src='+launch['volume']+',dst=/state,readonly','--entrypoint','node',launch['image'],'-e',historycode],text=True)
        histories.append({'launch':str(launchfile.relative_to(a.output)),'events':[json.loads(s) for s in raw.splitlines()]})
    save(a.output/'native-history-before-removal.json',histories)
    for volume in volumes:
        metadata=json.loads(subprocess.check_output(['docker','volume','inspect',volume],text=True))[0]
        assert metadata.get('Labels',{}).get('chio.task')=='required-agent-integrations'
        assert not subprocess.check_output(['docker','ps','-a','--filter','volume='+volume,'--format','{{.ID}}'],text=True).strip()
    save(a.output/'removal-plan.json',{'volumes':volumes,'consumer':str(consumer),'configurationSha256':digest,'preserve':['owner databases','owner resource and audit volumes','original config and journal','shared images','all other profiles and consumers']})
    for volume in volumes:
        run('remove-volume-'+str(len(removed)),['docker','volume','rm',volume],30);removed.append(volume)
    run('remove-adapter',['npm','uninstall','--prefix',consumer,'--ignore-scripts','--offline','--no-audit','--no-fund','@chio/openclaw-kernel'],90)
    assert not pkg.exists()
else:
    run('remove-adapter',[uv,'pip','uninstall','--python',py,'chio-hermes'])
    run('verify-removed',[py,'-I','-c',"import importlib.util,pathlib,sys;assert importlib.util.find_spec('chio_hermes') is None;assert not (pathlib.Path(sys.executable).parent/'chio-hermes-restricted').exists();print('isolated adapter and entrypoint absent')"])
assert all(sha(Path(path))==digest for path,digest in retained.items()) and observe()==before
save(a.output/'after-removal.json',observe());save(a.output/'identity.json',identity)
save(a.output/'summary.json',{'passed':True,'archivedCandidateUpgrade':True,'liveNativeCurrentAfterUpgrade':True,'sameOriginalAuthorityFencedAfterReplacement':True,'signedOriginalRecoveryWithoutWriteRedispatch':True,'revokedBeforeRemoval':True,'removedGuestVolumes':removed,'removedOnlySelectedAdapter':True,'operatorConfigJournalResourcesPreserved':True,'normalProfileModified':False,'publicationClaim':False})
print(json.dumps({'host':a.host,'lifecyclePassed':True}),flush=True)
