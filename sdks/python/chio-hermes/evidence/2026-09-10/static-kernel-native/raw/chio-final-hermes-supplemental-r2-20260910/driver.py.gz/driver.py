import subprocess,json,time,hashlib,os,signal
from pathlib import Path
root=Path('/tmp/chio-final-hermes-supplemental-r2-20260910');root.mkdir(mode=0o700)
scriptroot=Path('/Users/connor/Medica/backbay/standalone/arc/.worktrees/hermes-required-integration-20260909/sdks/python/chio-hermes/scripts')
common=['--operator-state','/Users/connor/.local/share/chio-required-operators/final-hermes-native-20260910/native','--bridge','/tmp/chio-kernel-rc-consumers-20260910/hermes/bridge/node_modules/@chio/bridge','--host-python','/tmp/chio-hermes-public-final-install-20260910/qualified-venv/bin/python','--host-root','/tmp/chio-hermes-public-final-install-20260910/source','--model-auth-file','/Users/connor/.local/share/chio-required-operators/native-subscription-auth-20260909/codex/profile/auth.json']
(root/'driver.py').write_bytes(Path(__file__).read_bytes());rows=[]
for case,script in [('native-parallel','probe_native_parallel.py'),('disabled-native-tools','probe_disabled_native_tools.py')]:
 cmd=['/tmp/chio-kernel-rc-consumers-20260910/hermes/consumer/bin/python',str(scriptroot/script),*common,'--output',str(root/case)]
 digest=hashlib.sha256((scriptroot/script).read_bytes()).hexdigest();(root/script).write_bytes((scriptroot/script).read_bytes());started=time.monotonic();timed=False;cleanup=[]
 with (root/(case+'.stdout')).open('w') as out,(root/(case+'.stderr')).open('w') as err:
  child=subprocess.Popen(cmd,stdout=out,stderr=err,start_new_session=True)
  try:code=child.wait(timeout=240)
  except subprocess.TimeoutExpired:
   timed=True
   for sig,grace in [(signal.SIGTERM,15),(signal.SIGKILL,10)]:
    try:os.killpg(child.pid,sig)
    except ProcessLookupError:pass
    except OSError as e:cleanup.append(type(e).__name__)
    try:child.wait(timeout=grace);break
    except subprocess.TimeoutExpired:cleanup.append('wait timeout')
   code=child.poll()
 rows.append({'case':case,'command':cmd,'exitCode':code,'timedOut':timed,'processGroup':child.pid,'cleanupErrors':cleanup,'elapsedSeconds':time.monotonic()-started,'harnessSha256':digest,'harnessUnchanged':hashlib.sha256((scriptroot/script).read_bytes()).hexdigest()==digest,'liveInference':False});(root/'runs.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows[-1]),flush=True)
 if timed:raise RuntimeError('same-owner work stopped after timeout; preserve original state')
