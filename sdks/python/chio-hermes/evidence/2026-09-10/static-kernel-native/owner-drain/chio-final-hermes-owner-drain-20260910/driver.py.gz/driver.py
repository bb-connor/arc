from pathlib import Path
import datetime,hashlib,json,subprocess,time
owners=json.loads(Path('/tmp/chio-final-owned-still-running-20260910.json').read_text())
helper=Path('/Users/connor/Medica/backbay/standalone/arc/.worktrees/required-agent-integrations-20260909/integrations/required-agents/serve-filesystem.py')
outputs={h:Path('/tmp/chio-final-'+h+'-owner-drain-20260910') for h in ['hermes','openclaw']};records={h:[] for h in outputs}
for p in outputs.values():p.mkdir(mode=0o700);(p/'driver.py').write_bytes(Path(__file__).read_bytes())
for row in owners:
 owner=Path(row['owner']);host='hermes' if owner.parent.name.startswith('final-hermes-') else 'openclaw';out=outputs[host]
 assert owner.parent.name.startswith('final-'+host+'-');assert int((owner/'kernel.pid').read_text())==row['pid']
 op=json.loads((owner/'operator.json').read_text());assert (op['port'],op['volume'])==(row['port'],row['volume']);assert op['kernelSha256']=='c03a8a711dbbd15da2c59655d9ab6d8f0068a20187363db7a78f4b5422ded93e'
 cmdline=subprocess.check_output(['ps','-p',str(row['pid']),'-o','command='],text=True);assert str(owner/'sessions.sqlite') in cmdline and op['command'][0] in cmdline
 files={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in owner.rglob('*.json') if p.name in ['operator.json','gateway.json','prepare.json'] or 'journal' in p.parts}
 dbnames=[str(p.relative_to(owner)) for p in owner.glob('*.sqlite*') if p.is_file() and not str(p).endswith(('-wal','-shm'))]
 cmd=['python3',str(helper),'stop','--state-dir',str(owner)];start=time.monotonic();r=subprocess.run(cmd,capture_output=True,timeout=40)
 label=str(row['port']);(out/(label+'.stdout')).write_bytes(r.stdout);(out/(label+'.stderr')).write_bytes(r.stderr)
 assert r.returncode==0
 assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==s for p,s in files.items())
 assert all((owner/n).exists() for n in dbnames)
 for volume in [op['volume'],op['auditVolume']]:subprocess.run(['docker','volume','inspect',volume],stdout=subprocess.DEVNULL,check=True,timeout=20)
 still=subprocess.run(['ps','-p',str(row['pid']),'-o','command='],capture_output=True,text=True);assert str(owner/'sessions.sqlite') not in still.stdout
 rec={'atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),**row,'command':cmd,'exitCode':r.returncode,'elapsedSeconds':time.monotonic()-start,'helperSha256':hashlib.sha256(helper.read_bytes()).hexdigest(),'kernelSha256':op['kernelSha256'],'auditVolume':op['auditVolume'],'preservedConfigJournalFiles':files,'retainedDatabaseFiles':dbnames,'configAndJournalUnchanged':True,'originalKernelNoLongerRunning':True,'databaseFilesAndVolumesPreserved':True,'authorityReissuedOrRecovered':False}
 records[host].append(rec);(out/'runs.json').write_text(json.dumps(records[host],indent=2)+'\n');print({'host':host,'stoppedPort':row['port'],'preservedUnknownState':True},flush=True)
for host,out in outputs.items():(out/'summary.json').write_text(json.dumps({'stoppedOwners':len(records[host]),'allIdentityMatched':True,'databasesCredentialsJournalsResourcesAndAuditPreserved':True,'unknownOutcomesRecovered':False,'publicationClaim':False},indent=2)+'\n')
