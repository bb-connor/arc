#!/usr/bin/env python3
"""Repeat existing real-host cases against one immutable kernel candidate.

Each host gets a disposable owner and cold consumer. Existing acceptance drivers
perform native-call and independent-effect assertions. This driver never clears
an operation journal, manufactures provider output, or claims complete acceptance.
"""
import argparse
import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import socket
import subprocess
import time

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--binary', type=Path, required=True)
p.add_argument('--source', required=True)
p.add_argument('--sha256', required=True)
p.add_argument('--output', type=Path, required=True)
p.add_argument('--owner-root', type=Path, required=True)
p.add_argument('--hosts', nargs='+', default=['claude','codex','pi','hermes','openclaw'])
p.add_argument('--stage', choices=['useful','matrix'], default='matrix')
p.add_argument('--base-port', type=int, default=59101)
p.add_argument('--volume-prefix', default='chio-required-rc-20260910')
a = p.parse_args()
ROOT = Path('/Users/connor/Medica/backbay/standalone/arc/.worktrees/required-agent-integrations-20260909')
# Use explicit owning repositories only for test drivers, never runtime imports.
STANDALONE = Path('/Users/connor/Medica/backbay/standalone')
CONSUMERS = Path('/tmp/chio-kernel-rc-consumers-20260910')
BUNDLE = Path('/Users/connor/.local/share/chio-required-candidates/20260909')
AUTH = Path('/Users/connor/.local/share/chio-required-operators/native-subscription-auth-20260909/codex/profile/auth.json')
IMAGE = 'sha256:188cb84d5d0bb4063d4ce5a3b9c3832445a5acda5604911cda80a9136d1850a0'
OC_IMAGE = 'sha256:7f925d68ced724f4a6314ab76dc117e9000515ba62149ee971a11c510be6637f'
REPOS = {name: STANDALONE / folder / '.worktrees/required-agent-integrations-20260909' for name,folder in [('claude','chio-claude-code-plugin'),('codex','chio-codex-plugin'),('openclaw','chio-open-claw-plugin')]}
REPOS['pi'] = STANDALONE / 'chio-pi-plugin'
NAMES = {'claude':'claude-code-plugin','codex':'codex-plugin','pi':'pi-plugin','openclaw':'openclaw-kernel'}
PACKAGES = {name: CONSUMERS/name/'consumer/node_modules/@chio'/package for name,package in NAMES.items()}
PACKAGES['hermes'] = CONSUMERS/'hermes/bridge/node_modules/@chio/bridge'
HERMES = ['--launcher-python',str(CONSUMERS/'hermes/consumer/bin/python'),'--host-python','/tmp/chio-hermes-20260909/clean-host-venv/bin/python','--host-root','/tmp/chio-hermes-20260909/public-upstream-source']
SUITES = ['forbidden-read','forbidden-write','forbidden-edit','secret-dry-run','secret-list','secret-path-alias','forbidden-write-alias','approvals','revocation','in-flight-capability','in-flight-credential','kernel-killed','kernel-malformed','kernel-timeout','kernel-absent','expired-credential','wrong-principal','wrong-session','wrong-resource','scope-escalation','evidence-foreign-receipt','evidence-wrong-signer','evidence-request-id','concurrent-owners']

def save(path,value):
    path.write_text(json.dumps(value,indent=2)+'\n')
    path.chmod(0o600)

assert hashlib.sha256(a.binary.read_bytes()).hexdigest() == a.sha256
assert len(a.hosts) == len(set(a.hosts)) and all(h in PACKAGES for h in a.hosts)
assert 1024 <= a.base_port <= 65530
assert a.volume_prefix.startswith('chio-required-') and all(c.isalnum() or c=='-' for c in a.volume_prefix)
a.output.mkdir(mode=0o700,exist_ok=False)
a.owner_root.mkdir(mode=0o700,exist_ok=False)
(a.output/'driver.py').write_bytes(Path(__file__).read_bytes())
test_sources={}
for name,repo in {'kernel':ROOT,**REPOS}.items():
    test_sources[name]={'directory':str(repo),'commit':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'dirty':subprocess.check_output(['git','-C',str(repo),'status','--porcelain'],text=True).splitlines()}
save(a.output/'identity.json',{'kernelSource':a.source,'kernelSha256':a.sha256,'binary':str(a.binary),'kernelVersion':subprocess.check_output([str(a.binary),'--version'],text=True).strip(),'resourceImage':IMAGE,'hostImage':OC_IMAGE,'testSources':test_sources,'hosts':a.hosts,'stage':a.stage,'remainingMandatoryHost':{'cursor':'blocked on supported server-enforced action restriction; not a skipped pass'},'claim':'bounded new-candidate real-host observations only; public release and remaining gates stay open'})
(a.output/'installations.json').write_bytes((CONSUMERS/'installations.json').read_bytes())
(a.output/'hermes-installation.json').write_bytes((CONSUMERS/'hermes/archive-to-install.json').read_bytes())

def host(name):
    folder=a.output/name;folder.mkdir(mode=0o700)
    owner=a.owner_root/name
    port=a.base_port+['claude','codex','pi','hermes','openclaw'].index(name)
    volume=a.volume_prefix+'-'+name
    with socket.socket() as sock: sock.bind(('127.0.0.1',port))
    records=[]
    def run(label,command,limit=1200):
        started=time.monotonic()
        timed_out=False
        with (folder/(label+'.stdout')).open('w') as stdout,(folder/(label+'.stderr')).open('w') as stderr:
            try:
                result=subprocess.run(command,stdout=stdout,stderr=stderr,timeout=limit)
                code=result.returncode
            except subprocess.TimeoutExpired:
                code=None;timed_out=True
        record={'case':label,'command':command,'exitCode':code,'timedOut':timed_out,'elapsedSeconds':time.monotonic()-started}
        if len(command)>1 and Path(command[1]).is_file():record['driverSha256']=hashlib.sha256(Path(command[1]).read_bytes()).hexdigest()
        records.append(record);save(folder/'runs.json',records)
        print(json.dumps({'host':name,'case':label,'exitCode':code,'timedOut':timed_out}),flush=True)
        if code!=0:raise RuntimeError(label+' failed; original state retained')
    try:
        launch=ROOT/'integrations/required-agents/serve-filesystem.py'
        run('start-owner',['python3',str(launch),'start','--state-dir',str(owner),'--kernel',str(a.binary),'--kernel-sha256',a.sha256,'--image',IMAGE,'--volume',volume,'--port',str(port)])
        deadline=time.monotonic()+45
        while not (owner/'sessions.sqlite.admission.kernel.pub').exists():
            if time.monotonic()>deadline:raise TimeoutError('owner signer not ready')
            time.sleep(.1)
        run('prepare-resource',['python3',str(ROOT/'integrations/required-agents/prepare-session.py'),'--operator-state',str(owner),'--bridge',str(PACKAGES[name] if name=='hermes' else PACKAGES[name]/'node_modules/@chio/bridge')])
        run('seed-approved-fixture',['docker','run','--rm','--network','none','--read-only','--user','1000:1000','--cap-drop','ALL','--mount','type=volume,src='+volume+',dst=/workspace','--entrypoint','node',IMAGE,'-e',"require('fs').writeFileSync('/workspace/approved.txt','independent approved fixture\\n')"])
        common=['--operator-state',str(owner),'--package-dir',str(PACKAGES[name])]
        out=['--output',str(folder/'useful')]
        if name=='claude':
            command=['python3',str(REPOS[name]/'scripts/acceptance/native-subscription.py'),*common,*out,'--cases','useful','--artifact-sha256','0dd0d906fc34b3ac7d09e3b7f6cdee9f13f511731b25ec761feca7172c9b1158']
        elif name in ['codex','pi']:
            command=['python3',str(REPOS[name]/'scripts/qualify-http-host.py'),*common,*out,'--cases','useful']
            command+=['--provider','openai-codex','--model','gpt-5.5','--codex-auth',str(AUTH)] if name=='pi' else ['--model-auth-file',str(AUTH)]
        elif name=='hermes':
            command=['python3',str(ROOT/'sdks/python/chio-hermes/scripts/qualify_http_host.py'),'--operator-state',str(owner),'--bridge',str(PACKAGES[name]),*HERMES,*out,'--model','gpt-5.5','--model-auth','codex-subscription','--codex-auth-file',str(AUTH),'--cases','useful']
        else:
            command=['python3',str(REPOS[name]/'native/test/qualify-http-host.py'),*common,*out,'--cases','useful','--image',OC_IMAGE,'--model-auth-file',str(AUTH),'--require-watchdog-cleanup']
        run('useful',command)
        shared=['python3',str(ROOT/'scripts/acceptance/host-approvals.py'),'--host',name,*common]
        if name!='claude':shared+=['--model-auth-file',str(AUTH)]
        if name=='hermes':shared+=HERMES
        if name=='openclaw':shared+=['--image',OC_IMAGE]
        if a.stage=='matrix':
            for suite in SUITES:
                output=folder/suite
                run(suite,shared+['--suite',suite,'--output',str(output)])
                if suite in ['kernel-killed','kernel-malformed','kernel-timeout'] or suite.startswith('evidence-'):
                    config=json.loads((output/'identity.json').read_text())['privateConfiguration']
                    run(suite+'-fence',shared+['--suite','resume-fence','--existing-config',config,'--output',str(folder/(suite+'-fence'))])
                    if suite.startswith('evidence-'):
                        run(suite+'-recovery',shared+['--suite','recover-owner-result','--existing-config',config,'--operator-bridge',str(BUNDLE/'install/operator-bridge/node_modules/@chio/bridge'),'--output',str(folder/(suite+'-recovery'))])
        save(folder/'summary.json',{'passed':True,'cases':len(records),'stage':a.stage,'skips':0,'remaining':'other native lifecycle, budget, expiry, confinement, storage and release cases remain separately required for this binary'})
        return {'host':name,'passed':True,'cases':len(records)}
    except Exception as error:
        save(folder/'failure.json',{'type':type(error).__name__,'message':str(error),'originalStateRetained':True})
        print(json.dumps({'host':name,'failed':True,'type':type(error).__name__}),flush=True)
        return {'host':name,'passed':False,'casesCompleted':len(records)}
with concurrent.futures.ThreadPoolExecutor(max_workers=5) as pool:
    result=list(pool.map(host,a.hosts))
save(a.output/'results.json',result)
raise SystemExit(0 if all(r['passed'] for r in result) else 1)
