from pathlib import Path
import hashlib,json,sqlite3,subprocess,time
state=Path('/Users/connor/.local/share/chio-required-operators/claude-live-expiry-20260910')
out=Path('/tmp/chio-claude-live-expiry-20260910/owner-stop')
out.mkdir(exist_ok=False)
helper=Path('/Users/connor/Medica/backbay/standalone/arc/.worktrees/live-host-capability-expiry-20260910/integrations/required-agents/serve-filesystem.py')
op=json.loads((state/'operator.json').read_text())
assert op['stateDir']==str(state) and op['port']==59227 and op['volume']=='chio-required-claude-live-expiry-20260910'
assert op['kernelSha256']=='c03a8a711dbbd15da2c59655d9ab6d8f0068a20187363db7a78f4b5422ded93e'
def digest_files():
 return {str(p.relative_to(state)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(state.rglob('*')) if p.is_file() and not p.is_symlink() and p.suffix in ['.json','.jsonl','.yaml','.yml','.pub','.key']}
def logical_rows():
 result={}
 for p in sorted(state.rglob('*.sqlite')):
  c=sqlite3.connect(f'file:{p}?mode=ro',uri=True)
  try:
   result[str(p.relative_to(state))]={}
   for (name,) in c.execute("select name from sqlite_master where type='table' order by name"):
    quoted='"'+name.replace('"','""')+'"'
    rows=sorted(repr(row) for row in c.execute('select * from '+quoted))
    result[str(p.relative_to(state))][name]={'rows':len(rows),'sha256':hashlib.sha256('\n'.join(rows).encode()).hexdigest()}
  finally:c.close()
 return result
before=digest_files();before_rows=logical_rows()
command=['python3',str(helper),'stop','--state-dir',str(state)]
t0=time.monotonic();r=subprocess.run(command,capture_output=True,text=True,timeout=20)
(out/'stop.stdout').write_text(r.stdout);(out/'stop.stderr').write_text(r.stderr)
after=digest_files();after_rows=logical_rows()
containers=subprocess.run(['docker','ps','-aq','--filter','label=chio.owner='+op['volume']],capture_output=True,text=True,timeout=20)
volumes={}
for v in [op['volume'],op['auditVolume']]:
 q=subprocess.run(['docker','volume','inspect',v,'--format','{{.Name}}'],capture_output=True,text=True,timeout=20)
 volumes[v]={'exitCode':q.returncode,'name':q.stdout.strip()}
code="const f=require('fs');const files={};for(const n of f.readdirSync('/observe'))if(f.lstatSync('/observe/'+n).isFile())files[n]=f.readFileSync('/observe/'+n,'utf8');const p='/audit/dispatch.jsonl';console.log(JSON.stringify({files,dispatch:f.existsSync(p)?f.readFileSync(p,'utf8').split('\\n').filter(Boolean).map(JSON.parse):[]}))"
obs=subprocess.run(['docker','run','--rm','--network','none','--read-only','--mount',f"type=volume,src={op['volume']},dst=/observe,readonly",'--mount',f"type=volume,src={op['auditVolume']},dst=/audit,readonly",'--entrypoint','node',op['image'],'-e',code],capture_output=True,text=True,timeout=30)
(out/'after-stop-observation.json').write_text(obs.stdout);(out/'observation.stderr').write_text(obs.stderr)
previous=json.loads((out.parent/'case/in-flight-expiry/after.json').read_text())
observation_unchanged=obs.returncode==0 and json.loads(obs.stdout)==previous
record={'command':command,'helperSha256':hashlib.sha256(helper.read_bytes()).hexdigest(),'exitCode':r.returncode,'elapsedSeconds':time.monotonic()-t0,'stateDir':str(state),'port':op['port'],'kernelSha256':op['kernelSha256'],'protectedBefore':before,'protectedAfter':after,'protectedFilesUnchanged':before==after,'sqliteLogicalRowsBefore':before_rows,'sqliteLogicalRowsAfter':after_rows,'sqliteLogicalRowsUnchanged':before_rows==after_rows,'volumes':volumes,'labeledContainerExitCode':containers.returncode,'labeledContainersRemaining':containers.stdout.split(),'resourceAndDispatchObservationUnchanged':observation_unchanged,'recoveryOrAcknowledgementPerformed':False}
record['passed']=r.returncode==0 and before==after and before_rows==after_rows and observation_unchanged and containers.returncode==0 and not containers.stdout.strip() and all(v['exitCode']==0 and v['name']==k for k,v in volumes.items())
(out/'record.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k not in ['protectedBefore','protectedAfter','sqliteLogicalRowsBefore','sqliteLogicalRowsAfter']}))
raise SystemExit(0 if record['passed'] else 1)
