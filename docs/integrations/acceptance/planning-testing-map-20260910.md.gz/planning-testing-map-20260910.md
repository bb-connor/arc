# Testing Patterns

**Analysis Date:** 2026-09-08
**Source scope:** `/Users/connor/Medica/backbay/standalone/arc/.worktrees/chio-strategy-design-20260908`, commit `d99e03027c57dc9c0929a5bca553e745c6286d99`.
**Method:** Source inspection and static configuration parsing only. No tests, builds, benchmark runs, hosted checks, live-model calls, or formal tools were executed. Retained results below are documentary evidence from the checked-in execution ledger, not fresh verification of archives or hosted state.
**Confidence:** High for inspected code paths and explicit contracts; moderate for implications drawn from their composition; independent adoption and current release acceptance are unestablished by this map.

## Test Framework

**Runner:**
- Rust's Cargo/libtest with `#[test]` and Tokio `#[tokio::test]`; toolchain 1.94.1 is pinned in `rust-toolchain.toml`. Workspace dependency declarations include Proptest 1.10, Criterion 0.5, Loom 0.7, Wiremock 0.6, Tempfile 3, and Testcontainers 0.27.3 in `Cargo.toml`. These are manifest requirements, not a fresh installed-tool inventory.
- Python process tests use `unittest` assertions and mocks and are run by pytest. `sdks/python/chio-process/pyproject.toml` specifies `pytest>=8,<9`; `sdks/python/chio-process/tests/test_invocation.py` contains representative tests.
- JavaScript process and AI SDK packages use Node's built-in test runner. Node >=22 and the exact package test commands are in `sdks/typescript/packages/process/package.json` and `sdks/typescript/packages/ai-sdk-process/package.json`.
- Shell/Python assurance self-tests live in `scripts/tests/`; `.github/workflows/ci.yml` and `scripts/ci-workspace.sh` select required invocations.

**Assertion Library:**
- Rust native assertions, Proptest assertions, and `chio_test_support::{prelude,ctx}` extensions from `crates/tooling/chio-test-support/src/lib.rs`.
- Python `unittest.TestCase` and `unittest.mock`, with examples in `sdks/python/chio-process/tests/test_invocation.py`.
- JavaScript `node:assert/strict`, with examples in `sdks/typescript/packages/ai-sdk-process/test/process.test.mjs`.

**Run Commands:**

```bash
# Documented workspace checks, not executed for this map.
cargo test --workspace
cargo clippy --workspace -- -D warnings
cargo fmt --all -- --check

# Focused process semantics, including opt-in worker/mailbox code.
cargo test --locked -p chio-process --features worker-server,mailboxes

# Public native host and signed-response boundaries.
cargo test --locked -p chio-cli --test process_host
cargo test --locked -p chio-cli --test receipt_verify --test process_response_verify
cargo test --locked -p chio-cli --test process_state

# Installed dependency environments are prerequisites for these package commands.
python -m pytest -q sdks/python/chio-process/tests
npm test --prefix sdks/typescript --workspace @chio-protocol/process
npm run build --prefix sdks/typescript --workspace @chio-protocol/ai-sdk-process
npm test --prefix sdks/typescript --workspace @chio-protocol/ai-sdk-process

# Full orchestrators are expensive and have additional prerequisites.
./scripts/ci-workspace.sh
./scripts/qualify-release.sh
./scripts/run-coverage.sh
```

Sources: `AGENTS.md`, `crates/kernel/chio-process/Cargo.toml`, `.github/workflows/process-workers.yml`, `scripts/ci-workspace.sh`, `scripts/qualify-release.sh`, and the package manifests above. No dedicated watch-mode contract was detected in these inspected surfaces.

`scripts/ci-workspace.sh` differs from a literal workspace-all-targets invocation: it runs Clippy for `--lib --bins --examples`, tests the workspace excluding `chio-wasm-guards`, and then tests that crate's library separately. `AGENTS.md` describes the WASM target and optional Python/Go guard artifact prerequisites; missing optional artifacts can mean skipped coverage.

## Test File Organization

**Location:**
- Put private Rust unit tests next to implementation or in included `src/**/tests` modules. Examples: `crates/kernel/chio-kernel/src/kernel/tests.rs` and `crates/kernel/chio-kernel/src/kernel/tests/drop_guard_proptest.rs`.
- Put public crate-boundary and real process tests in the owning crate's `tests/` directory. `crates/kernel/chio-process/tests/` separates crash recovery, worker protocol, process state, blobs, child submission, and mailboxes.
- Put CLI-level integration targets in `crates/products/chio-cli/tests/`; their Python worker/failure-injection components live under `crates/products/chio-cli/tests/process_host/`.
- Put deployment/backend qualifications with the relevant executable fixture. Examples: `examples/shared-resource-swarm/qualify_native.py`, `examples/shared-resource-swarm/qualify_ownership.py`, and `examples/postgres-job-swarm/`.

**Naming:**
- Use behavior names that specify both trigger and forbidden/required result, as in `completed_effect_survives_abrupt_exit_and_a_fresh_os_process` in `crates/kernel/chio-process/tests/crash_recovery.rs`.
- A directory or test name is not an evidence classification: `tests/e2e/tests/full_flow.rs` explicitly describes an in-process pipeline with no I/O.

**Structure:**

```text
crates/kernel/chio-process/
  src/                     Public API plus private store/registry implementation
  tests/support/mod.rs     Durable kernel/authority fixture construction
  tests/crash_recovery.rs   Parent/child OS process crash and reopen tests
  tests/worker_protocol.rs  Native worker protocol boundary
  tests/mailboxes.rs        Durable mailbox behavior
crates/products/chio-cli/tests/
  process_host.rs           Rust assertions around the native CLI harness
  process_host/             Python/JavaScript worker and interruption fixtures
scripts/tests/             Assurance-checker regression and mutation self-tests
```

## Test Structure

**Suite Organization:**

Actual short test from `crates/kernel/chio-process/tests/crash_recovery.rs`:

```rust
#[test]
fn unknown_effect_is_not_redispatched_after_process_death() -> Result {
    let dir = tempfile::tempdir()?;
    assert_eq!(phase(dir.path(), "crash-in-tool")?.code(), Some(73));
    assert!(phase(dir.path(), "recover-unknown")?.success());
    assert_eq!(
        std::fs::read_to_string(dir.path().join("external.log"))?,
        "external-effect\n"
    );
    Ok(())
}
```

**Patterns:**
- Setup creates an isolated directory, durable authority/receipt/process stores, bounded signed capabilities, and an injectable tool server. Reuse the construction pattern in `crates/kernel/chio-process/tests/support/mod.rs`.
- Real crash tests spawn the current test binary with an exact helper name and phase environment, write and synchronize the external effect, then call `std::process::exit`. Reopening occurs in a fresh OS process, not just a replacement Rust object. Source: `crates/kernel/chio-process/tests/crash_recovery.rs`.
- Assert external state and dispatch counts as well as receipts. `crates/products/chio-cli/tests/process_host.rs` checks the original receipt signature, expected kernel key, and one publication after recovery.
- Use `TempDir`/`TemporaryDirectory` and explicit cleanup registration. Python setup demonstrates `addCleanup(directory.cleanup)` in `sdks/python/chio-process/tests/test_invocation.py`; process/container qualifications separately verify cleanup in `examples/mini-swe-recovery/compare_upstream.py`.
- Enumerate genuinely small state spaces exhaustively. `crates/kernel/chio-kernel/src/kernel/tests/drop_guard_proptest.rs` covers all eight monetary/dispatch/lease combinations explicitly while using Proptest's error/assertion machinery.

## Mocking

**Framework:** Manual Rust trait implementations, `unittest.mock`, and AI SDK mock models. Sources: `crates/kernel/chio-process/tests/crash_recovery.rs`, `sdks/python/chio-process/tests/test_invocation.py`, and `sdks/typescript/packages/ai-sdk-process/test/process.test.mjs`.

**Patterns:**

Actual tool classification excerpt from `crates/kernel/chio-process/tests/crash_recovery.rs`:

```rust
fn tool_is_read_only(&self, tool: &str) -> bool {
    tool == "read"
}
```

That test server performs real synchronized file writes, then optionally terminates the OS process. It combines a controlled tool implementation with actual process/storage behavior; label both dimensions.

- `sdks/python/chio-process/tests/test_invocation.py` patches the process client and verifier subprocess to assert request freezing, refusal before dispatch, unresolved transport behavior, and original artifact retention. Those unit tests do not run the native verifier themselves.
- `sdks/typescript/packages/ai-sdk-process/test/process.test.mjs` uses `MockLanguageModelV4` to exercise `generateText`, `streamText`, concurrency, and denial propagation. The framework is real; model decisions are controlled.
- `sdks/typescript/packages/ai-sdk-process/qualification/qualify.py` reports `live_model_called: false` explicitly. Its native host/package checks remain useful without establishing live model quality.

**What to Mock:**
- External model decisions when checking framework integration deterministically; use the pattern above and preserve the explicit model-source label.
- Backend failures and bad verifier exits for unit-level error handling, as in `sdks/python/chio-process/tests/test_invocation.py`.
- Small mathematical state spaces in bounded property/model tests, with the scope retained in their manifests, such as `scripts/run-dst.sh`.

**What NOT to Mock:**
- Do not replace process death, durable reopen, or the OS isolation boundary with an in-memory exception when claiming those properties. Reuse `crates/kernel/chio-process/tests/crash_recovery.rs` and `crates/products/chio-cli/tests/process_host/container_runner.py`.
- Do not make the expected Chio result itself the business correctness oracle. Owned-resource qualifications inspect resource state and delivery counts in `examples/shared-resource-swarm/qualify_ownership.py`; the PostgreSQL workflow uses a real gateway/backend in `.github/workflows/postgres-job-swarm.yml`.
- Do not replace cryptographic verification with an SDK `verdict` field when accepting recorded evidence. `scripts/qualify-process-packages.py` invokes the copied native CLI before inspecting signed receipt fields.

## Fixtures and Factories

**Test Data:**
- `crates/kernel/chio-process/tests/support/mod.rs` supplies deterministic test-only signing identities, root/child capability construction, private directories, and a durable SQLite-backed kernel. These are fixtures, not production provisioning defaults.
- `crates/tooling/chio-test-support/src/lib.rs` provides shared assertions and loopback probes. Import one assertion family and add it as a dev dependency.
- `tests/bindings/vectors/` holds serialization/security vector corpora; `tests/conformance/scenarios/` holds conformance scenarios consumed by release qualification in `scripts/qualify-release.sh`.

**Location:**
- Keep live measurement summaries and named retained archives separate from fixture inputs. `docs/evidence/shared-resource-usage-2026-09-08.json` is referenced as an extraction of recorded model reports by `docs/architecture/SWARM_EXECUTION_CONTRACT.md`.
- `crates/kernel/chio-runtime-harness/README.md` describes proof-fixture regeneration through a real disposable kernel, SQLite/file I/O, and a stub tool server. Its built-in scenario test expects a semantic parity mismatch. This is a proof-fixture consistency facility, not evidence that an independently operated application succeeds.

## Coverage

**Requirements:**
- No global coverage percentage is established by this map. `scripts/run-coverage.sh` uses optional `COVERAGE_FAIL_UNDER`; without that setting it does not impose a numerical floor.
- The same script excludes several packages, including `chio-e2e`, `chio-control-plane`, `chio-conformance`, and `chio-wasm-guards`. Its percentage must be reported with exclusions and run configuration.
- `scripts/check-proptest-coverage.sh` checks presence of eighteen named invariant functions by text matching. This protects names/inventory; it neither executes those functions nor proves assertion sensitivity.
- `scripts/run-exact-cargo-test-inventory.sh` lists and executes a specified target, then `scripts/check-exact-cargo-test-inventory.py` compares exact names or a committed count/digest and actual pass records. Reuse this instead of inventing another pass-count parser.
- `scripts/tests/check-exact-cargo-test-inventory.test.py` mutation-tests the inventory verifier with malformed/missing/interleaved output. This establishes checker sensitivity for its controls, separately from application behavior.
- Static parsing finds fifteen `releases.toml` gate entries, all with `posture = "advisory"`. This does not make the direct invocations in `scripts/ci-workspace.sh` optional. Distinguish fleet lane posture, directly required CI commands, and mutation activation state.

**View Coverage:**

```bash
./scripts/run-coverage.sh
# Inspect coverage/summary.txt, coverage/html/index.html, and coverage/lcov.info.
```

The script generates the reports and validates their existence; they were not generated for this mapping pass. Source: `scripts/run-coverage.sh`.

## Test Types

**Unit Tests:**
- Type validation, capability algebra, state transitions, operation identity, verifier error propagation, and controlled framework interactions. Examples: `crates/kernel/chio-process/src/types.rs`, `crates/kernel/chio-kernel/src/kernel/tests/drop_guard_proptest.rs`, and `sdks/typescript/packages/ai-sdk-process/test/process.test.mjs`.

**Integration Tests:**
- Durable kernel/authority/process composition and real abrupt process death: `crates/kernel/chio-process/tests/crash_recovery.rs`.
- Public native CLI host, worker supervision, mailboxes, adaptive children, cancellation, and host recovery: `crates/products/chio-cli/tests/process_host.rs` and its `process_host/` helpers.
- Native response/request/context verification: `crates/products/chio-cli/tests/process_response_verify.rs` and `sdks/python/chio-process/tests/test_invocation.py`.
- Real SQLite ownership and stale-worker rejection: `examples/shared-resource-swarm/qualify_native.py` and `examples/shared-resource-swarm/qualify_ownership.py`.
- Real PostgreSQL worker API, ownership fencing, TLS fixture, and interrupted claim paths: `.github/workflows/postgres-job-swarm.yml` and `examples/postgres-job-swarm/`.

**E2E Tests:**
- `tests/e2e/tests/full_flow.rs` composes kernel, guards, capability validation, and receipt signing in-process with no I/O. It cannot establish OS supervision, network isolation, or crash recovery despite the directory name.
- `scripts/qualify-process-packages.py` creates an offline starter, runs installed Python/JavaScript packages against a copied native host, checks package import locations, exercises recovery, checks operator status/logs, and verifies original receipts. This is a reusable installation/system qualification.
- `.github/workflows/process-workers.yml` selects Linux native host, container, installed framework, shared-resource, and opt-in optimized comparison jobs. Workflow source establishes intended execution; only a completed run bound to the exact candidate establishes a result.

**Evidence classes and limits:**

| Class | Existing source/evidence | Establishes when executed successfully | Does not establish |
|---|---|---|---|
| Lexical/structural gate | `scripts/check-proptest-coverage.sh`, `scripts/check-workspace-layering.sh` | Required patterns or inventory remain present | Runtime correctness, coverage, or semantic dependency closure |
| Checker mutation/self-test | `scripts/tests/check-exact-cargo-test-inventory.test.py` | The checker rejects its named corrupt controls | Production fault sensitivity outside those controls |
| Bounded pure/model proof | `formal/proof-manifest.toml`, `formal/assumptions.toml`, `scripts/run-dst.sh` | Stated property over stated model/domain/bounds | Arbitrary distributed runtime behavior or external effects |
| Controlled framework qualification | `sdks/typescript/packages/ai-sdk-process/qualification/qualify.py` | Installed SDK/native host interoperability for controlled model decisions | Live-model task quality or model-cost advantage |
| Real OS/process/backend integration | `crates/kernel/chio-process/tests/crash_recovery.rs`, `.github/workflows/postgres-job-swarm.yml` | Named crash/restart/resource behavior in the exercised environment | Every deployment's isolation/storage/network guarantees |
| Recorded live-model experiment | `docs/evidence/shared-resource-usage-2026-09-08.json`, `docs/architecture/SWARM_EXECUTION_CONTRACT.md` | Outcomes of the retained cohort/configuration | General advantage, causal cost savings, independent adoption |
| Immutable hosted-source evidence | `scripts/qualify-release.sh`, `scripts/check-committed-linux-evidence.py` | Results/provenance under their source and artifact validation rules | Qualification of a changed candidate or adoption value |
| Release acceptance | `scripts/qualify-release.sh`, `.github/workflows/release-qualification.yml`, `releases.toml` | Completion of the declared applicable acceptance gates for an exact candidate | A consumer's decision to operate and retain Chio |
| Independent adoption | Missing in `docs/architecture/SWARM_EXECUTION_CONTRACT.md` | No independent adopter acceptance is established in the inspected ledger | It cannot be inferred from fixtures, packages, code counts, or draft PRs |

**Formal boundary:**
- `formal/assumptions.toml` explicitly assumes cryptographic primitives, scoped canonicalization behavior, operator-accepted time, SQLite atomicity, transport, subprocess isolation, and other external services. Its SQLite entry leaves cross-row crash recovery, ordering, and conservation outside the formal claim boundary.
- `docs/reference/CLAIM_REGISTRY.md` disallows claims that runtime revocation or all kernel fail-closed behavior are formally verified end to end. It limits production inclusion-proof refinement to the published eight-leaf verification bound under the hash assumption.
- `formal/OWNERS.md` requires mirror review without treating a matching hash as proof of production behavior. `scripts/check-formal-proofs.sh`, `scripts/check-aeneas-production.sh`, `scripts/check-aeneas-equivalence.sh`, and `scripts/check-rust-verification-gates.sh` provide distinct checking stages.
- `scripts/run-dst.sh` admits the explicit `single_process_single_store` scope and fixed/wide/replay lanes. `releases.toml` labels the Loom lane as bounded abstract models. Do not report either as universal distributed execution coverage.

**Retained experiment boundary:**
- `docs/architecture/SWARM_EXECUTION_CONTRACT.md` records three accepted normal runs each for competent direct MCP and Chio, both using 8-9 model calls with overlapping token totals. The matched worker-death cases distinguish Chio receipt recovery without another delivery from correct resource deduplication by the baseline. No general task-success/model-cost advantage follows.
- The same ledger records serial Linux release dispatch medians around 41.5 ms for fresh Chio dispatch versus 1.7 ms for direct resource access at `e470d05f3b2c04dd3a09178df0612346c17fa9e1`. It explicitly says guarantees differ, model latency and installation are excluded, and those timings precede the response-binding correction.
- At this map's snapshot, the ledger says the output-shape correction `7716292a34dccc580a18df3c8d6513e925c6d9cd` still requires hosted qualification. Earlier passing PostgreSQL or Linux results cannot qualify that correction. The ledger also keeps dependency failures and workspace acceptance separate.
- The finding-worker source assessment in the same ledger identifies existing isolation, attempt limits, concurrency, heartbeat, cancellation, and fenced completion. No migration or reduced owner effort is established by wrapping that consumer.

## Common Patterns

**Async Testing:**
- Use Tokio tests for asynchronous kernel/worker interactions. The subprocess helper in `crates/kernel/chio-process/tests/crash_recovery.rs` uses `#[tokio::test]`; keep the outer process-death assertions in the parent.
- Await admitted work during cancellation and assert queued work never starts. `sdks/typescript/packages/ai-sdk-process/test/process.test.mjs` uses controlled deferred promises to test this ordering.
- Select features and OS explicitly. `crates/products/chio-cli/tests/process_host.rs` is Unix-gated and contains Linux-only tests; the process crate's worker/mailbox features are declared in `crates/kernel/chio-process/Cargo.toml`.

**Error Testing:**
- Pair a successful baseline with named forbidden mutations, changed identities, bad output shapes, unavailable state, or interrupted writes. Use `crates/products/chio-cli/tests/process_response_verify.rs`, `sdks/python/chio-process/tests/test_invocation.py`, and the exact-inventory self-test patterns.
- Record denial, incomplete outcome, and tool error distinctly. Tests in `sdks/typescript/packages/ai-sdk-process/test/process.test.mjs` require each to escape the framework's normal success path.
- Inspect skip diagnostics in network suites. `skip_when_loopback_bind_denied` in `crates/tooling/chio-test-support/src/lib.rs` allows early return for `PermissionDenied`; other probe errors panic. Exact executed test names cannot detect that a test returned before its network assertions. Require the intended network-capable environment for the corresponding claim.

**Reuse for consumer-relevant qualification:**

| Required responsibility/evidence | Reuse first | Consumer-specific work still required |
|---|---|---|
| Installation outside the source tree | `scripts/qualify-process-packages.py`, `examples/process-starter/` | Actual operator installation/configuration time and supported deployment requirements |
| Native host/worker recovery | `crates/products/chio-cli/tests/process_host.rs`, `crates/kernel/chio-process/tests/crash_recovery.rs` | The consumer's actual interruption points, external state oracle, and residual manual recovery |
| Delegated worker isolation | `crates/products/chio-cli/tests/process_host/container_runner.py` | Confirm the consumer's credential, filesystem, network, and OS boundary in its deployment |
| Recorded invocation and binding verification | `sdks/python/chio-process/src/chio_process/invocation.py`, `crates/products/chio-cli/tests/process_response_verify.rs` | Identify the intended operation/context and the external resource's observable committed outcome |
| Atomic resource ownership/fencing | `examples/shared-resource-swarm/qualify_ownership.py`, `examples/postgres-job-swarm/` | Integrate at the resource's atomic mutation boundary and preserve its domain semantics |
| Baseline path and recovery timing | `examples/shared-resource-swarm/probe_dispatch.py` | Comparable guarantees, end-to-end workload timing, operator interventions, and installation burden |
| Exact test inventory and negative controls | `scripts/run-exact-cargo-test-inventory.sh`, `scripts/tests/check-exact-cargo-test-inventory.test.py` | Select requirement-sized tests and inspect environment skips; do not add another bespoke parser |
| Immutable source/artifact provenance | `scripts/qualify-release.sh`, `scripts/check-committed-linux-evidence.py` | Apply each validator only to its declared schema/profile; the Linux evidence checker is specific to enterprise migration artifacts |
| Adoption acceptance | `docs/architecture/SWARM_EXECUTION_CONTRACT.md` records the missing evidence | Name the real owner, responsibility removed or enabled, retained obligations, measurable cost, and the owner's acceptance decision |

The repository's current qualification machinery supplies many of the technical controls. The missing adoption result is not produced by another fixture count: the inspected execution contract requires integration effort and operator burden to be measured against a competent existing integration. Keep those measurements alongside technical acceptance rather than substituting one for the other. Source: `docs/architecture/SWARM_EXECUTION_CONTRACT.md`.

---

*Testing analysis: 2026-09-08, source inspection at `d99e03027c57dc9c0929a5bca553e745c6286d99`.*
