from pathlib import Path
import subprocess,json,concurrent.futures,re
out=Path('/tmp/chio-arc-hosted-security-triage-20260909');repo='bb-connor/arc'
paths={'run':f'repos/{repo}/actions/runs/34434602977','job':f'repos/{repo}/actions/jobs/102736958085','pr':f'repos/{repo}/pulls/1156','logs':f'repos/{repo}/actions/jobs/102736958085/logs'}
def run(pair):
 key,path=pair;r=subprocess.run(['gh','api',path],capture_output=True,text=True,timeout=90)
 text=r.stdout;patterns=[(r'(?i)(authorization\s*[:=]\s*bearer\s+)[A-Za-z0-9_.\-]+',r'\1[REDACTED]'),(r'\b(?:github_pat_[A-Za-z0-9_]{20,}|gh[pousr]_[A-Za-z0-9]{20,}|npm_[A-Za-z0-9]{30,}|sk-(?:proj-|ant-)?[A-Za-z0-9_-]{30,})\b','[REDACTED]')]
 count=0
 for regex,replacement in patterns:text,n=re.subn(regex,replacement,text);count+=n
 suffix='.txt' if key=='logs' else '.json';(out/(key+suffix)).write_text(text)
 return key,{'exit':r.returncode,'stderr':r.stderr.strip(),'redactions':count,'bytes':len(text.encode())}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:records=dict(pool.map(run,paths.items()))
(out/'fetch-results.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(records,indent=2))
if any(x['exit'] for x in records.values()):raise SystemExit(1)
job=json.loads((out/'job.json').read_text());check_path=job['check_run_url'].replace('https://api.github.com/','')
r=subprocess.run(['gh','api',check_path+'/annotations?per_page=100','--paginate'],capture_output=True,text=True,timeout=60);(out/'annotations.json').write_text(r.stdout)
print(json.dumps({'annotationsExit':r.returncode,'jobName':job['name'],'conclusion':job['conclusion'],'failedSteps':[x for x in job['steps'] if x.get('conclusion')=='failure']},indent=2))
