# DER unblock: cargo-vet criteria review

Date: 2026-09-10. Read-only review; no repository changes, certification, policy change, cargo invocation, or dependency build performed.

## Conclusion

**High confidence:** built-in `safe-to-deploy` does not require correctness of every unused public API. My earlier refusal to consider a `der 0.8.2` audit solely because `SetOfRef` has an unused logic defect was too strict. A normal `0.8.0 -> 0.8.2` delta audit remains a feasible route without a new exemption, custom criterion, or vendor fork.

**Moderate confidence, reviewer judgment:** the complete published delta review, actual Chio dependency/feature-path review, and the parent's Ed25519/SPKI regressions can support that audit. The known defect must remain explicit. Its absence from Chio's call graph is useful evidence, not a replacement for judging the security significance of the changed code. This document does not itself certify the crate or claim the pending regressions passed.

## Exact authoritative criterion

Chio CI pins cargo-vet 0.10.2 at `.github/workflows/ci.yml:373`. The upstream tag resolves to commit `28f617ea97392d527799649db588a6dbb695da8d`; raw downloads were checked against this immutable commit. The current hosted definition agrees with the pinned text.

The [pinned safe-to-deploy definition, line 4](https://github.com/mozilla/cargo-vet/blob/28f617ea97392d527799649db588a6dbb695da8d/src/criteria/safe-to-deploy.txt#L4) says:

> Auditors are not required to perform a full logic review of the entire crate.

Line 12 also says “some discretion is permitted”. The required judgment concerns serious security vulnerabilities under untrusted input. The review must cover unsafe blocks and powerful imports deeply enough to reason about their behavior under reasonable use; the text requires recording discretionary judgments in audit notes. This is a security criterion, not a universal functional-correctness certificate. [Current official definition](https://mozilla.github.io/cargo-vet/built-in-criteria.html).

The [audit-entry definition, lines 21-25](https://github.com/mozilla/cargo-vet/blob/28f617ea97392d527799649db588a6dbb695da8d/book/src/audit-entries.md#L21) requires properties to be “actually preserved, not merely” that a diff lacks obvious violations. A delta audit therefore needs enough baseline context to substantiate its conclusion. The already-existing 0.8.0 exemption is not proof that the changed 0.8.2 code meets the criterion. [Recording audits](https://github.com/mozilla/cargo-vet/blob/28f617ea97392d527799649db588a6dbb695da8d/book/src/recording-audits.md#L8) treats certification as the auditor's affirmative determination, not a tool-generated result.

The [criteria guide](https://github.com/mozilla/cargo-vet/blob/28f617ea97392d527799649db588a6dbb695da8d/book/src/audit-criteria.md#L30) distinguishes additional crypto-correctness review from the built-in criterion and separately describes lowering requirements for unexposed dependencies. No lowering is proposed here.

## Scope and export are separate

An audit is attached to a package version or version delta and criteria. Its `notes` are human-readable context; there is no audit-entry field that machine-checks a restriction to Chio, a feature, a target, or a particular call graph. Adding such words to notes does not redefine `safe-to-deploy`.

There is a supported `importable = false` field:

- [Serialization, lines 295-338](https://github.com/mozilla/cargo-vet/blob/28f617ea97392d527799649db588a6dbb695da8d/src/serialization.rs#L295): accepts an optional Boolean; omitted entries default to importable.
- [Import filtering, lines 1221-1222](https://github.com/mozilla/cargo-vet/blob/28f617ea97392d527799649db588a6dbb695da8d/src/storage.rs#L1221): foreign non-importable audits are filtered out.
- [Audit representation, lines 301-308](https://github.com/mozilla/cargo-vet/blob/28f617ea97392d527799649db588a6dbb695da8d/src/format.rs#L301): notes and importability are separate from criteria.

This is a useful containment option for a review heavily informed by Chio usage. It prevents automatic reuse elsewhere; it does not authorize a false certification or impose a feature-use restriction within Chio. The source supports this field even though the audit-entry documentation does not describe it. I have not tested a resulting record with cargo-vet in this task.

## Feasible route and remaining judgment

1. Use published, non-yanked 0.8.2, not 0.8.1. The retained source review establishes that 0.8.2 restores nested-reader full-consumption checking. Keep the complete `0.8.0 -> 0.8.1` and `0.8.1 -> 0.8.2` diffs as the review basis.
2. Finish the parent's real malformed-parent-key regressions and dependency/feature traces. Cover optional Iroh's actual Ed25519/SPKI inputs, not only the default CLI where this dependency is absent. Confirm no reviewed caller uses `SetOfRef`, and record what configurations that statement covers.
3. Explicitly assess the remaining `SetOfRef` behavior: typed decode errors become iterator termination and comparison errors can be accepted. The prior source-derived malformed-SET case is retained; it is not silently reclassified as correct. This appears to be safe-Rust validation/canonicalization behavior, not a newly introduced unsafe block or powerful import. Whether it constitutes a serious security vulnerability for reasonable use remains a security judgment; an argument based only on lack of unsafe code would be insufficient.
4. If the reviewer concludes the built-in criterion is preserved with documented discretion, record an ordinary `safe-to-deploy` delta audit, exact source identities, validation evidence, and the defect/usage limitations. Consider `importable = false` to avoid exporting a context-heavy judgment. No new exemption or relaxed criterion is needed.
5. Run `cargo vet --locked` and the existing release gates on the final lock/audit state. The command validates the audit graph and metadata; it does not independently prove the security judgment. Any later addition of `SetOfRef` use should trigger review because notes alone do not enforce that boundary.

If the investigation instead establishes an exploitable serious defect in reasonable use, or cannot justify why the known defect is within the criterion's discretion, certification remains unwarranted. That is the substantive stop condition, not the mere existence of an unused API defect.

## Repository conventions and retained evidence

`supply-chain/README.md:35-41` permits certification records with reviewer identity, criterion, and short justification covering surface area, IO, and unsafe usage, followed by locked verification. Lines 62-64 retain `safe-to-deploy` as the workspace standard. Existing audits illustrate contextual notes: `anyhow` delta at `audits.toml:262-266`; `wasm-encoder` and `wasm-smith` feature-use notes at 1372-1376 and 1390-1394. These conventions support recording context, but do not establish that any particular risk is acceptable.

The previous complete source review remains `/tmp/chio-kernel-release-audit-20260909/der-review/REVIEW.md`. Its two findings and source evidence are preserved. This note corrects the earlier inference that every unused public-API defect necessarily prevents the built-in audit; it does not retract either source finding.

Raw pinned upstream files, tag resolution, repository README/CI snapshots, repository HEAD/status, and a SHA-256 manifest accompany this file under `/tmp/chio-der-unblock-20260909/`.
