# Published DER 0.8.2 parent API conformance

Executed 2026-09-10 in an isolated standalone crate and target directory. **17 tests passed, 0 failed, 0 skipped.** The retained case ledger contains 4 accepted valid inputs and 59 rejected malformed inputs. This is library-level conformance evidence, not an Iroh network/session test or six-host integration acceptance.

## Reproduce

```sh
cd /tmp/chio-der-unblock-20260909/parent-conformance
CARGO_TARGET_DIR="$PWD/target" CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 cargo fetch --locked
CARGO_TARGET_DIR="$PWD/target" CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 cargo test --locked --offline -- --nocapture --test-threads=1
cargo tree --locked --offline -e normal,build --format '{p} {f}'
```

The package has its own workspace declaration. It uses published registry packages, no path dependencies, no patched source, and no private sibling checkouts. The initial lock was copied from the Chio release worktree, then updated only in this temporary harness to select `der 0.8.2`; unrelated workspace packages were pruned by Cargo. All 34 other retained registry package versions/checksums match the immutable Chio baseline `73f0feffe0aa2cf1e01eee9305aec1c477247a98`. Full baseline lock, final harness lock, graph, and metadata are retained.

## Selected versions and feature fidelity

- `ed25519-dalek = 3.0.0-rc.0`, with its defaults plus `serde`, `rand_core`, `zeroize`, `pkcs8`, and `pem`: exactly the dependency declaration in published `iroh 1.0.1`, `Cargo.toml:233-241`.
- `ed25519 3.0.0`, `pkcs8 0.11.0`, `spki 0.8.0`, and published `der 0.8.2`.
- Resolved DER features: `alloc,oid,pem,zeroize`. Parent features and all transitive versions are in `cargo-tree.stdout` and `cargo-metadata.stdout`.
- Executed with Rust 1.93.0 on aarch64-apple-darwin. Full compiler/OS identities are in `toolchain.stdout` and `environment.json`.

This reproduces Iroh's declared Ed25519 parsing dependency features. It does not claim to reproduce every additional feature that a larger workspace could unify into dependencies.

## Tested behavior

Positive tests derive four valid public keys from fixed reproducible seed bytes using `SigningKey::from_bytes`, encode SPKI using the published encoder, decode using `VerifyingKey::from_public_key_der`, compare exact key and encoding, and verify an actual signature under the decoded key. These are deterministic test keys, not randomly generated production credentials.

Negative tests call that same public decoder and assert an error for:

- All 44 truncated prefixes of the 44-byte valid SPKI.
- Short/long outer and AlgorithmIdentifier lengths, and an oversized BIT STRING length.
- Trailing data outside the outer SEQUENCE and inside AlgorithmIdentifier.
- Wrong algorithm OID and forbidden NULL algorithm parameters.
- A valid BIT STRING with one unused bit, and an invalid count of eight unused bits.
- Correctly framed short and long public-key byte arrays.
- Nonminimal long-form length and indefinite length encoding.

Observed errors include `TrailingData` for nested and outer leftovers, `OidUnknown` for the wrong OID, and `KeyMalformed` for forbidden parameters, non-octet-aligned key bits, and incorrect key sizes. `case-results.json` preserves each complete input and returned result; `test-after-fetch.stdout` is the raw test transcript.

## Actual published API path

The following original source files are copied under `source-proof/`, with original line numbering:

1. `iroh-1.0.1/src/endpoint/connection.rs:394-397` obtains the remote endpoint key with `VerifyingKey::from_public_key_der(&certs[0])` and propagates failure.
2. `spki-0.8.0/src/traits.rs:73-79` implements `DecodePublicKey` by decoding `SubjectPublicKeyInfoRef` and converting it to the requested parent type.
3. `spki-0.8.0/src/spki.rs:99-111,137-145` decodes AlgorithmIdentifier then BIT STRING; `algorithm.rs:34-45` decodes OID and optional parameters.
4. `der-0.8.2/src/decode.rs:106-115` routes typed decoding through bounded `read_value`; `reader/slice.rs:90-116` rejects successful nested decoders that leave trailing data.
5. `ed25519-dalek-3.0.0-rc.0/src/verifying.rs:683-688` converts through `PublicKeyBytes`; `ed25519-3.0.0/src/pkcs8.rs:271-287` checks the Ed25519 OID, forbids parameters, requires byte-aligned BIT STRING data, and requires the exact 32-byte key array.
6. `ed25519-dalek-3.0.0-rc.0/src/verifying.rs:660-666` calls `VerifyingKey::from_bytes` and maps invalid point encodings to `KeyMalformed`.

The harness calls the published parent decoder directly. It neither modifies the parser nor replaces its validation logic.

## Provenance and limitations

`registry-source-verification.json` records verification of all 35 selected registry archives against their locked SHA-256 checksums and byte comparison of 1,401 extracted source files against those archives. The DER archive also equals the independently downloaded archive retained by the previous full source-delta review: SHA-256 `a878c850e9e421b20262e9b41f9c860e4785fa07541c266b62ff9d1ef998a80a`. The copied Iroh manifest and call site were separately checked against its baseline-locked archive in `iroh-source-verification.json`.

The first offline test invocation failed because the published DER archive was not yet in Cargo's cache; its logs are retained as `test.*`. `cargo fetch --locked` downloaded it, and the subsequent offline test run passed. Source-verification comparison initially consulted a concurrently changing repository lock; final verification uses the immutable baseline commit identified above.

These tests do not exercise `SetOfRef`, establish its correctness, provide a cargo-vet certification, or demonstrate end-to-end Iroh transport behavior. Its separately documented defect remains unresolved in the published package. No repository source, lockfile, audit record, or selected release artifact was changed by this harness work.
