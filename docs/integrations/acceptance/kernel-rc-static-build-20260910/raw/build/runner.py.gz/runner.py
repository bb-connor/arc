import datetime,hashlib,json,os,platform,subprocess,time
from pathlib import Path
root=Path('/Users/connor/Medica/backbay/standalone/arc/.worktrees/required-kernel-rc-20260910')
out=Path('/tmp/chio-kernel-rc-static-build-20260910');out.mkdir(mode=0o700,exist_ok=False)
prepared=Path('/tmp/chio-openssl-static-3.6.4-20260910'); scan=Path('/tmp/chio-openssl-static-scan-20260910/native-openssl-scan.json')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git','-C',str(root),*args],text=True).strip()
source=git('rev-parse','HEAD'); assert source=='bafa02b06de93553cecb6f60b340f3dd8fd9b401'
assert not git('status','--porcelain')
manifest=json.loads((prepared/'native-openssl.json').read_text()); scanned=json.loads(scan.read_text()); assert scanned['passed'] and scanned['native_manifest_sha256']==sha(prepared/'native-openssl.json')
assert manifest['recipe_sha256']==sha(root/'scripts/prepare-macos-release-openssl.py')
material={str(prepared/'install'/rel):expected for rel,expected in manifest['files'].items()}
material[str(prepared/'native-openssl.json')]=sha(prepared/'native-openssl.json')
material[str(scan)]=sha(scan)
for filename,expected in material.items():assert sha(Path(filename))==expected
native_env=json.loads((prepared/'cargo-env.json').read_text())
env=os.environ.copy()
removed=[]
for key in list(env):
 if 'OPENSSL' in key or key.startswith('DYLD_') or key in ['RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER']:
  removed.append(key);env.pop(key)
env.update(native_env);env.update(CARGO_TARGET_DIR='/tmp/chio-kernel-rc-build-20260910/target',CARGO_BUILD_JOBS='2',CARGO_INCREMENTAL='0')
command=['cargo','auditable','build','--release','--locked','--package','chio-cli','--bin','chio','--target','aarch64-apple-darwin']
record={'source':source,'tree':git('rev-parse','HEAD^{tree}'),'cargoLockSha256':sha(root/'Cargo.lock'),'command':command,'workingDirectory':str(root),'platform':platform.platform(),'rustc':subprocess.check_output(['rustc','--version'],text=True).strip(),'cargo':subprocess.check_output(['cargo','--version'],text=True).strip(),'nativeEnvironment':native_env,'removedEnvironmentKeys':removed,'nativeMaterialSha256':material,'selectedEnvironment':{k:env[k] for k in ['CARGO_TARGET_DIR','CARGO_BUILD_JOBS','CARGO_INCREMENTAL']},'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'claim':'Local static auditable candidate build; actual loader, SBOM, host qualification and hosted signed delivery remain required'}
(out/'build.json').write_text(json.dumps(record,indent=2)+'\n');(out/'runner.py').write_bytes(Path(__file__).read_bytes())
start=time.monotonic()
with (out/'build.log').open('w') as log:
 result=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
record.update(exitCode=result.returncode,finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),elapsedSeconds=time.monotonic()-start,sourceUnchanged=(git('rev-parse','HEAD')==source and not git('status','--porcelain')),nativeInputsUnchanged=all(sha(Path(filename))==expected for filename,expected in material.items()))
if result.returncode==0:
 binary=Path(env['CARGO_TARGET_DIR'])/'aarch64-apple-darwin/release/chio';record.update(binary=str(binary),binarySha256=sha(binary),binaryBytes=binary.stat().st_size,version=subprocess.check_output([str(binary),'--version'],text=True).strip())
(out/'build.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:v for k,v in record.items() if k!='nativeMaterialSha256'},indent=2));raise SystemExit(result.returncode if record['sourceUnchanged'] and record['nativeInputsUnchanged'] else 2)
