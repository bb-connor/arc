from pathlib import Path
import hashlib, json, os, re

ROOT = Path('/Users/connor/Medica/backbay/standalone/arc/.worktrees/required-agent-integrations-20260909')
BASE = Path('/Users/connor/.local/share/chio-required-operators')
EVIDENCE = ROOT / 'docs/integrations/acceptance/20260909'
KEYS = {'accesstoken', 'refreshtoken', 'idtoken', 'bearertoken', 'admintoken', 'agenttoken', 'authorization', 'apikey', 'accountid'}
secrets = set()
sources = 0
def collect(value):
    if isinstance(value, dict):
        for key, child in value.items():
            normalized = re.sub('[^a-z]', '', key.lower())
            if normalized in KEYS and isinstance(child, str) and len(child) >= 16:
                secrets.add(child.encode())
                if child.lower().startswith('bearer '):
                    secrets.add(child[7:].encode())
            collect(child)
    elif isinstance(value, list):
        for child in value:
            collect(child)
for path in BASE.rglob('*.json'):
    if path.name not in {'operator.json', 'gateway.json', 'prepare.json', 'auth.json', 'capture.private.json'} or path.is_symlink():
        continue
    try:
        data = json.loads(path.read_text())
    except (OSError, ValueError):
        continue
    sources += 1
    collect(data)
for key in ['OPENAI_API_KEY', 'ANTHROPIC_API_KEY', 'ANTHROPIC_AUTH_TOKEN']:
    value = os.environ.get(key)
    if value and len(value) >= 16:
        secrets.add(value.encode())
rc = BASE / 'npm-publisher-auth-20260909/npmrc'
if rc.is_file():
    for line in rc.read_text().splitlines():
        if '_authToken=' in line:
            secrets.add(line.split('=', 1)[1].strip().encode())
