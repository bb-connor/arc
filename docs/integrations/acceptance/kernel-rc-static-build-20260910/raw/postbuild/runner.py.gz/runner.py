from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess,time
build=Path('/tmp/chio-kernel-rc-static-build-20260910')
out=Path('/tmp/chio-kernel-rc-static-artifact-20260910');out.mkdir(mode=0o700,exist_ok=False)
root=Path('/Users/connor/Medica/backbay/standalone/arc/.worktrees/required-agent-integrations-20260909')
source_root=Path('/Users/connor/Medica/backbay/standalone/arc/.worktrees/required-kernel-rc-20260910')
started=time.monotonic()
while True:
 try:meta=json.loads((build/'build.json').read_text())
 except json.JSONDecodeError:meta={}
 if 'exitCode' in meta:break
 if time.monotonic()-started>7200:raise TimeoutError('build completion was not observed')
 time.sleep(2)
assert meta['exitCode']==0 and meta['sourceUnchanged'] and meta['nativeInputsUnchanged']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
original=Path(meta['binary']);expected=meta['binarySha256'];assert sha(original)==expected
candidate=Path('/Users/connor/.local/share/chio-required-candidates/kernel-rc-static-20260910');candidate.mkdir(mode=0o700,exist_ok=False)
binary=candidate/('chio-'+expected[:12]);shutil.copy2(original,binary);binary.chmod(0o555);assert sha(binary)==expected and sha(original)==expected
(out/'build.json').write_bytes((build/'build.json').read_bytes())
identity={'kernelSource':meta['source'],'kernelSha256':expected,'binary':str(binary),'size':binary.stat().st_size,'version':meta['version'],'buildSourceTree':meta['tree'],'frozenAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'claim':'Local static auditable candidate; exact local binary only. Hosted signing, provenance, public delivery and final host qualification remain separate.'}
(candidate/'identity.json').write_text(json.dumps(identity,indent=2)+'\n');(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n')
print(json.dumps({'frozen':str(binary),'sha256':expected,'source':meta['source']}),flush=True)
syft=Path('/tmp/chio-syft151-tool-20260910/syft');assert sha(syft)=='47cd0bc89537c80eed48f34766743d54574e5830deff243cf54d99696a8e9ce0'
commands=[('linkage',['python3',str(root/'scripts/check-macos-release-linkage.py'),'--binary',str(binary),'--target','aarch64-apple-darwin','--expected-version','0.1.1-rc.1','--output',str(out/'linkage.json')]),('syft',[str(syft),'--config',str(root/'deploy/sbom/syft.yaml'),'file:'+str(binary),'-o','cyclonedx-json@1.6='+str(out/'sbom.json')]),('inventory-validation',['python3',str(root/'scripts/check-release-binary-sbom.py'),'--sbom',str(out/'sbom.json'),'--binary',str(binary),'--root',str(source_root),'--expected-version','0.1.1-rc.1','--report',str(out/'validation.json')])]
records=[]
for label,command in commands:
 sources={str(Path(x)):sha(Path(x)) for x in command if Path(x).is_file()}
 begin=time.monotonic()
 with (out/(label+'.stdout')).open('w') as stdout,(out/(label+'.stderr')).open('w') as stderr:r=subprocess.run(command,stdout=stdout,stderr=stderr,timeout=600)
 record={'case':label,'command':command,'exitCode':r.returncode,'elapsedSeconds':time.monotonic()-begin,'inputHashes':sources,'inputsUnchanged':all(sha(Path(x))==h for x,h in sources.items())};records.append(record);(out/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
 print(json.dumps({'case':label,'exitCode':r.returncode}),flush=True)
 assert r.returncode==0 and record['inputsUnchanged']
outputs=list(Path('/tmp/chio-kernel-rc-build-20260910/target/aarch64-apple-darwin/release/build').glob('openssl-sys-*/output'))
matched=[p for p in outputs if b'/private/tmp/chio-openssl-static-3.6.4-20260910/install/lib' in p.read_bytes()]
assert len(matched)==1;data=matched[0].read_bytes();assert b'cargo:rustc-link-lib=static=ssl' in data and b'cargo:rustc-link-lib=static=crypto' in data and b'cargo:version_number=30600040' in data
(out/'openssl-sys-build-output.txt').write_bytes(data)
assert sha(binary)==expected
(out/'result.json').write_text(json.dumps({'passed':True,**identity,'loaderPassed':True,'embeddedInventoryPassed':True,'nativeBuildOutputSha256':hashlib.sha256(data).hexdigest(),'hostAcceptance':False,'published':False},indent=2)+'\n')
print(json.dumps({'artifactChecksPassed':True,'binary':str(binary),'sha256':expected}),flush=True)
