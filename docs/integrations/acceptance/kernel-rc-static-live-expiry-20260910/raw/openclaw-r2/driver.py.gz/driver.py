#!/usr/bin/env python3
import argparse,concurrent.futures,hashlib,importlib.util,json,os,socket,subprocess,time,tarfile,zipfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--hosts',nargs='+',required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--owner-root',type=Path,required=True);p.add_argument('--volume-prefix',required=True);p.add_argument('--ttl',type=int,default=20);a=p.parse_args()
assert 1<=a.ttl<=45 and a.volume_prefix.startswith('chio-required-')
ROOT=Path('/Users/connor/Medica/backbay/standalone/arc/.worktrees/required-agent-integrations-20260909')
DRIVERS=ROOT.parent/'live-host-capability-expiry-20260910'
BINARY=Path('/Users/connor/.local/share/chio-required-candidates/kernel-rc-static-20260910/chio-c03a8a711dbb')
SHA='c03a8a711dbbd15da2c59655d9ab6d8f0068a20187363db7a78f4b5422ded93e'
IMAGE='sha256:188cb84d5d0bb4063d4ce5a3b9c3832445a5acda5604911cda80a9136d1850a0'
OC='sha256:7f925d68ced724f4a6314ab76dc117e9000515ba62149ee971a11c510be6637f'
CONSUMERS=Path('/tmp/chio-kernel-rc-consumers-20260910')
AUTH=Path('/Users/connor/.local/share/chio-required-operators/native-subscription-auth-20260909/codex/profile/auth.json')
NAMES={'codex':'codex-plugin','pi':'pi-plugin','openclaw':'openclaw-kernel'}
PORTS={'codex':59301,'pi':59302,'hermes':59303,'openclaw':59304}
assert len(set(a.hosts))==len(a.hosts) and all(h in PORTS for h in a.hosts)
assert hashlib.sha256(BINARY.read_bytes()).hexdigest()==SHA
spec=importlib.util.spec_from_file_location('owner_readiness',ROOT/'integrations/required-agents/prepare-session.py');ready=importlib.util.module_from_spec(spec);spec.loader.exec_module(ready)
a.output.mkdir(mode=0o700,exist_ok=False);a.owner_root.mkdir(mode=0o700,exist_ok=False)
(a.output/'driver.py').write_bytes(Path(__file__).read_bytes())
sources=[ROOT/'integrations/required-agents/serve-filesystem.py',ROOT/'integrations/required-agents/prepare-session.py',ROOT/'integrations/required-agents/filesystem-policy.yaml',*sorted((DRIVERS/'scripts/acceptance').glob('*.mjs')),DRIVERS/'scripts/acceptance/host-approvals.py',DRIVERS/'scripts/acceptance/live_expiry_native.py']
hashes={str(f):hashlib.sha256(f.read_bytes()).hexdigest() for f in sources}
(a.output/'source-snapshots').mkdir()
for i,f in enumerate(sources):(a.output/'source-snapshots'/f'{i}-{f.name}').write_bytes(f.read_bytes())
identity={'kernel':str(BINARY),'kernelSha256':SHA,'kernelSource':'bafa02b06de93553cecb6f60b340f3dd8fd9b401','image':IMAGE,'openclawImage':OC,'sourceHashes':hashes,'driverSource':subprocess.check_output(['git','-C',str(DRIVERS),'rev-parse','HEAD'],text=True).strip(),'productionSource':subprocess.check_output(['git','-C',str(ROOT),'rev-parse','HEAD'],text=True).strip(),'capabilityTtl':a.ttl,'claim':'Supplemental real-host in-flight capability-bound authority expiry; no host acceptance or publication.'}
(a.output/'identity.json').write_text(json.dumps(identity,indent=2)+'\n')
def installed_runtime_identities():
 entries=json.loads(Path('/tmp/chio-kernel-rc-static-installations-20260910.json').read_text());checked=[]
 for entry in entries:
  if entry['host'] not in a.hosts:continue
  archive=Path(entry['archive']);package=Path(entry['packageDirectory']);count=0
  assert hashlib.sha256(archive.read_bytes()).hexdigest()==entry['sha256']
  with tarfile.open(archive) as stream:
   for member in stream.getmembers():
    if not member.isfile():continue
    assert member.name.startswith('package/')
    relative=Path(member.name.removeprefix('package/'));assert not relative.is_absolute() and '..' not in relative.parts
    assert (package/relative).read_bytes()==stream.extractfile(member).read();count+=1
  assert count==entry['filesVerified']
  checked.append({'host':entry['host'],'archive':str(archive),'archiveSha256':entry['sha256'],'packageDirectory':str(package),'filesVerified':count})
 if 'hermes' in a.hosts:
  bundle=Path('/Users/connor/.local/share/chio-required-candidates/20260909')
  wheel=bundle/'hermes-wheelhouse/chio_hermes-0.1.2-py3-none-any.whl';wheel_sha='625979d5331796e7aef5906e69e3e2c746796aa570291af026c305ed4227c818'
  assert hashlib.sha256(wheel.read_bytes()).hexdigest()==wheel_sha
  site=CONSUMERS/'hermes/consumer/lib/python3.11/site-packages';count=0
  with zipfile.ZipFile(wheel) as stream:
   for name in stream.namelist():
    if name.endswith('/') or name.endswith('.dist-info/RECORD'):continue
    assert not Path(name).is_absolute() and '..' not in Path(name).parts
    assert (site/name).read_bytes()==stream.read(name);count+=1
  assert count==22
  bridge_archive=bundle/'packages/chio-bridge-hermes-0.3.0-b7785282b4f4.tgz';bridge_sha='b7785282b4f4e4da42e4158c7390a2d1411ba2763b01956b07896aadf6dcc6d9'
  assert hashlib.sha256(bridge_archive.read_bytes()).hexdigest()==bridge_sha
  bridge=CONSUMERS/'hermes/bridge/node_modules/@chio/bridge';bridge_count=0
  with tarfile.open(bridge_archive) as stream:
   for member in stream.getmembers():
    if not member.isfile():continue
    assert member.name.startswith('package/');relative=Path(member.name.removeprefix('package/'))
    assert not relative.is_absolute() and '..' not in relative.parts
    assert (bridge/relative).read_bytes()==stream.extractfile(member).read();bridge_count+=1
  assert bridge_count==1052
  native=json.loads(Path('/tmp/chio-hermes-public-final-install-20260910/identity.json').read_text())
  assert hashlib.sha256(Path(native['hostPython']).read_bytes()).hexdigest()==native['pythonBinarySha256']
  assert subprocess.check_output(['git','-C',native['sourceDirectory'],'rev-parse','HEAD'],text=True).strip()==native['sourceCommit']
  assert not subprocess.check_output(['git','-C',native['sourceDirectory'],'status','--porcelain','--untracked-files=no'],text=True).strip()
  checked.append({'host':'hermes','wheelSha256':wheel_sha,'adapterRuntimeFilesVerified':18,'adapterWheelFilesVerified':count,'bridgeSha256':bridge_sha,'bridgeFilesVerified':bridge_count,'nativeSource':native['sourceCommit'],'nativePythonSha256':native['pythonBinarySha256']})
 for selection in [IMAGE]+([OC] if 'openclaw' in a.hosts else []):
  assert subprocess.check_output(['docker','image','inspect','--format','{{.Id}}',selection],text=True).strip()==selection
 return checked
before_identities=installed_runtime_identities()
(a.output/'installed-identities-before.json').write_text(json.dumps(before_identities,indent=2)+'\n')
policy=(ROOT/'integrations/required-agents/filesystem-policy.yaml').read_text();assert policy.count('ttl: 3600')==2
policy=policy.replace('ttl: 3600',f'ttl: {a.ttl}');policy_file=a.output/'policy.yaml';policy_file.write_text(policy)

def host(name):
 folder=a.output/name;folder.mkdir(mode=0o700);owner=a.owner_root/name;records=[]
 def run(label,cmd,timeout=300):
  with (folder/(label+'.stdout')).open('wb') as out,(folder/(label+'.stderr')).open('wb') as err:
   start=time.monotonic();child=subprocess.Popen(cmd,stdout=out,stderr=err,start_new_session=True)
   try:code=child.wait(timeout=timeout);timed=False
   except subprocess.TimeoutExpired:
    import signal
    os.killpg(child.pid,signal.SIGTERM)
    try:child.wait(timeout=5)
    except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait(timeout=5)
    code=child.returncode;timed=True
  record={'label':label,'command':cmd,'processGroup':child.pid,'exitCode':code,'timedOut':timed,'seconds':time.monotonic()-start};records.append(record);(folder/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps({'host':name,**{k:record[k] for k in ['label','exitCode','timedOut']}}),flush=True)
  if code or timed:raise RuntimeError(label+' failed; original owner and outcome state retained')
 try:
  with socket.socket() as s:s.bind(('127.0.0.1',PORTS[name]))
  run('start',['python3',str(ROOT/'integrations/required-agents/serve-filesystem.py'),'start','--state-dir',str(owner),'--kernel',str(BINARY),'--kernel-sha256',SHA,'--image',IMAGE,'--volume',a.volume_prefix+'-'+name,'--port',str(PORTS[name]),'--policy',str(policy_file)])
  ready.wait_for_owner(owner,60)
  package=CONSUMERS/name/'consumer/node_modules/@chio'/NAMES[name] if name!='hermes' else CONSUMERS/'hermes/bridge/node_modules/@chio/bridge'
  cmd=['python3',str(DRIVERS/'scripts/acceptance/host-approvals.py'),'--suite','in-flight-expiry','--host',name,'--operator-state',str(owner),'--package-dir',str(package),'--model-auth-file',str(AUTH),'--output',str(folder/'case')]
  if name=='hermes':cmd+=['--launcher-python',str(CONSUMERS/'hermes/consumer/bin/python'),'--host-python','/tmp/chio-hermes-public-final-install-20260910/qualified-venv/bin/python','--host-root','/tmp/chio-hermes-public-final-install-20260910/source']
  if name=='openclaw':cmd+=['--image',OC]
  run('in-flight-expiry',cmd)
  result=json.loads((folder/'case/in-flight-expiry-result.json').read_text());assert result['passed'] and result['expiredRequestDispatches']==0
  run('stop',['python3',str(ROOT/'integrations/required-agents/serve-filesystem.py'),'stop','--state-dir',str(owner)],40)
  return {'host':name,'passed':True,'originalStateRetained':True}
 except Exception as error:
  failure={'host':name,'passed':False,'type':type(error).__name__,'message':str(error),'originalStateRetained':True};(folder/'failure.json').write_text(json.dumps(failure,indent=2)+'\n');return failure
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:results=list(pool.map(host,a.hosts))
assert hashlib.sha256(BINARY.read_bytes()).hexdigest()==SHA
after_identities=installed_runtime_identities()
assert after_identities==before_identities
(a.output/'installed-identities-after.json').write_text(json.dumps(after_identities,indent=2)+'\n')
unchanged=all(hashlib.sha256(Path(f).read_bytes()).hexdigest()==h for f,h in hashes.items())
(a.output/'results.json').write_text(json.dumps({'hosts':results,'sourceInputsUnchanged':unchanged},indent=2)+'\n')
raise SystemExit(0 if unchanged and all(r['passed'] for r in results) else 1)
