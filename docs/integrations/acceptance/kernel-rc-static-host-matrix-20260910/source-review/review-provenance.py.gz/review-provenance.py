from pathlib import Path
import ast,datetime,hashlib,json,re,subprocess,tarfile,zipfile
M=Path('/tmp/chio-kernel-rc-static-matrix-20260910')
O=Path('/tmp/chio-static-matrix-source-review-20260910');O.mkdir(mode=0o700,exist_ok=False)
ROOT=Path('/Users/connor/Medica/backbay/standalone/arc/.worktrees/required-agent-integrations-20260909')
def digest(b):return hashlib.sha256(b).hexdigest()
identity=json.loads((M/'identity.json').read_text());revision=identity['testSources']['kernel']['commit']
records=[];unsnapshotted=[]
for h in identity['hosts']:
 for r in json.loads((M/h/'runs.json').read_text()):
  if 'driverSha256' not in r:unsnapshotted.append({'host':h,'case':r['case'],'command':r['command']});continue
  q=M/h/'driver-snapshots'/(r['case']+'-'+Path(r['command'][1]).name)
  assert digest(q.read_bytes())==r['driverSha256'] and r['driverUnchangedDuringRun'] is True
  records.append({'host':h,'case':r['case'],'snapshot':str(q.relative_to(M)),'sha256':r['driverSha256'],'recordedBeforeAfterUnchanged':True})
helpers=[]
s=M/'claude/driver-snapshots/forbidden-read-host-approvals.py'
for name in sorted(set(re.findall(r"with_name\('([^']+)'\)",s.read_text()))):
 path='scripts/acceptance/'+name
 b=subprocess.check_output(['git','-C',str(ROOT),'show',revision+':'+path])
 current=(ROOT/path).read_bytes();q=O/name;q.write_bytes(b)
 history=subprocess.check_output(['git','-C',str(ROOT),'log','--format=%H',revision+'..9e3f7c35f95b5afafc56f7f1ba62cb8432755293','--',path],text=True).splitlines()
 helpers.append({'path':path,'sourceRevision':revision,'sourceSha256':digest(b),'currentSha256':digest(current),'currentMatchesSource':b==current,'commitsChangingPathThroughRecordBase':history,'copiedSource':str(q),'scope':'Read from recorded Git revision and compared after the host run. Not a per-command runtime helper snapshot.'})
assert len(records)==180 and len(unsnapshotted)==5
artifacts=[]
def archive_compare(archive,package,expected,label):
 b=archive.read_bytes();assert digest(b)==expected
 verified=0
 with tarfile.open(archive) as t:
  for member in t.getmembers():
   if not member.isfile():continue
   assert member.name.startswith('package/')
   rel=Path(member.name[8:]);assert not rel.is_absolute() and '..' not in rel.parts
   assert (package/rel).read_bytes()==t.extractfile(member).read(),str(package/rel)
   verified+=1
 artifacts.append({'label':label,'archive':str(archive),'archiveSha256':expected,'packageDirectory':str(package),'regularArchiveFilesMatched':verified,'scope':'Post-run byte comparison only. The four host npm archives also received this comparison at batch startup; supplementary Hermes/operator comparisons here do not imply a startup assertion absent from driver.py.'})
for e in json.loads((M/'installations.json').read_text()):
 archive_compare(Path(e['archive']),Path(e['packageDirectory']),e['sha256'],e['host'])
bundle=Path('/Users/connor/.local/share/chio-required-candidates/20260909')
archive_compare(bundle/'packages/chio-bridge-hermes-0.3.0-b7785282b4f4.tgz',Path('/tmp/chio-kernel-rc-consumers-20260910/hermes/bridge/node_modules/@chio/bridge'),'b7785282b4f4e4da42e4158c7390a2d1411ba2763b01956b07896aadf6dcc6d9','hermes-bridge')
archive_compare(bundle/'packages/chio-bridge-operator-0.3.0-02a0e4ad4e61.tgz',bundle/'install/operator-bridge/node_modules/@chio/bridge','02a0e4ad4e61ffb989302cae8774a9ae9ab8f647473f1926d1e671673169a37b','operator-recovery-bridge')
wheel=bundle/'hermes-wheelhouse/chio_hermes-0.1.2-py3-none-any.whl';wsha=digest(wheel.read_bytes());assert wsha=='625979d5331796e7aef5906e69e3e2c746796aa570291af026c305ed4227c818'
sites=list(Path('/tmp/chio-kernel-rc-consumers-20260910/hermes/consumer/lib').glob('python*/site-packages'));assert len(sites)==1
matched=0
with zipfile.ZipFile(wheel) as z:
 for name in z.namelist():
  if not name.startswith('chio_hermes/') or name.endswith('/'):continue
  assert (sites[0]/name).read_bytes()==z.read(name);matched+=1
binary=Path(identity['binary']);assert digest(binary.read_bytes())==identity['kernelSha256']
report={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'recordBaseRevision':'9e3f7c35f95b5afafc56f7f1ba62cb8432755293','matrixDriverSha256':digest((M/'driver.py').read_bytes()),'entrySnapshotsMatched':len(records),'uniqueEntryScriptHashes':len({r['sha256'] for r in records}),'entrySnapshotBindings':records,'commandsWithoutEntryScriptSnapshot':unsnapshotted,'siblingHelperSourceComparison':helpers,'postRunArchiveComparisons':artifacts,'hermesWheelPostRunComparison':{'wheel':str(wheel),'wheelSha256':wsha,'adapterFilesMatched':matched,'scope':'Only chio_hermes package files; wheel metadata and all interpreter transitive dependencies are not covered by this comparison.'},'kernelPostRunSha256':identity['kernelSha256'],'limits':['The aggregate driver copies itself once; it does not record its own before/after equality across the entire batch.','Entry-script before/after equality does not recursively cover interpreters, sibling helpers or all imported dependencies.','A post-run file comparison is not a retroactive runtime attestation.','Hermes host startup asserts the selected Python binary hash, public source HEAD and absence of tracked source changes. The copied host identity contains installer measurements which the batch does not independently repeat in full.'],'noHostOrDockerLaunchDuringReview':True,'acceptedHosts':0}
(O/'post-run-provenance.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'entrySnapshotsMatched':len(records),'helperSourceComparisons':len(helpers),'archiveComparisons':len(artifacts),'hermesAdapterFilesMatched':matched,'sourceReviewFiles':len(list(O.iterdir()))}))
