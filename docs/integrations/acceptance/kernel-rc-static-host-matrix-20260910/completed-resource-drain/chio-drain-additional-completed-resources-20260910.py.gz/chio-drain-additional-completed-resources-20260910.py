from pathlib import Path
import datetime,gzip,hashlib,json,subprocess
OUT=Path('/tmp/chio-completed-resource-drain-20260910')
ROOT=Path('/Users/connor/Medica/backbay/standalone/arc/.worktrees/required-agent-integrations-20260909')
HELPER=ROOT/'integrations/required-agents/serve-filesystem.py'
IMAGE='sha256:188cb84d5d0bb4063d4ce5a3b9c3832445a5acda5604911cda80a9136d1850a0'
ops=json.loads((OUT/'operators.json').read_text());idx=json.loads((OUT/'additional-completion-evidence-index.json').read_text())
SKIP={'cursor-parent-http-20260909','aggregate-preack-20260909'}
plans=[]
for o in ops:
 state=Path(o['stateDir'])
 if state.name not in {'bridge-host-delivery-ordinary-20260909','openclaw-subscription-probes-20260909'}:continue
 assert 'final-' not in str(state.parent) and 'static' not in str(state)
 assert '20260909' in o['volume'] or state.name in ['claude-result-contract-budget-20260910','claude-result-contract-20260910']
 hits=[Path(x) for x in idx[str(state)]]
 proof=[x for x in hits if x.name in ['results.json','result.json','summary.json','results.json.gz','result.json.gz','summary.json.gz','cases.json']]
 proof.sort(key=lambda x:(not any(s in str(x) for s in ['current-r5','final-subscription-cold','subscription-r15/ordinary','controls-sequential','budget-correct-policy']),len(str(x))))
 if not proof:
  identity=next(x for x in hits if x.name=='identity.json')
  name='FAILED-INSTRUMENTATION.json' if state.name=='codex-paired-timing-20260909' else ('result.json' if state.name=='codex-paired-timing-r2-20260909' else 'cases.json')
  proof=[identity.parent/name]
 p=proof[0];b=p.read_bytes();body=gzip.decompress(b) if p.suffix=='.gz' else b;d=json.loads(body)
 rows=d if isinstance(d,list) else [d]
 terminal_keys={'passed','exitCode','exit_code','outcome','status','failure'}
 assert rows and all(any(k in r for k in terminal_keys) for r in rows),(state,p)
 assert any(str(state).encode() in (gzip.decompress(q.read_bytes()) if q.suffix=='.gz' else q.read_bytes()) or o['volume'].encode() in (gzip.decompress(q.read_bytes()) if q.suffix=='.gz' else q.read_bytes()) for q in hits)
 plans.append({'operator':o,'completionProof':{'path':str(p),'sha256':hashlib.sha256(b).hexdigest(),'terminalRows':len(rows),'note':'Terminal recorded results prove this prior run ended; failed cases remain failures. This shutdown is not an acceptance claim.'}})
assert len(plans)==2,len(plans)
(OUT/'additional-stop-plan.json').write_text(json.dumps(plans,indent=2)+'\n')
ids=[c for plan in plans for c in plan['operator']['containerIds']]
stats=subprocess.run(['docker','stats','--no-stream','--format','{{json .}}',*ids],capture_output=True,text=True)
(OUT/'additional-candidate-stats-before.json').write_text(json.dumps({'exitCode':stats.returncode,'containers':[json.loads(s) for s in stats.stdout.splitlines() if s.strip()],'stderr':stats.stderr},indent=2)+'\n')

def refs(o):
 rows=[]
 for l in subprocess.check_output(['ps','-axo','pid=,ppid=,command='],text=True).splitlines():
  x=l.strip().split(None,2)
  if len(x)==3:rows.append((int(x[0]),int(x[1]),x[2]))
 descendants={o['pid']}
 for _ in range(12):
  new={pid for pid,parent,cmd in rows if parent in descendants};old=len(descendants);descendants|=new
  if len(descendants)==old:break
 return [pid for pid,parent,cmd in rows if pid not in descendants and (o['stateDir'] in cmd or o['volume'] in cmd)]

def inspect(cid):
 r=subprocess.run(['docker','inspect',cid],capture_output=True,text=True)
 if r.returncode:return None
 return json.loads(r.stdout)[0]

def verify_container(c,o):
 assert c['Image']==IMAGE and (c['Config'].get('Labels') or {}).get('chio.owner')==o['volume']
 assert sorted((m['Type'],m.get('Name'),m['Destination']) for m in c['Mounts'])==sorted([('volume',o['volume'],'/workspace'),('volume',o['auditVolume'],'/audit')])

results=[]
for plan in plans:
 o=plan['operator'];state=Path(o['stateDir']);record={'state':str(state),'volume':o['volume'],'auditVolume':o['auditVolume'],'completionProof':plan['completionProof'],'at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 try:
  assert hashlib.sha256((state/'operator.json').read_bytes()).hexdigest()==o['operatorFileSha256'],'operator identity changed'
  assert int((state/'kernel.pid').read_text())==o['pid'],'owner restarted since inventory'
  assert not refs(o),'active non-owner reference appeared'
  for cid in o['containerIds']:
   c=inspect(cid)
   if c:verify_container(c,o)
  persistent=[p for p in state.rglob('*') if p.is_file() and (p.suffix in ['.sqlite','.db'] or 'journal' in p.name)]
  record['persistentFilesBefore']=[str(p.relative_to(state)) for p in persistent]
  cmd=['python3',str(HELPER),'stop','--state-dir',str(state)]
  r=subprocess.run(cmd,capture_output=True,text=True,timeout=25)
  record.update(command=cmd,exitCode=r.returncode,stdout=r.stdout,stderr=r.stderr)
  assert r.returncode==0,'owner stop failed'
  record['leftoverContainerStops']=[]
  for cid in o['containerIds']:
   c=inspect(cid)
   if not c or not c['State']['Running']:continue
   verify_container(c,o)
   # Only this exact stopped owner's resource container is eligible.
   r=subprocess.run(['docker','stop','--time','10',cid],capture_output=True,text=True,timeout=20)
   record['leftoverContainerStops'].append({'containerId':cid,'exitCode':r.returncode,'stdout':r.stdout,'stderr':r.stderr})
   assert r.returncode==0,'resource stop failed'
  record['containersStopped']=[cid for cid in o['containerIds'] if not (inspect(cid) or {}).get('State',{}).get('Running',False)]
  record['missingPersistentFiles']=[str(p.relative_to(state)) for p in persistent if not p.is_file()]
  assert not record['missingPersistentFiles'],'persistent file missing'
  record['namedVolumesPreserved']=all(subprocess.run(['docker','volume','inspect',name],capture_output=True).returncode==0 for name in [o['volume'],o['auditVolume']])
  assert record['namedVolumesPreserved'],'named volume absent'
  record['passed']=True
 except Exception as e:
  record.update(passed=False,errorType=type(e).__name__,error=str(e))
 results.append(record);(OUT/'additional-actions.json').write_text(json.dumps(results,indent=2)+'\n')
 print(json.dumps({'state':state.name,'passed':record['passed'],'stoppedContainers':len(record.get('containersStopped',[]))}),flush=True)
 if not record['passed']:break
(OUT/'additional-drain-summary.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'plannedOwners':len(plans),'ownersStopped':sum(r.get('exitCode')==0 for r in results),'resourceContainersStopped':sum(len(r.get('containersStopped',[])) for r in results),'failures':[r['state'] for r in results if not r['passed']],'doubtfulOwnersUntouched':sorted(SKIP),'helperSha256':hashlib.sha256(HELPER.read_bytes()).hexdigest(),'scope':'Only completed prior-run owners. No current static/final owner, unrelated container, daemon setting, private database, journal or named volume removed.'},indent=2)+'\n')
