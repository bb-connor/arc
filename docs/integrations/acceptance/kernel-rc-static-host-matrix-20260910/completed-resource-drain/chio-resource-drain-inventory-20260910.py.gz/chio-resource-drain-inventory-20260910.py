from pathlib import Path
import json,subprocess,hashlib,datetime
OUT=Path('/tmp/chio-completed-resource-drain-20260910');OUT.mkdir(mode=0o700,exist_ok=True)
IMAGE='sha256:188cb84d5d0bb4063d4ce5a3b9c3832445a5acda5604911cda80a9136d1850a0'
ROOT=Path('/Users/connor/Medica/backbay/standalone/arc/.worktrees/required-agent-integrations-20260909')
prior=ROOT/'docs/integrations/acceptance/completed-native-owners-20260910.json'
(OUT/'previous-completed-owner-stops.json').write_bytes(prior.read_bytes())
ids=subprocess.check_output(['docker','ps','-q'],text=True).split()
inspection=subprocess.run(['docker','inspect',*ids],capture_output=True,text=True)
full=json.loads(inspection.stdout)
(OUT/'inventory-race.json').write_text(json.dumps({'exitCode':inspection.returncode,'stderr':inspection.stderr,'note':'Completed ephemeral containers may disappear during this read-only snapshot; no missing container is acted on'},indent=2)+'\n')
safe=[]
for c in full:
 mounts=[{k:m[k] for k in ['Type','Name','Destination','RW'] if k in m} for m in c['Mounts']]
 safe.append({'id':c['Id'],'name':c['Name'],'image':c['Image'],'running':c['State']['Running'],'startedAt':c['State']['StartedAt'],'ownerLabel':(c['Config'].get('Labels') or {}).get('chio.owner'),'mounts':mounts})
(OUT/'before.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'containers':safe},indent=2)+'\n')
operators=[]
for p in Path('/Users/connor/.local/share/chio-required-operators').rglob('operator.json'):
 if p.is_symlink():continue
 try:d=json.loads(p.read_text())
 except (ValueError,OSError):continue
 if 'volume' not in d:continue
 found=[c['id'] for c in safe if c['image']==IMAGE and any(m.get('Name')==d['volume'] and m['Destination']=='/workspace' for m in c['mounts'])]
 if not found:continue
 record={k:d[k] for k in ['stateDir','volume','auditVolume','kernelSha256','port','image'] if k in d}
 record.update(operatorFile=str(p),operatorFileSha256=hashlib.sha256(p.read_bytes()).hexdigest(),containerIds=found)
 pidfile=p.parent/'kernel.pid'
 if pidfile.is_file():
  pid=int(pidfile.read_text());r=subprocess.run(['ps','-p',str(pid),'-o','command='],capture_output=True,text=True)
  record.update(pid=pid,processPresent=r.returncode==0 and bool(r.stdout.strip()),processIdentityMatches=r.returncode==0 and d['command'][0] in r.stdout and str(p.parent/'sessions.sqlite') in r.stdout)
 operators.append(record)
(OUT/'operators.json').write_text(json.dumps(operators,indent=2)+'\n')
for o in operators:
 print(json.dumps({'state':o['operatorFile'],'volume':o['volume'],'containers':len(o['containerIds']),'live':o.get('processPresent'),'pidMatch':o.get('processIdentityMatches'),'protectedCurrent': '20260910' in o['volume'] and o['stateDir'] not in {r['state'] for r in json.loads(prior.read_text())['results']}}))
print('running containers',len(safe),'mapped resource owners',len(operators))
