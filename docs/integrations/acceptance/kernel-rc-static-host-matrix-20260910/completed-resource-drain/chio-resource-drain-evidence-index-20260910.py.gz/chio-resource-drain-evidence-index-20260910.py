from pathlib import Path
import gzip,json,subprocess
OUT=Path('/tmp/chio-completed-resource-drain-20260910')
ops=json.loads((OUT/'operators.json').read_text());candidates=[o for o in ops if '20260909' in o['volume'] or 'claude-contract' in o['volume']]
base=Path('/Users/connor/Medica/backbay/standalone')
roots=[base/'arc/.worktrees/required-agent-integrations-20260909/docs/integrations/acceptance',base/'arc/.worktrees/required-agent-integrations-20260909/sdks/python/chio-hermes/evidence']
for repo in ['chio-claude-code-plugin','chio-codex-plugin','chio-open-claw-plugin','chio-cursor-plugin','chio-bridge']:
 p=base/repo/'.worktrees/required-agent-integrations-20260909'
 for suffix in ['acceptance','evidence','docs']:
  if (p/suffix).is_dir():roots.append(p/suffix)
for suffix in ['evidence','docs']:
 roots.append(base/'chio-pi-plugin'/suffix)
index={o['stateDir']:[] for o in candidates}
for root in roots:
 for f in root.rglob('*'):
  if not f.is_file() or f.is_symlink() or f.suffix not in ['.gz','.json','.jsonl','.md','.txt']:continue
  try:b=gzip.decompress(f.read_bytes()) if f.suffix=='.gz' else f.read_bytes()
  except (OSError,EOFError):continue
  for o in candidates:
   if o['stateDir'].encode() in b or o['volume'].encode() in b:
    index[o['stateDir']].append(str(f))
(OUT/'completion-evidence-index.json').write_text(json.dumps(index,indent=2)+'\n')
for o in candidates:
 hits=index[o['stateDir']]
 hits.sort(key=lambda x:(not any(n in Path(x).name.lower() for n in ['readme','result','summary','manifest','final']),len(x)))
 print(json.dumps({'state':o['stateDir'],'hits':len(hits),'examples':hits[:7]}))
