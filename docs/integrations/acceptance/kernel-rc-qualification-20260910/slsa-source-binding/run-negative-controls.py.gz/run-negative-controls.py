from pathlib import Path
import base64, concurrent.futures, hashlib, json, subprocess
root=Path(__file__).parent
base=json.loads((root/'actual-upstream-cosign.json').read_text())['args']
cases={}
for name,flag,value in [('foreign-builder','--certificate-identity','https://github.com/slsa-framework/slsa-github-generator/.github/workflows/generator_generic_slsa3.yml@f7dd8c54c2067bafc12ca7a55595d5ee9b75204a'),('foreign-source','--certificate-github-workflow-sha','a'*40),('foreign-repository','--certificate-github-workflow-repository','backbay-labs/chio'),('foreign-ref','--certificate-github-workflow-ref','refs/tags/v0.1.1-rc.1'),('foreign-issuer','--certificate-oidc-issuer','https://issuer.invalid')]:
    args=base.copy(); args[args.index(flag)+1]=value; cases[name]=args
changed=root/'modified-artifact'; changed.write_bytes((root/'upstream-generic-binary').read_bytes()+b'negative-control')
args=base.copy(); args[-1]=str(changed); cases['modified-artifact']=args
for kind in ('signature','payload'):
    bundle=json.loads((root/'upstream-generic-example.intoto.jsonl').read_text())
    if kind=='signature':
        raw=bytearray(base64.b64decode(bundle['dsseEnvelope']['signatures'][0]['sig'])); raw[-1]^=1
        bundle['dsseEnvelope']['signatures'][0]['sig']=base64.b64encode(raw).decode()
    else:
        raw=base64.b64decode(bundle['dsseEnvelope']['payload'])+b' '
        bundle['dsseEnvelope']['payload']=base64.b64encode(raw).decode()
    path=root/f'modified-{kind}.json'; path.write_text(json.dumps(bundle))
    args=base.copy(); args[args.index('--bundle')+1]=str(path); cases[f'modified-{kind}']=args

def execute(item):
    name,args=item; p=subprocess.run(args,capture_output=True,timeout=90)
    (root/f'negative-{name}.stdout').write_bytes(p.stdout)
    (root/f'negative-{name}.stderr').write_bytes(p.stderr)
    result={'name':name,'args':args,'exitCode':p.returncode,'expectedRejection':True}
    (root/f'negative-{name}.json').write_text(json.dumps(result,indent=2)+'\n')
    return result
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as executor:
    results=list(executor.map(execute,cases.items()))
assert all(p['exitCode']!=0 for p in results)
(root/'negative-controls.json').write_text(json.dumps({'scope':'Actual official upstream signed fixture only; no Chio hosted positive claimed.','results':results},indent=2)+'\n')
for result in results: print(result['name'],result['exitCode'])
