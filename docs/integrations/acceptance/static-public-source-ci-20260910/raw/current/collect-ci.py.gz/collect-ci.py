import datetime,gzip,hashlib,json,re,subprocess,sys
from pathlib import Path
base=Path('/tmp/chio-static-public-source-ci-final-20260910');repo=sys.argv[1];pr=json.loads((base/(repo+'-pr.json')).read_text());commands=[]
old=Path('/Users/connor/Medica/backbay/standalone/arc/.worktrees/required-agent-integrations-20260909/docs/integrations/acceptance/20260909/raw/publication-and-ci')
cached={('chio-codex-plugin','102790439048'):Path('/tmp/chio-final-codex-silent-omission-ci-20260910/final-head.log.gz'),('chio-bridge','102740489703'):old/'bridge-success-job.log.gz'}
def call(name,argv):
 r=subprocess.run(argv,capture_output=True,timeout=60);(base/(name+'.stderr')).write_bytes(r.stderr);commands.append({'command':argv,'exitCode':r.returncode,'observedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat()});(base/(repo+'-ci-commands.json')).write_text(json.dumps(commands,indent=2)+'\n')
 if r.returncode:raise RuntimeError('CI data retrieval failed; inspect retained stderr')
 return r.stdout
runs={};jobs=[]
for check in pr['statusCheckRollup']:
 assert check['status']=='COMPLETED' and check['conclusion']=='SUCCESS'
 run,job=re.search(r'/actions/runs/(\d+)/job/(\d+)',check['detailsUrl']).groups()
 if run not in runs:
  raw=call(repo+'-run-'+run,['gh','run','view',run,'--repo','backbay-labs/'+repo,'--json','databaseId,url,status,conclusion,headSha,event,createdAt,updatedAt,jobs']);(base/(repo+'-run-'+run+'.json')).write_bytes(raw);data=json.loads(raw);assert data['status']=='completed' and data['conclusion']=='success' and data['headSha']==pr['headRefOid'];runs[run]=data
 if (repo,job) in cached:
  p=cached[(repo,job)];body=gzip.decompress(p.read_bytes());origin={'cachedLog':str(p),'cachedCompressedSha256':hashlib.sha256(p.read_bytes()).hexdigest()}
 else:
  body=call(repo+'-job-'+job,['gh','api','repos/backbay-labs/'+repo+'/actions/jobs/'+job+'/logs']);origin={'command':['gh','api','repos/backbay-labs/'+repo+'/actions/jobs/'+job+'/logs']}
 target=base/(repo+'-job-'+job+'.log.gz');target.write_bytes(gzip.compress(body,mtime=0))
 lines=body.decode().splitlines();checkouts=[]
 for i,line in enumerate(lines[:-1]):
  if '[command]' in line and 'git log -1 --format=%H' in line:
   match=re.search(r'\b([0-9a-f]{40})\s*$',lines[i+1]);assert match,(repo,job,line)
   checkouts.append({'sha':match.group(1),'commandLine':i+1,'valueLine':i+2,'context':lines[max(0,i-2):i+3]})
 assert checkouts,(repo,job)
 jobs.append({'jobId':int(job),'runId':int(run),'url':check['detailsUrl'],'name':check['name'],'status':check['status'],'conclusion':check['conclusion'],'completedAt':check['completedAt'],'log':target.name,'logSha256':hashlib.sha256(body).hexdigest(),'logBytes':len(body),'compressedSha256':hashlib.sha256(target.read_bytes()).hexdigest(),'provenance':origin,'actualCheckouts':checkouts})
(base/(repo+'-executed-source.json')).write_text(json.dumps({'repository':'backbay-labs/'+repo,'head':pr['headRefOid'],'jobs':jobs},indent=2)+'\n')
print(repo,'completed successful jobs',len(jobs),'first checkout(s)',[j['actualCheckouts'][0]['sha'] for j in jobs])
