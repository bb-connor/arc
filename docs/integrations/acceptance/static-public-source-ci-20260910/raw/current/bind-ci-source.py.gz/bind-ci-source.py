from pathlib import Path
import datetime,json,subprocess,sys
base=Path('/tmp/chio-static-public-source-ci-final-20260910');repo=sys.argv[1]
source=json.loads((base/(repo+'-executed-source.json')).read_text());head=source['head'];commits={};commands=[]
for sha in sorted({head}|{j['actualCheckouts'][0]['sha'] for j in source['jobs']}):
 cmd=['gh','api','repos/backbay-labs/'+repo+'/git/commits/'+sha]
 r=subprocess.run(cmd,capture_output=True,timeout=45)
 name=repo+'-commit-'+sha;(base/(name+'.json')).write_bytes(r.stdout);(base/(name+'.stderr')).write_bytes(r.stderr);commands.append({'command':cmd,'exitCode':r.returncode,'observedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat()})
 if r.returncode:raise RuntimeError('Commit metadata retrieval failed')
 d=json.loads(r.stdout);assert d['sha']==sha;commits[sha]=d
(base/(repo+'-git-commands.json')).write_text(json.dumps(commands,indent=2)+'\n')
bindings=[]
for job in source['jobs']:
 checkout=job['actualCheckouts'][0]['sha'];actual=commits[checkout]
 binding={'jobId':job['jobId'],'runId':job['runId'],'jobUrl':job['url'],'name':job['name'],'completedAt':job['completedAt'],'conclusion':job['conclusion'],'actualJobCheckout':checkout,'actualJobTree':actual['tree']['sha'],'topicHeadTree':commits[head]['tree']['sha'],'treeEquivalent':actual['tree']['sha']==commits[head]['tree']['sha'],'mergeParentShas':[p['sha'] for p in actual['parents']],'topicHeadIsMergeParent':head in [p['sha'] for p in actual['parents']],'rawLogPath':job['log'],'rawLogSha256':job['logSha256'],'otherRecordedCheckouts':job['actualCheckouts'][1:]}
 assert binding['treeEquivalent'] and binding['topicHeadIsMergeParent'];bindings.append(binding)
result={'repository':source['repository'],'prHead':head,'topicHeadTree':commits[head]['tree']['sha'],'jobs':bindings,'scope':'Successful source/package CI at the exact recorded synthetic merge checkout. Equal source trees do not equate commits or establish host acceptance, final frozen archive qualification or release.'}
(base/(repo+'-source-tree-binding.json')).write_text(json.dumps(result,indent=2)+'\n')
print(repo,'tree',result['topicHeadTree'],'all job source bindings verified')
