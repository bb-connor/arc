from pathlib import Path
import datetime,gzip,hashlib,json,re
base=Path('/tmp/chio-static-public-source-ci-final-20260910')
root=Path('/Users/connor/Medica/backbay/standalone/arc/.worktrees/required-delivery-readiness-20260910/docs/integrations/acceptance/static-public-source-ci-20260910')
root.mkdir()
repos=['chio-claude-code-plugin','chio-codex-plugin','chio-cursor-plugin','chio-open-claw-plugin','chio-pi-plugin','chio-test-harness','chio-bridge','chio']
labels=['Claude Code','Codex','Cursor','OpenClaw','Pi','Shared harness','Shared bridge','Chio kernel and Hermes source']
summary=[]
for repo,label in zip(repos,labels):
 pr=json.loads((base/(repo+'-pr.json')).read_text());command=json.loads((base/(repo+'-pr-command.json')).read_text());checks={}
 for check in pr['statusCheckRollup']:
  key=check.get('conclusion') or check.get('status') or check.get('state');checks[key]=checks.get(key,0)+1
 entry={'component':label,'repository':'backbay-labs/'+repo,'url':pr['url'],'number':pr['number'],'head':pr['headRefOid'],'headRef':pr['headRefName'],'state':pr['state'],'draft':pr['isDraft'],'mergeState':pr['mergeStateStatus'],'observedAtUtc':command['observedAtUtc'],'checks':checks,'jobs':pr['statusCheckRollup']}
 if repo!='chio':entry['sourceBinding']=json.loads((base/(repo+'-source-tree-binding.json')).read_text())
 summary.append(entry)
(root/'summary.json').write_text(json.dumps({'recordedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Public draft source and bounded hosted source checks only; no artifact publication or host acceptance.','pullRequests':summary},indent=2)+'\n')
rows=[];binding_rows=[]
for r in summary:
 source_checks=', '.join(str(n)+' '+k.lower().replace('_',' ') for k,n in r['checks'].items())
 rows.append('| '+r['component']+' | [draft PR '+str(r['number'])+']('+r['url']+') | `'+r['head']+'` | '+source_checks+' |')
 for job in r.get('sourceBinding',{}).get('jobs',[]):
  binding_rows.append('| '+r['component']+' / '+job['name']+' | ['+job['conclusion']+']('+job['jobUrl']+') | `'+job['actualJobCheckout']+'` | `'+job['actualJobTree']+'` |')
first=min(r['observedAtUtc'] for r in summary);last=max(r['observedAtUtc'] for r in summary)
(root/'README.md').write_text('''# Public source CI checkpoint for the static candidate program

This record establishes public draft source availability and the exact source
checked by completed hosted jobs. It does not accept an agent host, promote the
local static bundle, publish a release, or close I01/I08 public installation.
Confidence is high in the captured API identities, raw logs and tree comparisons.
All six integrations remain mandatory under document 19.

The initial 08:11 UTC checkpoint is preserved byte-for-byte under
`raw/initial/`. The later PR snapshots below were captured from
`'''+first+'''` through
`'''+last+'''`. All eight PRs were open drafts. The
OpenClaw head advanced from the initial `647c4fef` snapshot to `ec426777`;
its new completed result is recorded separately, without rewriting the earlier
snapshot. Later remote changes require a new record.

| Component | Source PR | Exact captured head | Captured check rollup |
|---|---|---|---|
'''+ '\n'.join(rows)+'''

The Chio PR remains at source `bafa02b06de93553cecb6f60b340f3dd8fd9b401`.
Its `Build, lint, test` and `MSRV build and test` jobs are still in progress in
this snapshot. Eleven skipped jobs remain explicitly listed in `summary.json`
and the raw API response. Neither running nor skipped jobs are treated as
successful checks. This PR does not contain the program's later local evidence
commits merely because they exist in an owning worktree. No claim here says the
final program source head or complete root CI has passed.

## Actual successful checkout identities

The seven standalone repositories have eight completed successful jobs. Their
workflow runs name the exact recorded topic heads, while the job logs identify
actual synthetic merge checkouts. GitHub Git-object responses prove each first
job checkout's complete tree equals its topic head's tree and the topic head is
a merge parent. Commit identities remain distinct. Both harness jobs are bound
separately. The full responses, exact log line contexts and every additional
checkout are retained in `raw/current/` and `summary.json`.

| Component and job | Captured result | Actual job checkout | Tree equal to recorded topic head |
|---|---|---|---|
'''+ '\n'.join(binding_rows)+'''

Claude's source suite records 32 passed and one skipped test: `trusted host
supervisor stops its process group when the parent lifeline closes`. Cursor's
source suite records 32 passed and one skipped test: `actual macOS process
boundary blocks operator reads, aliases, links, writes and unrelated network`.
These skipped checks provide no execution evidence here. Codex records 32
passed, OpenClaw 25, and Pi 23. The harness delivery-integrity job records 13
passing integrity tests. Its separate self-test job also succeeds, but explicitly
checks out historical kernel source `d8c5f53705173e614a853bad6c0a85acfdf1212b`.

The bridge records 144 component tests and 16 real-kernel API tests. That job
checks out the same historical `d8c5f537` kernel and separate harness source
`05945ccf4f652a22801c9ab35cabf99456ef76c9`. These API and self-test results are
not evidence for the frozen static binary `c03a8a711dbbd15d...`, kernel source
`bafa02b0`, or any final real-host acceptance matrix. Successful source packaging
or clean consumer checks also do not establish that the locally selected frozen
archive was executed by CI or publicly released. Per-host exact-artifact records
remain authoritative for those independent claims.

The Codex and bridge log bytes were reused from existing exact-job captures;
source and compressed hashes identify those retained inputs. Remaining completed
job logs were retrieved read-only from their precise GitHub job IDs. OpenClaw's
existing anonymous HTTP-200 repository, PR, commit and evidence-source checks
are retained under `raw/openclaw-public/`; its exact merge/head tree binding was
also independently rechecked here. No native host, kernel, CI rerun, merge,
package publication or release operation was performed for this record.

## Evidence and unresolved delivery

`raw-files.json` binds every retained source byte stream to its lossless compressed
copy. `SHA256SUMS` covers this record. Credential exclusion scans compare both
plain files and decompressed raw files against known provider, npm, operator and
delegated credentials without exporting secret values. Raw completed logs retain
all skips and outcomes; initial snapshots and later observations stay separate.

No selected kernel/plugin/SDK package or bundle identity was modified. The actual
hosted release build, required source/release gates, public artifact downloads,
provenance verification and per-host cold installation/lifecycle tests must
still establish usable public delivery. Cursor's supported enforcement contract
and every host's acceptance status are separate program records, not conclusions
that can be inferred from these green source checks.
''')
records=[]
def retain(group,p):
 destination=root/'raw'/group/(p.name if p.suffix=='.gz' else p.name+'.gz');destination.parent.mkdir(parents=True,exist_ok=True)
 src=p.read_bytes()
 if p.suffix=='.gz':original=gzip.decompress(src);encoded=src
 else:original=src;encoded=gzip.compress(src,mtime=0)
 destination.write_bytes(encoded)
 records.append({'path':str(destination.relative_to(root)),'originalPath':str(p),'sourceBytes':len(original),'sourceSha256':hashlib.sha256(original).hexdigest(),'sha256':hashlib.sha256(encoded).hexdigest(),'compressedBytes':len(encoded)})
for p in sorted(Path('/tmp/chio-static-source-ci-checkpoint-20260910').iterdir()):
 if p.is_file():retain('initial',p)
for p in sorted(base.iterdir()):
 if p.is_file():retain('current',p)
public=Path('/tmp/chio-openclaw-public-draft-20260910')
for name in ['anonymous-commit.json','anonymous-evidence-readme.md','anonymous-pr-merge-commit.json','anonymous-pr.json','anonymous-repository.json','public-verification.json','summary.json','SHA256SUMS.json']:
 retain('openclaw-public',public/name)
(root/'raw-files.json').write_text(json.dumps(records,indent=2)+'\n')
for r in records:
 data=(root/r['path']).read_bytes();original=gzip.decompress(data)
 assert hashlib.sha256(data).hexdigest()==r['sha256'] and hashlib.sha256(original).hexdigest()==r['sourceSha256'] and len(original)==r['sourceBytes']
print('Retained',len(records),'lossless raw files; 8 PR snapshots and 8 successful job bindings')
