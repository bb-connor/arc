"""Qualification budgets cannot be raised or satisfied by empty measurements."""
from copy import deepcopy
import json
from pathlib import Path
import unittest

import package_measurements
from package_measurements import audit_performance


class PerformanceAuditTest(unittest.TestCase):
    def test_error_empty_charge_mismatch_and_changed_ceiling_refuse(self):
        pure = {name: {"samples": 1000, "warmups": 100, "p95_ns": 10,
                      "p95_ceiling_ns": ceiling}
                for name, ceiling in {"intake": 5000000, "digest": 250000,
                                      "reduction": 250000, "graph_16_steps": 1000000}.items()}
        pure.update(errors=0, profile="debug")
        good = {"passed": True, "native_p95_ceiling_ns": 220683049, "pure": pure,
                "native": {"samples": 64, "warmups": 8, "replays": 8,
                           "p95_ns": 100, "errors": 0, "profile": "debug",
                           "effect_count": 72, "logical_call_charges": 72}}
        audit_performance(good)
        for mutation in ["error", "empty", "charges", "ceiling", "slow", "pure"]:
            row = deepcopy(good)
            if mutation == "error": row["native"]["errors"] = 1
            elif mutation == "empty": row["native"]["samples"] = 0
            elif mutation == "charges": row["native"]["logical_call_charges"] = 73
            elif mutation == "ceiling": row["native_p95_ceiling_ns"] += 1
            elif mutation == "slow": row["native"]["p95_ns"] = 220683050
            else: row["pure"]["digest"]["samples"] = 0
            with self.assertRaises(ValueError, msg=mutation): audit_performance(row)

    def test_passing_budget_cannot_substitute_an_unmeasured_faster_value(self):
        evidence = Path(__file__).parent
        actual = json.loads((evidence / "performance.json").read_bytes())
        native = (evidence / "logs/task-5-native-performance.log").read_text()
        pure = (evidence / "logs/task-5-pure-performance.log").read_text()
        package_measurements.audit_performance_logs(actual, native, pure)
        altered = deepcopy(actual)
        altered["native"]["p95_ns"] -= 1
        audit_performance(altered)
        with self.assertRaises(ValueError):
            package_measurements.audit_performance_logs(altered, native, pure)
        for changed_native, changed_pure in [
            (native.replace("1 passed; 0 failed; 0 ignored", "0 passed; 0 failed; 1 ignored"), pure),
            (native + native, pure),
            (native, ""),
            (native, pure + pure),
        ]:
            with self.assertRaises(ValueError):
                package_measurements.audit_performance_logs(actual, changed_native, changed_pure)


if __name__ == "__main__": unittest.main()
