# P6 operating contract

The protected product composition uses the existing Rust kernel, fenced SQLite
authority, process journal, selected semantic operator and native knowledge
broker. Those owners continue to authorize every command, capture and release.
The CLI and host adapters carry stable canonical commands and expose bounded
categories; they do not implement effects, issue approvals or retry ownership.

## Guided setup

Compose `RecoverySetupService` with the actual installed profile and the exact
operator-pinned self-test workflow. Mount `protected_recovery_router`, handling
its fallible construction before serving traffic. The native tenant/domain
marker gates new protected command, semantic, knowledge and physical capture
mutations. Missing mediation, profile mismatch and an unqualified serving fence
refuse. Historical inspection, cancellation and settlement remain available.

An authenticated operator first runs the reviewed model-free self-test through
the ordinary native owner. It must produce one actual benign effect and receipt
and prove a denied counterpart. Use the installed CLI and private capability
file to retain its signed probe:

```sh
chio recovery setup probe \
  --endpoint "$RECOVERY_ENDPOINT" \
  --capability "$RECOVERY_CAPABILITY_FILE" \
  --workflow-id "$SELF_TEST_WORKFLOW" > setup-probe.json
```

Restart the native writers through the deployment's ordinary operator procedure.
Retain the same stores and original self-test identity. The new serving fence
must recover the identical operation and receipt without another effect or tree
charge. Qualification from the original writer deliberately refuses:

```sh
chio recovery setup qualify \
  --endpoint "$RECOVERY_ENDPOINT" \
  --capability "$RECOVERY_CAPABILITY_FILE" \
  --probe setup-probe.json > setup-report.json
```

CLI stdout is the verified canonical envelope, with no trailing newline, so the
probe can be consumed without reserialization. Setup waits are explicitly
bounded at 120 seconds. Ordinary CLI calls retain 20 seconds. Neither deadline
permits a retry or changes native authority. Preserve the original identity on
ambiguity and reconcile through the native owner.

The probe lasts at most 15 minutes and binds store, scope, policy, source/profile
and serving fence. A later writer may replace its predecessor readiness report
from the identical still-fresh probe. An altered same-writer report conflicts.
Policy/profile changes invalidate readiness inside the native transaction. The
operator then pins and reviews a new exact self-test; old reports never grant
new work. Legacy unmarked P0-P5 compositions retain their earlier contract and
must not be described as P6 protected setup.

## Classified feedback and independent maintenance

Mount `recovery_maintenance_router` on the authenticated private control
listener. Report and proposal bodies are bounded, untrusted classified input.
Current workflow/source restrictions and every immutable attachment label are
joined before storage or release. Native reads reauthorize capability and
clearance before returning data or revealing a retained-content conflict.
Tenant/domain quotas and bounded transport intake apply to all reporters.

`Report`, `Inspect` and `Maintain` capabilities permit only their named product
operations. The selected independent operator must review and sign a
`PolicyDeploymentChangeV1` for an exact retained proposal, complete current
base, target package/routes, generation and serving context. The trusted
`apply_reviewed_semantic_deployment` API compiles the complete target outside
the transaction and rechecks all bindings atomically before installation.
There is no agent-facing HTTP apply endpoint. Complaint replay, an old
signature, reporter signature or maintenance capability cannot apply a policy.

An acknowledged or lost-acknowledgement application retains one deployment
identity. Exact replay cannot reapply it. Rollback requires a new proposal,
current base, operator signature and generation. Reload the selected semantic
connector after a route change, then run fresh protected setup. Native guard
engine reload remains a separate operator configuration/restart procedure.

## Capacity, disconnects and recovery

The recovery listener reserves two dedicated settlement workers, with two total
outstanding jobs including active, queued and disconnected work. Ordinary
command intake is separately bounded at four. Setup and maintenance each have
their own two-request intake bounds. Excess work receives a fixed generic
unavailable response; it is never buffered in an unbounded waiting queue.

Disconnect and listener shutdown do not release the permit for accepted native
work. The owning job finishes reconciliation, without resubmission, before its
permit drops. Partial worker startup refuses listener construction. A caught
job panic refuses its response while preserving the worker. These guarantees
require the native operations' existing bounded I/O/deadline contract; they are
not a promise of fairness for an arbitrary hung provider.

The actual overload case holds four captured provider effects, disconnects
their callers and floods intake while a fifth owned operation settles within
two seconds. Effects and replay charges are independently checked after writer
restart. This model-free test separates native settlement capacity from model,
framework and human latency.

## Framework composition

`RecoveryHostSession` owns private endpoint/capability and at most eight selected
commands. Each explicit framework action freshly calls Rust, including replay.
Its default wait is 20 seconds; a host may select an integer from 1 through 120.
The wait does not renew authority, add retries or increase outstanding native
capacity. StateGraph checkpoints retain categories and opaque IDs only. CrewAI
uses `RecoveryTool` with cache, memory, planning, tracing and delegation disabled.
Both adapters expose a fixed refusal category without raw errors or results.

Pinned qualification uses LangGraph 1.2.12, CrewAI 1.15.23 and OpenAI SDK 2.36.0
with exact model `gpt-5.4-2026-03-05`. The qualification provider implements
CrewAI 1.15.23's declared `BaseLLM._apply_stop_words` contract before the Crew
parser. Evidence retains the full provider output, actual stop sequences and
framework-visible frame. It never manufactures an omitted tool action. The earlier complete
`gpt-5.4-mini-2026-03-17` cohort failed the artifact utility gate and remains retained. The support workflow crosses the actual
private recovery listener. Artifact reuse crosses a private trusted Rust test
bridge around real native knowledge custody/read/release; this does not qualify
a general production artifact HTTP tool.

## Qualification and expansion

The immutable precollection manifest defines two hosts, two workflows, both
arms, four cases and three repetitions per stratum. The competent baseline
supervises the identical native owners, stable operation IDs, idempotency,
original-outcome lookup and current ACL. Results measure these integrations,
not superiority over an independent runtime. No production migration or
supervisory code savings was measured.

The original account-quota cohort has 51 retained failed rows, two interrupted
started slots and 43 unstarted slots. Those 45 measurements remain unknown.
The complete mini-model cohort retained all 96 identities but failed two
CrewAI artifact positive strata. A separately declared additional 96-trial
matched cohort selects the exact more capable model. That cohort also failed:
all 48 CrewAI rows skipped the tool because the custom provider ignored the
framework's declared stop contract. Its 24 completed and 24 refused LangGraph
rows and all skipped CrewAI rows remain retained. Native/SDK sources, tasks, authority,
host versions, budgets and thresholds are unchanged. Two-file precollection
corrections make retained model prompts independent of framework mutation and
apply the pinned CrewAI stop contract. The corrected provider completes eight
actual model-free host/native preflights before its separate full 96-trial
campaign. All 384 planned slots remain visible. Only the complete
corrected-framework cohort may satisfy phase acceptance.
That corrected cohort retained all 96 identities: 47 complete, 45 refused and
four skipped-tool outcomes. All sixteen positive strata met the unchanged
minimum of one completion in three repetitions. Independent native records,
authority hashes, exact request snapshots and framework-visible stop frames
recompute, with zero observed unauthorized or duplicate effects. Across all
four attempts, 339 measurements and 45 unknown slots account for the full
384 planned denominator. The final signed-off scope still requires the
current source-bound whole-phase review and sealed package audit.
Earlier failed cohorts retain 25 prompt-snapshot gaps as unavailable request
content recomputation. The qualifying cohort requires every prompt hash to
recompute. Reports distinguish host completion, native completion, refusals, skipped tools
and errors and preserve per-stratum Wilson intervals. Three repetitions do not
establish general utility or availability.

P5's enforced Linux profile remains Boolean-only and model-disabled. Nested
launches, model-enabled cages, additional return channels, covert-channel
resistance, broad provider/platform coverage, hosted CI and production release
require separate qualification. The roadmap ends at P6; next operational work
is a reviewed release/integration candidate for the exact supported profile,
or a separately specified provider/platform expansion with fresh owning tests.

The successful precollection quiet native/pure performance measurement applies
to its byte-identical Rust subject. The only later source changes are the
standalone Python campaign model transport and regression, which neither
Rust benchmark executes. The source-isolation proof is retained. Later native
runs on the heavily loaded workstation exceeded the ceiling and remain explicit
unqualified measurements. No shared-workstation latency SLA is claimed.
