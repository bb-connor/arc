"""Validate measured budgets and the limited scope of finite assurance."""
import json
import re

from inventory import PHASE, ROOT, sha
from package_audit import refuse

PURE_CEILINGS = {"intake": 5000000, "digest": 250000,
                 "reduction": 250000, "graph_16_steps": 1000000}


def audit_performance(row):
    native = row["native"]
    refuse(row["passed"] is True and row["native_p95_ceiling_ns"] == 220683049,
           "performance_ceiling")
    refuse(native["samples"] == 64 and native["warmups"] == native["replays"] == 8,
           "performance_denominator")
    refuse(native["errors"] == 0 and native["profile"] == "debug"
           and native["effect_count"] == native["logical_call_charges"] == 72,
           "performance_effects")
    refuse(type(native["p95_ns"]) is int and 0 < native["p95_ns"] <= 220683049,
           "performance_latency")
    pure = row["pure"]
    refuse(pure["errors"] == 0 and pure["profile"] == "debug", "pure_errors")
    for name, ceiling in PURE_CEILINGS.items():
        sample = pure[name]
        refuse(sample["samples"] == 1000 and sample["warmups"] == 100
               and sample["p95_ceiling_ns"] == ceiling
               and type(sample["p95_ns"]) is int and 0 < sample["p95_ns"] <= ceiling,
               "pure_budget")
    return row


def audit_performance_logs(row, native_log, pure_log):
    audit_performance(row)
    for name, prefix, text in [("native", "P0_NATIVE_BASELINE ", native_log),
                               ("pure", "P0_PURE_BASELINE ", pure_log)]:
        records = [line[len(prefix):] for line in text.splitlines() if line.startswith(prefix)]
        refuse(len(records) == 1 and json.loads(records[0]) == row[name],
               "performance_log_recomputation")
    refuse("test measured_native_baseline ... ok" in native_log
           and re.findall(r"test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored", native_log)
               == [("1", "0", "0")], "performance_actual_test")
    return row


def audit_adoption(row):
    paths = ["sdks/python/chio-sdk-python/src/chio_sdk/recovery_host.py",
             "sdks/python/chio-langgraph/src/chio_langgraph/recovery.py",
             "sdks/python/chio-crewai/src/chio_crewai/recovery.py",
             "fixtures/recovery-product/campaign_baseline.py"]
    measured = []
    for path in paths:
        data = (ROOT / path).read_bytes()
        measured.append({"path":path, "lines":len(data.splitlines()), "bytes":len(data)})
    refuse(row["measured_source_files"] == measured
           and row["supervisory_code_removed_lines"] == 0, "adoption_source_measurements")
    cli = json.loads((PHASE / "evidence/task-3-cli-linux-canonical/result.json").read_bytes())
    refuse(row["cli"] == cli and cli["passed"] is True
           and cli["effects"] == cli["tree_calls"] == 1
           and cli["operator_actions"] == [
               {"action":"probe", "exit_code":0}, {"action":"qualify", "exit_code":1},
               {"action":"operator_writer_restart", "exit_code":0},
               {"action":"qualify", "exit_code":0}], "adoption_native_cli")
    refuse(row["installation_actions_observed"] == [
        "Install pinned host/provider distributions", "Overlay exact current SDK sources",
        "Compose protected native listener and selected operator profile",
        "Execute existing reviewed self-test operation", "Probe native outcome",
        "Restart all native writers", "Qualify retained exact operation"], "adoption_action_inventory")
    return row


def audit_assurance():
    from assurance_map import build_map, verify_map
    evidence = PHASE / "evidence"
    mapping = json.loads((evidence / "assurance-map.json").read_bytes())
    verify_map(ROOT, mapping)
    refuse(build_map(ROOT) == mapping and mapping["full_system_proof"] is False,
           "assurance_current_scope")
    model = evidence / "model-current"
    row = json.loads((model / "evidence.json").read_bytes())
    refuse(row["warnings_denied"] is True and row["formatting_checked"] is True
           and row["toolchain"] == "+1.94.1" and "release: 1.94.1" in row["compiler"],
           "assurance_toolchain")
    for source in row["sources"]:
        refuse(sha(model / source["path"]) == source["sha256"]
               and sha(ROOT / "docs/architecture/recoverable-agent-runtime/model" / source["path"]) == source["sha256"],
               "model_source")
    outputs = []
    for run in row["runs"]:
        refuse(run["exit_code"] == 0 and sha(model / run["output"]) == run["output_sha256"],
               "model_execution")
        outputs.append((model / run["output"]).read_text())
    refuse(len(row["sources"]) == 8 and len(outputs) == 3
           and sum(text.count("MUTATION REJECTED") for text in outputs) == 20,
           "model_denominator")
    loom = (evidence / "logs/task-5-loom-current-green.log").read_text()
    refuse(re.search(r"test result: ok\. 18 passed; 0 failed; 0 ignored", loom)
           and "loom_real_session_admission_never_outlives_terminal ... ok" in loom,
           "loom_denominator")
    return {"mapping": mapping, "finite_model": row, "loom_tests": 18,
            "limitations": "Finite abstract models and session/foundation interleavings only; no complete SQL, two-store, provider or whole-system proof."}


def audit_performance_provenance(current_sources):
    from inventory import binding
    evidence = PHASE / "evidence"
    proof = json.loads((evidence / "performance-provenance.json").read_bytes())
    original = json.loads((evidence / "live-manifest/manifest.json").read_bytes())
    before = {row["path"]:row["sha256"] for row in original["sources"]}
    delta = [row for row in current_sources if before.get(row["path"]) != row["sha256"]]
    refuse({row["path"] for row in delta} == {"fixtures/recovery-product/campaign_runner.py",
                "fixtures/recovery-product/test_campaign_runner.py"}
           and proof["measured_runtime_binding"] == original["source_binding"]
           and proof["current_runtime_binding"] == binding(current_sources)
           and proof["non_subject_delta"] == delta
           and proof["unchanged_subject_sources"] == [row for row in current_sources if row not in delta],
           "performance_subject_source")
    qualified_logs = proof["qualified_logs"]
    refuse(set(qualified_logs) == {"native", "pure"}, "performance_log_inventory")
    texts = {}
    for name, item in qualified_logs.items():
        path = PHASE / item["path"]
        refuse(item["path"] == "evidence/logs/task-5-" + name + "-performance.log"
               and item["source_binding"] == original["source_binding"]
               and sha(path) == item["sha256"], "performance_log_binding")
        texts[name] = path.read_text()
    audit_performance_logs(json.loads((evidence / "performance.json").read_bytes()),
                           texts["native"], texts["pure"])
    for later in proof["later_unqualified_shared_host_measurements"]:
        log = (PHASE / later["log"]).read_text()
        measurement = json.loads(next(line.split(" ", 1)[1] for line in log.splitlines()
                                      if line.startswith("P0_NATIVE_BASELINE ")))
        refuse(measurement == later["measurement"]
               and later["budget_passed"] is (measurement["p95_ns"] <= 220683049),
               "retained_noisy_measurement")
    return proof
