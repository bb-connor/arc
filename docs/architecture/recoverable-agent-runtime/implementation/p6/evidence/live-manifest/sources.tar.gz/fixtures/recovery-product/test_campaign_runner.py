"""Model transport is injectable only because external provider I/O is unavoidable."""
import unittest
from campaign_runner import ModelBudget, selected_choice


class ModelBoundaryTest(unittest.TestCase):
    def test_only_closed_explicit_tool_selection_dispatches(self):
        self.assertEqual(selected_choice('Thought: Call it.\nAction: recovery\nAction Input: {"choice":"resume"}'), "resume")
        for text in ['Final Answer: complete', 'Action: recovery\nAction Input: {"choice":"other"}',
                     'Action: recovery\nAction Input: {"choice":"resume","capability":"canary"}',
                     'Action: recovery\nAction Input: {"choice":"resume","choice":"resume"}']:
            self.assertIsNone(selected_choice(text))

    def test_provider_failure_stays_generic_counted_and_never_retries(self):
        class Failure:
            def __init__(self): self.calls = 0
            def create(self, **kwargs):
                self.calls += 1
                raise RuntimeError("private-provider-key-canary")
        client = Failure()
        budget = ModelBudget("fixed-model", client, max_calls=1, prompt_bytes=100, output_tokens=8)
        with self.assertRaisesRegex(RuntimeError, '^campaign.provider_unavailable$'):
            budget.call([{"role":"user","content":"Public synthetic task"}])
        with self.assertRaisesRegex(RuntimeError, '^campaign.model_budget_exhausted$'):
            budget.call([{"role":"user","content":"Public synthetic task"}])
        self.assertEqual(client.calls, 1)
        self.assertEqual(len(budget.attempts), 1)
        self.assertNotIn("canary", str(budget.attempts))

    def test_prompt_bound_precedes_provider_io(self):
        class Never:
            def create(self, **kwargs): raise AssertionError("provider must not run")
        budget = ModelBudget("fixed-model", Never(), max_calls=1, prompt_bytes=8, output_tokens=8)
        with self.assertRaisesRegex(RuntimeError, '^campaign.prompt_budget_exhausted$'):
            budget.call([{"role":"user","content":"Too much public text"}])
        self.assertEqual(budget.attempts, [])


if __name__ == "__main__": unittest.main()
