//! Native P1 fixture bootstrap. Uses the production serving authority, receipt
//! writer, capability verifier and manifest resolver. The external effect server
//! is installed by the fixture, with independent durable effect accounting.
use super::*;
use chio_flow::CategoryLabelMap;
use chio_kernel::KernelConfig;
use chio_manifest::{
    sign_manifest, AuthoritativeToolPolicy, RuntimeToolTopology, ToolAnnotations, ToolDefinition,
    ToolFlowDeclaration, ToolManifest, VerifiedManifestRegistry, TOOL_MANIFEST_SCHEMA,
};
use chio_security_kernel::SecurityClock;
use chio_security_types::flow::Compartment;
use chio_security_types::ports::{
    ClassificationPort, ClassificationRequest, ClassificationResult, ClassifierId,
    ClassifierVersion, PortError, PortResult,
};
use chio_store_sqlite::SqliteReceiptStore;
use std::collections::BTreeSet;
pub(super) type TestResult<T = ()> = Result<T, Box<dyn std::error::Error>>;
pub(super) fn open_kernel(
    directory: &std::path::Path,
    authority: &SqliteAuthorityStore,
    signer: &Keypair,
) -> TestResult<(ChioKernel, Arc<AtomicUsize>)> {
    let mut kernel = ChioKernel::new(KernelConfig {
        ca_public_keys: vec![signer.public_key()],
        keypair: signer.clone(),
        max_delegation_depth: 5,
        policy_hash: chio_core::sha256_hex(b"native-flow-policy-test"),
        allow_sampling: false,
        allow_sampling_tool_use: false,
        allow_elicitation: false,
        max_stream_duration_secs: chio_kernel::DEFAULT_MAX_STREAM_DURATION_SECS,
        max_stream_total_bytes: chio_kernel::DEFAULT_MAX_STREAM_TOTAL_BYTES,
        require_web3_evidence: false,
        allow_ephemeral_receipt_log: false,
        allow_ephemeral_revocation_store: false,
        checkpoint_batch_size: chio_kernel::DEFAULT_CHECKPOINT_BATCH_SIZE,
        retention_config: None,
        memory_budget: chio_kernel::MemoryBudgetConfig::defaults(),
        deadlines: chio_kernel::HotPathDeadlineConfig::default(),
    });
    let receipts = SqliteReceiptStore::open(directory.join("receipts.db"))?;
    receipts.wait_for_writer_ready(std::time::Duration::from_secs(30))?;
    kernel.set_receipt_store_handle(Arc::new(receipts))?;
    kernel.set_durable_admission_store(
        Arc::new(authority.admission_operation_store()),
        Arc::new(authority.tool_outcome_store()),
        authority.mutation_fence(),
    )?;
    kernel.set_budget_store_handle(Arc::new(authority.budget_store()));
    kernel.set_revocation_store_handle(Arc::new(authority.revocation_store()));
    let invocations = Arc::new(AtomicUsize::new(0));
    Ok((kernel, invocations))
}

pub(super) fn now_ms() -> PortResult<u64> {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map_err(|_| PortError::unavailable())?
        .as_millis()
        .try_into()
        .map_err(|_| PortError::unavailable())
}

#[derive(Default)]
pub(super) struct Clock {
    pub mode: AtomicUsize,
}

impl SecurityClock for Clock {
    fn now_unix_ms(&self) -> PortResult<u64> {
        match self.mode.load(Ordering::SeqCst) {
            0 => now_ms(),
            1 => Ok(0),
            2 => Ok((1_u64 << 53) - 1),
            3 => panic!("native policy clock panic"),
            _ => Err(PortError::unavailable()),
        }
    }
}

pub(super) struct CountingEmptyClassifier {
    calls: AtomicUsize,
}

impl CountingEmptyClassifier {
    pub(super) fn new() -> Self {
        Self {
            calls: AtomicUsize::new(0),
        }
    }
}

impl ClassificationPort for CountingEmptyClassifier {
    fn classify(&self, request: &ClassificationRequest) -> PortResult<ClassificationResult> {
        self.calls.fetch_add(1, Ordering::SeqCst);
        Ok(ClassificationResult {
            tenant_id: request.tenant_id.clone(),
            request_id: request.request_id.clone(),
            payload_digest: request.payload_digest,
            classifier_id: ClassifierId::new("classifier.empty").map_err(PortError::from)?,
            classifier_version: ClassifierVersion::new("1").map_err(PortError::from)?,
            findings: chio_security_types::ports::BoundedVec::new(Vec::new())
                .map_err(|_| PortError::invalid_data())?,
        })
    }
}

pub(super) fn restricted_label() -> InformationLabel {
    InformationLabel::try_known(
        BTreeMap::new(),
        BTreeSet::from([
            Compartment::new("restricted").unwrap_or_else(|error| panic!("compartment: {error}"))
        ]),
    )
    .unwrap_or_else(|error| panic!("label: {error}"))
}

pub(super) fn declassification_registry(
    purpose: &DeclassificationPurpose,
) -> Arc<VerifiedManifestRegistry> {
    let signer = Keypair::from_seed(&[73; 32]);
    let flow = ToolFlowDeclaration::new(
        None,
        Some(InformationLabel::bottom()),
        true,
        BTreeSet::from([purpose.clone()]),
    )
    .unwrap_or_else(|error| panic!("flow: {error}"));
    let manifest = ToolManifest {
        schema: TOOL_MANIFEST_SCHEMA.to_string(),
        server_id: "server-a".to_string(),
        name: "Flow server".to_string(),
        description: None,
        version: "1.0.0".to_string(),
        tools: vec![ToolDefinition {
            name: "send".to_string(),
            description: "Send".to_string(),
            input_schema: serde_json::json!({"type": "object"}),
            output_schema: Some(serde_json::json!({"type": "object"})),
            pricing: None,
            annotations: ToolAnnotations {
                read_only: false,
                destructive: false,
                idempotent: true,
                requires_approval: false,
            },
            latency_hint: None,
            flow: Some(flow),
        }],
        server_tools: Vec::new(),
        required_permissions: None,
        public_key: signer.public_key().to_hex(),
    };
    let signed =
        sign_manifest(&manifest, &signer).unwrap_or_else(|error| panic!("sign manifest: {error}"));
    let policy = AuthoritativeToolPolicy::new(
        vec![InformationLabel::bottom()],
        InformationLabel::bottom(),
        BTreeSet::from([purpose.clone()]),
    )
    .unwrap_or_else(|error| panic!("policy: {error}"));
    let mut registry = VerifiedManifestRegistry::default();
    registry
        .register(
            signed,
            &signer.public_key(),
            &BTreeMap::from([("send".to_string(), policy)]),
            &BTreeMap::from([("send".to_string(), RuntimeToolTopology::remote())]),
        )
        .unwrap_or_else(|error| panic!("register manifest: {error}"));
    Arc::new(registry)
}

pub(super) fn category_labels() -> CategoryLabelMap {
    CategoryLabelMap::new(
        ClassifierId::new("classifier.empty").unwrap_or_else(|error| panic!("classifier: {error}")),
        ClassifierVersion::new("1").unwrap_or_else(|error| panic!("classifier version: {error}")),
        BTreeMap::new(),
    )
    .unwrap_or_else(|error| panic!("category map: {error}"))
}
