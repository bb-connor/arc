//! An exact predecessor catalog and a populated, byte-preserving P1 upgrade.
use super::*;

/// Disposable predecessor construction must never erase recovery custody or
/// an authenticated global reference. Production migrations do not use this.
pub(super) fn remove_empty_recovery_tables(connection: &Connection) -> rusqlite::Result<()> {
    for table in [
        "admission_operation_recovery_events",
        "admission_operation_recovery_records",
    ] {
        assert_eq!(
            connection.query_row(&format!("SELECT COUNT(*) FROM {table}"), [], |row| {
                row.get::<_, i64>(0)
            })?,
            0,
            "predecessor fixture cannot discard recovery history"
        );
    }
    assert_eq!(
        connection.query_row(
            "SELECT COUNT(*) FROM authority_global_commits WHERE projection_kind = 'recovery'",
            [],
            |row| row.get::<_, i64>(0),
        )?,
        0,
        "predecessor fixture cannot discard global recovery references"
    );
    connection.execute_batch(
        "DROP TABLE admission_operation_recovery_events;
         DROP TABLE admission_operation_recovery_records;",
    )
}

fn rows(connection: &Connection, table: &str) -> AnchoredTestResult<Vec<Vec<Value>>> {
    assert!(matches!(
        table,
        "admission_operations" | "admission_operation_commits" | "authority_global_commits"
    ));
    let mut statement = connection.prepare(&format!("SELECT * FROM {table} ORDER BY rowid"))?;
    let columns = statement.column_count();
    let rows = statement
        .query_map([], |row| {
            (0..columns)
                .map(|index| row.get(index))
                .collect::<rusqlite::Result<Vec<Value>>>()
        })?
        .collect::<rusqlite::Result<Vec<_>>>()?;
    Ok(rows)
}

#[test]
fn recovery_p1_populated_v34_upgrade_preserves_original_operations_and_global_chain(
) -> AnchoredTestResult {
    let f = fixture();
    let operation = prepared_operation(
        &f.fence,
        AdmissionOperationKind::ToolDispatch,
        "p1-predecessor-operation",
        "p1-predecessor-capability",
    );
    f.store.begin(&operation, &f.fence, now_ms())?;
    let _lease = claim(&f, &operation, "p1-predecessor-owner", now_ms());
    let before = {
        let db = f.store.connection()?;
        [
            rows(&db, "admission_operations")?,
            rows(&db, "admission_operation_commits")?,
            rows(&db, "authority_global_commits")?,
        ]
    };
    let Fixture {
        _temp,
        database,
        lock_root,
        store,
        authority,
        ..
    } = f;
    drop(store);
    drop(authority);
    install_v34_fixture(&database)?;
    SqliteAuthorityStore::provision(&database, &lock_root)?;
    let db = Connection::open(&database)?;
    for (index, table) in [
        "admission_operations",
        "admission_operation_commits",
        "authority_global_commits",
    ]
    .into_iter()
    .enumerate()
    {
        assert_eq!(
            before[index],
            rows(&db, table)?,
            "rewrote predecessor: {table}"
        );
    }
    assert!(matches!(
        crate::check_schema_version(&db, "admission_operation", 34, &["admission_operations"]),
        Err(crate::SchemaVersionError::FutureSchema {
            found: 35,
            supported: 34
        })
    ));
    assert_eq!(
        db.query_row(
            "SELECT count(*) FROM admission_operation_recovery_records",
            [],
            |r| r.get::<_, i64>(0)
        )?,
        0
    );
    assert!(!db.query_row(
        "SELECT EXISTS(SELECT 1 FROM pragma_foreign_key_check)",
        [],
        |r| r.get::<_, bool>(0)
    )?);
    drop(db);
    let reopened = SqliteAuthorityStore::open_serving(&database, &lock_root)?;
    assert_eq!(
        reopened
            .admission_operation_store()
            .load_by_operation_id(operation.binding().operation_id())?,
        Some(operation)
    );
    Ok(())
}

fn install_v34_fixture(database: &std::path::Path) -> AnchoredTestResult {
    let db = Connection::open(database)?;
    let tx = db.unchecked_transaction()?;
    remove_empty_recovery_tables(&tx)?;
    tx.execute_batch(
        "DROP TRIGGER authority_global_commits_immutable;
        DROP TRIGGER authority_global_commits_no_delete;
        DROP INDEX authority_global_commits_projection;
        ALTER TABLE authority_global_commits RENAME TO global_v35_fixture;",
    )?;
    tx.execute_batch(include_str!("../fixtures/recovery-v34-global.sql"))?;
    tx.execute_batch(
        "INSERT INTO authority_global_commits SELECT * FROM global_v35_fixture;
        DROP TABLE global_v35_fixture;
        UPDATE chio_store_schema_versions SET version=34 WHERE store_key='admission_operation';",
    )?;
    tx.commit()?;
    Ok(())
}

#[test]
#[ignore = "only the fresh-process migration parent starts this child"]
fn recovery_p1_migration_crash_child() -> AnchoredTestResult {
    let database =
        std::env::var_os("CHIO_RECOVERY_P1_MIGRATION_DATABASE").ok_or("migration database")?;
    let locks = std::env::var_os("CHIO_RECOVERY_P1_MIGRATION_LOCKS").ok_or("migration locks")?;
    SqliteAuthorityStore::provision(PathBuf::from(database), PathBuf::from(locks))?;
    Err("migration child did not reach its cutpoint".into())
}

#[cfg(unix)]
#[test]
fn recovery_p1_os_death_before_upgrade_commit_is_restartable_and_byte_preserving(
) -> AnchoredTestResult {
    use std::os::unix::process::ExitStatusExt;
    use std::time::{Duration, Instant};
    let f = fixture();
    let operation = prepared_operation(
        &f.fence,
        AdmissionOperationKind::ToolDispatch,
        "p1-interrupted-migration",
        "p1-interrupted-capability",
    );
    f.store.begin(&operation, &f.fence, now_ms())?;
    let Fixture {
        _temp,
        database,
        lock_root,
        store,
        authority,
        ..
    } = f;
    drop(store);
    drop(authority);
    install_v34_fixture(&database)?;
    let db = Connection::open(&database)?;
    let before = [
        rows(&db, "admission_operations")?,
        rows(&db, "admission_operation_commits")?,
        rows(&db, "authority_global_commits")?,
    ];
    drop(db);
    let marker = _temp.path().join("migration-cutpoint");
    let log = std::fs::File::create(_temp.path().join("migration-child.log"))?;
    let mut child = std::process::Command::new(std::env::current_exe()?)
        .args([
            "--exact",
            "admission_operation_store::tests::schema::recovery::recovery_p1_migration_crash_child",
            "--ignored",
            "--nocapture",
            "--test-threads=1",
        ])
        .env("CHIO_RECOVERY_P1_MIGRATION_DATABASE", &database)
        .env("CHIO_RECOVERY_P1_MIGRATION_LOCKS", &lock_root)
        .env("CHIO_RECOVERY_P1_MIGRATION_MARKER", &marker)
        .stdout(log.try_clone()?)
        .stderr(log)
        .spawn()?;
    let started = Instant::now();
    let status = loop {
        if let Some(status) = child.try_wait()? {
            break status;
        }
        if started.elapsed() > Duration::from_secs(60) {
            child.kill()?;
            child.wait()?;
            return Err("migration child exceeded its bound".into());
        }
        std::thread::sleep(Duration::from_millis(20));
    };
    assert_eq!(status.signal(), Some(6));
    assert_eq!(std::fs::read(marker)?, b"verified-v35-before-commit");
    let db = Connection::open(&database)?;
    assert_eq!(
        db.query_row(
            "SELECT version FROM chio_store_schema_versions WHERE store_key='admission_operation'",
            [],
            |row| row.get::<_, i64>(0)
        )?,
        34
    );
    for (index, table) in [
        "admission_operations",
        "admission_operation_commits",
        "authority_global_commits",
    ]
    .into_iter()
    .enumerate()
    {
        assert_eq!(
            before[index],
            rows(&db, table)?,
            "crash rewrote predecessor: {table}"
        );
    }
    assert!(!db.query_row("SELECT EXISTS(SELECT 1 FROM sqlite_schema WHERE name='admission_operation_recovery_records')", [], |row| row.get::<_, bool>(0))?);
    drop(db);
    SqliteAuthorityStore::provision(&database, &lock_root)?;
    let reopened = SqliteAuthorityStore::open_serving(&database, &lock_root)?;
    assert_eq!(
        reopened
            .admission_operation_store()
            .load_by_operation_id(operation.binding().operation_id())?,
        Some(operation)
    );
    Ok(())
}
