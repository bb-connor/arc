//! Owning gates compare retained readiness with the actual native transaction.
use super::*;

pub(in crate::admission_operation_store) fn require_ready(
    tx: &Connection,
    scope: &RecoveryScopeV1,
    fence: &StoreMutationFence,
) -> Result<(), AdmissionOperationStoreError> {
    if let Some(value) = load(tx, scope)? {
        if value.probe.scope != *scope {
            return Err(refused("unqualified scope"));
        }
        ready(tx, &value, fence)?;
    }
    Ok(())
}
pub(in crate::admission_operation_store) fn require_command(
    tx: &Transaction<'_>,
    scope: &RecoveryScopeV1,
    fence: &StoreMutationFence,
    body: &RecoveryCommandBodyV1,
) -> Result<(), AdmissionOperationStoreError> {
    let Some(value) = load(tx, scope)? else {
        return Ok(());
    };
    if matches!(
        body,
        RecoveryCommandBodyV1::InspectWorkflow { .. }
            | RecoveryCommandBodyV1::CancelWorkflow { .. }
            | RecoveryCommandBodyV1::ReportDecision { .. }
    ) {
        return Ok(());
    }
    if let RecoveryCommandBodyV1::ResumeWorkflow { workflow_id, .. } = body {
        let record = protected::workflow_tx(tx, scope, workflow_id)?;
        if let Some(id) = &record.native_link {
            let operation =
                load_by_operation_id_tx(tx, &AdmissionOperationId::from_persisted(id.as_str())?)?
                    .ok_or_else(|| refused("lost original operation"))?;
            if record.captured && operation.operation.state() == AdmissionOperationState::Completed
            {
                return Ok(());
            }
        }
    }
    if ready(tx, &value, fence).is_ok() && value.probe.scope == *scope {
        return Ok(());
    }
    current(tx, &value)?;
    let id = match body {
        RecoveryCommandBodyV1::CreateWorkflow {
            creation_key,
            request_seed,
            ..
        } => {
            let id = WorkflowId::new(&format!(
                "workflow:{}",
                sha256_hex(&protected::encode(&(scope, creation_key))?)
            ))
            .map_err(refused)?;
            if CanonicalPayloadDigest::from_bytes(digest(
                "chio.recovery.setup.creation.v1",
                request_seed,
            )?) != value.creation
            {
                return Err(refused("unselected setup creation"));
            }
            id
        }
        RecoveryCommandBodyV1::SelectOffer { workflow_id, .. }
        | RecoveryCommandBodyV1::SubmitApproval { workflow_id, .. }
        | RecoveryCommandBodyV1::ResumeWorkflow { workflow_id, .. } => workflow_id.clone(),
        _ => return Ok(()),
    };
    if value.probe.scope != *scope || id != value.probe.benign_workflow {
        return Err(refused("setup required"));
    }
    Ok(())
}
pub(in crate::admission_operation_store) fn require_capture(
    tx: &Connection,
    owner: &SqliteServingOwner,
    operation: &AdmissionOperationV1,
    context: &SecurityInvocationContext,
    native: &chio_kernel::admission_operation::NativeSecurityAuthorityBindingV1,
) -> Result<(), AdmissionOperationStoreError> {
    let scope = RecoveryScopeV1 {
        authority_domain: AuthorityDomainId::new(&owner.fence.store_uuid).map_err(refused)?,
        tenant_id: RecoveryTenantId::new(context.as_v1().tenant_id().as_str()).map_err(refused)?,
        process_id: ProcessId::new("native-capture").map_err(refused)?,
    };
    let Some(value) = load(tx, &scope)? else {
        return Ok(());
    };
    current(tx, &value)?;
    let deployment = protected::deployment_tx(tx, &value.probe.scope)?;
    // Physical capture observes a joined flow generation, while the selected
    // process identity intentionally does not carry that transient generation.
    if native != &deployment.native_authority
        || context.as_v1().tenant_id() != deployment.security_context.as_v1().tenant_id()
        || context.as_v1().session_id() != deployment.security_context.as_v1().session_id()
        || context.as_v1().principal_id() != deployment.security_context.as_v1().principal_id()
        || context.as_v1().lineage_root_id()
            != deployment.security_context.as_v1().lineage_root_id()
        || context.as_v1().isolation_epoch_id()
            != deployment.security_context.as_v1().isolation_epoch_id()
        || context.as_v1().context_generation()
            != deployment.security_context.as_v1().context_generation()
    {
        return Err(refused("capture scope"));
    }
    if ready(tx, &value, &owner.fence).is_ok() {
        return Ok(());
    }
    let record = super::recovery::native::located(tx, operation.binding())?
        .ok_or_else(|| refused("unselected setup capture"))?;
    if record.scope != value.probe.scope
        || record.workflow_id != value.probe.benign_workflow
        || creation(&record)? != value.creation
        || record.captured
    {
        return Err(refused("unselected setup capture"));
    }
    Ok(())
}
