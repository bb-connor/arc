"""Execute a sealed finite corpus. Never repair, retry or replace a trial."""
from __future__ import annotations
import argparse
import asyncio
from concurrent.futures import ThreadPoolExecutor
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import subprocess
import threading
import time

from campaign_baseline import SupervisorSession
from campaign_runner import ModelBudget, crew_trial, graph_trial, public_task
from campaign_report import summarize
from chio_sdk.recovery_host import RecoveryHostSession
from chio_sdk.recovery_host import RecoveryHostOutcome


def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()


class DeadlineSession:
    def __init__(self, owner, deadline):
        self._owner = owner
        self._deadline = deadline
    @property
    def attempts(self): return self._owner.attempts
    async def execute(self, choice):
        if time.monotonic() >= self._deadline:
            return RecoveryHostOutcome("budget_exhausted")
        return await self._owner.execute(choice)


def trial_run(root, evidence, manifest, trial):
    exchange = evidence / trial["id"]
    exchange.mkdir(mode=0o700, parents=True, exist_ok=False)
    (exchange/"configuration.json").write_text(json.dumps({key:trial[key] for key in ["workflow", "case"]}))
    environment = {**os.environ, "CHIO_P6_CAMPAIGN_EXCHANGE":str(exchange.resolve())}
    # Native code never receives a provider credential.
    environment.pop("OPENAI_API_KEY", None)
    log = (exchange/"native.log").open("wb")
    process = subprocess.Popen(["cargo", "test", "--offline", "--locked", "-p", "chio-control-plane", "--lib",
                               "p6_live_comparative_native_host", "--", "--ignored", "--test-threads=1"],
                               cwd=root, env=environment, stdout=log, stderr=subprocess.STDOUT)
    started = time.monotonic()
    model = None
    session = None
    row = {**trial, "requested_model":manifest["model"], "authority_policy":manifest["authority_policy"],
           "source_binding":manifest["source_binding"], "model_attempts":[], "tool_actions":0,
           "hidden_retries":0, "outcome":"native_error", "native":None, "elapsed_seconds":0}
    try:
        deadline = started + manifest["budgets"]["native_preparation_seconds"]
        while not (exchange/"ready").is_file():
            if process.poll() is not None or time.monotonic() > deadline:
                raise RuntimeError("campaign.native_preparation_failed")
            time.sleep(.05)
        row["native_preparation_seconds"] = round(time.monotonic()-started, 6)
        row["authority_policy"] = sha(exchange/"authority-contract.json")
        if row["authority_policy"] != manifest["authority_policy"]:
            raise RuntimeError("campaign.authority_mismatch")
        endpoint = (exchange/"ready").read_text()
        capability = (exchange/"capability.json").read_text()
        wire = (exchange/"command.json").read_bytes()
        if trial["arm"] == "product":
            session = RecoveryHostSession(endpoint, capability, {"resume":wire}, max_tool_actions=8, timeout_seconds=120)
        else:
            session = SupervisorSession(endpoint, capability, wire)
        deadline_at = time.monotonic() + manifest["budgets"]["host_start_deadline_seconds"]
        session = DeadlineSession(session, deadline_at)
        from openai import OpenAI
        with OpenAI(max_retries=0, timeout=manifest["budgets"]["provider_seconds"]) as provider:
            model = ModelBudget(manifest["model"], provider.chat.completions,
                max_calls=manifest["budgets"]["model_calls"], prompt_bytes=manifest["budgets"]["prompt_bytes"],
                output_tokens=manifest["budgets"]["output_tokens"], deadline_at=deadline_at)
            host_started = time.monotonic()
            if trial["host"] == "langgraph":
                output = asyncio.run(graph_trial(session, model, public_task(trial)))
            else:
                output = crew_trial(session, model, public_task(trial))
            row["host_model_native_seconds"] = round(time.monotonic()-host_started, 6)
        row["outcome"] = output.get("category", "parser_error") if output else "skipped_tool"
        row["host_output"] = output
    except Exception as error:
        category = str(error) if isinstance(error, RuntimeError) and str(error).startswith("campaign.") else "campaign.framework_error"
        row["error_category"] = category
        row["outcome"] = "provider_error" if category == "campaign.provider_unavailable" else \
                         "budget_exhausted" if category in ["campaign.model_budget_exhausted", "campaign.prompt_budget_exhausted", "campaign.response_budget_exhausted"] else \
                         "parser_error" if category in ["campaign.response_invalid", "campaign.parser_error"] else \
                         "native_error" if category in ["campaign.native_preparation_failed", "campaign.authority_mismatch"] else "framework_error"
    finally:
        if model is not None:
            row["model_attempts"] = model.attempts
        if session is not None:
            row["tool_actions"] = session.attempts
        (exchange/"finish").touch()
        try:
            status = process.wait(timeout=manifest["budgets"]["native_shutdown_seconds"])
        except subprocess.TimeoutExpired:
            process.terminate()
            status = process.wait(timeout=30)
            row["native_shutdown_error"] = True
        log.close()
        if (exchange/"native-evidence.json").is_file():
            row["native"] = json.loads((exchange/"native-evidence.json").read_bytes())
        if status != 0 or "1 passed; 0 failed; 0 ignored" not in (exchange/"native.log").read_text():
            row["native_execution_error"] = True
        row["elapsed_seconds"] = round(time.monotonic()-started, 6)
        (exchange/"result.json").write_text(json.dumps(row, indent=2, allow_nan=False)+"\n")
    return row


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--checkout", type=Path, required=True)
    parser.add_argument("--evidence", type=Path, required=True)
    args = parser.parse_args()
    raw = args.manifest.read_bytes()
    assert sha(args.manifest) == args.manifest.with_suffix(".sha256").read_text().strip()
    manifest = json.loads(raw)
    assert len(manifest["trials"]) == 96
    for distribution, version in manifest["hosts"].items():
        assert importlib.metadata.version(distribution) == version
    for source in manifest["sources"]:
        assert sha(args.checkout/source["path"]) == source["sha256"], "campaign source mismatch"
    args.evidence.mkdir(mode=0o700, parents=True, exist_ok=False)
    lock = threading.Lock()
    rows = []
    def execute(trial):
        row = trial_run(args.checkout, args.evidence, manifest, trial)
        with lock:
            rows.append(row)
            with (args.evidence/"results.jsonl").open("a") as output:
                output.write(json.dumps(row, separators=(",", ":"), allow_nan=False)+"\n")
            print(f"Retained {len(rows)}/96 {row['id']} {row['outcome']}", flush=True)
    with ThreadPoolExecutor(max_workers=manifest["budgets"]["concurrent_trials"]) as executor:
        list(executor.map(execute, manifest["trials"]))
    report = summarize(manifest, rows)
    (args.evidence/"summary.json").write_text(json.dumps(report, indent=2, allow_nan=False)+"\n")
    assert report["unauthorized_effects"] == report["duplicate_effects"] == 0
    assert all(row["native"]["source_label_retained"] for row in rows)
    assert all(not row.get("native_execution_error") and row["elapsed_seconds"] <= manifest["budgets"]["trial_seconds"] for row in rows)
    # All declared positive strata must demonstrate useful execution. Failures
    # remain in their exact three-trial denominator; no replacement is allowed.
    assert all(stratum["completion"]["numerator"] >= 1 for stratum in report["strata"] if stratum["case"] in ["authorized", "lost_ack_restart"])
    print("Completed source-bound 96-trial live campaign", flush=True)


if __name__ == "__main__": main()
