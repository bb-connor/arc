//! Required real Linux acceptance. Missing measured executables are failures.
use super::*;
use chio_cage::{CompiledCage, ExecutionIdentity, OperatorCeilings, RuntimeResourcePaths};
use chio_manifest::{
    sign_manifest, NativeSyscallProfile, RequiredPermissions, RuntimeToolTopology, ToolAnnotations,
    ToolDefinition, ToolManifest, VerifiedManifestRegistry, TOOL_MANIFEST_SCHEMA,
};
use std::collections::BTreeSet;
use std::path::{Path, PathBuf};

fn compiled(f: &ConfinedFixture, target: &Path) -> TestResult<CompiledCage> {
    compiled_with_environment(f, target, &BTreeMap::new(), BTreeSet::new())
}
fn compiled_with_environment(
    f: &ConfinedFixture,
    target: &Path,
    parent: &BTreeMap<String, String>,
    allowed: BTreeSet<chio_manifest::EnvironmentVariableName>,
) -> TestResult<CompiledCage> {
    let signer = Keypair::from_seed(&[235; 32]);
    let manifest = ToolManifest {
        schema: TOOL_MANIFEST_SCHEMA.into(),
        server_id: "confined-reader".into(),
        name: "Confined reader".into(),
        description: None,
        version: "1".into(),
        tools: vec![ToolDefinition {
            name: "read".into(),
            description: "Bounded projection".into(),
            input_schema: serde_json::json!({"type":"object"}),
            output_schema: None,
            pricing: None,
            annotations: ToolAnnotations {
                read_only: true,
                destructive: false,
                idempotent: false,
                requires_approval: true,
            },
            latency_hint: None,
            flow: None,
        }],
        server_tools: vec![],
        required_permissions: Some(RequiredPermissions {
            read_paths: None,
            write_paths: None,
            network_destinations: None,
            environment_variables: (!allowed.is_empty()).then(|| allowed.iter().cloned().collect()),
            native_syscall_profile: NativeSyscallProfile::NativeMinimalV1,
        }),
        public_key: signer.public_key().to_hex(),
    };
    let signed = sign_manifest(&manifest, &signer)?;
    let mut registry = VerifiedManifestRegistry::default();
    registry.register_public_only(signed, &signer.public_key(), RuntimeToolTopology::local())?;
    let ceilings = OperatorCeilings::new(
        BTreeSet::new(),
        BTreeSet::new(),
        BTreeSet::new(),
        allowed,
        BTreeSet::from([NativeSyscallProfile::NativeMinimalV1]),
    )
    .with_forbidden_paths(BTreeSet::from([f.knowledge.f.path.clone()]));
    let admitted = chio_cage::admit(
        registry.authorize_cage_manifest("confined-reader")?,
        &ceilings,
    )?;
    let helper = PathBuf::from(
        std::env::var_os("CHIO_CAGE_TEST_HELPER").ok_or("missing measured cage-init")?,
    );
    let identity = if nix::unistd::geteuid().is_root() {
        ExecutionIdentity::new(65534, 65534, vec![])?
    } else {
        ExecutionIdentity::from_observed_credentials(
            nix::unistd::geteuid().as_raw(),
            nix::unistd::getegid().as_raw(),
            nix::unistd::getgroups()?
                .into_iter()
                .map(|gid| gid.as_raw())
                .collect(),
        )?
    };
    let runtime = chio_cage::retain_runtime_resources(&RuntimeResourcePaths::new(
        helper,
        target.to_path_buf(),
        std::fs::canonicalize(std::env::temp_dir())?,
        BTreeSet::new(),
        identity,
    ))?;
    Ok(chio_cage::compile(admitted, runtime, parent, None)?)
}
fn measured_fixture(target: &Path) -> TestResult<(ConfinedFixture, CompiledCage)> {
    let mut f = ConfinedFixture::new()?;
    let cage = compiled(&f, target)?;
    f.profile.generation = SafeInteger::new(2)?;
    f.profile.execution = crate::confinement::confined_execution_profile(&cage)?;
    f.runtime = NativeConfinedRuntime::new(
        f.knowledge.f.kernel.clone(),
        Arc::new(f.knowledge.f.authority.admission_operation_store()),
        f.knowledge.broker.clone(),
        f.profile.clone(),
        f.knowledge.f.authority.mutation_fence(),
    )?;
    Ok((f, cage))
}
fn reader() -> TestResult<PathBuf> {
    Ok(PathBuf::from(
        std::env::var_os("CHIO_P5_READER").ok_or("missing measured reader")?,
    ))
}
fn approve(
    body: ConfinedReturnEvidenceV1,
) -> TestResult<(SignedConfinedDisclosureV1, SignedConfinedEndorsementV1)> {
    Ok((
        SignedConfinedDisclosureV1::sign(body.clone(), &Keypair::from_seed(&[233; 32]))?,
        SignedConfinedEndorsementV1::sign(body, &Keypair::from_seed(&[234; 32]))?,
    ))
}
#[test]
fn p5_linux_fixed_environment_rejects_parent_controlled_channels() -> TestResult {
    let f = ConfinedFixture::new()?;
    let target = reader()?;
    let clean = compiled(&f, &target)?;
    let parent = BTreeMap::from([
        ("LANG".into(), "P5-PARENT-CANARY".into()),
        ("LC_ALL".into(), "P5-PARENT-CANARY".into()),
        ("TZ".into(), "P5-PARENT-CANARY".into()),
        ("HOME".into(), "P5-PARENT-CANARY".into()),
        ("APP_MODE".into(), "P5-PARENT-CANARY".into()),
    ]);
    let isolated = compiled_with_environment(&f, &target, &parent, BTreeSet::new())?;
    assert_eq!(
        clean.plan().environment,
        BTreeMap::from([
            ("LANG".into(), "C".into()),
            ("LC_ALL".into(), "C".into()),
            ("TZ".into(), "UTC".into()),
        ])
    );
    assert_eq!(clean.plan().environment, isolated.plan().environment);
    let profile = crate::confinement::confined_execution_profile(&clean)?;
    assert_eq!(
        profile,
        crate::confinement::confined_execution_profile(&isolated)?
    );
    let exposed = compiled_with_environment(
        &f,
        &target,
        &parent,
        BTreeSet::from([chio_manifest::EnvironmentVariableName::new("APP_MODE")?]),
    )?;
    assert!(crate::confinement::confined_execution_profile(&exposed).is_err());
    let connection = rusqlite::Connection::open(f.knowledge.f.path.join("admission.db"))?;
    let reservations: i64 = connection.query_row(
        "SELECT count(*) FROM admission_operation_recovery_records WHERE record_key GLOB 'confined-boundary:*'",
        [],
        |row| row.get(0),
    )?;
    assert_eq!(reservations, 0);
    Ok(())
}
#[test]
fn p5_linux_unknown_input_provenance_withholds_a_correct_projection() -> TestResult {
    let (mut f, cage) = measured_fixture(&reader()?)?;
    f.observation = publish_label(
        &f.knowledge,
        "unknown-confined-input",
        br#"{"eligible":true,"secret":"P5-UNKNOWN-CANARY"}"#,
        restricted_label(),
    )?;
    let actor = f.knowledge.actor(RecoveryPermission::KnowledgeRead)?;
    let inventory = f
        .knowledge
        .f
        .authority
        .admission_operation_store()
        .artifact_transfer_inventory(
            &actor,
            &f.observation,
            &f.knowledge.f.authority.mutation_fence(),
            now_ms()?,
        )?;
    assert!(
        inventory
            .last()
            .ok_or("observation")?
            .metadata
            .influence
            .unknown
    );
    let request = RequestId::new("unknown-confined-return")?;
    f.reserve(
        request.as_str(),
        &child(&f.knowledge, "unknown-child", 201)?,
    )?;
    let execution = f.runtime.launch(&f.knowledge.f.control, &request, cage)?;
    assert!(execution.stage(&f.knowledge.f.control).is_err());
    let connection = rusqlite::Connection::open(f.knowledge.f.path.join("admission.db"))?;
    let exit: i64 = connection.query_row(
        "SELECT json_extract(payload,'$.terminal.exit.exit_code') FROM admission_operation_recovery_records WHERE record_key GLOB 'confined-boundary:*'",
        [],
        |row| row.get(0),
    )?;
    assert_eq!(
        exit, 0,
        "projection worker failed before provenance refusal"
    );
    assert!(f
        .runtime
        .prepare_return(&f.knowledge.f.control, &request)
        .is_err());
    assert_eq!(f.count()?, 1);
    let admitted: i64 = connection.query_row(
        "SELECT count(*) FROM admission_operation_recovery_records WHERE record_key GLOB 'confined-boundary:*' AND json_extract(payload,'$.return_admission') IS NOT NULL",
        [],
        |row| row.get(0),
    )?;
    assert_eq!(admitted, 0);
    Ok(())
}
#[test]
fn p5_linux_useful_decision_exact_authority_and_parent_join_before_first_byte() -> TestResult {
    let (f, cage) = measured_fixture(&reader()?)?;
    let cap = child(&f.knowledge, "measured-child", 201)?;
    let reservation = f.reserve("real-spawn", &cap)?;
    let before = f
        .knowledge
        .f
        .authority
        .admission_operation_store()
        .observe_security_participant_flow(
            &f.knowledge.profile.native_authority,
            &recovery_flow_key(&f.knowledge.profile.producer_context),
            &f.knowledge.f.authority.mutation_fence(),
            now_ms()?,
        )?;
    let execution =
        f.runtime
            .launch(&f.knowledge.f.control, &RequestId::new("real-spawn")?, cage)?;
    let context = f
        .knowledge
        .f
        .process
        .recovery_security_context(reservation.boundary.child.as_str())?;
    assert_eq!(
        context.as_v1().lineage_root_id().as_str(),
        reservation.boundary.lineage.as_str()
    );
    let body = execution.stage(&f.knowledge.f.control)?;
    assert!(!body.source.flows_to(&InformationLabel::bottom()));
    let sink = f.knowledge.sink();
    let request = RequestId::new("real-spawn")?;
    assert!(f
        .runtime
        .deliver(
            &f.knowledge.f.control,
            f.runtime.prepare_return(&f.knowledge.f.control, &request)?,
            &sink,
            None,
            None
        )
        .is_err());
    assert!(sink.delivered.lock().map_err(|_| "sink")?.is_empty());
    let (disclosure, endorsement) = approve(body)?;
    assert!(f
        .runtime
        .deliver(
            &f.knowledge.f.control,
            f.runtime.prepare_return(&f.knowledge.f.control, &request)?,
            &sink,
            Some(&disclosure),
            None
        )
        .is_err());
    let admitted = f.runtime.deliver(
        &f.knowledge.f.control,
        f.runtime.prepare_return(&f.knowledge.f.control, &request)?,
        &sink,
        Some(&disclosure),
        Some(&endorsement),
    )?;
    assert_eq!(
        sink.delivered.lock().map_err(|_| "sink")?.as_slice(),
        &[b"true".to_vec()]
    );
    let after = f
        .knowledge
        .f
        .authority
        .admission_operation_store()
        .observe_security_participant_flow(
            &f.knowledge.profile.native_authority,
            &recovery_flow_key(&f.knowledge.profile.producer_context),
            &f.knowledge.f.authority.mutation_fence(),
            now_ms()?,
        )?;
    assert_eq!(
        before.snapshot().ok_or("before")?.principal_label,
        after.snapshot().ok_or("after")?.principal_label
    );
    let again = f.runtime.deliver(
        &f.knowledge.f.control,
        f.runtime.prepare_return(&f.knowledge.f.control, &request)?,
        &sink,
        None,
        None,
    )?;
    assert_eq!(admitted.admitted.release, again.admitted.release);
    assert_eq!(f.count()?, 1);
    f.runtime
        .cancel(&f.knowledge.f.control, &f.knowledge.f.process, &request)?;
    assert!(f
        .runtime
        .prepare_return(&f.knowledge.f.control, &request)
        .is_err());
    Ok(())
}
#[test]
fn p5_linux_channel_canaries_never_reach_parent_or_bypass_projection() -> TestResult {
    let root = PathBuf::from(
        std::env::var_os("CHIO_P5_CANARY_DIR").ok_or("missing measured canary images")?,
    );
    for mode in [
        "error",
        "log",
        "progress",
        "stream",
        "file",
        "callback",
        "wrong-predicate",
        "overflow",
    ] {
        let (mut f, cage) = measured_fixture(&root.join(mode))?;
        // Make ordinary Unix permissions and endpoint availability permissive.
        // A missing socket/private directory must not make the probe pass.
        use std::os::unix::fs::PermissionsExt;
        let probe = tempfile::tempdir()?;
        std::fs::set_permissions(probe.path(), std::fs::Permissions::from_mode(0o777))?;
        let file = probe.path().join("forbidden-canary-file");
        let socket = probe.path().join("forbidden-callback.sock");
        let listener = std::os::unix::net::UnixListener::bind(&socket)?;
        std::fs::set_permissions(&socket, std::fs::Permissions::from_mode(0o666))?;
        listener.set_nonblocking(true)?;
        let input = chio_core::canonical_json_bytes(
            &serde_json::json!({"eligible":true,"secret":"P5-PRIVATE-CANARY","probe_file":file.to_str().ok_or("file")?,"probe_socket":socket.to_str().ok_or("socket")?}),
        )?;
        f.observation = f.knowledge.publish(&format!("probe-{mode}"), &input)?;
        let cap = child(&f.knowledge, "canary-child", 201)?;
        f.reserve("canary-spawn", &cap)?;
        let staged = f
            .runtime
            .launch(
                &f.knowledge.f.control,
                &RequestId::new("canary-spawn")?,
                cage,
            )
            .and_then(|execution| execution.stage(&f.knowledge.f.control));
        let sink = f.knowledge.sink();
        if matches!(mode, "log" | "file") {
            let (disclosure, endorsement) = approve(staged?)?;
            let request = RequestId::new("canary-spawn")?;
            f.runtime.deliver(
                &f.knowledge.f.control,
                f.runtime.prepare_return(&f.knowledge.f.control, &request)?,
                &sink,
                Some(&disclosure),
                Some(&endorsement),
            )?;
            assert_eq!(
                sink.delivered.lock().map_err(|_| "sink")?.as_slice(),
                &[b"true".to_vec()]
            );
        } else {
            let error = staged.err().ok_or("canary unexpectedly admitted")?;
            assert!(!error.to_string().contains("P5-PRIVATE-CANARY"));
            assert!(sink.delivered.lock().map_err(|_| "sink")?.is_empty());
        }
        assert!(!file.exists(), "{mode}: filesystem bypass");
        match listener.accept() {
            Ok(_) => return Err("callback escaped the cage".into()),
            Err(error) if error.kind() == std::io::ErrorKind::WouldBlock => (),
            Err(error) => return Err(error.into()),
        }
        let db = std::fs::read(f.knowledge.f.path.join("admission.db"))?;
        assert!(!db
            .windows(b"P5-PRIVATE-CANARY".len())
            .any(|b| b == b"P5-PRIVATE-CANARY"));
    }
    Ok(())
}

#[test]
fn p5_linux_parent_cancellation_withholds_returns_before_and_after_native_join() -> TestResult {
    use crate::confinement::ConfinedCutpoint::{BeforeAdmission, BeforeDelivery, ReturnCommitted};
    for (cut, label) in [
        (BeforeAdmission, "before native admission"),
        (ReturnCommitted, "after native join"),
        (BeforeDelivery, "before delivery"),
    ] {
        let (f, cage) = measured_fixture(&reader()?)
            .map_err(|error| format!("{label}: measured fixture: {error}"))?;
        let request = RequestId::new("cancel-parent-return")?;
        f.reserve(
            request.as_str(),
            &child(&f.knowledge, "cancelled-parent-child", 201)?,
        )
        .map_err(|error| format!("{label}: reservation: {error}"))?;
        let execution = f
            .runtime
            .launch(&f.knowledge.f.control, &request, cage)
            .map_err(|error| format!("{label}: launch: {error}"))?;
        let body = execution
            .stage(&f.knowledge.f.control)
            .map_err(|error| format!("{label}: stage: {error}"))?;
        let (disclosure, endorsement) = approve(body)?;
        let sink = f.knowledge.sink();
        let process = f.knowledge.f.process.clone();
        let runtime = f.runtime.clone().with_test_cutpoint(Arc::new(move |stage| {
            if stage == cut {
                process
                    .cancel("root")
                    .map_err(|_| KernelError::DurableAdmission("cancel parent".into()))?;
            }
            Ok(())
        }));
        let prepared = runtime
            .prepare_return(&f.knowledge.f.control, &request)
            .map_err(|error| format!("{label}: preparation: {error}"))?;
        // Already prepared host custody cannot turn a later cancelled process
        // into a live recipient. Cancellation also correctly refuses new blob
        // reads, so retain this separate affine handle before the cutpoint.
        let replay = if cut == BeforeAdmission {
            None
        } else {
            Some(f.runtime.prepare_return(&f.knowledge.f.control, &request)?)
        };
        assert!(
            runtime
                .deliver(
                    &f.knowledge.f.control,
                    prepared,
                    &sink,
                    Some(&disclosure),
                    Some(&endorsement)
                )
                .is_err(),
            "{label}"
        );
        assert!(
            sink.delivered.lock().map_err(|_| "sink")?.is_empty(),
            "{label}"
        );
        assert_eq!(f.count()?, 1);
        let connection = rusqlite::Connection::open(f.knowledge.f.path.join("admission.db"))?;
        let consumed: i64 = connection.query_row(
            "SELECT count(*) FROM admission_operation_recovery_records WHERE record_key GLOB 'confined-evidence:*'",
            [],
            |row| row.get(0),
        )?;
        let admissions: i64 = connection.query_row(
            "SELECT count(*) FROM admission_operation_recovery_records WHERE record_key GLOB 'confined-boundary:*' AND json_extract(payload,'$.return_admission') IS NOT NULL",
            [],
            |row| row.get(0),
        )?;
        assert_eq!(consumed, if cut == BeforeAdmission { 0 } else { 2 });
        assert_eq!(admissions, if cut == BeforeAdmission { 0 } else { 1 });
        // Cancellation never rolls back the join or spent evidence. An admitted
        // value remains classified and replay must still refuse the dead parent.
        if let Some(retained) = replay {
            assert!(f
                .runtime
                .deliver(&f.knowledge.f.control, retained, &sink, None, None)
                .is_err());
            assert!(sink.delivered.lock().map_err(|_| "sink")?.is_empty());
        }
    }
    Ok(())
}
#[test]
fn p5_linux_duplicate_launch_and_cancel_preserve_the_observation_and_consumed_slot() -> TestResult {
    let (f, cage) = measured_fixture(&reader()?)?;
    let cap = child(&f.knowledge, "measured-child", 201)?;
    f.reserve("real-spawn", &cap)?;
    let request = RequestId::new("real-spawn")?;
    let execution = f.runtime.launch(&f.knowledge.f.control, &request, cage)?;
    assert!(f
        .runtime
        .launch(&f.knowledge.f.control, &request, compiled(&f, &reader()?)?)
        .is_err());
    execution.cancel(&f.knowledge.f.control, &f.knowledge.f.process)?;
    assert_eq!(
        f.reserve("real-spawn", &cap)?.state,
        IsolationStateV1::Cancelled
    );
    assert_eq!(f.count()?, 1);
    assert!(f
        .runtime
        .prepare_return(&f.knowledge.f.control, &request)
        .is_err());
    Ok(())
}

#[test]
fn p5_linux_launch_cutpoints_never_duplicate_measurement_or_reset_observation() -> TestResult {
    use crate::confinement::ConfinedCutpoint::*;
    for cutpoint in [LaunchPrepared, Enforced, ObservationCommitted, BeforeInput] {
        let (f, cage) = measured_fixture(&reader()?)?;
        let cap = child(&f.knowledge, "measured-child", 201)?;
        let original = f.reserve("cut-launch", &cap)?;
        let request = RequestId::new("cut-launch")?;
        let faulty = f.runtime.clone().with_test_cutpoint(Arc::new(move |stage| {
            if stage == cutpoint {
                return Err(KernelError::Internal("lost acknowledgement".into()));
            }
            Ok(())
        }));
        assert!(faulty
            .launch(&f.knowledge.f.control, &request, cage)
            .is_err());
        let recovered = f.reserve("cut-launch", &cap)?;
        assert_eq!(original.boundary, recovered.boundary);
        assert_eq!(f.count()?, 1);
        assert!(f
            .runtime
            .launch(&f.knowledge.f.control, &request, compiled(&f, &reader()?)?)
            .is_err());
        let observed = f
            .knowledge
            .f
            .authority
            .admission_operation_store()
            .observe_security_participant_flow(
                &f.knowledge.profile.native_authority,
                &recovery_flow_key(&recovered.child_context),
                &f.knowledge.f.authority.mutation_fence(),
                now_ms()?,
            )?;
        assert_eq!(
            observed.snapshot().is_some(),
            matches!(cutpoint, ObservationCommitted | BeforeInput)
        );
        f.runtime
            .cancel(&f.knowledge.f.control, &f.knowledge.f.process, &request)?;
    }
    Ok(())
}

#[test]
fn p5_linux_return_cutpoints_reopen_the_native_writer_without_second_disclosure() -> TestResult {
    use crate::confinement::ConfinedCutpoint::*;
    for cutpoint in [
        ReturnStaged,
        BeforeAdmission,
        ReturnCommitted,
        BeforeDelivery,
        DeliveryCompleted,
    ] {
        let (mut f, cage) = measured_fixture(&reader()?)?;
        let cap = child(&f.knowledge, "measured-child", 201)?;
        f.reserve("cut-return", &cap)?;
        let request = RequestId::new("cut-return")?;
        let faulty = f.runtime.clone().with_test_cutpoint(Arc::new(move |stage| {
            if stage == cutpoint {
                return Err(KernelError::Internal("lost acknowledgement".into()));
            }
            Ok(())
        }));
        let staged = faulty
            .launch(&f.knowledge.f.control, &request, cage)?
            .stage(&f.knowledge.f.control);
        if cutpoint == ReturnStaged {
            assert!(staged.is_err());
        } else {
            staged?;
        }
        let body = f.runtime.review_return(&f.knowledge.f.control, &request)?;
        let (disclosure, endorsement) = approve(body)?;
        let sink = f.knowledge.sink();
        if cutpoint != ReturnStaged {
            assert!(faulty
                .deliver(
                    &f.knowledge.f.control,
                    faulty.prepare_return(&f.knowledge.f.control, &request)?,
                    &sink,
                    Some(&disclosure),
                    Some(&endorsement)
                )
                .is_err());
            assert_eq!(
                sink.delivered.lock().map_err(|_| "sink")?.len(),
                usize::from(cutpoint == DeliveryCompleted)
            );
        }
        let installation = f.profile.clone();
        let deployment = f.knowledge.f.kernel.recovery_deployment(&f.profile.scope)?;
        let control = f.knowledge.f.control.clone();
        let path = f.knowledge.f.path.clone();
        let directory = f.knowledge.f._directory.take();
        drop(faulty);
        drop(f);
        let reopened = RecoveryFixture::open(path, directory, false)?;
        reopened.kernel.set_capability_trust_root(
            reopened.seed.capability.issuer.clone(),
            scope_hash(&reopened.seed.capability.scope)?,
        );
        reopened
            .authority
            .admission_operation_store()
            .configure_recovery_deployment(&deployment)?;
        let broker = Arc::new(reopened.process.enable_durable_knowledge()?);
        let runtime = NativeConfinedRuntime::new(
            reopened.kernel.clone(),
            Arc::new(reopened.authority.admission_operation_store()),
            broker,
            installation,
            reopened.authority.mutation_fence(),
        )?;
        let admitted = runtime.deliver(
            &control,
            runtime.prepare_return(&control, &request)?,
            &sink,
            Some(&disclosure),
            Some(&endorsement),
        )?;
        assert_eq!(
            sink.delivered
                .lock()
                .map_err(|_| "sink")?
                .last()
                .ok_or("value")?,
            b"true"
        );
        let again = runtime.deliver(
            &control,
            runtime.prepare_return(&control, &request)?,
            &sink,
            None,
            None,
        )?;
        assert_eq!(admitted.admitted.release, again.admitted.release);
        let connection = rusqlite::Connection::open(reopened.path.join("admission.db"))?;
        let consumed:i64=connection.query_row("SELECT count(*) FROM admission_operation_recovery_records WHERE record_key GLOB 'confined-evidence:*'",[],|row|row.get(0))?;
        assert_eq!(consumed, 2);
    }
    Ok(())
}

#[test]
fn p5_linux_valid_signatures_cannot_authorize_cross_parent_epoch_or_stale_returns() -> TestResult {
    let (f, cage) = measured_fixture(&reader()?)?;
    let cap = child(&f.knowledge, "measured-child", 201)?;
    f.reserve("binding", &cap)?;
    let request = RequestId::new("binding")?;
    let body = f
        .runtime
        .launch(&f.knowledge.f.control, &request, cage)?
        .stage(&f.knowledge.f.control)?;
    let sink = f.knowledge.sink();
    for n in 0..7 {
        let mut substituted = body.clone();
        match n {
            0 => substituted.boundary = CanonicalPayloadDigest::from_bytes([0; 32]),
            1 => substituted.launch = CanonicalPayloadDigest::from_bytes([0; 32]),
            2 => substituted.parent.principal = PrincipalId::new("another-parent")?,
            3 => substituted.parent.isolation_epoch = ProtectedText::new("another-epoch")?,
            4 => substituted.content = CanonicalPayloadDigest::from_bytes([0; 32]),
            5 => substituted.policy = PolicyDigest::from_bytes([0; 32]),
            _ => {
                let now = now_ms()?;
                substituted.issued_at_unix_ms = SafeInteger::new(now - 60001)?;
                substituted.expires_at_unix_ms = SafeInteger::new(now - 1)?;
            }
        }
        let (disclosure, endorsement) = approve(substituted)?;
        assert!(f
            .runtime
            .deliver(
                &f.knowledge.f.control,
                f.runtime.prepare_return(&f.knowledge.f.control, &request)?,
                &sink,
                Some(&disclosure),
                Some(&endorsement)
            )
            .is_err());
    }
    assert!(sink.delivered.lock().map_err(|_| "sink")?.is_empty());
    let mut changed = f.profile.clone();
    changed.generation = SafeInteger::new(3)?;
    changed.contract.field = ProtectedText::new("rotated")?;
    f.knowledge
        .f
        .authority
        .admission_operation_store()
        .configure_confinement(&changed)?;
    assert!(f
        .runtime
        .prepare_return(&f.knowledge.f.control, &request)
        .is_err());
    Ok(())
}

#[test]
fn p5_linux_absolute_deadline_kills_a_held_handle_without_parent_io() -> TestResult {
    let image =
        PathBuf::from(std::env::var_os("CHIO_P5_CANARY_DIR").ok_or("missing canary images")?)
            .join("hang");
    let (mut f, cage) = measured_fixture(&image)?;
    f.profile.generation = SafeInteger::new(3)?;
    f.profile.limits.wall_clock_ms = SafeInteger::new(2500)?;
    f.runtime = NativeConfinedRuntime::new(
        f.knowledge.f.kernel.clone(),
        Arc::new(f.knowledge.f.authority.admission_operation_store()),
        f.knowledge.broker.clone(),
        f.profile.clone(),
        f.knowledge.f.authority.mutation_fence(),
    )?;
    let cap = child(&f.knowledge, "held-child", 201)?;
    let reserved = f.reserve("deadline", &cap)?;
    let request = RequestId::new("deadline")?;
    let execution = f.runtime.launch(&f.knowledge.f.control, &request, cage)?;
    // Keep affine execution custody alive beyond the reserved absolute deadline.
    std::thread::sleep(std::time::Duration::from_millis(2800));
    assert!(f
        .knowledge
        .f
        .process
        .recovery_security_context(reserved.boundary.child.as_str())
        .is_err());
    assert!(execution.stage(&f.knowledge.f.control).is_err());
    assert!(f
        .runtime
        .prepare_return(&f.knowledge.f.control, &request)
        .is_err());
    assert_eq!(f.count()?, 1);
    let connection = rusqlite::Connection::open(f.knowledge.f.path.join("admission.db"))?;
    let pid:u32=connection.query_row("SELECT json_extract(payload,'$.enforcement.prepared.process_id') FROM admission_operation_recovery_records WHERE record_key GLOB 'confined-boundary:*'",[],|row|row.get(0))?;
    assert!(
        !Path::new(&format!("/proc/{pid}")).exists(),
        "deadline left the child running"
    );
    Ok(())
}
