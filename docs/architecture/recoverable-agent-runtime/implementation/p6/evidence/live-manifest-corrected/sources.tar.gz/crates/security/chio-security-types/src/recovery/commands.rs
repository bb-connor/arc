//! Stable authenticated commands carry data; the host supplies current authority.
use super::{CommandId, ProtectedText, SafeInteger, TemplateId, VersionV1, WorkflowId};
use serde::{Deserialize, Serialize};

#[derive(Clone, Copy, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub enum RecoveryCommandSchema {
    #[serde(rename = "chio.recovery.command.v1")]
    V1,
}
#[derive(Clone, Copy, Debug, Eq, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum RecoveryTemplateV1 {
    SupportTicketPublicIssue,
}

#[derive(Clone, Eq, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct RecoveryCommandV1 {
    pub schema: RecoveryCommandSchema,
    pub version: VersionV1,
    pub command_id: CommandId,
    pub command: RecoveryCommandBodyV1,
}
#[derive(Clone, Eq, PartialEq, Serialize, Deserialize)]
#[serde(tag = "kind", rename_all = "snake_case", deny_unknown_fields)]
pub enum RecoveryCommandBodyV1 {
    CreateWorkflow {
        creation_key: TemplateId,
        template: RecoveryTemplateV1,
        request_seed: ProtectedText<32768>,
    },
    InspectWorkflow {
        workflow_id: WorkflowId,
    },
    SelectOffer {
        workflow_id: WorkflowId,
        expected_revision: SafeInteger,
        offer_id: TemplateId,
    },
    SubmitApproval {
        workflow_id: WorkflowId,
        expected_revision: SafeInteger,
        approval: ProtectedText<32768>,
    },
    ResumeWorkflow {
        workflow_id: WorkflowId,
        expected_revision: SafeInteger,
    },
    CancelWorkflow {
        workflow_id: WorkflowId,
        expected_revision: SafeInteger,
    },
    ReportDecision {
        workflow_id: WorkflowId,
        expected_revision: SafeInteger,
        decision: RecoveryReportedDecision,
    },
}
#[derive(Clone, Copy, Debug, Eq, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum RecoveryReportedDecision {
    Accepted,
    Declined,
    NeedsReview,
}
impl RecoveryCommandBodyV1 {
    pub const fn permission(&self) -> &'static str {
        match self {
            Self::CreateWorkflow { .. } => "create",
            Self::InspectWorkflow { .. } => "inspect",
            Self::SelectOffer { .. } => "select",
            Self::SubmitApproval { .. } => "approve",
            Self::ResumeWorkflow { .. } => "resume",
            Self::CancelWorkflow { .. } => "cancel",
            Self::ReportDecision { .. } => "report",
        }
    }
}
impl core::fmt::Debug for RecoveryCommandV1 {
    fn fmt(&self, f: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        f.write_str("RecoveryCommandV1([redacted])")
    }
}
impl core::fmt::Debug for RecoveryCommandBodyV1 {
    fn fmt(&self, f: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        f.write_str("RecoveryCommandBodyV1([redacted])")
    }
}

/// The first template accepts only the exact reviewed issue title and body.
/// Sink selection, attachments and credentials are never tool input.
#[derive(Clone, Eq, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct RecoverySupportIssueInputV1 {
    pub title: ProtectedText<256>,
    pub body: ProtectedText<16384>,
}
impl core::fmt::Debug for RecoverySupportIssueInputV1 {
    fn fmt(&self, f: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        f.write_str("RecoverySupportIssueInputV1([redacted])")
    }
}
