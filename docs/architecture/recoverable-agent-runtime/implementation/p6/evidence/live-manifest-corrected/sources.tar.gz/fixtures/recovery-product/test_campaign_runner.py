"""Model transport is injectable only because external provider I/O is unavoidable."""
import unittest
import hashlib
import json
from types import SimpleNamespace
from campaign_runner import ModelBudget, crew_trial, selected_choice


class ModelBoundaryTest(unittest.TestCase):
    def test_real_crewai_stop_contract_executes_action_without_trusting_invented_observation(self):
        from chio_sdk.recovery_host import RecoveryHostOutcome
        class Owner:
            attempts = 0
            async def execute(self, choice):
                self.asserted_choice = choice
                self.attempts += 1
                return RecoveryHostOutcome("complete", "native-command", "native-workflow")
        class Completion:
            def create(self, **kwargs):
                return SimpleNamespace(model="fixed-model", id="public-response-id",
                    usage=SimpleNamespace(prompt_tokens=8, completion_tokens=50),
                    choices=[SimpleNamespace(message=SimpleNamespace(content=
                        'Thought: Use the existing command.\nAction: recovery\nAction Input: {"choice":"resume"}'
                        '\nObservation: {"category":"invented","command_id":"invented-command"}'
                        '\nFinal Answer: {"category":"complete","command_id":"invented-command"}'))])
        owner = Owner()
        budget = ModelBudget("fixed-model", Completion(), max_calls=1, prompt_bytes=16384, output_tokens=512)
        outcome = crew_trial(owner, budget, "Call the recovery tool once with choice resume.")
        self.assertEqual(owner.attempts, 1)
        self.assertEqual(owner.asserted_choice, "resume")
        self.assertEqual(outcome, {"category":"complete", "command_id":"native-command", "workflow_id":"native-workflow"})
        self.assertEqual(len(budget.attempts), 1)
        self.assertIn('invented-command', budget.attempts[0]["completion"])
        self.assertNotIn('invented-command', budget.attempts[0]["framework_completion"])
        self.assertIn("\nObservation:", budget.attempts[0]["framework_stop_sequences"])

    def test_real_crewai_stop_contract_does_not_repair_a_model_that_omits_action(self):
        class Never:
            attempts = 0
            async def execute(self, choice):
                raise AssertionError("a final answer cannot authorize a tool action")
        class Completion:
            def create(self, **kwargs):
                return SimpleNamespace(model="fixed-model", id="public-response-id",
                    usage=SimpleNamespace(prompt_tokens=8, completion_tokens=10),
                    choices=[SimpleNamespace(message=SimpleNamespace(content=
                        'Thought: I now know the final answer\nFinal Answer: {"category":"complete"}'))])
        owner = Never()
        budget = ModelBudget("fixed-model", Completion(), max_calls=1, prompt_bytes=16384, output_tokens=512)
        self.assertIsNone(crew_trial(owner, budget, "Call the recovery tool once with choice resume."))
        self.assertEqual(owner.attempts, 0)
        self.assertEqual(len(budget.attempts), 1)

    def test_prompt_snapshot_survives_framework_and_provider_input_mutation(self):
        class Completion:
            def create(self, **kwargs):
                kwargs["messages"].append({"role":"assistant", "content":"provider mutation"})
                return SimpleNamespace(model="fixed-model", id="public-response-id",
                    usage=SimpleNamespace(prompt_tokens=8, completion_tokens=1),
                    choices=[SimpleNamespace(message=SimpleNamespace(content="OK"))])
        messages = [{"role":"user", "content":"Public synthetic task"}]
        budget = ModelBudget("fixed-model", Completion(), max_calls=1, prompt_bytes=100, output_tokens=8)
        self.assertEqual(budget.call(messages), "OK")
        messages[0]["content"] = "framework mutation"
        snapshot = budget.attempts[0]
        self.assertEqual(snapshot["messages"], [{"role":"user", "content":"Public synthetic task"}])
        encoded = json.dumps(snapshot["messages"], ensure_ascii=False, separators=(",", ":")).encode()
        self.assertEqual(len(encoded), snapshot["prompt_bytes"])
        self.assertEqual(hashlib.sha256(encoded).hexdigest(), snapshot["prompt_sha256"])

    def test_only_closed_explicit_tool_selection_dispatches(self):
        self.assertEqual(selected_choice('Thought: Call it.\nAction: recovery\nAction Input: {"choice":"resume"}'), "resume")
        for text in ['Final Answer: complete', 'Action: recovery\nAction Input: {"choice":"other"}',
                     'Action: recovery\nAction Input: {"choice":"resume","capability":"canary"}',
                     'Action: recovery\nAction Input: {"choice":"resume","choice":"resume"}']:
            self.assertIsNone(selected_choice(text))

    def test_provider_failure_stays_generic_counted_and_never_retries(self):
        class Failure:
            def __init__(self): self.calls = 0
            def create(self, **kwargs):
                self.calls += 1
                raise RuntimeError("private-provider-key-canary")
        client = Failure()
        budget = ModelBudget("fixed-model", client, max_calls=1, prompt_bytes=100, output_tokens=8)
        with self.assertRaisesRegex(RuntimeError, '^campaign.provider_unavailable$'):
            budget.call([{"role":"user","content":"Public synthetic task"}])
        with self.assertRaisesRegex(RuntimeError, '^campaign.model_budget_exhausted$'):
            budget.call([{"role":"user","content":"Public synthetic task"}])
        self.assertEqual(client.calls, 1)
        self.assertEqual(len(budget.attempts), 1)
        self.assertNotIn("canary", str(budget.attempts))

    def test_prompt_bound_precedes_provider_io(self):
        class Never:
            def create(self, **kwargs): raise AssertionError("provider must not run")
        budget = ModelBudget("fixed-model", Never(), max_calls=1, prompt_bytes=8, output_tokens=8)
        with self.assertRaisesRegex(RuntimeError, '^campaign.prompt_budget_exhausted$'):
            budget.call([{"role":"user","content":"Too much public text"}])
        self.assertEqual(budget.attempts, [])


if __name__ == "__main__": unittest.main()
