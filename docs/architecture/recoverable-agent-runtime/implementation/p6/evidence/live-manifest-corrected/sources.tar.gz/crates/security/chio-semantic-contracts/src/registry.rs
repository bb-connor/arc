use crate::VerificationBudget;
use alloc::vec::Vec;
use chio_core_types::{recovery::*, PublicKey};
use chio_security_types::{recovery::*, semantic::*};
use serde::{Deserialize, Serialize};

/// The host supplies its actual manifest, not a package's claim about exposure.
#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ExposedSemanticToolV1 {
    pub server: ProtectedText<128>,
    pub tool: ProtectedText<128>,
    pub implementation: CanonicalPayloadDigest,
    pub input_schema: CanonicalPayloadDigest,
    pub output_schema: CanonicalPayloadDigest,
    pub channels: NonEmptyBoundedList<SemanticChannelRuleV1, 13>,
}

/// Resolved data is reusable historical evidence, not a native capture witness.
#[derive(Clone, Debug)]
pub struct CompiledSemanticRegistryV1 {
    deployment: SemanticDeploymentV1,
    packages: Vec<SemanticPackageV1>,
    digest: SemanticRegistryDigest,
}
impl CompiledSemanticRegistryV1 {
    pub fn deployment(&self) -> &SemanticDeploymentV1 {
        &self.deployment
    }
    pub fn digest(&self) -> SemanticRegistryDigest {
        self.digest
    }
    pub fn resolve(
        &self,
        server: &str,
        tool: &str,
    ) -> Result<(&SemanticRouteV1, &SemanticOperationContractV1), ContractError> {
        let route = self
            .deployment
            .routes
            .as_slice()
            .iter()
            .find(|route| route.server.as_str() == server && route.tool.as_str() == tool)
            .ok_or(ContractError::UnsupportedProfile)?;
        for package in &self.packages {
            if semantic_package_digest(package).map_err(|_| ContractError::Malformed)?
                == route.package
            {
                return package
                    .operations
                    .as_slice()
                    .iter()
                    .find(|op| op.operation == route.operation)
                    .map(|op| (route, op))
                    .ok_or(ContractError::MissingDependency);
            }
        }
        Err(ContractError::MissingDependency)
    }
}

const ALL_CHANNELS: [SemanticChannelV1; 13] = [
    SemanticChannelV1::Input,
    SemanticChannelV1::Success,
    SemanticChannelV1::Error,
    SemanticChannelV1::NoValue,
    SemanticChannelV1::Nested,
    SemanticChannelV1::Batch,
    SemanticChannelV1::Pagination,
    SemanticChannelV1::Redirect,
    SemanticChannelV1::Stream,
    SemanticChannelV1::File,
    SemanticChannelV1::Log,
    SemanticChannelV1::Shell,
    SemanticChannelV1::Model,
];
pub fn validate_semantic_channels(
    rules: &[SemanticChannelRuleV1],
    budget: &mut VerificationBudget,
) -> Result<(), ContractError> {
    if rules.len() != ALL_CHANNELS.len() {
        return Err(ContractError::UnsupportedProfile);
    }
    for (index, channel) in ALL_CHANNELS.iter().enumerate() {
        budget.charge(rules.len() as u32 + 1)?;
        let matching: Vec<_> = rules
            .iter()
            .filter(|rule| rule.channel == *channel)
            .collect();
        if matching.len() != 1 || matching[0].enabled != (index < 4) {
            return Err(ContractError::UnsupportedProfile);
        }
    }
    Ok(())
}
fn validate_selectors(
    selectors: &[SemanticSelectorV1],
    fields: &[SemanticFieldId],
    budget: &mut VerificationBudget,
) -> Result<(), ContractError> {
    for selector in selectors {
        budget.charge(fields.len() as u32 + 1)?;
        let field = match selector {
            SemanticSelectorV1::Present { field }
            | SemanticSelectorV1::Equals { field, .. }
            | SemanticSelectorV1::TextBytesAtMost { field, .. } => field,
        };
        if !fields.contains(field) {
            return Err(ContractError::BindingMismatch);
        }
        if matches!(selector, SemanticSelectorV1::TextBytesAtMost { bytes, .. } if bytes.get() == 0 || bytes.get() > 4096)
        {
            return Err(ContractError::UnsupportedProfile);
        }
    }
    Ok(())
}

pub fn compile_semantic_registry(
    deployment: &SignedSemanticDeploymentV1,
    packages: &[SignedSemanticPackageV1],
    operator_root: &PublicKey,
    publisher_roots: &[PublicKey],
    exposed: &[ExposedSemanticToolV1],
    budget: &mut VerificationBudget,
) -> Result<CompiledSemanticRegistryV1, ContractError> {
    if packages.is_empty()
        || packages.len() > 16
        || publisher_roots.is_empty()
        || publisher_roots.len() > 16
        || exposed.len() > 16
        || deployment.authority_key() != operator_root
        || !deployment
            .verify_signature()
            .map_err(|_| ContractError::Malformed)?
    {
        return Err(ContractError::BindingMismatch);
    }
    let body = deployment.body();
    if body.exposure_binding
        != semantic_content_digest(&exposed).map_err(|_| ContractError::Malformed)?
    {
        return Err(ContractError::BindingMismatch);
    }
    if body.packages.as_slice().len() != packages.len()
        || body.routes.as_slice().len() != exposed.len()
    {
        return Err(ContractError::BindingMismatch);
    }
    let mut digests = Vec::new();
    let mut resolved = Vec::new();
    let mut operation_count = 0;
    let mut operation_ids = Vec::new();
    for package in packages {
        budget.charge((publisher_roots.len() + digests.len() + 1) as u32)?;
        if !publisher_roots.contains(package.authority_key())
            || package.authority_key() == operator_root
            || !package
                .verify_signature()
                .map_err(|_| ContractError::Malformed)?
        {
            return Err(ContractError::BindingMismatch);
        }
        let digest =
            semantic_package_digest(package.body()).map_err(|_| ContractError::Malformed)?;
        if digests.contains(&digest)
            || !body.packages.as_slice().contains(&digest)
            || resolved
                .iter()
                .any(|prior: &SemanticPackageV1| prior.package == package.body().package)
        {
            return Err(ContractError::DuplicateIdentity);
        }
        operation_count += package.body().operations.as_slice().len();
        if operation_count > 16 {
            return Err(ContractError::LimitExceeded);
        }
        for (index, operation) in package.body().operations.as_slice().iter().enumerate() {
            budget.charge(operation_ids.len() as u32 + 1)?;
            if operation_ids.contains(&operation.operation) {
                return Err(ContractError::DuplicateIdentity);
            }
            operation_ids.push(operation.operation.clone());
            if package.body().operations.as_slice()[..index]
                .iter()
                .any(|prior| prior.operation == operation.operation)
            {
                return Err(ContractError::DuplicateIdentity);
            }
            validate_semantic_channels(operation.channels.as_slice(), budget)?;
            for (index, field) in operation.input_fields.as_slice().iter().enumerate() {
                budget.charge((index + 1) as u32)?;
                if operation.input_fields.as_slice()[..index].contains(field) {
                    return Err(ContractError::DuplicateIdentity);
                }
            }
            if operation.input_fields.as_slice().is_empty() {
                return Err(ContractError::UnsupportedProfile);
            }
            if operation.kind == SemanticOperationKindV1::IssueWrite
                && operation.required_assertions.as_slice().is_empty()
            {
                return Err(ContractError::UnsupportedProfile);
            }
            validate_selectors(
                operation.selectors.as_slice(),
                operation.input_fields.as_slice(),
                budget,
            )?;
            for (index, fact) in operation.prerequisites.as_slice().iter().enumerate() {
                budget.charge((index + 1) as u32)?;
                if operation.prerequisites.as_slice()[..index]
                    .iter()
                    .any(|prior| prior.fact == fact.fact)
                {
                    return Err(ContractError::DuplicateIdentity);
                }
            }
            for (index, field) in operation.projection_fields.as_slice().iter().enumerate() {
                budget.charge((index + operation.input_fields.as_slice().len() + 1) as u32)?;
                if !operation.input_fields.as_slice().contains(field)
                    || operation.projection_fields.as_slice()[..index].contains(field)
                {
                    return Err(ContractError::BindingMismatch);
                }
            }
            if (operation.kind == SemanticOperationKindV1::FieldProjection)
                == operation.projection_fields.as_slice().is_empty()
            {
                return Err(ContractError::UnsupportedProfile);
            }
        }
        digests.push(digest);
        resolved.push(package.body().clone());
    }
    // Iterative topological validation, with no recursive stack or include order.
    let mut done = Vec::new();
    while done.len() < resolved.len() {
        let mut progress = false;
        for (index, package) in resolved.iter().enumerate() {
            budget.charge((done.len() + package.dependencies.as_slice().len() + 1) as u32)?;
            if done.contains(&digests[index]) {
                continue;
            }
            for (edge, dependency) in package.dependencies.as_slice().iter().enumerate() {
                if !digests.contains(dependency) {
                    return Err(ContractError::MissingDependency);
                }
                if package.dependencies.as_slice()[..edge].contains(dependency) {
                    return Err(ContractError::DuplicateIdentity);
                }
            }
            if package
                .dependencies
                .as_slice()
                .iter()
                .all(|dependency| done.contains(dependency))
            {
                done.push(digests[index]);
                progress = true;
            }
        }
        if !progress {
            return Err(ContractError::DependencyCycle);
        }
    }
    let registry = CompiledSemanticRegistryV1 {
        deployment: body.clone(),
        packages: resolved,
        digest: semantic_registry_digest(body).map_err(|_| ContractError::Malformed)?,
    };
    for (index, route) in body.routes.as_slice().iter().enumerate() {
        budget.charge((exposed.len() + index + 1) as u32)?;
        if body.routes.as_slice()[..index].iter().any(|prior| {
            prior.operation == route.operation
                || (prior.server == route.server && prior.tool == route.tool)
        }) {
            return Err(ContractError::DuplicateIdentity);
        }
        let (_, op) = registry.resolve(route.server.as_str(), route.tool.as_str())?;
        let actual = exposed
            .iter()
            .find(|tool| tool.server == route.server && tool.tool == route.tool)
            .ok_or(ContractError::UnsupportedProfile)?;
        validate_selectors(
            route.operator_selectors.as_slice(),
            op.input_fields.as_slice(),
            budget,
        )?;
        for (index, authority) in route.annotators.as_slice().iter().enumerate() {
            budget.charge((index + 1) as u32)?;
            if route.annotators.as_slice()[..index]
                .iter()
                .any(|prior| prior.key == authority.key)
                || (!authority.may_attest_facts && !authority.facts.as_slice().is_empty())
            {
                return Err(ContractError::BindingMismatch);
            }
        }
        if route.implementation != op.implementation
            || route.input_schema != op.input_schema
            || route.output_schema != op.output_schema
            || actual.implementation != op.implementation
            || actual.input_schema != op.input_schema
            || actual.output_schema != op.output_schema
            || actual.channels != op.channels
        {
            return Err(ContractError::BindingMismatch);
        }
        for (index, destination) in route.destinations.as_slice().iter().enumerate() {
            budget.charge((index + 1) as u32)?;
            if route.destinations.as_slice()[..index]
                .iter()
                .any(|prior| prior.destination == destination.destination)
            {
                return Err(ContractError::DuplicateIdentity);
            }
            // Canonical URL validation belongs to the native transport adapter.
            if !destination.endpoint.as_str().starts_with("https://") {
                return Err(ContractError::UnsupportedProfile);
            }
        }
        for (index, override_rule) in route.reviewed_overrides.as_slice().iter().enumerate() {
            let selector = usize::try_from(override_rule.selector_index.get())
                .map_err(|_| ContractError::LimitExceeded)?;
            if selector >= op.selectors.as_slice().len()
                || route.reviewed_overrides.as_slice()[..index]
                    .iter()
                    .any(|prior| prior.selector_index == override_rule.selector_index)
            {
                return Err(ContractError::BindingMismatch);
            }
        }
    }
    Ok(registry)
}
