//! Bounded private setup transport retains ownership after caller disconnect.
use super::*;
use axum::{
    body::Bytes,
    extract::{DefaultBodyLimit, State},
    routing::post,
    Router,
};
use chio_core_types::recovery::{decode_contract, decode_recovery_capability};
use serde::{Deserialize, Serialize};
use tokio::sync::Semaphore;

#[derive(Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct ProbeRequest {
    capability: ProtectedText<32768>,
    workflow_id: WorkflowId,
}
#[derive(Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct QualifyRequest {
    capability: ProtectedText<32768>,
    probe: ProtectedText<32768>,
}
#[derive(Clone)]
struct Host {
    service: Arc<RecoverySetupService>,
    capacity: Arc<Semaphore>,
}
pub fn protected_recovery_router(
    service: Arc<RecoverySetupService>,
) -> Result<Router, RecoveryRuntimeError> {
    let recovery = super::super::transport::recovery_router(service.runtime.clone())?;
    Ok(recovery.merge(
        Router::new()
            .route("/v1/recovery/setup/probe", post(probe))
            .route("/v1/recovery/setup/qualify", post(qualify))
            .layer(DefaultBodyLimit::max(MAX_RECOVERY_WIRE_BYTES))
            .with_state(Host {
                service,
                capacity: Arc::new(Semaphore::new(2)),
            }),
    ))
}
async fn probe(State(host): State<Host>, bytes: Bytes) -> axum::response::Response {
    let Ok(permit) = host.capacity.try_acquire_owned() else {
        return super::super::transport::response::<SignedRecoverySetupProbeV1>(Err(
            RecoveryRuntimeError::Unavailable,
        ));
    };
    let handle = tokio::runtime::Handle::current();
    let result = tokio::task::spawn_blocking(move || {
        let _permit = permit;
        handle.block_on(async {
            let input: ProbeRequest =
                decode_contract(&bytes).map_err(|_| RecoveryRuntimeError::InvalidCommand)?;
            let capability = decode_recovery_capability(input.capability.as_str().as_bytes())
                .map_err(|_| RecoveryRuntimeError::InvalidCommand)?;
            host.service.probe(&capability, &input.workflow_id).await
        })
    })
    .await
    .unwrap_or(Err(RecoveryRuntimeError::Unavailable));
    super::super::transport::response(result)
}
async fn qualify(State(host): State<Host>, bytes: Bytes) -> axum::response::Response {
    let Ok(permit) = host.capacity.try_acquire_owned() else {
        return super::super::transport::response::<SignedRecoverySetupReportV1>(Err(
            RecoveryRuntimeError::Unavailable,
        ));
    };
    let handle = tokio::runtime::Handle::current();
    let result = tokio::task::spawn_blocking(move || {
        let _permit = permit;
        handle.block_on(async {
            let input: QualifyRequest =
                decode_contract(&bytes).map_err(|_| RecoveryRuntimeError::InvalidCommand)?;
            let capability = decode_recovery_capability(input.capability.as_str().as_bytes())
                .map_err(|_| RecoveryRuntimeError::InvalidCommand)?;
            let probe = decode_contract(input.probe.as_str().as_bytes())
                .map_err(|_| RecoveryRuntimeError::InvalidCommand)?;
            host.service.qualify(&capability, &probe).await
        })
    })
    .await
    .unwrap_or(Err(RecoveryRuntimeError::Unavailable));
    super::super::transport::response(result)
}
