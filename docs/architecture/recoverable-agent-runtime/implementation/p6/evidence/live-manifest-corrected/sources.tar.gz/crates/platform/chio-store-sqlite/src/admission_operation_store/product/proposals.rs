use super::*;
use chio_kernel::recovery::RecoveryCommandPortError;

impl SqliteAdmissionOperationStore {
    pub fn propose_policy_maintenance(
        &self,
        actor: &AuthenticatedRecoveryActor,
        reader: &AuthenticatedRecoveryActor,
        proposal: &PolicyMaintenanceProposalV1,
        fence: &StoreMutationFence,
        now: u64,
    ) -> Result<StoredPolicyMaintenanceProposalV1, RecoveryCommandPortError> {
        proposal.validate().map_err(refused)?;
        self.recovery_mutation(actor, fence, now, |tx, profile, now| {
            if actor.permission() != RecoveryPermission::Maintain
                || proposal.scope != *actor.scope()
            {
                return Err(refused("maintenance permission").into());
            }
            require_reader(tx, actor, Some(reader), profile, now)?;
            let report = stored_report(tx, actor.scope(), &proposal.report_id)?;
            let mut label = current_label(tx, profile)?
                .join_restrictions(&report.label)
                .map_err(refused)?;
            for reference in report.report.attachments.as_slice() {
                label = join_attachment(tx, actor.scope(), label, reference)?;
            }
            for case in proposal
                .benign_trajectories
                .as_slice()
                .iter()
                .chain(proposal.adversarial_trajectories.as_slice())
            {
                label = join_attachment(tx, actor.scope(), label, &case.artifact)?;
            }
            require_clearance(actor, profile, &label)?;
            let digest = CanonicalPayloadDigest::from_bytes(hash(
                "chio.recovery.policy-maintenance-proposal.v1",
                proposal,
            )?);
            let key = proposal_key(actor.scope(), &proposal.proposal_id)?;
            if let Some(old) = load::<StoredPolicyMaintenanceProposalV1>(tx, &key)? {
                require_clearance(
                    actor,
                    profile,
                    &label.join_restrictions(&old.label).map_err(refused)?,
                )?;
                if old.digest != digest {
                    return Err(RecoveryCommandPortError::Conflict);
                }
                return Ok(old);
            }
            let current =
                super::super::semantic::installation(tx, actor.scope())?.policy_basis()?;
            if current.policy != proposal.base_policy
                || current.deployment != proposal.base_deployment
            {
                return Err(RecoveryCommandPortError::Conflict);
            }
            reserve_quota(tx, &self.serving_owner, actor.scope(), "proposals", 16)?;
            for case in proposal
                .benign_trajectories
                .as_slice()
                .iter()
                .chain(proposal.adversarial_trajectories.as_slice())
            {
                super::super::knowledge::retain_product_evidence(
                    tx,
                    &self.serving_owner,
                    &case.artifact,
                    &format!(
                        "proposal-{}",
                        sha256_hex(&protected::encode(&(
                            &proposal.proposal_id,
                            &case.artifact
                        ))?)
                    ),
                )?;
            }
            let value = StoredPolicyMaintenanceProposalV1 {
                proposal: proposal.clone(),
                digest,
                maintainer: actor.principal().clone(),
                maintainer_subject: actor.capability().subject.clone(),
                label,
                influence: ArtifactInfluenceV1 {
                    commitment: digest,
                    externally_influenced: true,
                    unknown: true,
                },
                submitted_at_unix_ms: SafeInteger::new(now).map_err(refused)?,
            };
            save(tx, &self.serving_owner, actor.scope(), &key, &value)?;
            Ok(value)
        })
    }
}
