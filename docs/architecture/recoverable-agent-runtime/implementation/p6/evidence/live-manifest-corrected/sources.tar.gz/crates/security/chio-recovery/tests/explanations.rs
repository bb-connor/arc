//! Joined P2 acceptance: deterministic pure advice and classified verification.
mod explanations {
    mod basis;
    pub mod common;
    mod privacy;
    mod verification;
}
