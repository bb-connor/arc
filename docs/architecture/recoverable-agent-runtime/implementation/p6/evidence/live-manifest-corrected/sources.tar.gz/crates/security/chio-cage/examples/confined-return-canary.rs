//! Linux acceptance adversary. Build each image with CHIO_P5_CANARY_MODE; that
//! measured image has no runtime mode/argument/environment escape hatch.
#![forbid(unsafe_code)]
use chio_core_types::recovery::{decode_confined_input, project_confined_boolean};
use std::io::{Read, Write};
use std::process::ExitCode;
use zeroize::Zeroizing;

fn run() -> Result<(), Box<dyn std::error::Error>> {
    let mut packet = Zeroizing::new(Vec::new());
    std::io::stdin()
        .lock()
        .take(65537)
        .read_to_end(&mut packet)?;
    let input = decode_confined_input(&packet)?;
    let field = input.field;
    let observation = input.observation;
    let data: serde_json::Value = serde_json::from_slice(observation)?;
    let canary = data
        .get("secret")
        .and_then(|v| v.as_str())
        .ok_or("canary fixture")?
        .as_bytes();
    match option_env!("CHIO_P5_CANARY_MODE").unwrap_or("error") {
        "error" => {
            std::io::stderr().write_all(canary)?;
            return Err("classified failure".into());
        }
        "log" => std::io::stderr().write_all(canary)?,
        "progress" | "stream" => {
            for b in canary {
                std::io::stdout().write_all(core::slice::from_ref(b))?;
            }
            return Ok(());
        }
        "file" => {
            let path = data
                .get("probe_file")
                .and_then(|v| v.as_str())
                .ok_or("file fixture")?;
            if std::fs::write(path, canary).is_ok() {
                return Err("filesystem confinement failed".into());
            }
        }
        "callback" => {
            #[cfg(unix)]
            {
                let path = data
                    .get("probe_socket")
                    .and_then(|v| v.as_str())
                    .ok_or("callback fixture")?;
                if let Ok(mut socket) = std::os::unix::net::UnixStream::connect(path) {
                    socket.write_all(canary)?;
                }
            }
            return Err("callback attempted".into());
        }
        "wrong-predicate" => {
            std::io::stdout().write_all(b"false")?;
            return Ok(());
        }
        "overflow" => {
            std::io::stderr().write_all(&vec![b'x'; 16385])?;
            return Ok(());
        }
        "hang" => loop {
            std::hint::spin_loop();
        },
        _ => return Err("unregistered fixture mode".into()),
    }
    let value = Zeroizing::new(project_confined_boolean(observation, field)?);
    std::io::stdout().write_all(&value)?;
    Ok(())
}
fn main() -> ExitCode {
    match run() {
        Ok(()) => ExitCode::SUCCESS,
        Err(_) => ExitCode::FAILURE,
    }
}
