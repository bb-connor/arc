//! Thin transport to the trusted Rust recovery host, with no local decisions.
use crate::CliError;
use clap::Subcommand;
use serde_json::Value;
use std::{
    fs::File,
    io::{Read, Write},
    path::{Path, PathBuf},
    time::Duration,
};

#[derive(Debug, Subcommand)]
pub(crate) enum RecoveryCommands {
    /// Prove native protected setup, then qualify after an operator writer restart.
    Setup {
        #[command(subcommand)]
        command: SetupCommands,
    },
    /// Read signed audience-safe advice. Native resume rechecks current facts.
    Explain {
        #[arg(long)]
        endpoint: String,
        #[arg(long)]
        capability: PathBuf,
        #[arg(long)]
        workflow_id: String,
    },
    /// Submit or replay one exact canonical command. Retain its ID on ambiguity.
    Command {
        #[arg(long)]
        endpoint: String,
        #[arg(long)]
        capability: PathBuf,
        #[arg(long)]
        command: PathBuf,
    },
    /// Read the full exact preview under current approval authority.
    Review {
        #[arg(long)]
        endpoint: String,
        #[arg(long)]
        capability: PathBuf,
        #[arg(long)]
        workflow_id: String,
    },
    /// Reconcile the original operation under current settlement authority.
    Settle {
        #[arg(long)]
        endpoint: String,
        #[arg(long)]
        capability: PathBuf,
        #[arg(long)]
        workflow_id: String,
    },
}
#[derive(Debug, Subcommand)]
pub(crate) enum SetupCommands {
    /// Run the operator-pinned model-free benign and refused commands.
    Probe {
        #[arg(long)]
        endpoint: String,
        #[arg(long)]
        capability: PathBuf,
        #[arg(long)]
        workflow_id: String,
    },
    /// Recover the same operation under the fresh writer and return signed readiness evidence.
    Qualify {
        #[arg(long)]
        endpoint: String,
        #[arg(long)]
        capability: PathBuf,
        #[arg(long)]
        probe: PathBuf,
    },
}
fn refused() -> CliError {
    CliError::cli_other_error(
        "recovery transport refused or unavailable; retain the original command identity",
    )
}
fn bounded(path: &Path, limit: usize) -> Result<String, CliError> {
    let mut bytes = Vec::new();
    File::open(path)?
        .take((limit + 1) as u64)
        .read_to_end(&mut bytes)?;
    if bytes.len() > limit {
        return Err(refused());
    }
    String::from_utf8(bytes).map_err(|_| refused())
}
pub(crate) fn run(command: RecoveryCommands) -> Result<(), CliError> {
    let (endpoint, capability, path, body) = match command {
        RecoveryCommands::Setup {
            command:
                SetupCommands::Probe {
                    endpoint,
                    capability,
                    workflow_id,
                },
        } => (
            endpoint,
            capability,
            "setup/probe",
            ("workflow_id", workflow_id),
        ),
        RecoveryCommands::Setup {
            command:
                SetupCommands::Qualify {
                    endpoint,
                    capability,
                    probe,
                },
        } => {
            let proof = bounded(&probe, 32768)?;
            let _: chio_core_types::recovery::SignedRecoverySetupProbeV1 =
                chio_core_types::recovery::decode_contract(proof.as_bytes())
                    .map_err(|_| refused())?;
            (endpoint, capability, "setup/qualify", ("probe", proof))
        }
        RecoveryCommands::Explain {
            endpoint,
            capability,
            workflow_id,
        } => (
            endpoint,
            capability,
            "explain",
            ("workflow_id", workflow_id),
        ),
        RecoveryCommands::Command {
            endpoint,
            capability,
            command,
        } => (
            endpoint,
            capability,
            "commands",
            ("command", bounded(&command, 65536)?),
        ),
        RecoveryCommands::Review {
            endpoint,
            capability,
            workflow_id,
        } => (endpoint, capability, "review", ("workflow_id", workflow_id)),
        RecoveryCommands::Settle {
            endpoint,
            capability,
            workflow_id,
        } => (endpoint, capability, "settle", ("workflow_id", workflow_id)),
    };
    let mut url = reqwest::Url::parse(&endpoint).map_err(|_| refused())?;
    let local = matches!(
        url.host_str(),
        Some("localhost" | "127.0.0.1" | "[::1]" | "::1")
    );
    if (url.scheme() != "https" && !(url.scheme() == "http" && local))
        || !url.username().is_empty()
        || url.password().is_some()
        || url.query().is_some()
        || url.fragment().is_some()
    {
        return Err(refused());
    }
    url.set_path(&format!("/v1/recovery/{path}"));
    let capability = bounded(&capability, 32768)?;
    chio_core_types::recovery::decode_recovery_capability(capability.as_bytes())
        .map_err(|_| refused())?;
    let wire: Value = serde_json::json!({"capability":capability,body.0:body.1});
    let bytes = chio_core_types::canonical_json_bytes(&wire).map_err(|_| refused())?;
    if bytes.len() > 65536 {
        return Err(refused());
    }
    let client = reqwest::blocking::Client::builder()
        .timeout(Duration::from_secs(if path.starts_with("setup/") {
            120
        } else {
            20
        }))
        .redirect(reqwest::redirect::Policy::none())
        .retry(reqwest::retry::never())
        .build()
        .map_err(|_| refused())?;
    let response = client
        .post(url)
        .header("content-type", "application/json")
        .body(bytes)
        .send()
        .map_err(|_| refused())?;
    let success = response.status().is_success();
    let mut bytes = Vec::new();
    response
        .take(262145)
        .read_to_end(&mut bytes)
        .map_err(|_| refused())?;
    if bytes.len() > 262144 {
        return Err(refused());
    }
    if !success {
        // Only fixed public categories cross into operator output. Arbitrary
        // upstream messages, credentials and provider diagnostics stay private.
        return Err(match bytes.as_slice() {
            b"recovery.restart_required" => CliError::cli_other_error(
                "recovery.restart_required: the operator must restart the native writer",
            ),
            b"recovery.uncovered_mediation" => CliError::cli_other_error(
                "recovery.uncovered_mediation: a required native mediator is unavailable",
            ),
            _ => refused(),
        });
    }
    let value: Value = serde_json::from_slice(&bytes).map_err(|_| refused())?;
    if path == "explain" {
        // Structural validation only. Selecting the trusted issuer/key and
        // recomputing a classified basis are separate inspector operations.
        let view: chio_core_types::recovery::SignedRecoveryExplanationViewV1 =
            chio_core_types::recovery::decode_contract(&bytes).map_err(|_| refused())?;
        view.body().validate().map_err(|_| refused())?;
    }
    if path == "setup/probe" {
        let proof: chio_core_types::recovery::SignedRecoverySetupProbeV1 =
            chio_core_types::recovery::decode_contract(&bytes).map_err(|_| refused())?;
        if !proof.verify_signature().map_err(|_| refused())? {
            return Err(refused());
        }
        eprintln!("Native probe retained. The operator must restart the serving writer, then run setup qualify with this exact proof.");
    } else if path == "setup/qualify" {
        let proof: chio_core_types::recovery::SignedRecoverySetupReportV1 =
            chio_core_types::recovery::decode_contract(&bytes).map_err(|_| refused())?;
        if !proof.verify_signature().map_err(|_| refused())? {
            return Err(refused());
        }
        eprintln!("Signed native readiness evidence returned. Current capabilities and mediation remain required for every action.");
    }
    if path.starts_with("setup/") {
        // Emit the exact verified native envelope, without even a newline.
        // These bytes are the input to the strict canonical qualify decoder.
        std::io::stdout().write_all(&bytes)?;
    } else {
        println!("{}", serde_json::to_string_pretty(&value)?);
    }
    Ok(())
}
