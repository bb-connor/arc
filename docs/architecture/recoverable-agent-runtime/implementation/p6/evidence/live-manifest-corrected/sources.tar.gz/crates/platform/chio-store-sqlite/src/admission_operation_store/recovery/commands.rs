use super::*;
use serde::{Deserialize, Serialize};

#[derive(Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct CommandRecord {
    digest: CommandDigest,
    response: RecoveryCommandResponseV1,
}

pub(in crate::admission_operation_store) fn apply(
    tx: &Transaction<'_>,
    owner: &SqliteServingOwner,
    actor: &AuthenticatedRecoveryActor,
    command: &RecoveryCommandV1,
    deployment: &RecoveryDeploymentV1,
    now: u64,
) -> Result<RecoveryCommandResponseV1, RecoveryCommandPortError> {
    if actor.permission().wire_name() != command.command.permission() {
        return Err(invariant("recovery permission refused").into());
    }
    super::super::setup::require_command(tx, actor.scope(), &owner.fence, &command.command)?;
    let scope = scope_key(actor.scope())?;
    let key = format!(
        "command:{}",
        sha256_hex(&encode(&(
            actor.scope(),
            actor.principal(),
            command.command.permission(),
            &command.command_id
        ))?)
    );
    let digest = CommandDigest::from_bytes(hash("chio.recovery.command.v1", &command.command)?);
    // Resolve a committed identity before examining its original revision. The
    // caller and returned audience were freshly authorized by recovery_mutation.
    if let Some(existing) = raw(tx, &key)? {
        let existing: CommandRecord = decode(&existing.payload)?;
        if existing.digest != digest {
            return Err(RecoveryCommandPortError::Conflict);
        }
        let current = workflow_tx(tx, actor.scope(), &existing.response.workflow_id)?;
        verify_status(actor, deployment, &current)?;
        return Ok(existing.response);
    }
    let commands = tenant_record_count(tx, actor.scope(), "command")?;
    let intake = matches!(
        command.command,
        RecoveryCommandBodyV1::CreateWorkflow { .. }
            | RecoveryCommandBodyV1::SelectOffer { .. }
            | RecoveryCommandBodyV1::SubmitApproval { .. }
    );
    let ceiling = if intake {
        MAX_RECOVERY_COMMANDS - 512
    } else {
        MAX_RECOVERY_COMMANDS
    };
    let total: i64 = tx
        .query_row(
            "SELECT count(*) FROM admission_operation_recovery_records WHERE kind='command'",
            [],
            |row| row.get(0),
        )
        .map_err(sqlite_error)?;
    let total_ceiling = if intake { 7168 } else { 8192 };
    if total >= total_ceiling || commands >= ceiling as i64 {
        return Err(invariant("recovery command quota exhausted").into());
    }
    let record = match &command.command {
        RecoveryCommandBodyV1::CreateWorkflow {
            creation_key,
            template: RecoveryTemplateV1::SupportTicketPublicIssue,
            request_seed,
        } => {
            let id = WorkflowId::new(&format!(
                "workflow:{}",
                sha256_hex(&encode(&(actor.scope(), creation_key))?)
            ))
            .map_err(|_| invariant("recovery identity refused"))?;
            let seed: ToolCallRequest =
                chio_core_types::recovery::decode_contract(request_seed.as_str().as_bytes())
                    .map_err(|_| invariant("recovery seed wire bound refused"))?;
            validate_seed(&seed, deployment)?;
            if let Some(existing) = raw(tx, &workflow_key(actor.scope(), &id)?)? {
                let existing: RecoveryWorkflowRecordV1 = decode(&existing.payload)?;
                if existing.creation_seed != *request_seed {
                    return Err(RecoveryCommandPortError::Conflict);
                }
                existing
            } else {
                let count = tenant_record_count(tx, actor.scope(), "workflow")?;
                let total: i64 = tx.query_row("SELECT count(*) FROM admission_operation_recovery_records WHERE kind='workflow'", [], |row| row.get(0)).map_err(sqlite_error)?;
                if total >= 128 || count >= MAX_RECOVERY_WORKFLOWS as i64 {
                    return Err(invariant("recovery workflow quota exhausted").into());
                }
                // Closed identities are retained. P1 has no deletion or identity
                // recycling, including after quota exhaustion or cancellation.
                let suffix = sha256_hex(&encode(&(actor.scope(), &id))?);
                let mut new = RecoveryWorkflowRecordV1 {
                    scope: actor.scope().clone(),
                    workflow_id: id,
                    step_id: StepId::new(&format!("step:{suffix}"))
                        .map_err(|_| invariant("recovery identity refused"))?,
                    continuation_id: ContinuationId::new(&format!("continuation:{suffix}"))
                        .map_err(|_| invariant("recovery identity refused"))?,
                    revision: SafeInteger::new(1)
                        .map_err(|_| invariant("recovery version refused"))?,
                    control: WorkflowControlV1::Active,
                    seed,
                    creation_seed: request_seed.clone(),
                    deployment_digest: DeploymentDigest::from_bytes(hash(
                        "chio.recovery.deployment.v1",
                        deployment,
                    )?),
                    created_by: actor.principal().clone(),
                    effect_cardinality: deployment.effect_cardinality,
                    action: None,
                    process_reservation: None,
                    selected: false,
                    review: None,
                    approval: None,
                    issuance: None,
                    signed_grant: None,
                    envelope: None,
                    admission: None,
                    admission_closed: false,
                    native_link: None,
                    captured: false,
                    effect: EffectObservationV1::NeverAdmitted,
                    release: ReleaseDispositionV1::NotAvailable,
                    original_flow: None,
                    reported_decision: None,
                    provider_finality: None,
                    provider_lookups: SafeInteger::ZERO,
                };
                save_workflow(tx, owner, &mut new)?;
                new
            }
        }
        body => {
            let (id, revision) = selector(body)?;
            let mut record = workflow_tx(tx, actor.scope(), id)?;
            verify_status(actor, deployment, &record)?;
            if revision.is_some_and(|revision| revision != record.revision) {
                return Err(RecoveryCommandPortError::Conflict);
            }
            match body {
                RecoveryCommandBodyV1::InspectWorkflow { .. }
                | RecoveryCommandBodyV1::ResumeWorkflow { .. } => {}
                RecoveryCommandBodyV1::SelectOffer { offer_id, .. } => {
                    require_active(&record)?;
                    if record.process_reservation.is_none() {
                        return Err(invariant("recovery process reservation is absent").into());
                    }
                    let action = record
                        .action
                        .as_ref()
                        .ok_or_else(|| invariant("recovery offer is absent"))?;
                    if offer_id.as_str()
                        != format!(
                            "offer:{}",
                            hex(&hash("chio.recovery.action-intent.v1", action)?)
                        )
                    {
                        return Err(invariant("recovery offer changed").into());
                    }
                    fresh_basis(tx, deployment, &record, now)?;
                    if !record.selected {
                        record.selected = true;
                        save_workflow(tx, owner, &mut record)?;
                    }
                }
                RecoveryCommandBodyV1::SubmitApproval { approval, .. } => {
                    require_active(&record)?;
                    if !record.selected {
                        return Err(invariant("recovery identity is not reserved").into());
                    }
                    let submitted: RecoveryApprovalSubmissionV1 =
                        chio_core_types::recovery::decode_contract(approval.as_str().as_bytes())
                            .map_err(|_| invariant("recovery approval wire bound refused"))?;
                    verify_preview(actor, deployment, &record)?;
                    if submitted.intent.reviewer != *actor.principal() {
                        return Err(invariant("recovery reviewer changed").into());
                    }
                    validate_approval(&record, &submitted, deployment, now)?;
                    fresh_basis(tx, deployment, &record, now)?;
                    match &record.approval {
                        Some(existing) if encode(existing)? == encode(&submitted)? => {}
                        Some(_) => return Err(RecoveryCommandPortError::Conflict),
                        None => {
                            record.approval = Some(submitted);
                            save_workflow(tx, owner, &mut record)?;
                        }
                    }
                }
                RecoveryCommandBodyV1::CancelWorkflow { .. } => {
                    if record.control == WorkflowControlV1::Active {
                        record.control = WorkflowControlV1::CancelRequested;
                        if record.admission.is_none() {
                            record.admission_closed = true;
                            record.control = WorkflowControlV1::Cancelled;
                        }
                        save_workflow(tx, owner, &mut record)?;
                    }
                }
                RecoveryCommandBodyV1::ReportDecision { decision, .. } => {
                    if !record.effect.is_settled() {
                        return Err(invariant("recovery effect is unresolved").into());
                    }
                    match record.reported_decision {
                        Some(existing) if existing != *decision => {
                            return Err(RecoveryCommandPortError::Conflict)
                        }
                        Some(_) => {}
                        None => {
                            record.reported_decision = Some(*decision);
                            save_workflow(tx, owner, &mut record)?;
                        }
                    }
                }
                RecoveryCommandBodyV1::CreateWorkflow { .. } => {
                    return Err(invariant("recovery command shape refused").into())
                }
            }
            record
        }
    };
    // Exactly one effectful continuation exists in this P1 template. Settlement
    // never clears selection, consumption or the spent step to permit another.
    let response = RecoveryCommandResponseV1 {
        command_id: command.command_id.clone(),
        workflow_id: record.workflow_id.clone(),
        revision: record.revision,
        control: record.control,
        effect: record.effect.clone(),
        release: record.release.clone(),
    };
    save(
        tx,
        owner,
        &key,
        &scope,
        "command",
        &encode(&CommandRecord {
            digest,
            response: response.clone(),
        })?,
        None,
    )?;
    Ok(response)
}

// Quotas aggregate every operator-configured process in a tenant. A caller
// cannot gain another quota allocation by selecting another process scope.
// Deployment records are protected, canonical and share each row's scope key.
fn tenant_record_count(
    tx: &Transaction<'_>,
    scope: &RecoveryScopeV1,
    kind: &str,
) -> Result<i64, AdmissionOperationStoreError> {
    tx.query_row(
        "SELECT count(*) FROM admission_operation_recovery_records r
         JOIN admission_operation_recovery_records d ON d.scope_key=r.scope_key AND d.kind='deployment'
         WHERE r.kind=?1 AND json_extract(d.payload,'$.scope.tenant_id')=?2
           AND json_extract(d.payload,'$.scope.authority_domain')=?3",
        params![kind,scope.tenant_id.as_str(),scope.authority_domain.as_str()],
        |row| row.get(0),
    ).map_err(sqlite_error)
}
fn selector(
    body: &RecoveryCommandBodyV1,
) -> Result<(&WorkflowId, Option<SafeInteger>), AdmissionOperationStoreError> {
    match body {
        RecoveryCommandBodyV1::InspectWorkflow { workflow_id } => Ok((workflow_id, None)),
        RecoveryCommandBodyV1::SelectOffer {
            workflow_id,
            expected_revision,
            ..
        }
        | RecoveryCommandBodyV1::SubmitApproval {
            workflow_id,
            expected_revision,
            ..
        }
        | RecoveryCommandBodyV1::ResumeWorkflow {
            workflow_id,
            expected_revision,
        }
        | RecoveryCommandBodyV1::CancelWorkflow {
            workflow_id,
            expected_revision,
        }
        | RecoveryCommandBodyV1::ReportDecision {
            workflow_id,
            expected_revision,
            ..
        } => Ok((workflow_id, Some(*expected_revision))),
        _ => Err(invariant("recovery command selector refused")),
    }
}
