"""Model-free actual framework/native corpus preflight, outside live denominators."""
import argparse
import asyncio
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time
from campaign_baseline import SupervisorSession
from campaign_runner import graph_trial, crew_trial, public_task
from chio_sdk.recovery_host import RecoveryHostSession


class ExplicitAction:
    model = "model-free-corpus-preflight"
    def __init__(self): self.calls = 0
    def call(self, messages):
        self.calls += 1
        if self.calls > 1: raise RuntimeError("preflight model-free action bound")
        return 'Thought: Check the owned command.\nAction: recovery\nAction Input: {"choice":"resume"}'


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkout", type=Path, required=True)
    parser.add_argument("--evidence", type=Path, required=True)
    args = parser.parse_args()
    args.evidence.mkdir(mode=0o700, parents=True, exist_ok=False)
    results = []
    policy = None
    for host in ["langgraph", "crewai"]:
        for workflow in ["support", "artifact"]:
            for arm in ["baseline", "product"]:
                trial = {"host":host,"workflow":workflow,"arm":arm,"case":"authorized"}
                directory = args.evidence/f"{host}-{workflow}-{arm}"
                directory.mkdir(mode=0o700)
                (directory/"configuration.json").write_text(json.dumps({"workflow":workflow,"case":"authorized"}))
                log = (directory/"native.log").open("wb")
                env = {**os.environ,"CHIO_P6_CAMPAIGN_EXCHANGE":str(directory.resolve())}
                env.pop("OPENAI_API_KEY", None)
                process = subprocess.Popen(["cargo","test","--offline","--locked","-p","chio-control-plane","--lib",
                    "p6_live_comparative_native_host","--","--ignored","--test-threads=1"],cwd=args.checkout,
                    env=env,stdout=log,stderr=subprocess.STDOUT)
                try:
                    deadline = time.monotonic()+240
                    while not (directory/"ready").is_file():
                        if process.poll() is not None or time.monotonic() > deadline: raise RuntimeError("preflight native startup failed")
                        time.sleep(.05)
                    descriptor = (directory/"authority-contract.json").read_bytes()
                    digest = hashlib.sha256(descriptor).hexdigest()
                    if policy is None:
                        policy = digest
                        (args.evidence/"authority-contract.json").write_bytes(descriptor)
                    assert policy == digest
                    capability = (directory/"capability.json").read_text()
                    wire = (directory/"command.json").read_bytes()
                    endpoint = (directory/"ready").read_text()
                    session = RecoveryHostSession(endpoint,capability,{"resume":wire},timeout_seconds=120) if arm == "product" else SupervisorSession(endpoint,capability,wire)
                    model = ExplicitAction()
                    output = asyncio.run(graph_trial(session,model,public_task(trial))) if host == "langgraph" else crew_trial(session,model,public_task(trial))
                    assert output["category"] == "complete" and session.attempts == model.calls == 1
                    (directory/"finish").touch()
                    assert process.wait(timeout=120) == 0
                    facts = json.loads((directory/"native-evidence.json").read_bytes())
                    assert facts["useful_completion"] and facts["source_label_retained"]
                    assert facts["unauthorized_effects"] == facts["duplicate_effects"] == 0
                    results.append({**trial,"native":facts,"outcome":output,"model_free_actions":model.calls,"authority_policy":digest})
                    print("Actual model-free preflight passed",host,workflow,arm,flush=True)
                finally:
                    (directory/"finish").touch()
                    if process.poll() is None: process.wait(timeout=120)
                    log.close()
    (args.evidence/"result.json").write_text(json.dumps({"cases":results,"passed":len(results)==8},indent=2)+"\n")


if __name__ == "__main__": main()
