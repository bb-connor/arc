use crate::canonical::CanonicalBytes;
use chio_security_types::ports::Digest32;
use sha2::{Digest, Sha256};

const ACTION_INTENT_DOMAIN: &[u8] = b"chio.recovery.action-intent.v1\0";
const OFFER_DOMAIN: &[u8] = b"chio.recovery.offer.v1\0";
const PLAN_DOMAIN: &[u8] = b"chio.recovery.plan.v1\0";
const BASIS_DOMAIN: &[u8] = b"chio.recovery.basis.v1\0";
const EXPLANATION_DOMAIN: &[u8] = b"chio.recovery.explanation.v1\0";
const AUTHORIZATION_REQUIREMENTS_DOMAIN: &[u8] = b"chio.recovery.authorization-requirements.v1\0";
const SEMANTIC_DEPLOYMENT_DOMAIN: &[u8] = b"chio.semantic.deployment.v1\0";
const ARTIFACT_PROVENANCE_DOMAIN: &[u8] = b"chio.artifact.provenance.v1\0";
const RETURN_CONTRACT_DOMAIN: &[u8] = b"chio.isolation.return-contract.v1\0";
const EXPLANATION_SNAPSHOT_DOMAIN: &[u8] = b"chio.recovery.explanation-snapshot.v1\0";
const REMEDY_REGISTRY_DOMAIN: &[u8] = b"chio.recovery.remedy-registry.v1\0";
const EXPLANATION_EVALUATION_DOMAIN: &[u8] = b"chio.recovery.explanation-evaluation.v1\0";
const EXPLANATION_PROJECTION_DOMAIN: &[u8] = b"chio.recovery.explanation-projection.v1\0";

/// New digest meanings do not change any legacy request or receipt algorithm.
/// Digest computation establishes content identity, never execution authority.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum RecoveryDigestDomain {
    ActionIntent,
    Offer,
    Plan,
    Basis,
    Explanation,
    AuthorizationRequirements,
    SemanticDeployment,
    ArtifactProvenance,
    ReturnContract,
    ExplanationSnapshot,
    RemedyRegistry,
    ExplanationEvaluation,
    ExplanationProjection,
}
pub const RECOVERY_DIGEST_DOMAINS: [RecoveryDigestDomain; 13] = [
    RecoveryDigestDomain::ActionIntent,
    RecoveryDigestDomain::Offer,
    RecoveryDigestDomain::Plan,
    RecoveryDigestDomain::Basis,
    RecoveryDigestDomain::Explanation,
    RecoveryDigestDomain::AuthorizationRequirements,
    RecoveryDigestDomain::SemanticDeployment,
    RecoveryDigestDomain::ArtifactProvenance,
    RecoveryDigestDomain::ReturnContract,
    RecoveryDigestDomain::ExplanationSnapshot,
    RecoveryDigestDomain::RemedyRegistry,
    RecoveryDigestDomain::ExplanationEvaluation,
    RecoveryDigestDomain::ExplanationProjection,
];
impl RecoveryDigestDomain {
    pub const fn prefix(self) -> &'static [u8] {
        match self {
            Self::ActionIntent => ACTION_INTENT_DOMAIN,
            Self::Offer => OFFER_DOMAIN,
            Self::Plan => PLAN_DOMAIN,
            Self::Basis => BASIS_DOMAIN,
            Self::Explanation => EXPLANATION_DOMAIN,
            Self::AuthorizationRequirements => AUTHORIZATION_REQUIREMENTS_DOMAIN,
            Self::SemanticDeployment => SEMANTIC_DEPLOYMENT_DOMAIN,
            Self::ArtifactProvenance => ARTIFACT_PROVENANCE_DOMAIN,
            Self::ReturnContract => RETURN_CONTRACT_DOMAIN,
            Self::ExplanationSnapshot => EXPLANATION_SNAPSHOT_DOMAIN,
            Self::RemedyRegistry => REMEDY_REGISTRY_DOMAIN,
            Self::ExplanationEvaluation => EXPLANATION_EVALUATION_DOMAIN,
            Self::ExplanationProjection => EXPLANATION_PROJECTION_DOMAIN,
        }
    }
    pub fn digest(self, body: &CanonicalBytes) -> Digest32 {
        let mut hash = Sha256::new();
        hash.update(self.prefix());
        hash.update(body.as_bytes());
        Digest32::new(hash.finalize().into())
    }
}
