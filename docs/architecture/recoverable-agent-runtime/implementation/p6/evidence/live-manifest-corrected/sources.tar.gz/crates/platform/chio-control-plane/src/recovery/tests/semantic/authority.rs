use super::*;
use chio_kernel::ToolCallResponse;

fn installation(
    f: &RecoveryFixture,
    p: &SemanticFixture,
) -> TestResult<NativeSemanticInstallationV1> {
    let native = f.kernel.recovery_deployment(&p.plan.scope)?;
    Ok(NativeSemanticInstallationV1 {
        deployment: p.deployment.clone(),
        packages: NonEmptyBoundedList::new(vec![p.package.clone()])?,
        operator_root: p.operator.public_key(),
        publisher_roots: NonEmptyBoundedList::new(vec![p.publisher.public_key()])?,
        exposed: NonEmptyBoundedList::new(vec![p.exposed.clone()])?,
        native_authority: native.native_authority,
        security_context: native.security_context,
    })
}
fn denied(result: &Result<ToolCallResponse, KernelError>) -> bool {
    result.is_err()
        || result
            .as_ref()
            .is_ok_and(|response| response.verdict == Verdict::Deny)
}
#[tokio::test]
async fn p3_native_alternate_destination_selects_exact_account_transport() -> TestResult {
    let f = native_fixture("alternate")?;
    let (runtime, request, _) =
        prepare(&f, "alternate-a", SemanticOutputDispositionV1::ReturnValue)?;
    let response = runtime
        .execute_step(&f.process, "root", "alternate-a", &request)
        .await?;
    assert_eq!(response.verdict, Verdict::Allow);
    let db = rusqlite::Connection::open(f.path.join("semantic-effects.db"))?;
    let actual: (String, String) = db.query_row(
        "SELECT account,resource FROM semantic_submissions",
        [],
        |row| Ok((row.get(0)?, row.get(1)?)),
    )?;
    assert_eq!(
        actual,
        ("alternate-account".into(), "alternate-queue".into())
    );
    for (key, mutation) in [("alternate-b", 0), ("alternate-c", 1)] {
        let (runtime, mut request, mut p) =
            prepare(&f, key, SemanticOutputDispositionV1::ReturnValue)?;
        if mutation == 0 {
            p.invocation.action.destination = SemanticDestinationId::new("unselected-account")?;
        } else {
            let mut body = p.invocation.audience.body().clone();
            body.account = ProviderAccountId::new("foreign-account")?;
            p.invocation.audience = SignedSemanticAudienceV1::sign(body, &p.resolver)?;
        }
        request.arguments = serde_json::to_value(&p.invocation)?;
        assert!(denied(
            &runtime
                .execute_step(&f.process, "root", key, &request)
                .await
        ));
        assert_eq!(f.effects.load(Ordering::SeqCst), 1);
    }
    Ok(())
}
#[tokio::test]
async fn p3_native_authority_matrix_rejects_annotation_and_capability_escalation() -> TestResult {
    for case in [
        "annotation",
        "capability",
        "model",
        "payload",
        "version",
        "foreign-generation",
    ] {
        let f = native_fixture("write")?;
        let (runtime, mut request, mut p) =
            prepare(&f, "authority-a", SemanticOutputDispositionV1::ReturnValue)?;
        match case {
            "annotation" => {
                let body = SemanticAnnotationV1 {
                    domain_version: VersionV1,
                    scope: p.plan.scope.clone(),
                    input: p.invocation.action.inputs.as_slice()[0].clone(),
                    restrictions: restricted_label(),
                    externally_influenced: true,
                    facts: BoundedList::new(vec![SemanticFactId::new(
                        "customer-instructions-reviewed",
                    )?])?,
                    confidence_basis_points: SafeInteger::new(10000)?,
                    issued_at_unix_ms: p.invocation.action.issued_at_unix_ms,
                    valid_until_unix_ms: p.invocation.action.valid_until_unix_ms,
                };
                p.invocation.annotations =
                    BoundedList::new(vec![SignedSemanticAnnotationV1::sign(body, &p.annotator)?])?;
            }
            "capability" => {
                request.capability = f.kernel.issue_capability(
                    &request.capability.subject,
                    ChioScope::default(),
                    600,
                )?;
                p.invocation.action =
                    runtime.frame_action(&request, p.invocation.action, &p.payload)?;
                chains::attach_endorsement(&mut p, "authority-capability")?;
            }
            "model" => {
                request.model_metadata = Some(chio_core::capability::scope::ModelMetadata {
                    model_id: "unbound-model".into(),
                    safety_tier: None,
                    provider: None,
                    provenance_class: Default::default(),
                });
            }
            "payload" => {
                let mut fields = p.invocation.payload.fields.as_slice().to_vec();
                fields[0].value = SemanticValueV1::Text {
                    value: ProtectedText::new("substituted-payload")?,
                };
                p.invocation.payload.fields = NonEmptyBoundedList::new(fields)?;
            }
            "foreign-generation" => {
                let other = f.process.tool_request(
                    "root",
                    "foreign-source",
                    "server-a",
                    "send",
                    f.seed.arguments.clone(),
                )?;
                let denied = f
                    .process
                    .invoke_known_only("root", "foreign-source", &other)
                    .await?;
                assert_eq!(denied.verdict, Verdict::Deny);
            }
            _ => {
                let mut inputs = p.invocation.action.inputs.as_slice().to_vec();
                inputs[0].version = ArtifactVersionId::from_bytes([98; 32]);
                p.invocation.action.inputs = NonEmptyBoundedList::new(inputs)?;
                chains::attach_endorsement(&mut p, "authority-version")?;
            }
        }
        request.arguments = serde_json::to_value(&p.invocation)?;
        assert!(
            denied(
                &runtime
                    .execute_step(&f.process, "root", "authority-a", &request)
                    .await
            ),
            "{case}"
        );
        assert_eq!(f.effects.load(Ordering::SeqCst), 0);
    }
    Ok(())
}
#[tokio::test]
async fn p3_native_evidence_is_one_shot_across_distinct_actions_and_plan_revisions() -> TestResult {
    let f = native_fixture("write")?;
    let (runtime, request, first) = prepare(&f, "once-a", SemanticOutputDispositionV1::Withhold)?;
    runtime
        .execute_step(&f.process, "root", "once-a", &request)
        .await?;
    let (runtime, mut request, mut second) =
        prepare(&f, "once-b", SemanticOutputDispositionV1::ReturnValue)?;
    chains::attach_endorsement(
        &mut second,
        first.invocation.endorsements.as_slice()[0]
            .body()
            .evidence
            .as_str(),
    )?;
    request.arguments = serde_json::to_value(&second.invocation)?;
    assert!(denied(
        &runtime
            .execute_step(&f.process, "root", "once-b", &request)
            .await
    ));
    assert_eq!(f.effects.load(Ordering::SeqCst), 1);
    let (runtime, mut revised, mut p) =
        prepare(&f, "once-a", SemanticOutputDispositionV1::ReturnValue)?;
    revised.request_id = "direct-revised-action".into();
    p.invocation.action = runtime.frame_action(&revised, p.invocation.action, &p.payload)?;
    chains::attach_endorsement(&mut p, "fresh-revised-endorsement")?;
    revised.arguments = serde_json::to_value(&p.invocation)?;
    let context = f.process.recovery_security_context("root")?;
    assert!(denied(
        &f.kernel
            .evaluate_tool_call_with_security_context(&revised, &context)
            .await
    ));
    assert_eq!(f.effects.load(Ordering::SeqCst), 1);
    Ok(())
}
#[tokio::test]
async fn p3_native_reload_is_atomic_stales_uncaptured_and_preserves_original_completed(
) -> TestResult {
    let f = native_fixture("write")?;
    let (runtime, original, _) = prepare(&f, "captured-a", SemanticOutputDispositionV1::Withhold)?;
    let completed = runtime
        .execute_step(&f.process, "root", "captured-a", &original)
        .await?;
    let (runtime, pending, p) = prepare(&f, "pending-a", SemanticOutputDispositionV1::ReturnValue)?;
    let mut selected = installation(&f, &p)?;
    let mut body = selected.deployment.body().clone();
    body.generation = SafeInteger::new(2)?;
    body.exposure_binding = CanonicalPayloadDigest::from_bytes([99; 32]);
    selected.deployment = SignedSemanticDeploymentV1::sign(body.clone(), &p.operator)?;
    assert!(f
        .authority
        .admission_operation_store()
        .configure_semantic_deployment(&selected)
        .is_err());
    // Failed activation leaves generation one available to new plans.
    let (_, _, _) = prepare(
        &f,
        "after-invalid",
        SemanticOutputDispositionV1::ReturnValue,
    )?;
    body.exposure_binding = p.deployment.body().exposure_binding;
    selected.deployment = SignedSemanticDeploymentV1::sign(body, &p.operator)?;
    f.authority
        .admission_operation_store()
        .configure_semantic_deployment(&selected)?;
    assert!(denied(
        &runtime
            .execute_step(&f.process, "root", "pending-a", &pending)
            .await
    ));
    let replay = runtime
        .execute_step(&f.process, "root", "captured-a", &original)
        .await?;
    assert_eq!(replay.output, completed.output);
    assert_eq!(f.effects.load(Ordering::SeqCst), 1);
    Ok(())
}
#[tokio::test]
async fn p3_native_completed_withhold_restarts_without_effect_or_raw_release() -> TestResult {
    let directory = tempfile::tempdir()?;
    std::fs::write(directory.path().join("semantic-kind"), "write")?;
    let f = RecoveryFixture::open(directory.path().to_path_buf(), None, false)?;
    let (runtime, request, _) = prepare(&f, "restart-a", SemanticOutputDispositionV1::Withhold)?;
    let original = runtime
        .execute_step(&f.process, "root", "restart-a", &request)
        .await?;
    drop(runtime);
    drop(f);
    let f = RecoveryFixture::open(directory.path().to_path_buf(), None, false)?;
    let runtime = NativeSemanticRuntime::new(
        f.kernel.clone(),
        Arc::new(f.authority.admission_operation_store()),
        f.runtime.scope.clone(),
        f.authority.mutation_fence(),
    );
    let replay = runtime
        .execute_step(&f.process, "root", "restart-a", &request)
        .await?;
    assert_eq!(replay.output, original.output);
    assert_eq!(f.effects.load(Ordering::SeqCst), 1);
    assert!(!chio_core::canonical_json_string(&replay.receipt)?.contains("provider-output-canary"));
    Ok(())
}
#[tokio::test]
async fn p3_native_provider_error_has_no_raw_fallback_or_replacement_attempt() -> TestResult {
    let f = native_fixture("error")?;
    std::fs::write(f.path.join("provider-error"), "enabled")?;
    let (runtime, request, _) = prepare(&f, "error-a", SemanticOutputDispositionV1::Withhold)?;
    let result = runtime
        .execute_step(&f.process, "root", "error-a", &request)
        .await;
    assert!(!format!("{result:?}").contains("provider-private-error-canary"));
    assert_eq!(f.effects.load(Ordering::SeqCst), 1);
    let replay = runtime
        .execute_step(&f.process, "root", "error-a", &request)
        .await;
    assert!(!format!("{replay:?}").contains("provider-private-error-canary"));
    assert_eq!(f.effects.load(Ordering::SeqCst), 1);
    Ok(())
}
#[tokio::test]
async fn p3_native_protected_semantic_inventory_tamper_fails_before_effect() -> TestResult {
    let f = native_fixture("write")?;
    let (runtime, request, _) = prepare(&f, "tamper-a", SemanticOutputDispositionV1::ReturnValue)?;
    let db = rusqlite::Connection::open(f.path.join("admission.db"))?;
    let result = db.execute("UPDATE admission_operation_recovery_records SET payload=CAST(replace(CAST(payload AS TEXT),'issue-queue','foreign-queue') AS BLOB) WHERE record_key LIKE 'semantic-deployment:%'", []);
    if result.is_ok() {
        assert!(denied(
            &runtime
                .execute_step(&f.process, "root", "tamper-a", &request)
                .await
        ));
    }
    assert_eq!(f.effects.load(Ordering::SeqCst), 0);
    Ok(())
}
