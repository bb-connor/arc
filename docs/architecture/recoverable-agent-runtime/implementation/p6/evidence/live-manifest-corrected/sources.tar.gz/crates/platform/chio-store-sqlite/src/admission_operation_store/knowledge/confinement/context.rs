//! Context derivation has no caller-selected lineage or epoch override.
use super::*;
use chio_kernel::SecurityInvocationContextV1;
use chio_security_types::ports::{IsolationEpochId, LineageId, SessionId, TenantId};

pub(super) fn make(
    profile: &NativeKnowledgeInstallationV1,
    child: &CapabilityToken,
    lineage: &IsolationLineageId,
    epoch: &ProtectedText<128>,
) -> Result<SecurityInvocationContext, AdmissionOperationStoreError> {
    Ok(SecurityInvocationContext::v1(
        SecurityInvocationContextV1::new(
            TenantId::new(profile.scope.tenant_id.as_str()).map_err(refused)?,
            SessionId::new(profile.producer_context.as_v1().session_id().as_str())
                .map_err(refused)?,
            chio_security_types::PrincipalId::new(child.subject.to_hex()).map_err(refused)?,
            IsolationEpochId::new(epoch.as_str()).map_err(refused)?,
            LineageId::new(lineage.as_str()).map_err(refused)?,
            1,
        ),
    ))
}
pub(super) fn validate_delegation(
    parent: &CapabilityToken,
    child: &CapabilityToken,
) -> Result<(), AdmissionOperationStoreError> {
    use chio_core::capability::attenuation::{scope_hash, validate_attenuation};
    if !parent.scope.authorizes_delegation()
        || !parent.verify_signature().map_err(refused)?
        || !child.verify_signature().map_err(refused)?
    {
        return Err(refused("delegation signature"));
    }
    validate_attenuation(&parent.scope, &child.scope).map_err(refused)?;
    let (last, prefix) = child
        .delegation_chain
        .split_last()
        .ok_or_else(|| refused("delegation hop"))?;
    if child.issuer != parent.issuer
        || child.issued_at < parent.issued_at
        || child.expires_at > parent.expires_at
        || child.issued_at >= child.expires_at
        || protected::encode(&child.aggregate_invocation_budget)?
            != protected::encode(&parent.aggregate_invocation_budget)?
        || child.budget_share_bps.unwrap_or(10_000) > parent.budget_share_bps.unwrap_or(10_000)
        || protected::encode(&prefix)? != protected::encode(&parent.delegation_chain)?
        || last.capability_id != parent.id
        || last.delegator != parent.subject
        || last.delegatee != child.subject
        || last.scope_hash.as_ref() != Some(&scope_hash(&parent.scope).map_err(refused)?)
        || !last.verify_signature().map_err(refused)?
    {
        return Err(refused("delegation binding"));
    }
    Ok(())
}
fn live(
    tx: &Connection,
    cap: &CapabilityToken,
    now: u64,
) -> Result<(), AdmissionOperationStoreError> {
    cap.validate_time(now / 1000).map_err(refused)?;
    for id in std::iter::once(cap.id.as_str()).chain(
        cap.delegation_chain
            .iter()
            .map(|v| v.capability_id.as_str()),
    ) {
        let revoked: bool = tx
            .query_row(
                "SELECT EXISTS(SELECT 1 FROM revoked_capabilities WHERE capability_id=?1)",
                [id],
                |r| r.get(0),
            )
            .map_err(sqlite_error)?;
        if revoked {
            return Err(refused("retained capability revoked"));
        }
    }
    Ok(())
}
pub(super) fn verify_retained(
    tx: &Connection,
    record: &BoundaryRecord,
    now: u64,
) -> Result<(), AdmissionOperationStoreError> {
    let deployment = protected::deployment_tx(tx, &record.reservation.boundary.scope)?;
    if !deployment.actors.as_slice().iter().any(|a| {
        a.subject == record.initiator.subject
            && a.principal == record.initiating_principal
            && a.permissions
                .as_slice()
                .contains(&RecoveryPermission::ConfinedLaunch)
    }) {
        return Err(refused("initiator assignment changed"));
    }
    live(tx, &record.initiator, now)?;
    live(tx, &record.parent_capability, now)?;
    live(tx, &record.child_capability, now)
}

pub(in crate::admission_operation_store) fn resolve(
    tx: &Transaction<'_>,
    runtime: &str,
    lineage: &[CapabilityToken],
    now: u64,
) -> Result<Option<SecurityInvocationContext>, AdmissionOperationStoreError> {
    // The process journal supports a root plus 64 ordinary descendants. Scan
    // that complete bounded ancestry before deciding confinement is absent.
    if lineage.len() > 65 {
        return Err(refused("ancestry bound"));
    }
    for (index, capability) in lineage.iter().enumerate().rev() {
        let cap_key = format!("confined-cap:{}", sha256_hex(capability.id.as_bytes()));
        let Some(record_key) = load::<String>(tx, &cap_key)? else {
            continue;
        };
        if lineage.len() > 32 {
            return Err(refused("confined ancestry bound"));
        }
        let record: BoundaryRecord =
            load(tx, &record_key)?.ok_or_else(|| refused("boundary lookup"))?;
        let profile = super::super::installation(tx, &record.reservation.boundary.scope)?;
        validate_current(tx, &record, &profile, now)?;
        if capability_digest(capability)? != record.reservation.boundary.child_capability
            || runtime
                != record
                    .reservation
                    .child_context
                    .as_v1()
                    .session_id()
                    .as_str()
            || now >= record.reservation.boundary.deadline_unix_ms.get()
            || record.reservation.state != IsolationStateV1::EnforcedRunning
            || record.observation_release.is_none()
            || index == 0
            || capability_digest(&lineage[index - 1])?
                != record.reservation.boundary.parent_capability
        {
            return Err(refused("confined context unavailable"));
        }
        for pair in lineage[index..].windows(2) {
            validate_delegation(&pair[0], &pair[1])?;
        }
        for cap in &lineage[index..] {
            live(tx, cap, now)?;
        }
        let last = lineage.last().ok_or_else(|| refused("ancestry"))?;
        return make(
            &profile,
            last,
            &record.reservation.boundary.lineage,
            &record.reservation.boundary.isolation_epoch,
        )
        .map(Some);
    }
    Ok(None)
}

impl SqliteAdmissionOperationStore {
    pub fn confined_process_context(
        &self,
        runtime: &str,
        lineage: &[CapabilityToken],
        fence: &StoreMutationFence,
        now: u64,
    ) -> Result<Option<SecurityInvocationContext>, AdmissionOperationStoreError> {
        let mut connection = self.connection()?;
        let tx = self.begin_read(&mut connection)?;
        schema::verify_active_owner(&tx, &self.serving_owner, Some(fence))?;
        let now = schema::authority_validation_time(&tx, now)?;
        let result = resolve(&tx, runtime, lineage, now)?;
        tx.commit().map_err(sqlite_error)?;
        Ok(result)
    }
}
