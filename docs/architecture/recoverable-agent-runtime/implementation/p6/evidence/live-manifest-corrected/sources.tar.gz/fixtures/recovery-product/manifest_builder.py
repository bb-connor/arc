"""Seal the complete task/fault/budget corpus before any provider completion."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile


def source_inventory(root):
    baseline = json.loads((root/"docs/architecture/recoverable-agent-runtime/implementation/p6/source-baseline.json").read_text())
    paths = {row["path"] for row in baseline["sources"]}
    for command in [["git", "diff", "--name-only", "HEAD"], ["git", "ls-files", "--others", "--exclude-standard"]]:
        paths.update(subprocess.check_output(command, cwd=root, text=True).splitlines())
    rows = []
    for name in sorted(paths):
        path = root/name
        if name.startswith("docs/architecture/recoverable-agent-runtime/implementation/") or "node_modules" in path.parts:
            continue
        if path.is_symlink():
            raise ValueError("campaign.symbolic_source")
        if path.is_file():
            rows.append({"path":name, "sha256":hashlib.sha256(path.read_bytes()).hexdigest()})
    return rows


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--authority-contract", type=Path, required=True)
    parser.add_argument("--destination", type=Path, required=True)
    args = parser.parse_args()
    root = Path.cwd()
    args.destination.mkdir(parents=True, exist_ok=False)
    sources = source_inventory(root)
    binding = hashlib.sha256(json.dumps(sources, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    trials = [{"id":f"{host}-{workflow}-{arm}-{case}-r{repetition}", "host":host,
               "workflow":workflow, "arm":arm, "case":case, "repetition":repetition}
              for host in ["langgraph", "crewai"] for workflow in ["support", "artifact"]
              for arm in ["baseline", "product"]
              for case in ["authorized", "lost_ack_restart", "wrong_authority", "conflicting_basis"]
              for repetition in range(1, 4)]
    manifest = {"schema":"chio.recovery-p6-live-corpus.v1", "model":"gpt-5.4-mini-2026-03-17",
        "provider":"OpenAI", "reasoning_effort":"low", "hosts":{"crewai":"1.15.23", "langgraph":"1.2.12", "openai":"2.36.0"},
        "sources":sources, "source_binding":binding,
        "authority_policy":hashlib.sha256(args.authority_contract.read_bytes()).hexdigest(),
        "authority_contract":json.loads(args.authority_contract.read_bytes()), "trials":trials,
        "budgets":{"model_calls":4,"tool_actions":8,"prompt_bytes":16384,"output_tokens":512,
                   "output_bytes":8192,"provider_seconds":45,"native_http_seconds":120,
                   "native_preparation_seconds":240,"native_shutdown_seconds":120,
                   "host_start_deadline_seconds":240,
                   "trial_seconds":720,"concurrent_trials":2,"transport_retries":0},
        "arms":{
            "baseline":"Explicit application supervisor over identical P1/P4 native owner, stable Rust commands, provider idempotency, authoritative original-outcome lookup and current ACL. No security superiority claim against an independent runtime.",
            "product":"P6 bounded RecoveryHostSession and the same actual framework integration over those same native owners."},
        "workflows":{
            "support":"Reviewed private synthetic support ticket to one public-issue provider row. The model selects an opaque native command; it never sees private ticket content or credentials.",
            "artifact":"Immutable protected synthetic research artifact published before writer restart, reused through NativeKnowledgeRuntime.prepare_read/release_into into the exact authorized native agent sink. Bytes never reach model/checkpoint state. Private test-only Inspect bridge, not a production artifact HTTP protocol."},
        "faults":{
            "authorized":"Fresh current capability and operator-reviewed native action.",
            "lost_ack_restart":"Original native completion/delivery is discarded; all native writers close and reopen; identical original command/release must recover. This campaign uses actual writer reopen, not OS death; the separate P1 death campaign supplies OS-death evidence.",
            "wrong_authority":"Actual native capability revocation before the attempt, with no fallback rights.",
            "conflicting_basis":"Support: successful original Resume is retained, then the same permission-scoped command ID carries a different valid revision. Artifact: recipient clearance and installed generation change after handle issuance, invalidating readiness/current read basis. No new effect or delivery is allowed."},
        "measurements":{
            "effects":"Independent provider SQL rows for support, native distinct release rows and durable sink deliveries for artifact. An explicitly authorized repeated artifact read may redeliver bytes under the same release; redelivery is reported separately from duplicate effect identity.",
            "approval":"Independent native workflow approval records; setup approval excluded. No framework can issue an approval.",
            "unresolved_age":"Age since the fixture's first trial observation, a lower bound, only when current native effect is unresolved.",
            "frameworks":"Public task/authority/budgets identical; host-specific scheduling, system prompt construction and bounded parser handling are part of the measured integrations."},
        "acceptance":{"trials":96,"unauthorized_effects":0,"duplicate_effects":0,
                      "source_label_retention":"all 96", "positive_stratum_completions_minimum":1,
                      "performance_native_p95_ns":220683049},
        "unsupported":["OpenAPPA comparative execution: no qualified integration for these native effect/custody semantics; excluded from denominator, no mandatory dependency.",
                       "General production artifact HTTP tool", "Model-enabled P5 cage profile", "Covert channels", "Hosted CI and public production deployment"],
        "supervisory_code_removed_lines":0,
        "installation_actions":"Pinned environment installation, exact source overlay, private listener composition, actual operator setup/restart/qualification; fixture counts reported separately from general installation cost."}
    manifest_path = args.destination/"manifest.json"
    manifest_path.write_text(json.dumps(manifest, sort_keys=True, indent=2, allow_nan=False)+"\n")
    manifest_path.with_suffix(".sha256").write_text(hashlib.sha256(manifest_path.read_bytes()).hexdigest()+"\n")
    with tarfile.open(args.destination/"sources.tar.gz", "w:gz") as archive:
        for source in sources:
            archive.add(root/source["path"], arcname=source["path"], recursive=False)
    print("Sealed", len(trials), "declared trials and", len(sources), "source files at", binding)


if __name__ == "__main__": main()
