use chio_security_types::recovery::{
    AdmissionIntentRef, ApprovalIntentRef, EvidenceRef, OperationRef, RefusalCode, StepId,
};

/// Planner results stay separate from workflow progress. P0 establishes the
/// vocabulary; finite remedy enumeration and offers are implemented in P2.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum PlanDecision {
    FeasibleUnderSnapshot,
    NoRegisteredRemedy,
    SearchBoundReached,
    Refused(RefusalCode),
}

/// Non-authorizing advice. There is deliberately no dispatch/resend directive,
/// wire conversion, signing method, or conversion to a kernel capture owner.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum WorkflowDirective {
    Materialize(StepId),
    RequestApproval(ApprovalIntentRef),
    ResumeNativeApproval(OperationRef),
    ResolveAdmission(AdmissionIntentRef),
    AwaitOutcome(OperationRef),
    Reconcile(OperationRef),
    ProjectOutcome(OperationRef),
    PreserveClosure(EvidenceRef),
    Halt,
}
