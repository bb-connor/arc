//! Affine artifact observation in the same native flow rows and global order.
use super::super::recovery::storage as protected;
use super::*;
use crate::security_state::NativeRowChange;
use chio_kernel::admission_operation::NativeSecurityAuthorityBindingV1;
use chio_security_types::ports::{
    BoundedVec, FlowJoinRequest, FlowStateKey, FlowStateSnapshot, RecordId,
};
use chio_security_types::{
    knowledge::ArtifactReleaseIntentV1, recovery::RecoveryScopeV1, InformationLabel,
};

pub(crate) struct NativeKnowledgeJoinAuthority {
    authority: AdmissionIdentifier,
    request: FlowJoinRequest,
}
impl NativeKnowledgeJoinAuthority {
    pub(crate) fn authority(&self) -> &str {
        self.authority.as_str()
    }
    pub(crate) fn request(&self) -> &FlowJoinRequest {
        &self.request
    }
}

#[derive(Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub(in crate::admission_operation_store) struct Record {
    pub authority: String,
    pub initialization: String,
    pub sequence: u64,
    pub previous: String,
    pub observed_at: u64,
    pub scope: RecoveryScopeV1,
    pub release: ArtifactReleaseIntentV1,
    pub request: FlowJoinRequest,
    pub result: FlowStateSnapshot,
    pub changes: BoundedVec<NativeRowChange, 4096>,
    pub current_rows: u64,
    pub current_bytes: u64,
}

pub(in crate::admission_operation_store) fn prefix(authority: &str) -> String {
    format!("knowledge-join:{}:", sha256_hex(authority.as_bytes()))
}
fn record_key(authority: &str, sequence: u64) -> String {
    format!("{}{sequence:016}", prefix(authority))
}

/// Influence follows every native scope that can carry confidentiality. Reading
/// an older checkpoint never discards later artifact or model observations.
pub(in crate::admission_operation_store) fn observed_influence(
    tx: &Connection,
    authority: &str,
    key: &FlowStateKey,
) -> Result<Option<chio_security_types::knowledge::ArtifactInfluenceV1>, AdmissionOperationStoreError>
{
    use chio_core::recovery::knowledge_digest;
    use chio_security_types::{knowledge::ArtifactInfluenceV1, recovery::CanonicalPayloadDigest};
    let mut observed = Vec::new();
    let mut external = false;
    let mut unknown = false;
    for sequence in 1..=head(tx, authority)? {
        let record = load(tx, authority, sequence)?;
        let other = &record.request.key;
        if other.tenant_id == key.tenant_id
            && other.isolation_epoch_id == key.isolation_epoch_id
            && (other.principal_id == key.principal_id
                || other.lineage_id == key.lineage_id
                || other.session_id == key.session_id)
        {
            external |= record.release.influence.externally_influenced;
            unknown |= record.release.influence.unknown;
            observed.push(record.release.influence);
        }
    }
    if observed.is_empty() {
        return Ok(None);
    }
    Ok(Some(ArtifactInfluenceV1 {
        commitment: CanonicalPayloadDigest::from_bytes(
            knowledge_digest(b"chio.knowledge.observed-influence.v1\0", &observed)
                .map_err(invalid)?,
        ),
        externally_influenced: external,
        unknown,
    }))
}
impl Record {
    pub(in crate::admission_operation_store) fn validate(
        &self,
    ) -> Result<(), AdmissionOperationStoreError> {
        let label = &self.release.source_label;
        let recipient = &self.release.recipient;
        if self.sequence == 0
            || self.current_rows > 65_536
            || self.current_bytes > 67_108_864
            || self.scope != recipient.scope
            || self.scope != self.release.artifact.scope
            || !self.release.admitted_label.flows_to(label)
            || !self.release.admitted_label.flows_to(&recipient.clearance)
            || self.request.principal_join != *label
            || self.request.lineage_join != *label
            || self.request.session_join != *label
            || self.result.key != self.request.key
            || self.release.observation_generation.get() != self.result.context_generation
            || self.request.transition_id.as_str() != self.release.observation_transition.as_str()
            || recipient.principal != self.request.key.principal_id
            || recipient.runtime.as_str() != self.request.key.session_id.as_str()
            || recipient.scope.tenant_id.as_str() != self.request.key.tenant_id.as_str()
            || recipient.lineage.as_str() != self.request.key.lineage_id.as_str()
            || recipient.isolation_epoch.as_str() != self.request.key.isolation_epoch_id.as_str()
            || self.changes.is_empty()
        {
            return Err(invalid("knowledge journal binding"));
        }
        for change in self.changes.as_slice() {
            change.validate_flow_join(&self.request).map_err(invalid)?;
        }
        Ok(())
    }
}
pub(in crate::admission_operation_store) fn head(
    tx: &Connection,
    authority: &str,
) -> Result<u64, AdmissionOperationStoreError> {
    let exists:bool=tx.query_row("SELECT EXISTS(SELECT 1 FROM sqlite_schema WHERE name='admission_operation_recovery_records')",[],|row|row.get(0)).map_err(sqlite_error)?;
    if !exists {
        return Ok(0);
    }
    let count: i64 = tx
        .query_row(
            "SELECT count(*) FROM admission_operation_recovery_records WHERE record_key GLOB ?1",
            [format!("{}*", prefix(authority))],
            |row| row.get(0),
        )
        .map_err(sqlite_error)?;
    if !(0..=4096).contains(&count) {
        return Err(invalid("knowledge history exhausted"));
    }
    u64::try_from(count).map_err(invalid)
}
pub(in crate::admission_operation_store) fn load(
    tx: &Connection,
    authority: &str,
    sequence: u64,
) -> Result<Record, AdmissionOperationStoreError> {
    let row = protected::raw(tx, &record_key(authority, sequence))?
        .ok_or_else(|| invalid("knowledge join absent"))?;
    let record: Record = protected::decode(&row.payload)?;
    if row.version != 1 || record.sequence != sequence || record.authority != authority {
        return Err(invalid("knowledge history changed"));
    }
    record.validate()?;
    Ok(record)
}

pub(in crate::admission_operation_store) struct KnowledgeJoin<'a> {
    pub binding: &'a NativeSecurityAuthorityBindingV1,
    pub key: &'a FlowStateKey,
    pub source: &'a InformationLabel,
    pub scope: &'a RecoveryScopeV1,
    pub release: ArtifactReleaseIntentV1,
    pub now: u64,
}
pub(in crate::admission_operation_store) fn join<'a>(
    tx: Transaction<'a>,
    owner: &SqliteServingOwner,
    input: KnowledgeJoin<'_>,
) -> Result<(Transaction<'a>, ArtifactReleaseIntentV1), AdmissionOperationStoreError> {
    let KnowledgeJoin {
        binding,
        key,
        source,
        scope,
        mut release,
        now,
    } = input;
    let initialized = records::load_metadata(&tx, binding.security_authority_id().as_str())?
        .ok_or_else(|| invalid("knowledge native initialization absent"))?;
    if initialized.admission_binding()? != *binding {
        return Err(invalid("knowledge native binding"));
    }
    let authority = binding.security_authority_id().as_str();
    let transition = RecordId::new(release.observation_transition.as_str()).map_err(invalid)?;
    let request =
        crate::security_state::resolve_native_label_join(&tx, authority, key, source, &transition)
            .map_err(invalid)?;
    let (mut rows, mut bytes) = history::ordered::latest_totals(&tx, &initialized)?;
    let sequence = head(&tx, authority)?
        .checked_add(1)
        .ok_or_else(|| invalid("knowledge sequence overflow"))?;
    let previous = if sequence == 1 {
        initialized.digest.clone()
    } else {
        sha256_hex(&protected::encode(&load(&tx, authority, sequence - 1)?)?)
    };
    let (tx, result, changes) = crate::security_state::join_native_knowledge(
        tx,
        NativeKnowledgeJoinAuthority {
            authority: initialized.authority.clone(),
            request: request.clone(),
        },
    )
    .map_err(invalid)?;
    for change in &changes {
        if let Some(before) = &change.before {
            rows = rows
                .checked_sub(1)
                .ok_or_else(|| invalid("knowledge row underflow"))?;
            bytes = bytes
                .checked_sub(before.len() as u64)
                .ok_or_else(|| invalid("knowledge byte underflow"))?;
        }
        if let Some(after) = &change.after {
            rows = rows
                .checked_add(1)
                .ok_or_else(|| invalid("knowledge row overflow"))?;
            bytes = bytes
                .checked_add(after.len() as u64)
                .ok_or_else(|| invalid("knowledge byte overflow"))?;
        }
    }
    release.source_label = request.principal_join.clone();
    release.observation_generation =
        chio_security_types::recovery::SafeInteger::new(result.context_generation)
            .map_err(invalid)?;
    let record = Record {
        authority: authority.to_owned(),
        initialization: initialized.digest,
        sequence,
        previous,
        observed_at: now,
        scope: scope.clone(),
        release: release.clone(),
        request,
        result,
        changes: BoundedVec::new(changes).map_err(invalid)?,
        current_rows: rows,
        current_bytes: bytes,
    };
    record.validate()?;
    protected::save(
        &tx,
        owner,
        &record_key(authority, sequence),
        &protected::scope_key(scope)?,
        "command",
        &protected::encode(&record)?,
        None,
    )?;
    history::ordered::validate_history_bounds(&tx, authority)?;
    Ok((tx, release))
}
