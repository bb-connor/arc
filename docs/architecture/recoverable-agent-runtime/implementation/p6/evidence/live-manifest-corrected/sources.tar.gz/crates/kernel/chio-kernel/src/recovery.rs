//! Recovery orchestration shares the original serving authority and admission.
//! Wire values and journal projections carry data, never dispatch permission.
#![forbid(unsafe_code)]

mod observation;
mod ports;
mod records;
pub use ports::*;
pub use records::*;

/// Recovery digests use the established canonical encoder and SHA-256 primitive.
pub fn recovery_digest<T: serde::Serialize>(
    domain: &str,
    value: &T,
) -> Result<[u8; 32], crate::KernelError> {
    let canonical = chio_core_types::canonical_json_bytes(value)
        .map_err(|_| crate::KernelError::DurableAdmission("recovery encoding refused".into()))?;
    let mut bytes = Vec::with_capacity(domain.len() + 1 + canonical.len());
    bytes.extend_from_slice(domain.as_bytes());
    bytes.push(0);
    bytes.extend_from_slice(&canonical);
    Ok(*chio_core_types::sha256(&bytes).as_bytes())
}

mod semantic;
pub use semantic::semantic_request_semantics;
