//! Pure contract validation. No provider, plugin, filesystem, store or clock.
#![cfg_attr(not(feature = "std"), no_std)]
#![forbid(unsafe_code)]
extern crate alloc;
mod effect;
mod graph;
mod plans;
mod registry;
mod selectors;
mod verification;
mod work;
pub use effect::*;
pub use graph::{
    validate_dependency_graph, DependencyGraphSchema, DependencyGraphV1, DependencyNodeV1,
    ValidatedDependencyGraph,
};
pub use plans::*;
pub use registry::*;
pub use selectors::*;
pub use verification::*;
pub use work::VerificationBudget;
