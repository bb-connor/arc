//! Bounded private-control projections. Classified payloads require fresh native reads.
use super::super::{transport::response, RecoveryRuntimeError};
use super::RecoveryMaintenanceRuntime;
use axum::{
    body::Bytes,
    extract::{DefaultBodyLimit, State},
    routing::post,
    Router,
};
use chio_core_types::recovery::{decode_contract, decode_recovery_capability};
use chio_security_types::recovery::*;
use serde::{Deserialize, Serialize};
use std::sync::Arc;
use tokio::sync::Semaphore;

#[derive(Clone)]
struct Host {
    service: Arc<RecoveryMaintenanceRuntime>,
    capacity: Arc<Semaphore>,
}
#[derive(Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct Submit {
    capability: ProtectedText<32768>,
    command_id: CommandId,
    report: ProtectedText<32768>,
}
#[derive(Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct Read {
    capability: ProtectedText<32768>,
    report_id: EvidenceRef,
}
#[derive(Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct Propose {
    capability: ProtectedText<32768>,
    proposal: ProtectedText<32768>,
}

/// Operator mounts this on the authenticated private control listener.
/// No report or proposal route can apply a policy or invoke an effect.
pub fn recovery_maintenance_router(service: Arc<RecoveryMaintenanceRuntime>) -> Router {
    Router::new()
        .route("/v1/recovery/reports/submit", post(submit))
        .route("/v1/recovery/reports/read", post(read))
        .route("/v1/recovery/policy/propose", post(propose))
        .layer(DefaultBodyLimit::max(MAX_RECOVERY_WIRE_BYTES))
        .with_state(Host {
            service,
            capacity: Arc::new(Semaphore::new(2)),
        })
}
async fn run<T, F>(host: Host, bytes: Bytes, work: F) -> axum::response::Response
where
    T: Serialize + Send + 'static,
    F: FnOnce(&RecoveryMaintenanceRuntime, Bytes) -> Result<T, RecoveryRuntimeError>
        + Send
        + 'static,
{
    let Ok(permit) = host.capacity.try_acquire_owned() else {
        return response::<T>(Err(RecoveryRuntimeError::Unavailable));
    };
    let result = tokio::task::spawn_blocking(move || {
        let _permit = permit;
        work(&host.service, bytes)
    })
    .await
    .unwrap_or(Err(RecoveryRuntimeError::Unavailable));
    response(result)
}
fn invalid<T>(_: T) -> RecoveryRuntimeError {
    RecoveryRuntimeError::InvalidCommand
}
async fn submit(State(host): State<Host>, bytes: Bytes) -> axum::response::Response {
    run(host, bytes, |service, bytes| {
        let request: Submit = decode_contract(&bytes).map_err(invalid)?;
        let capability =
            decode_recovery_capability(request.capability.as_str().as_bytes()).map_err(invalid)?;
        let report = decode_contract(request.report.as_str().as_bytes()).map_err(invalid)?;
        let value = service.submit_report(&capability, &request.command_id, &report)?;
        Ok(DecisionReportViewV1 {
            domain_version: VersionV1,
            id: value.id,
            digest: value.digest,
            report: value.report,
            label: value.label,
            influence: value.influence,
        })
    })
    .await
}
async fn read(State(host): State<Host>, bytes: Bytes) -> axum::response::Response {
    run(host, bytes, |service, bytes| {
        let request: Read = decode_contract(&bytes).map_err(invalid)?;
        let capability =
            decode_recovery_capability(request.capability.as_str().as_bytes()).map_err(invalid)?;
        let value = service.read_report(&capability, &request.report_id)?;
        Ok(DecisionReportViewV1 {
            domain_version: VersionV1,
            id: value.id,
            digest: value.digest,
            report: value.report,
            label: value.label,
            influence: value.influence,
        })
    })
    .await
}
async fn propose(State(host): State<Host>, bytes: Bytes) -> axum::response::Response {
    run(host, bytes, |service, bytes| {
        let request: Propose = decode_contract(&bytes).map_err(invalid)?;
        let capability =
            decode_recovery_capability(request.capability.as_str().as_bytes()).map_err(invalid)?;
        let proposal = decode_contract(request.proposal.as_str().as_bytes()).map_err(invalid)?;
        let value = service.propose(&capability, &proposal)?;
        Ok(PolicyMaintenanceViewV1 {
            domain_version: VersionV1,
            digest: value.digest,
            proposal: value.proposal,
            label: value.label,
            influence: value.influence,
        })
    })
    .await
}
