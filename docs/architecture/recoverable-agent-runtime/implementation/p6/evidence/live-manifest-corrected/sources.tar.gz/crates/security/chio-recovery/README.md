# chio-recovery

Pure, deterministic recovery advice for Chio. The crate defaults to `no_std + alloc`
and depends only on portable security data types. Its additive `std` feature does
not introduce a runtime, storage, transport, clock, signer or random-number source.

P0 establishes separate planner and workflow vocabularies and a bounded observation
reducer. Every input is an untrusted claim. Recommendations cannot allocate a native
operation, dispatch a connector, close an admission intent, consume a grant or release
protected bytes. Those actions remain in the existing kernel's admission/capture path.
Unknown operations preserve their identity through cancellation; settled partial
effects and withheld results never produce advice to submit another effect.

Finite remedy search is P2. Durable identity, authoritative observations, admission
closure and the driver are P1. Neither capability is advertised as implemented here.
