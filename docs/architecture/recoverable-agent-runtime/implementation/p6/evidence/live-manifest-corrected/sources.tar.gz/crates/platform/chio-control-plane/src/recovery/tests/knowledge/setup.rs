//! Real native setup requires a completed model-free effect and a fresh writer.
use super::*;
use crate::recovery::RecoverySetupHost;
use crate::recovery::RecoverySetupService;
use chio_core_types::recovery::{SignedRecoverySetupProbeV1, SignedSemanticDeploymentV1};
use chio_security_types::semantic::SemanticOutputDispositionV1;
mod cli_host;

fn setup(f: &KnowledgeFixture, workflow: &WorkflowId) -> TestResult<RecoverySetupService> {
    Ok(RecoverySetupService::new(
        f.f.runtime.clone(),
        Arc::new(f.f.authority.admission_operation_store()),
        f.f.authority.mutation_fence(),
        Some(Arc::new(f.runtime.clone())),
        Keypair::from_seed(&[211; 32]),
        workflow.clone(),
    )?)
}
async fn new_work(f: &KnowledgeFixture, key: &str) -> TestResult<RecoveryCommandResultV1> {
    f.f.execute(
        key,
        RecoveryCommandBodyV1::CreateWorkflow {
            creation_key: TemplateId::new(key)?,
            template: RecoveryTemplateV1::SupportTicketPublicIssue,
            request_seed: text(&f.f.seed)?,
        },
    )
    .await
}
struct RestartProof {
    path: std::path::PathBuf,
    directory: Option<tempfile::TempDir>,
    workflow: WorkflowId,
    probe: SignedRecoverySetupProbeV1,
    operation: OperationId,
    tree_calls: u32,
}
async fn begin_restart_proof() -> TestResult<RestartProof> {
    let mut f = KnowledgeFixture::from(super::super::semantic::native_fixture("read")?)?;
    let workflow = f.f.ready().await?;
    let service = setup(&f, &workflow)?;
    assert!(new_work(&f, "before-ready").await.is_err());
    let probe = service.probe(&f.f.control, &workflow).await?;
    assert!(probe.verify_signature()?);
    assert_eq!(
        service.qualify(&f.f.control, &probe).await.err(),
        Some(crate::recovery::RecoveryRuntimeError::RestartRequired)
    );
    let operation =
        f.f.record(&workflow)?
            .native_link
            .ok_or("native operation")?;
    let tree_calls = f.f.process.process("root")?.tree_calls;
    assert_eq!(external_count(&f.f.path)?, 1);
    Ok(RestartProof {
        path: f.f.path.clone(),
        directory: f.f._directory.take(),
        workflow,
        probe,
        operation,
        tree_calls,
    })
}
async fn qualify_reopened_writer(
    mut evidence: RestartProof,
    key: &str,
) -> TestResult<(
    RestartProof,
    chio_core_types::recovery::SignedRecoverySetupReportV1,
)> {
    let mut f = KnowledgeFixture::from(RecoveryFixture::open(
        evidence.path.clone(),
        evidence.directory.take(),
        false,
    )?)?;
    let service = setup(&f, &evidence.workflow)?;
    assert!(new_work(&f, &format!("{key}-unqualified")).await.is_err());
    let report = service.qualify(&f.f.control, &evidence.probe).await?;
    assert_eq!(
        report.authority_key(),
        &Keypair::from_seed(&[211; 32]).public_key()
    );
    assert!(report.verify_signature()?);
    assert_eq!(report.body().benign_operation, evidence.operation);
    assert_eq!(
        service.qualify(&f.f.control, &evidence.probe).await?,
        report
    );
    assert_eq!(external_count(&f.f.path)?, 1);
    assert_eq!(f.f.process.process("root")?.tree_calls, evidence.tree_calls);
    new_work(&f, &format!("{key}-qualified")).await?;
    // The newly authorized workflow may perform its own native source read.
    // Carry that actual charge into the next writer's replay comparison.
    evidence.tree_calls = f.f.process.process("root")?.tree_calls;
    evidence.directory = f.f._directory.take();
    Ok((evidence, report))
}
#[tokio::test]
async fn p6_setup_real_restart_recovers_the_identical_operation_once() -> TestResult {
    let evidence = Box::pin(begin_restart_proof()).await?;
    let (evidence, first) = Box::pin(qualify_reopened_writer(evidence, "second-writer")).await?;
    let (_, second) = Box::pin(qualify_reopened_writer(evidence, "third-writer")).await?;
    assert_ne!(
        first.body().current_serving_fence,
        second.body().current_serving_fence
    );
    Ok(())
}
#[tokio::test]
async fn p6_setup_every_foreign_binding_and_old_profile_refuses() -> TestResult {
    let mut f = KnowledgeFixture::from(super::super::semantic::native_fixture("read")?)?;
    let workflow = f.f.ready().await?;
    let service = setup(&f, &workflow)?;
    let probe = service.probe(&f.f.control, &workflow).await?;
    let path = f.f.path.clone();
    let directory = f.f._directory.take();
    drop(service);
    drop(f);
    let f = KnowledgeFixture::from(RecoveryFixture::open(path, directory, false)?)?;
    let service = setup(&f, &workflow)?;
    for mutation in 0..9 {
        let mut body = probe.body().clone();
        match mutation {
            0 => body.scope.authority_domain = AuthorityDomainId::new("foreign-store")?,
            1 => body.scope.process_id = ProcessId::new("foreign-process")?,
            2 => body.deployment = DeploymentDigest::from_bytes([80; 32]),
            3 => body.source_profile = SourceDigest::from_bytes([81; 32]),
            4 => body.required_coverage = CoverageDigest::from_bytes([82; 32]),
            5 => body.native_authority = SourceDigest::from_bytes([83; 32]),
            6 => body.scope.tenant_id = RecoveryTenantId::new("foreign-tenant")?,
            7 => body.probe_id = ChallengeId::new("foreign-challenge")?,
            _ => body.benign_workflow = WorkflowId::new("foreign-self-test")?,
        }
        let signed = SignedRecoverySetupProbeV1::sign(body, &Keypair::from_seed(&[211; 32]))?;
        assert!(service.qualify(&f.f.control, &signed).await.is_err());
    }
    let wrong_signer =
        SignedRecoverySetupProbeV1::sign(probe.body().clone(), &Keypair::from_seed(&[210; 32]))?;
    assert!(service.qualify(&f.f.control, &wrong_signer).await.is_err());
    let report = service.qualify(&f.f.control, &probe).await?;
    let store = f.f.authority.admission_operation_store();
    let mut installation = store.read_semantic_installation(
        f.f.runtime.scope(),
        &f.f.authority.mutation_fence(),
        now_ms()?,
    )?;
    let mut body = installation.deployment.body().clone();
    body.generation = SafeInteger::new(body.generation.get() + 1)?;
    installation.deployment =
        SignedSemanticDeploymentV1::sign(body, &Keypair::from_seed(&[211; 32]))?;
    store.configure_semantic_deployment(&installation)?;
    assert!(new_work(&f, "after-profile-change").await.is_err());
    assert!(service.qualify(&f.f.control, &probe).await.is_err());
    assert!(store
        .accept_setup_report(&report, &f.f.authority.mutation_fence(), now_ms()?)
        .is_err());
    assert_eq!(external_count(&f.f.path)?, 1);
    let creation = f.f.command(
        "new-profile-self-test",
        RecoveryCommandBodyV1::CreateWorkflow {
            creation_key: TemplateId::new("new-profile-self-test")?,
            template: RecoveryTemplateV1::SupportTicketPublicIssue,
            request_seed: text(&f.f.seed)?,
        },
    )?;
    let host = RecoverySetupHost {
        runtime: f.f.runtime.clone(),
        store: Arc::new(store),
        fence: f.f.authority.mutation_fence(),
        knowledge: Some(Arc::new(f.runtime.clone())),
        operator: Keypair::from_seed(&[211; 32]),
    };
    let replacement = RecoverySetupService::for_creation(host, &f.f.control, &creation).await?;
    assert_ne!(replacement.workflow(), &workflow);
    assert!(f.f.record(replacement.workflow())?.action.is_some());
    assert!(new_work(&f, "operator-pin-does-not-unlock-work")
        .await
        .is_err());
    assert_eq!(external_count(&f.f.path)?, 1);
    Ok(())
}
#[tokio::test]
async fn p6_setup_lost_live_broker_refuses_the_protected_review_route() -> TestResult {
    let f = KnowledgeFixture::from(super::super::semantic::native_fixture("read")?)?;
    let workflow = f.f.ready().await?;
    let _service = setup(&f, &workflow)?;
    assert!(f.f.runtime.review_document(&f.f.control, &workflow).is_ok());
    f.f.process.cancel("root")?;
    assert!(f
        .f
        .runtime
        .review_document(&f.f.control, &workflow)
        .is_err());
    assert_eq!(external_count(&f.f.path)?, 0);
    Ok(())
}
#[tokio::test]
async fn p6_setup_cannot_accept_a_new_native_semantic_plan_before_ready() -> TestResult {
    let f = KnowledgeFixture::from(super::super::semantic::native_fixture("write")?)?;
    let workflow = f.f.ready().await?;
    let _service = setup(&f, &workflow)?;
    assert!(super::super::semantic::prepare(
        &f.f,
        "unqualified-native-plan",
        SemanticOutputDispositionV1::ReturnValue
    )
    .is_err());
    assert_eq!(external_count(&f.f.path)?, 0);
    Ok(())
}
#[tokio::test]
async fn p6_setup_profile_change_between_preflight_and_native_capture_refuses() -> TestResult {
    type Change = (
        SqliteAdmissionOperationStore,
        RecoveryScopeV1,
        chio_core_types::StoreMutationFence,
    );
    let pending: Arc<Mutex<Option<Change>>> = Arc::new(Mutex::new(None));
    let observed = Arc::new(AtomicUsize::new(0));
    let holder = pending.clone();
    let observations = observed.clone();
    let observer: chio_kernel::NativeSecurityCaptureObserver = Arc::new(move |committed| {
        if committed {
            observations.fetch_add(100, Ordering::SeqCst);
            return Ok(());
        }
        let Some((store, scope, fence)) = holder
            .lock()
            .map_err(|_| KernelError::Internal("setup race".into()))?
            .take()
        else {
            return Ok(());
        };
        observations.fetch_add(1, Ordering::SeqCst);
        let mutate = || -> TestResult {
            let mut installation = store.read_semantic_installation(&scope, &fence, now_ms()?)?;
            let mut body = installation.deployment.body().clone();
            body.generation = SafeInteger::new(body.generation.get() + 1)?;
            installation.deployment =
                SignedSemanticDeploymentV1::sign(body, &Keypair::from_seed(&[211; 32]))?;
            store.configure_semantic_deployment(&installation)?;
            Ok(())
        };
        mutate().map_err(|_| KernelError::Internal("setup race".into()))
    });
    let directory = tempfile::tempdir()?;
    std::fs::write(directory.path().join("semantic-kind"), "read")?;
    let f = KnowledgeFixture::from(RecoveryFixture::open_with_native_observer(
        directory.path().to_path_buf(),
        Some(directory),
        false,
        Some(observer),
    )?)?;
    let workflow = f.f.ready().await?;
    let service = setup(&f, &workflow)?;
    *pending.lock().map_err(|_| "setup race")? = Some((
        f.f.authority.admission_operation_store(),
        f.f.runtime.scope().clone(),
        f.f.authority.mutation_fence(),
    ));
    assert!(service.probe(&f.f.control, &workflow).await.is_err());
    assert_eq!(observed.load(Ordering::SeqCst), 1);
    assert_eq!(external_count(&f.f.path)?, 0);
    assert!(new_work(&f, "race-bypass").await.is_err());
    f.f.execute(
        "cancel-after-race",
        RecoveryCommandBodyV1::CancelWorkflow {
            workflow_id: workflow.clone(),
            expected_revision: f.f.record(&workflow)?.revision,
        },
    )
    .await?;
    Ok(())
}
#[tokio::test]
async fn p6_setup_missing_broker_and_failed_benign_cannot_unlock_work() -> TestResult {
    let f = KnowledgeFixture::from(super::super::semantic::native_fixture("read")?)?;
    let workflow = f.f.ready().await?;
    assert!(RecoverySetupService::new(
        f.f.runtime.clone(),
        Arc::new(f.f.authority.admission_operation_store()),
        f.f.authority.mutation_fence(),
        None,
        Keypair::from_seed(&[211; 32]),
        workflow.clone()
    )
    .is_err());
    let service = setup(&f, &workflow)?;
    f.f.kernel.revoke_capability(&f.f.seed.capability.id)?;
    assert!(service.probe(&f.f.control, &workflow).await.is_err());
    assert!(new_work(&f, "after-failed-benign").await.is_err());
    assert_eq!(external_count(&f.f.path)?, 0);
    Ok(())
}
