//! This service needs an advisory signer and explicit facts, not a kernel,
//! process runtime, disclosure issuer, provider or mutation port.
use crate::recovery::RecoveryRuntimeError;
use chio_core_types::{recovery::*, Ed25519Backend, SigningBackend};
use chio_recovery::{prepare_explanation_report, ExplanationAudience};
use chio_security_types::{recovery::*, InformationLabel};
use rand_core::{OsRng, RngCore};
use std::{
    collections::BTreeMap,
    sync::{Arc, Mutex},
};

const MAX_EXPLANATION_ACTORS: usize = 64;
const MAX_EXPLANATIONS_PER_WINDOW: u64 = 32;
const EXPLANATION_WINDOW_MS: u64 = 60_000;

struct Intake {
    started: u64,
    requests: u64,
}

/// Lifetime-bounded actor identities and fixed-window intake. Exhaustion never
/// evicts an actor to create a fresh probe allowance.
pub struct RecoveryExplanationService {
    pub(super) scope: RecoveryScopeV1,
    trust_domain: AuthorityDomainId,
    issuer: IssuerId,
    signer: Arc<Ed25519Backend>,
    pub(super) limits: ExplanationLimitsV1,
    intake: Mutex<BTreeMap<ActorId, Intake>>,
}

pub struct ProtectedRecoveryExplanationV1 {
    pub snapshot: RecoverySnapshotV1,
    pub registry: RecoveryRemedyRegistryV1,
    pub report: SignedRecoveryExplanationReportV1,
    pub view: SignedRecoveryExplanationViewV1,
    pub classification: InformationLabel,
    pub(super) audience_clearance: InformationLabel,
}
impl core::fmt::Debug for ProtectedRecoveryExplanationV1 {
    fn fmt(&self, f: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        f.write_str("ProtectedRecoveryExplanationV1([redacted])")
    }
}
impl core::fmt::Debug for RecoveryExplanationService {
    fn fmt(&self, f: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        f.write_str("RecoveryExplanationService([redacted])")
    }
}
impl RecoveryExplanationService {
    pub fn new(
        scope: RecoveryScopeV1,
        trust_domain: AuthorityDomainId,
        issuer: IssuerId,
        signer: Arc<Ed25519Backend>,
        limits: ExplanationLimitsV1,
    ) -> Result<Self, RecoveryRuntimeError> {
        limits
            .validate()
            .map_err(|_| RecoveryRuntimeError::InvalidCommand)?;
        if limits.work.get() < 2 {
            return Err(RecoveryRuntimeError::InvalidCommand);
        }
        Ok(Self {
            scope,
            trust_domain,
            issuer,
            signer,
            limits,
            intake: Mutex::new(BTreeMap::new()),
        })
    }
    pub fn public_key(&self) -> chio_core_types::PublicKey {
        self.signer.public_key()
    }

    /// Called by the authenticated host before loading any workflow. Per-actor
    /// availability depends on admitted requests, never on hidden membership.
    pub(super) fn admit(&self, actor: &ActorId, now: u64) -> Result<(), RecoveryRuntimeError> {
        let mut intake = self
            .intake
            .lock()
            .map_err(|_| RecoveryRuntimeError::Unavailable)?;
        if !intake.contains_key(actor) && intake.len() >= MAX_EXPLANATION_ACTORS {
            return Err(RecoveryRuntimeError::Unavailable);
        }
        let entry = intake.entry(actor.clone()).or_insert(Intake {
            started: now,
            requests: 0,
        });
        let elapsed = now
            .checked_sub(entry.started)
            .ok_or(RecoveryRuntimeError::Unavailable)?;
        if elapsed >= EXPLANATION_WINDOW_MS {
            *entry = Intake {
                started: now,
                requests: 0,
            };
        }
        if entry.requests >= MAX_EXPLANATIONS_PER_WINDOW {
            return Err(RecoveryRuntimeError::Unavailable);
        }
        entry.requests = entry
            .requests
            .checked_add(1)
            .ok_or(RecoveryRuntimeError::Unavailable)?;
        Ok(())
    }

    /// Trusted dry-run API over already mediated facts. Its return object is
    /// classified; the network adapter returns only the separately signed view.
    pub fn evaluate(
        &self,
        snapshot: RecoverySnapshotV1,
        registry: RecoveryRemedyRegistryV1,
        audience: ExplanationAudience<'_>,
    ) -> Result<ProtectedRecoveryExplanationV1, RecoveryRuntimeError> {
        snapshot
            .scope
            .ensure_matches(&self.scope)
            .map_err(|_| RecoveryRuntimeError::AuthorityDenied)?;
        let invalid = |_| RecoveryRuntimeError::InvalidCommand;
        let snapshot = snapshot.normalized().map_err(invalid)?;
        let registry = registry.normalized(&snapshot).map_err(invalid)?;
        let report_ref = random_reference()?;
        let (view, body) = prepare_explanation_report(
            &snapshot,
            &registry,
            self.limits,
            &audience,
            &self.trust_domain,
            &self.issuer,
            report_ref,
        )
        .map_err(invalid)?;
        let mut classification = snapshot
            .context_label
            .join_restrictions(&registry.classification)
            .unwrap_or(InformationLabel::Top);
        for label in
            snapshot
                .observations
                .as_slice()
                .iter()
                .map(|fact| &fact.label)
                .chain(
                    registry.templates.as_slice().iter().flat_map(|template| {
                        [&template.classification, &template.disclosure_label]
                    }),
                )
        {
            classification = classification
                .join_restrictions(label)
                .unwrap_or(InformationLabel::Top);
        }
        // No lock or authority transaction spans signing.
        let report =
            SignedRecoveryExplanationReportV1::sign_with_backend(body, self.signer.as_ref())
                .map_err(|_| RecoveryRuntimeError::Unavailable)?;
        let view = SignedRecoveryExplanationViewV1::sign_with_backend(view, self.signer.as_ref())
            .map_err(|_| RecoveryRuntimeError::Unavailable)?;
        Ok(ProtectedRecoveryExplanationV1 {
            snapshot,
            registry,
            report,
            view,
            classification,
            audience_clearance: audience.clearance.clone(),
        })
    }
}

fn random_reference() -> Result<ExplanationRef, RecoveryRuntimeError> {
    let mut bytes = [0u8; 32];
    OsRng
        .try_fill_bytes(&mut bytes)
        .map_err(|_| RecoveryRuntimeError::Unavailable)?;
    let reference = format!(
        "advice:{}",
        bytes
            .iter()
            .map(|byte| format!("{byte:02x}"))
            .collect::<String>()
    );
    ExplanationRef::new(&reference).map_err(|_| RecoveryRuntimeError::Unavailable)
}
