//! Actual fenced reservation/refusal tests. These do not claim cage enforcement.
use super::*;
use crate::confinement::NativeConfinedRuntime;
use chio_core_types::capability::attenuation::{
    compute_attenuation_witness, delegate, scope_hash, AttenuationProof,
};
use chio_core_types::capability::token::{CapabilityTokenAttenuationBody, CapabilityTokenBody};
use chio_core_types::delegation_receipt::ScopeAttenuation;
use chio_security_types::confinement::*;

struct ConfinedFixture {
    knowledge: KnowledgeFixture,
    runtime: NativeConfinedRuntime,
    profile: NativeConfinedInstallationV1,
    observation: ArtifactVersionRefV1,
}
fn child(f: &KnowledgeFixture, id: &str, seed: u8) -> TestResult<CapabilityToken> {
    let parent = &f.f.seed.capability;
    signed_child(parent, id, seed, &Keypair::from_seed(&[140; 32]))
}
fn signed_child(
    parent: &CapabilityToken,
    id: &str,
    seed: u8,
    issuer: &Keypair,
) -> TestResult<CapabilityToken> {
    let scope = ChioScope::default();
    let subject = Keypair::from_seed(&[seed; 32]);
    let receipt = delegate(
        parent,
        &scope,
        &Keypair::from_seed(&[141; 32]),
        &subject.public_key(),
        ScopeAttenuation {
            budget_share_bps: Some(625),
            ..Default::default()
        },
        parent.issued_at,
        [seed; 16],
    )?;
    Ok(CapabilityToken::sign_attenuated(
        CapabilityTokenAttenuationBody {
            body: CapabilityTokenBody {
                id: id.into(),
                issuer: parent.issuer.clone(),
                subject: subject.public_key(),
                issued_at: parent.issued_at,
                expires_at: parent.expires_at,
                delegation_chain: receipt.complete_chain(),
                aggregate_invocation_budget: parent.aggregate_invocation_budget.clone(),
                scope: scope.clone(),
            },
            caveats: vec![],
            scope_attenuations: vec![],
            attenuation_proof: AttenuationProof {
                parent_scope_hash: scope_hash(&parent.scope)?,
                child_scope_hash: scope_hash(&scope)?,
                normalized_subset_proof: compute_attenuation_witness(&parent.scope, &scope)?,
            },
            budget_share_bps: Some(625),
        },
        issuer,
    )?)
}
impl ConfinedFixture {
    fn new() -> TestResult<Self> {
        let directory = tempfile::tempdir()?;
        std::fs::write(
            directory.path().join("confined-profile"),
            b"delegate-only-fixture",
        )?;
        let mut knowledge = KnowledgeFixture::from(RecoveryFixture::open(
            directory.path().to_path_buf(),
            Some(directory),
            false,
        )?)?;
        knowledge.f.kernel.set_capability_trust_root(
            knowledge.f.seed.capability.issuer.clone(),
            scope_hash(&knowledge.f.seed.capability.scope)?,
        );
        let mut deployment = knowledge
            .f
            .kernel
            .recovery_deployment(&knowledge.profile.scope)?;
        let mut actors = deployment.actors.as_slice().to_vec();
        let mut permissions = actors[0].permissions.as_slice().to_vec();
        permissions.extend([
            RecoveryPermission::ConfinedLaunch,
            RecoveryPermission::ConfinedReturn,
            RecoveryPermission::ConfinedCancel,
        ]);
        permissions.sort();
        permissions.dedup();
        actors[0].permissions = BoundedList::new(permissions.clone())?;
        deployment.actors = NonEmptyBoundedList::new(actors)?;
        deployment.authority_scope = recovery_authority_scope_digest(&deployment)?;
        knowledge
            .f
            .authority
            .admission_operation_store()
            .configure_recovery_deployment(&deployment)?;
        knowledge.f.control = knowledge.f.kernel.issue_capability(
            &knowledge.f.approval_key.public_key(),
            ChioScope {
                grants: permissions
                    .iter()
                    .map(|p| ToolGrant {
                        server_id: "chio.recovery".into(),
                        tool_name: p.wire_name().into(),
                        operations: vec![Operation::Invoke],
                        constraints: vec![],
                        max_invocations: None,
                        max_cost_per_invocation: None,
                        max_total_cost: None,
                        dpop_required: None,
                    })
                    .collect(),
                ..Default::default()
            },
            1200,
        )?;
        // Publish from the imported, already restricted native parent context.
        // Adoption intentionally retains unknown influence and cannot serve as
        // a known-provenance positive control for a confined return.
        let observation = knowledge.publish(
            "confined-private",
            br#"{"eligible":true,"secret":"P5-PRIVATE-CANARY"}"#,
        )?;
        let profile = NativeConfinedInstallationV1 {
            scope: knowledge.profile.scope.clone(),
            generation: SafeInteger::new(1)?,
            contract: ReturnContractV1 {
                domain_version: VersionV1,
                contract: ReturnContractDigest::from_bytes([1; 32]),
                schema: knowledge_content_digest(CONFINED_BOOLEAN_SCHEMA),
                implementation: knowledge_content_digest(CONFINED_BOOLEAN_IMPLEMENTATION),
                field: ProtectedText::new("eligible")?,
                parent: knowledge.profile.recipients.as_slice()[0].recipient.clone(),
                source_ceiling: InformationLabel::Top,
                target: InformationLabel::bottom(),
                require_integrity: true,
                max_bytes: SafeInteger::new(8)?,
                max_values: SafeInteger::new(1)?,
                channels: NonEmptyBoundedList::new(vec![ConfinedChannelV1::Value])?,
                expires_at_unix_ms: SafeInteger::new(now_ms()? + 600_000)?,
                policy: knowledge.profile.policy,
            },
            execution: ConfinedExecutionProfileV1 {
                manifest: CanonicalPayloadDigest::from_bytes([2; 32]),
                profile: CanonicalPayloadDigest::from_bytes([3; 32]),
                configuration: CanonicalPayloadDigest::from_bytes([4; 32]),
                helper: CanonicalPayloadDigest::from_bytes([5; 32]),
                image: CanonicalPayloadDigest::from_bytes([6; 32]),
                provider: ConfinedProviderV1::Disabled,
            },
            limits: ConfinedLimitsV1 {
                children: SafeInteger::new(16)?,
                depth: SafeInteger::new(8)?,
                input_bytes: SafeInteger::new(65536)?,
                diagnostic_bytes: SafeInteger::new(16384)?,
                launches: SafeInteger::new(1)?,
                tool_calls: SafeInteger::new(0)?,
                model_calls: SafeInteger::new(0)?,
                wall_clock_ms: SafeInteger::new(30000)?,
            },
            disclosure_root: Keypair::from_seed(&[233; 32]).public_key(),
            endorsement_root: Keypair::from_seed(&[234; 32]).public_key(),
        };
        let runtime = NativeConfinedRuntime::new(
            knowledge.f.kernel.clone(),
            Arc::new(knowledge.f.authority.admission_operation_store()),
            knowledge.broker.clone(),
            profile.clone(),
            knowledge.f.authority.mutation_fence(),
        )?;
        Ok(Self {
            knowledge,
            runtime,
            profile,
            observation,
        })
    }
    fn reserve(&self, key: &str, cap: &CapabilityToken) -> TestResult<NativeConfinedReservationV1> {
        Ok(self.runtime.reserve(
            &self.knowledge.f.control,
            &self.knowledge.f.process,
            &RequestId::new(key)?,
            cap,
            &[],
            &self.observation,
        )?)
    }
    fn count(&self) -> TestResult<u64> {
        let connection = rusqlite::Connection::open(self.knowledge.f.path.join("admission.db"))?;
        let count:i64=connection.query_row("SELECT json_extract(payload,'$') FROM admission_operation_recovery_records WHERE record_key GLOB 'confined-count:*'",[],|r|r.get(0))?;
        Ok(u64::try_from(count)?)
    }
}

#[test]
fn p5_native_reservation_replay_and_reopened_journal_keep_one_host_identity() -> TestResult {
    let f = ConfinedFixture::new()?;
    let cap = child(&f.knowledge, "child-a", 201)?;
    let first = f.reserve("spawn-a", &cap)?;
    let again = f.reserve("spawn-a", &cap)?;
    assert_eq!(first.boundary, again.boundary);
    assert_eq!(f.count()?, 1);
    assert_ne!(
        first.boundary.lineage.as_str(),
        first.boundary.parent.lineage.as_str()
    );
    assert_ne!(
        first.boundary.isolation_epoch,
        first.boundary.parent.isolation_epoch
    );
    let root = f.knowledge.f.process.recovery_security_context("root")?;
    let reopened = ProcessRuntime::open(
        f.knowledge.f.path.join("process.db"),
        f.knowledge.f.kernel.clone(),
    )?
    .with_security_profile(ProcessSecurityProfile {
        tenant_id: root.as_v1().tenant_id().as_str().into(),
        isolation_epoch_id: root.as_v1().isolation_epoch_id().as_str().into(),
        generation: root.as_v1().context_generation(),
    })?;
    let recovered = f.runtime.reserve(
        &f.knowledge.f.control,
        &reopened,
        &RequestId::new("spawn-a")?,
        &cap,
        &[],
        &f.observation,
    )?;
    assert_eq!(recovered.boundary, first.boundary);
    assert_eq!(f.count()?, 1);
    assert!(reopened
        .recovery_security_context(first.boundary.child.as_str())
        .is_err());
    Ok(())
}
#[test]
fn p5_native_forged_seed_and_capability_substitution_cannot_fork_context() -> TestResult {
    let f = ConfinedFixture::new()?;
    let cap = child(&f.knowledge, "child-a", 201)?;
    let first = f.reserve("spawn-a", &cap)?;
    let different = child(&f.knowledge, "child-b", 202)?;
    assert!(f.reserve("spawn-a", &different).is_err());
    let mut foreign = f.observation.clone();
    foreign.scope.tenant_id = RecoveryTenantId::new("other-tenant")?;
    assert!(f
        .runtime
        .reserve(
            &f.knowledge.f.control,
            &f.knowledge.f.process,
            &RequestId::new("spawn-a")?,
            &cap,
            &[],
            &foreign
        )
        .is_err());
    assert!(f
        .knowledge
        .f
        .process
        .recovery_security_context(first.boundary.child.as_str())
        .is_err());
    assert_eq!(f.count()?, 1);
    Ok(())
}
#[test]
fn p5_native_sensitive_observation_waits_for_real_enforcement() -> TestResult {
    let f = ConfinedFixture::new()?;
    let cap = child(&f.knowledge, "child-a", 201)?;
    let reservation = f.reserve("spawn-a", &cap)?;
    let actor = f.knowledge.actor(RecoveryPermission::ConfinedLaunch)?;
    let store = f.knowledge.f.authority.admission_operation_store();
    let fence = f.knowledge.f.authority.mutation_fence();
    assert!(store
        .confined_input_inventory(&actor, &RequestId::new("spawn-a")?, &fence, now_ms()?)
        .is_err());
    let packet = encode_confined_input("eligible", br#"{"eligible":true}"#, &[])?;
    assert!(store
        .admit_confined_input(
            &actor,
            &RequestId::new("spawn-a")?,
            &packet,
            &fence,
            now_ms()?
        )
        .is_err());
    let seal = f.knowledge.broker.stage(
        &ArtifactObjectId::new("forged-return")?,
        &reservation.boundary.child,
        b"true",
    )?;
    assert!(store
        .stage_confined_return(
            &actor,
            &RequestId::new("spawn-a")?,
            &seal,
            b"true",
            &fence,
            now_ms()?
        )
        .is_err());
    assert!(f
        .runtime
        .prepare_return(&f.knowledge.f.control, &RequestId::new("spawn-a")?)
        .is_err());
    Ok(())
}
#[test]
fn p5_native_cancel_revokes_context_and_keeps_inputs_pinned_and_slot_consumed() -> TestResult {
    let f = ConfinedFixture::new()?;
    let cap = child(&f.knowledge, "child-a", 201)?;
    let reservation = f.reserve("spawn-a", &cap)?;
    f.runtime.cancel(
        &f.knowledge.f.control,
        &f.knowledge.f.process,
        &RequestId::new("spawn-a")?,
    )?;
    assert_eq!(
        f.reserve("spawn-a", &cap)?.state,
        IsolationStateV1::Cancelled
    );
    assert_eq!(f.count()?, 1);
    assert!(f
        .knowledge
        .f
        .process
        .recovery_security_context(reservation.boundary.child.as_str())
        .is_err());
    assert!(f
        .knowledge
        .runtime
        .collect(&f.knowledge.f.control, &f.observation)
        .is_err());
    assert!(f.reserve("new-epoch-same-cap", &cap).is_err());
    Ok(())
}
#[test]
fn p5_native_ordinary_fork_retains_root_lineage_and_tainted_parent_control() -> TestResult {
    let f = ConfinedFixture::new()?;
    let cap = child(&f.knowledge, "ordinary-child", 201)?;
    f.knowledge
        .f
        .process
        .spawn("root", "ordinary-child", &cap)?;
    let root = f.knowledge.f.process.recovery_security_context("root")?;
    let ordinary = f
        .knowledge
        .f
        .process
        .recovery_security_context("ordinary-child")?;
    assert_eq!(
        root.as_v1().lineage_root_id(),
        ordinary.as_v1().lineage_root_id()
    );
    assert_eq!(
        root.as_v1().isolation_epoch_id(),
        ordinary.as_v1().isolation_epoch_id()
    );
    let handle = f.knowledge.runtime.handle(
        &f.knowledge.f.control,
        &f.observation,
        &ArtifactRecipientId::new("agent-root")?,
    )?;
    let sink = f.knowledge.sink();
    f.knowledge.runtime.release_into(
        &f.knowledge.f.control,
        &RequestId::new("taint-parent")?,
        f.knowledge
            .runtime
            .prepare_read(&f.knowledge.f.control, &handle)?,
        &sink,
    )?;
    let confined = f.reserve("tainted-control", &child(&f.knowledge, "fresh-child", 202)?)?;
    assert!(!confined
        .boundary
        .seed_label
        .flows_to(&InformationLabel::bottom()));
    assert!(confined.boundary.seed_influence.externally_influenced);
    Ok(())
}
#[test]
fn p5_native_profile_downgrade_and_integrity_root_alias_refuse() -> TestResult {
    let f = ConfinedFixture::new()?;
    let store = f.knowledge.f.authority.admission_operation_store();
    let mut p = f.profile.clone();
    p.endorsement_root = p.disclosure_root.clone();
    assert!(store.configure_confinement(&p).is_err());
    let mut p = f.profile.clone();
    p.contract.channels =
        NonEmptyBoundedList::new(vec![ConfinedChannelV1::Value, ConfinedChannelV1::Stream])?;
    assert!(store.configure_confinement(&p).is_err());
    let mut p = f.profile.clone();
    p.limits.model_calls = SafeInteger::new(1)?;
    assert!(store.configure_confinement(&p).is_err());
    let cap = child(&f.knowledge, "child-a", 201)?;
    f.reserve("spawn-a", &cap)?;
    let mut p = f.profile.clone();
    p.generation = SafeInteger::new(2)?;
    p.contract.field = ProtectedText::new("different")?;
    store.configure_confinement(&p)?;
    assert!(f.reserve("spawn-a", &cap).is_err());
    Ok(())
}
#[test]
fn p5_native_permanent_counts_stop_epoch_churn_at_tree_limit() -> TestResult {
    let f = ConfinedFixture::new()?;
    let actor = f.knowledge.actor(RecoveryPermission::ConfinedLaunch)?;
    let store = f.knowledge.f.authority.admission_operation_store();
    let fence = f.knowledge.f.authority.mutation_fence();
    for n in 0..16u8 {
        let cap = child(&f.knowledge, &format!("child-{n}"), 150 + n)?;
        store.reserve_confined_child(
            &actor,
            ConfinedChildReservationInput {
                request: &RequestId::new(&format!("spawn-{n}"))?,
                parent: &f.knowledge.f.seed.capability,
                child: &cap,
                seeds: &[],
                observation: &f.observation,
            },
            &fence,
            now_ms()?,
        )?;
    }
    let cap = child(&f.knowledge, "overflow", 200)?;
    assert!(store
        .reserve_confined_child(
            &actor,
            ConfinedChildReservationInput {
                request: &RequestId::new("overflow")?,
                parent: &f.knowledge.f.seed.capability,
                child: &cap,
                seeds: &[],
                observation: &f.observation
            },
            &fence,
            now_ms()?
        )
        .is_err());
    assert_eq!(f.count()?, 16);
    Ok(())
}
#[test]
fn p5_native_protected_boundary_and_quota_tampering_cannot_reactivate_context() -> TestResult {
    let f = ConfinedFixture::new()?;
    let cap = child(&f.knowledge, "child-a", 201)?;
    f.reserve("spawn-a", &cap)?;
    let connection = rusqlite::Connection::open(f.knowledge.f.path.join("admission.db"))?;
    assert!(connection.execute("UPDATE admission_operation_recovery_records SET payload='0' WHERE record_key GLOB 'confined-count:*'",[]).is_err());
    assert_eq!(f.count()?, 1);
    // Simulate a raw writer following the SQL version rule but bypassing the
    // immutable digest history and independent serving commit chain.
    connection.execute("UPDATE admission_operation_recovery_records SET payload='0', version=version+1 WHERE record_key GLOB 'confined-count:*'",[])?;
    assert!(f.reserve("spawn-a", &cap).is_err());
    Ok(())
}

#[test]
fn p5_native_lost_reservation_and_attachment_acknowledgements_keep_original_slot() -> TestResult {
    use crate::confinement::ConfinedCutpoint;
    for cutpoint in [ConfinedCutpoint::Reserved, ConfinedCutpoint::Attached] {
        let f = ConfinedFixture::new()?;
        let cap = child(&f.knowledge, "child-a", 201)?;
        let faulty = f.runtime.clone().with_test_cutpoint(Arc::new(move |stage| {
            if stage == cutpoint {
                return Err(KernelError::Internal("lost acknowledgement".into()));
            }
            Ok(())
        }));
        let request = RequestId::new("lost-ack")?;
        assert!(faulty
            .reserve(
                &f.knowledge.f.control,
                &f.knowledge.f.process,
                &request,
                &cap,
                &[],
                &f.observation
            )
            .is_err());
        let recovered = f.reserve("lost-ack", &cap)?;
        let replay = f.reserve("lost-ack", &cap)?;
        assert_eq!(recovered.boundary, replay.boundary);
        assert_eq!(f.count()?, 1);
        assert_eq!(
            f.knowledge
                .f
                .process
                .process(recovered.boundary.child.as_str())?
                .capability
                .id,
            cap.id
        );
    }
    Ok(())
}
#[test]
fn p5_native_capability_issuer_and_actual_delegation_right_are_required() -> TestResult {
    let f = ConfinedFixture::new()?;
    let store = f.knowledge.f.authority.admission_operation_store();
    let actor = f.knowledge.actor(RecoveryPermission::ConfinedLaunch)?;
    let fence = f.knowledge.f.authority.mutation_fence();
    let issuer = Keypair::from_seed(&[211; 32]);
    let mut body = f.knowledge.f.seed.capability.body();
    body.issuer = issuer.public_key();
    let parent = CapabilityToken::sign(body, &issuer)?;
    let cap = signed_child(&parent, "foreign-issuer", 201, &issuer)?;
    assert!(store
        .reserve_confined_child(
            &actor,
            ConfinedChildReservationInput {
                request: &RequestId::new("foreign")?,
                parent: &parent,
                child: &cap,
                seeds: &[],
                observation: &f.observation
            },
            &fence,
            now_ms()?
        )
        .is_err());
    let cap = child(&f.knowledge, "legitimate-child", 201)?;
    let mut body = f.knowledge.f.seed.capability.body();
    body.scope.grants[0].operations = vec![Operation::Invoke];
    let parent = CapabilityToken::sign(body, &Keypair::from_seed(&[140; 32]))?;
    assert!(store
        .reserve_confined_child(
            &actor,
            ConfinedChildReservationInput {
                request: &RequestId::new("no-delegate")?,
                parent: &parent,
                child: &cap,
                seeds: &[],
                observation: &f.observation
            },
            &fence,
            now_ms()?
        )
        .is_err());
    Ok(())
}
#[test]
fn p5_native_cancelled_principal_cannot_be_reissued_into_a_fresh_observation() -> TestResult {
    let f = ConfinedFixture::new()?;
    let first = child(&f.knowledge, "child-a", 201)?;
    f.reserve("spawn-a", &first)?;
    f.runtime.cancel(
        &f.knowledge.f.control,
        &f.knowledge.f.process,
        &RequestId::new("spawn-a")?,
    )?;
    let reissued = child(&f.knowledge, "new-cap-same-principal", 201)?;
    assert!(f.reserve("new-boundary", &reissued).is_err());
    assert_eq!(f.count()?, 1);
    Ok(())
}

#[test]
fn p5_native_attachment_requires_live_journal_ancestry_and_retained_signed_capability() -> TestResult
{
    use chio_kernel::knowledge::ArtifactBlobPort;
    let f = ConfinedFixture::new()?;
    let cap = child(&f.knowledge, "child-a", 201)?;
    let reserved = f.reserve("spawn-a", &cap)?;
    f.knowledge
        .broker
        .validate_confined_attachment(&reserved.boundary)?;
    f.knowledge
        .f
        .kernel
        .verify_retained_capability_liveness(&cap.id, &cap.subject)?;
    let mut substituted = reserved.boundary.clone();
    substituted.parent_capability = CapabilityBodyDigest::from_bytes([0; 32]);
    assert!(f
        .knowledge
        .broker
        .validate_confined_attachment(&substituted)
        .is_err());
    f.knowledge.f.process.cancel("root")?;
    assert!(f
        .knowledge
        .broker
        .validate_confined_attachment(&reserved.boundary)
        .is_err());
    assert_eq!(f.count()?, 1);
    Ok(())
}
#[test]
fn p5_native_original_tree_quota_denies_attachment_without_refunding_native_slot() -> TestResult {
    use chio_kernel::knowledge::ArtifactBlobPort;
    let f = ConfinedFixture::new()?;
    for n in 0..7u8 {
        f.reserve(
            &format!("tree-{n}"),
            &child(&f.knowledge, &format!("tree-child-{n}"), 150 + n)?,
        )?;
    }
    let cap = child(&f.knowledge, "tree-overflow", 200)?;
    assert!(f.reserve("tree-overflow", &cap).is_err());
    assert_eq!(f.count()?, 8);
    let actor = f.knowledge.actor(RecoveryPermission::ConfinedLaunch)?;
    let reservation = f
        .knowledge
        .f
        .authority
        .admission_operation_store()
        .confined_launch_reservation(
            &actor,
            &RequestId::new("tree-overflow")?,
            &f.knowledge.f.authority.mutation_fence(),
            now_ms()?,
        )?;
    assert!(f
        .knowledge
        .broker
        .validate_confined_attachment(&reservation.boundary)
        .is_err());
    Ok(())
}

#[cfg(all(target_os = "linux", target_arch = "x86_64"))]
mod linux;
