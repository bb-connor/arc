//! Selected operator self-test custody and report acceptance.
use super::*;

impl SqliteAdmissionOperationStore {
    /// Trusted selected operator pins and creates a new exact self-test in the
    /// same transaction. The supplied actor still needs fresh Create authority.
    /// This method is not exposed through the agent control listener.
    pub fn pin_setup_creation(
        &self,
        actor: &AuthenticatedRecoveryActor,
        command: &RecoveryCommandV1,
        receipt_key: &PublicKey,
        operator: &PublicKey,
        fence: &StoreMutationFence,
        now: u64,
    ) -> Result<WorkflowId, AdmissionOperationStoreError> {
        let wire = chio_core::canonical_json_bytes(command).map_err(refused)?;
        let _: RecoveryCommandV1 = chio_core::recovery::decode_contract(&wire).map_err(refused)?;
        let RecoveryCommandBodyV1::CreateWorkflow {
            creation_key,
            request_seed,
            ..
        } = &command.command
        else {
            return Err(refused("setup creation command"));
        };
        self.recovery_mutation(actor, fence, now, |tx, recovery, now| {
            if actor.permission() != RecoveryPermission::Create {
                return Err(refused("setup creation authority"));
            }
            let (_, _, _, root) = profile(tx, actor.scope(), receipt_key)?;
            if &root != operator {
                return Err(refused("selected operator"));
            }
            let workflow = WorkflowId::new(&format!(
                "workflow:{}",
                sha256_hex(&protected::encode(&(actor.scope(), creation_key))?)
            ))
            .map_err(refused)?;
            let creation = CanonicalPayloadDigest::from_bytes(digest(
                "chio.recovery.setup.creation.v1",
                request_seed,
            )?);
            if let Some(existing) = load(tx, actor.scope())? {
                if current(tx, &existing).is_ok() && now < existing.probe.expires_at_unix_ms.get() {
                    if existing.probe.scope != *actor.scope()
                        || existing.probe.benign_workflow != workflow
                        || existing.creation != creation
                        || existing.receipt_key != *receipt_key
                        || existing.operator != *operator
                    {
                        return Err(refused("active self-test cannot change"));
                    }
                } else {
                    if protected::raw(tx, &protected::workflow_key(actor.scope(), &workflow)?)?
                        .is_some()
                    {
                        return Err(refused("new profile needs a new unfinished self-test"));
                    }
                    let selection = make_selection(
                        tx,
                        SelectionInput {
                            scope: actor.scope(),
                            workflow: &workflow,
                            receipt_key,
                            operator,
                        },
                        creation,
                        SafeInteger::new(1).map_err(refused)?,
                        fence,
                        now,
                    )?;
                    save(tx, &self.serving_owner, &selection)?;
                }
            } else {
                let selection = make_selection(
                    tx,
                    SelectionInput {
                        scope: actor.scope(),
                        workflow: &workflow,
                        receipt_key,
                        operator,
                    },
                    creation,
                    SafeInteger::new(1).map_err(refused)?,
                    fence,
                    now,
                )?;
                save(tx, &self.serving_owner, &selection)?;
            }
            let response = super::super::recovery::apply_command(
                tx,
                &self.serving_owner,
                actor,
                command,
                recovery,
                now,
            )
            .map_err(refused)?;
            if response.workflow_id != workflow {
                return Err(refused("self-test creation identity"));
            }
            Ok(workflow)
        })
    }
    /// Trusted local operator pins a single unfinished model-free workflow.
    pub fn configure_protected_setup(
        &self,
        scope: &RecoveryScopeV1,
        workflow: &WorkflowId,
        receipt_key: &PublicKey,
        operator: &PublicKey,
        fence: &StoreMutationFence,
        now: u64,
    ) -> Result<NativeSetupPreparationV1, AdmissionOperationStoreError> {
        let mut connection = self.connection()?;
        super::recovery::require_intake_headroom(&connection)?;
        let tx = self.begin_write(&mut connection, Some(fence))?;
        let now = schema::authority_validation_time(&tx, now)?;
        let (_, _, _, root) = profile(&tx, scope, receipt_key)?;
        if &root != operator {
            return Err(refused("selected operator"));
        }
        if let Some(value) = load(&tx, scope)? {
            current(&tx, &value)?;
            if value.probe.scope != *scope
                || value.probe.benign_workflow != *workflow
                || value.receipt_key != *receipt_key
                || value.operator != *operator
            {
                return Err(refused("pinned self-test changed"));
            }
            tx.commit().map_err(sqlite_error)?;
            return Ok(preparation(&value));
        }
        let record = protected::workflow_tx(&tx, scope, workflow)?;
        if record.captured || record.native_link.is_some() {
            return Err(refused("self-test must be unfinished"));
        }
        let value = make_selection(
            &tx,
            SelectionInput {
                scope,
                workflow,
                receipt_key,
                operator,
            },
            creation(&record)?,
            record.revision,
            fence,
            now,
        )?;
        save(&tx, &self.serving_owner, &value)?;
        self.commit_write(tx)?;
        self.sync_after_write(&connection)?;
        Ok(preparation(&value))
    }
    pub fn setup_preparation(
        &self,
        actor: &AuthenticatedRecoveryActor,
        fence: &StoreMutationFence,
        now: u64,
    ) -> Result<NativeSetupPreparationV1, AdmissionOperationStoreError> {
        self.recovery_mutation(actor, fence, now, |tx, profile, _| {
            let value =
                load(tx, actor.scope())?.ok_or_else(|| refused("setup selection absent"))?;
            authorized(tx, actor, profile, &value)?;
            Ok(preparation(&value))
        })
    }
    pub fn commit_setup_probe(
        &self,
        actor: &AuthenticatedRecoveryActor,
        evidence: &NativeSetupProbeEvidenceV1<'_>,
        fence: &StoreMutationFence,
        now: u64,
    ) -> Result<SignedRecoverySetupProbeV1, AdmissionOperationStoreError> {
        let NativeSetupProbeEvidenceV1 {
            probe,
            benign,
            denied_request,
            denied,
        } = *evidence;
        if !probe.verify_signature().map_err(refused)?
            || !benign.verify_signature().map_err(refused)?
            || !denied.verify_signature().map_err(refused)?
        {
            return Err(refused("setup signature"));
        }
        self.recovery_mutation(actor, fence, now, |tx, profile, now| {
            let mut value =
                load(tx, actor.scope())?.ok_or_else(|| refused("setup selection absent"))?;
            authorized(tx, actor, profile, &value)?;
            if let Some(evidence) = &value.evidence {
                if &evidence.probe == probe {
                    return Ok(evidence.probe.clone());
                }
                return Err(refused("probe conflict"));
            }
            if probe.body() != &value.probe
                || probe.authority_key() != &value.operator
                || now >= value.probe.expires_at_unix_ms.get()
                || fence_digest(fence)? != value.previous_fence
                || denied.kernel_key != value.receipt_key
                || !denied.is_denied()
                || protected::encode(&denied_request.capability)?
                    != protected::encode(actor.capability())?
                || denied.capability_id != actor.capability().id
                || denied_request.request_id != value.probe.denied_command.as_str()
                || denied_request.server_id != profile.server_id.as_str()
                || denied_request.tool_name != profile.tool_name.as_str()
                || denied.tool_server != denied_request.server_id
                || denied.tool_name != denied_request.tool_name
            {
                return Err(refused("probe custody"));
            }
            value.evidence = Some(Evidence {
                probe: probe.clone(),
                operation: completed(tx, &value, benign)?,
                benign_receipt: SourceDigest::from_bytes(digest(
                    "chio.recovery.setup.benign-receipt.v1",
                    benign,
                )?),
                denied_command: CommandDigest::from_bytes(digest(
                    "chio.recovery.setup.denied-command.v1",
                    &(&value.probe.denied_command, denied_request, denied),
                )?),
            });
            save(tx, &self.serving_owner, &value)?;
            Ok(probe.clone())
        })
    }
    pub fn prepare_setup_report(
        &self,
        actor: &AuthenticatedRecoveryActor,
        probe: &SignedRecoverySetupProbeV1,
        benign: &ChioReceipt,
        fence: &StoreMutationFence,
        now: u64,
    ) -> Result<RecoverySetupReportV1, AdmissionOperationStoreError> {
        if !probe.verify_signature().map_err(refused)?
            || !benign.verify_signature().map_err(refused)?
        {
            return Err(refused("setup signature"));
        }
        self.recovery_mutation(actor, fence, now, |tx, profile, now| {
            let value =
                load(tx, actor.scope())?.ok_or_else(|| refused("setup selection absent"))?;
            authorized(tx, actor, profile, &value)?;
            let evidence = value
                .evidence
                .as_ref()
                .ok_or_else(|| refused("probe evidence absent"))?;
            let current_fence = fence_digest(fence)?;
            if &evidence.probe != probe
                || current_fence == value.previous_fence
                || now >= value.probe.expires_at_unix_ms.get()
                || completed(tx, &value, benign)? != evidence.operation
                || SourceDigest::from_bytes(digest(
                    "chio.recovery.setup.benign-receipt.v1",
                    benign,
                )?) != evidence.benign_receipt
            {
                return Err(refused("fresh writer proof"));
            }
            Ok(RecoverySetupReportV1 {
                domain_version: VersionV1,
                probe: value.probe.clone(),
                benign_operation: evidence.operation.clone(),
                benign_receipt: evidence.benign_receipt,
                denied_command_digest: evidence.denied_command,
                previous_serving_fence: value.previous_fence,
                current_serving_fence: current_fence,
                qualified_at_unix_ms: SafeInteger::new(now).map_err(refused)?,
            })
        })
    }
    /// A signed claim is accepted only against retained native self-test custody.
    pub fn accept_setup_report(
        &self,
        report: &SignedRecoverySetupReportV1,
        fence: &StoreMutationFence,
        now: u64,
    ) -> Result<SignedRecoverySetupReportV1, AdmissionOperationStoreError> {
        if !report.verify_signature().map_err(refused)? {
            return Err(refused("setup signature"));
        }
        let mut connection = self.connection()?;
        let tx = self.begin_write(&mut connection, Some(fence))?;
        let now = schema::authority_validation_time(&tx, now)?;
        let mut value = load(&tx, &report.body().probe.scope)?
            .ok_or_else(|| refused("setup selection absent"))?;
        current(&tx, &value)?;
        let evidence = value
            .evidence
            .as_ref()
            .ok_or_else(|| refused("probe evidence absent"))?;
        let body = report.body();
        if body.probe != value.probe
            || report.authority_key() != &value.operator
            || body.previous_serving_fence != value.previous_fence
            || body.current_serving_fence != fence_digest(fence)?
            || body.benign_operation != evidence.operation
            || body.benign_receipt != evidence.benign_receipt
            || body.denied_command_digest != evidence.denied_command
            || body.qualified_at_unix_ms.get() > now
            || (now >= value.probe.expires_at_unix_ms.get()
                && value.report.as_ref() != Some(report))
        {
            return Err(refused("setup report custody"));
        }
        let operation = load_by_operation_id_tx(
            &tx,
            &AdmissionOperationId::from_persisted(evidence.operation.as_str())?,
        )?
        .ok_or_else(|| refused("lost benign operation"))?;
        if operation.operation.state() != AdmissionOperationState::Completed {
            return Err(refused("benign completion"));
        }
        if let Some(existing) = &value.report {
            if existing == report {
                tx.commit().map_err(sqlite_error)?;
                return Ok(existing.clone());
            }
            if existing.body().current_serving_fence == body.current_serving_fence {
                return Err(refused("setup report conflict"));
            }
        }
        value.report = Some(report.clone());
        save(&tx, &self.serving_owner, &value)?;
        self.commit_write(tx)?;
        self.sync_after_write(&connection)?;
        Ok(report.clone())
    }
}

struct SelectionInput<'a> {
    scope: &'a RecoveryScopeV1,
    workflow: &'a WorkflowId,
    receipt_key: &'a PublicKey,
    operator: &'a PublicKey,
}
fn make_selection(
    tx: &Connection,
    input: SelectionInput<'_>,
    creation: CanonicalPayloadDigest,
    revision: SafeInteger,
    fence: &StoreMutationFence,
    now: u64,
) -> Result<Selection, AdmissionOperationStoreError> {
    let SelectionInput {
        scope,
        workflow,
        receipt_key,
        operator,
    } = input;
    let (authority, deployment, source, root) = profile(tx, scope, receipt_key)?;
    if &root != operator {
        return Err(refused("selected operator"));
    }
    let previous_fence = fence_digest(fence)?;
    let challenge = sha256_hex(&protected::encode(&(
        scope,
        workflow,
        &source,
        &previous_fence,
    ))?);
    Ok(Selection {
        probe: RecoverySetupProbeV1 {
            domain_version: VersionV1,
            scope: scope.clone(),
            probe_id: ChallengeId::new(&challenge).map_err(refused)?,
            native_authority: authority,
            deployment,
            source_profile: source,
            required_coverage: CoverageDigest::from_bytes(digest(
                "chio.recovery.setup.required-coverage.v1",
                &["native-capture", "native-semantic", "artifact-broker"],
            )?),
            benign_workflow: workflow.clone(),
            denied_command: CommandId::new(&format!("setup-denied:{challenge}"))
                .map_err(refused)?,
            issued_at_unix_ms: SafeInteger::new(now).map_err(refused)?,
            expires_at_unix_ms: SafeInteger::new(
                now.checked_add(900_000).ok_or_else(|| refused("clock"))?,
            )
            .map_err(refused)?,
        },
        creation,
        command: RecoveryCommandV1 {
            schema: RecoveryCommandSchema::V1,
            version: VersionV1,
            command_id: CommandId::new(&format!("setup-benign:{}", workflow.as_str()))
                .map_err(refused)?,
            command: RecoveryCommandBodyV1::ResumeWorkflow {
                workflow_id: workflow.clone(),
                expected_revision: revision,
            },
        },
        operator: root,
        receipt_key: receipt_key.clone(),
        previous_fence,
        evidence: None,
        report: None,
    })
}
