//! Confined lifecycle records and observations share the existing native writer.
use super::*;
use chio_core::capability::token::CapabilityToken;
use chio_security_types::confinement::*;

mod context;
mod launch;
mod returns;

#[derive(Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct NativeConfinedInstallationV1 {
    pub scope: RecoveryScopeV1,
    pub generation: SafeInteger,
    pub contract: ReturnContractV1,
    pub execution: ConfinedExecutionProfileV1,
    pub limits: ConfinedLimitsV1,
    pub disclosure_root: PublicKey,
    pub endorsement_root: PublicKey,
}
#[derive(Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct NativeConfinedReservationV1 {
    pub boundary: IsolationBoundaryV1,
    pub child_context: SecurityInvocationContext,
    pub state: IsolationStateV1,
}
pub struct ConfinedChildReservationInput<'a> {
    pub request: &'a RequestId,
    pub parent: &'a CapabilityToken,
    pub child: &'a CapabilityToken,
    pub seeds: &'a [ArtifactVersionRefV1],
    pub observation: &'a ArtifactVersionRefV1,
}
pub struct ConfinedReturnAdmissionInput<'a> {
    pub request: &'a RequestId,
    pub seal: &'a ArtifactBlobSealV1,
    pub parent: &'a ArtifactRecipientV1,
    pub disclosure: Option<&'a SignedConfinedDisclosureV1>,
    pub endorsement: Option<&'a SignedConfinedEndorsementV1>,
}
#[derive(Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct BoundaryRecord {
    reservation: NativeConfinedReservationV1,
    installation: NativeConfinedInstallationV1,
    initiator: CapabilityToken,
    initiating_principal: chio_security_types::PrincipalId,
    parent_capability: CapabilityToken,
    child_capability: CapabilityToken,
    prepared: Option<CanonicalPayloadDigest>,
    prepared_profile: Option<CanonicalPayloadDigest>,
    launch: Option<CanonicalPayloadDigest>,
    enforcement: Option<chio_cage::FullyEnforcedEvidence>,
    terminal: Option<chio_cage::CageEnforcementRecord>,
    input_packet: Option<CanonicalPayloadDigest>,
    expected_return: Option<CanonicalPayloadDigest>,
    observation_release: Option<ArtifactReleaseIntentV1>,
    return_seal: Option<ArtifactBlobSealV1>,
    return_artifact: Option<ArtifactVersionRefV1>,
    return_metadata: Option<ArtifactVersionV1>,
    return_admission: Option<ReturnAdmissionV1>,
    return_authority: Option<CapabilityBodyDigest>,
}
impl core::fmt::Debug for NativeConfinedInstallationV1 {
    fn fmt(&self, f: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        f.write_str("NativeConfinedInstallationV1([redacted])")
    }
}
impl core::fmt::Debug for NativeConfinedReservationV1 {
    fn fmt(&self, f: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        f.write_str("NativeConfinedReservationV1([redacted])")
    }
}

fn key(
    scope: &RecoveryScopeV1,
    request: &RequestId,
) -> Result<String, AdmissionOperationStoreError> {
    Ok(format!(
        "confined-boundary:{}:{}",
        scope_key(scope)?,
        request.as_str()
    ))
}
fn config_key(scope: &RecoveryScopeV1) -> Result<String, AdmissionOperationStoreError> {
    Ok(format!("confined-profile:{}", scope_key(scope)?))
}
fn capability_digest(
    cap: &CapabilityToken,
) -> Result<CapabilityBodyDigest, AdmissionOperationStoreError> {
    confined_capability_digest(cap).map_err(refused)
}
fn current(
    tx: &Connection,
    scope: &RecoveryScopeV1,
) -> Result<NativeConfinedInstallationV1, AdmissionOperationStoreError> {
    load(tx, &config_key(scope)?)?.ok_or_else(|| refused("confined profile"))
}
fn record(
    tx: &Connection,
    scope: &RecoveryScopeV1,
    request: &RequestId,
) -> Result<BoundaryRecord, AdmissionOperationStoreError> {
    load(tx, &key(scope, request)?)?.ok_or_else(|| refused("confined boundary"))
}
fn retain(
    tx: &Transaction<'_>,
    owner: &SqliteServingOwner,
    record: &BoundaryRecord,
) -> Result<(), AdmissionOperationStoreError> {
    save(
        tx,
        owner,
        &record.reservation.boundary.scope,
        &key(
            &record.reservation.boundary.scope,
            &record.reservation.boundary.request,
        )?,
        record,
    )
}
fn validate_current(
    tx: &Connection,
    record: &BoundaryRecord,
    profile: &NativeKnowledgeInstallationV1,
    now: u64,
) -> Result<(), AdmissionOperationStoreError> {
    let boundary = &record.reservation.boundary;
    if protected::encode(&record.installation)?
        != protected::encode(&current(tx, &boundary.scope)?)?
        || boundary.policy != profile.policy
        || boundary.parent != record.installation.contract.parent
        || profile.producer_context.as_v1().principal_id().as_str()
            != record.parent_capability.subject.to_hex()
        || now >= record.installation.contract.expires_at_unix_ms.get()
    {
        return Err(refused("confined current authority"));
    }
    context::verify_retained(tx, record, now)?;
    Ok(())
}
impl SqliteAdmissionOperationStore {
    /// Operator-only installation. A stripped/rotated profile invalidates pending
    /// releases; it never removes retained ownership or consumed resources.
    pub fn configure_confinement(
        &self,
        installation: &NativeConfinedInstallationV1,
    ) -> Result<(), AdmissionOperationStoreError> {
        installation.contract.validate().map_err(refused)?;
        installation.limits.validate().map_err(refused)?;
        if installation.scope != installation.contract.parent.scope
            || installation.generation.get() == 0
            || installation.disclosure_root == installation.endorsement_root
            || installation.contract.schema != knowledge_content_digest(CONFINED_BOOLEAN_SCHEMA)
            || installation.contract.implementation
                != knowledge_content_digest(CONFINED_BOOLEAN_IMPLEMENTATION)
            || !matches!(installation.contract.parent.sink, ArtifactSinkV1::Agent)
        {
            return Err(refused("confined installation"));
        }
        let mut connection = self.connection()?;
        let tx = self.begin_write(&mut connection, None)?;
        let profile = super::installation(&tx, &installation.scope)?;
        let deployment = protected::deployment_tx(&tx, &installation.scope)?;
        security_participant_state::verify_recovery_initialization(&tx, &profile.native_authority)?;
        if profile.policy != installation.contract.policy
            || deployment.policy_digest != profile.policy
            || !profile
                .recipients
                .as_slice()
                .iter()
                .any(|r| r.recipient == installation.contract.parent)
            || !installation
                .contract
                .target
                .flows_to(&installation.contract.parent.clearance)
        {
            return Err(refused("confined recipient"));
        }
        if let Some(old) =
            load::<NativeConfinedInstallationV1>(&tx, &config_key(&installation.scope)?)?
        {
            if protected::encode(&old)? == protected::encode(installation)? {
                return self.commit_write(tx);
            }
            if installation.generation <= old.generation {
                return Err(refused("confined generation"));
            }
        }
        save(
            &tx,
            &self.serving_owner,
            &installation.scope,
            &config_key(&installation.scope)?,
            installation,
        )?;
        self.commit_write(tx)?;
        self.sync_after_write(&connection)
    }

    /// The host supplies exact signed parent/child capabilities. The authority
    /// allocates all boundary/process/lineage/epoch IDs and accounts once.
    pub fn reserve_confined_child(
        &self,
        actor: &AuthenticatedRecoveryActor,
        input: ConfinedChildReservationInput<'_>,
        fence: &StoreMutationFence,
        now: u64,
    ) -> Result<NativeConfinedReservationV1, AdmissionOperationStoreError> {
        let ConfinedChildReservationInput {
            request,
            parent,
            child,
            seeds,
            observation,
        } = input;
        if actor.permission() != RecoveryPermission::ConfinedLaunch || seeds.len() > 8 {
            return Err(refused("launch authority"));
        }
        context::validate_delegation(parent, child)?;
        mutate(self, actor, fence, now, |tx, profile, now| {
            let installation = current(&tx, actor.scope())?;
            let parent_digest = capability_digest(parent)?;
            let child_digest = capability_digest(child)?;
            if let Some(old) = load::<BoundaryRecord>(&tx, &key(actor.scope(), request)?)? {
                validate_current(&tx, &old, profile, now)?;
                let b = &old.reservation.boundary;
                if b.parent_capability != parent_digest
                    || b.child_capability != child_digest
                    || b.seed_artifacts.as_slice() != seeds
                    || b.observation != *observation
                    || capability_digest(&old.initiator)? != capability_digest(actor.capability())?
                {
                    return Err(refused("spawn conflict"));
                }
                return Ok((tx, old.reservation));
            }
            if parent.subject.to_hex() != profile.producer_context.as_v1().principal_id().as_str()
                || parent.issuer != actor.capability().issuer
                || !parent.delegation_chain.is_empty()
                || !child.scope.grants.is_empty()
                || !child.scope.resource_grants.is_empty()
                || !child.scope.prompt_grants.is_empty()
                || child.subject == parent.subject
                || child.budget_share_bps != Some(625)
            {
                return Err(refused("root confined delegation"));
            }
            let rows = traversal::dependencies(&tx, actor.scope(), seeds)?;
            let observed =
                traversal::dependencies(&tx, actor.scope(), core::slice::from_ref(observation))?;
            let size = rows.iter().chain(&observed).try_fold(0u64, |total, r| {
                total
                    .checked_add(r.metadata.size_bytes.get())
                    .ok_or_else(|| refused("input overflow"))
            })?;
            if size > installation.limits.input_bytes.get() {
                return Err(refused("input bound"));
            }
            let counter_key = format!("confined-count:{}", scope_key(actor.scope())?);
            let count = load::<u64>(&tx, &counter_key)?.unwrap_or(0);
            if count >= installation.limits.children.get() {
                return Err(refused("child bound"));
            }
            let seed_label = traversal::join_metadata(
                source(&tx, &profile.native_authority, &profile.producer_context)?,
                &rows,
            )?;
            let seed_influence = traversal::influence(
                &tx,
                &profile.native_authority,
                &profile.producer_context,
                &rows,
                false,
            )?;
            let id = uuid::Uuid::new_v4().to_string();
            let child_id = ProcessId::new(&format!("confined_{id}")).map_err(refused)?;
            let lineage = IsolationLineageId::new(&format!("confined:{id}")).map_err(refused)?;
            let epoch = ProtectedText::new(&uuid::Uuid::new_v4().to_string()).map_err(refused)?;
            let context = context::make(profile, child, &lineage, &epoch)?;
            // An existing native principal is never renamed into a clean epoch.
            // The native reader also rejects an old principal under an absent epoch.
            if crate::security_state::observe_native_flow_state(
                &tx,
                profile.native_authority.security_authority_id().as_str(),
                &recovery_flow_key(&context),
            )
            .map_err(refused)?
            .0
            .is_some()
            {
                return Err(refused("child principal already observed"));
            }
            let boundary = IsolationBoundaryV1 {
                domain_version: VersionV1,
                boundary: EvidenceRef::new(&id).map_err(refused)?,
                request: request.clone(),
                scope: actor.scope().clone(),
                parent_capability: parent_digest,
                parent: installation.contract.parent.clone(),
                child: child_id,
                child_principal: context.as_v1().principal_id().clone(),
                child_capability: child_digest,
                ancestry: NonEmptyBoundedList::new(vec![actor.scope().process_id.clone()])
                    .map_err(refused)?,
                lineage,
                isolation_epoch: epoch,
                seed_artifacts: BoundedList::new(seeds.to_vec()).map_err(refused)?,
                observation: observation.clone(),
                parent_control: CanonicalPayloadDigest::from_bytes(
                    knowledge_digest(
                        b"chio.confined.parent-control.v1\0",
                        &(
                            request,
                            seeds,
                            observation,
                            &installation.contract.contract,
                            &profile.producer_context,
                            &seed_label,
                            &seed_influence,
                        ),
                    )
                    .map_err(refused)?,
                ),
                seed_label,
                seed_influence,
                execution: installation.execution.clone(),
                return_contract: installation.contract.contract,
                limits: installation.limits.clone(),
                deadline_unix_ms: SafeInteger::new(
                    now.checked_add(installation.limits.wall_clock_ms.get())
                        .ok_or_else(|| refused("deadline"))?,
                )
                .map_err(refused)?,
                policy: profile.policy,
            };
            boundary.validate().map_err(refused)?;
            let record = BoundaryRecord {
                reservation: NativeConfinedReservationV1 {
                    boundary,
                    child_context: context,
                    state: IsolationStateV1::Reserved,
                },
                installation,
                initiator: actor.capability().clone(),
                initiating_principal: actor.principal().clone(),
                parent_capability: parent.clone(),
                child_capability: child.clone(),
                prepared: None,
                prepared_profile: None,
                launch: None,
                enforcement: None,
                terminal: None,
                input_packet: None,
                expected_return: None,
                observation_release: None,
                return_seal: None,
                return_artifact: None,
                return_metadata: None,
                return_admission: None,
                return_authority: None,
            };
            validate_current(&tx, &record, profile, now)?;
            let cap_key = format!("confined-cap:{}", sha256_hex(child.id.as_bytes()));
            if load::<String>(&tx, &cap_key)?.is_some() {
                return Err(refused("child capability reused"));
            }
            let principal_key = format!(
                "confined-principal:{}:{}",
                scope_key(actor.scope())?,
                sha256_hex(child.subject.to_hex().as_bytes())
            );
            if load::<String>(&tx, &principal_key)?.is_some() {
                return Err(refused("child principal reused"));
            }
            save(
                &tx,
                &self.serving_owner,
                actor.scope(),
                &cap_key,
                &key(actor.scope(), request)?,
            )?;
            save(
                &tx,
                &self.serving_owner,
                actor.scope(),
                &principal_key,
                &key(actor.scope(), request)?,
            )?;
            save(
                &tx,
                &self.serving_owner,
                actor.scope(),
                &counter_key,
                &(count + 1),
            )?;
            // Native reservations permanently pin original immutable inputs.
            // The separate process/blob journal cannot collect them on restart.
            for (i, reference) in seeds
                .iter()
                .chain(core::iter::once(observation))
                .enumerate()
            {
                save(
                    &tx,
                    &self.serving_owner,
                    actor.scope(),
                    &format!(
                        "knowledge-pin:{}:confined:{}:{i}",
                        scope_key(actor.scope())?,
                        record.reservation.boundary.boundary.as_str()
                    ),
                    &Some(reference.clone()),
                )?;
            }
            retain(&tx, &self.serving_owner, &record)?;
            Ok((tx, record.reservation))
        })
    }
}
