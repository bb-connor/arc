//! A single pinned HTTPS issue sink with one physical submission attempt.
use chio_core_types::recovery::{decode_contract, SignedRecoveryProviderFinalityV1};
use chio_kernel::recovery::{RecordName, RecoveryEffectContractV1, RecoveryProviderLookup};
use chio_kernel::{
    KernelError, NestedFlowBridge, ToolInvocationContext, ToolInvocationCost, ToolServerConnection,
};
use chio_security_types::recovery::ProtectedText;
use serde::{Deserialize, Serialize};
use serde_json::Value;
use std::sync::Arc;
use std::time::Duration;
use tokio::sync::Semaphore;

/// Credentials and resource selection belong to the trusted host. Tool inputs
/// carry only the exact reviewed title and body, never credentials or a URL.
pub struct PinnedSupportIssueConnector {
    server: String,
    tool: String,
    contract: RecoveryEffectContractV1,
    resource: reqwest::Url,
    submit_token: zeroize::Zeroizing<String>,
    lookup_token: zeroize::Zeroizing<String>,
    client: reqwest::Client,
    capacity: Arc<Semaphore>,
}
impl core::fmt::Debug for PinnedSupportIssueConnector {
    fn fmt(&self, f: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        f.write_str("PinnedSupportIssueConnector([redacted])")
    }
}
#[derive(Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct IssueCreated {
    outcome: IssueSucceeded,
    issue_reference: ProtectedText<2048>,
}
#[derive(Serialize, Deserialize)]
enum IssueSucceeded {
    #[serde(rename = "succeeded")]
    Succeeded,
}
fn refused() -> KernelError {
    KernelError::Internal("pinned recovery connector refused or unavailable".into())
}
impl PinnedSupportIssueConnector {
    pub fn new(
        server: String,
        tool: String,
        contract: RecoveryEffectContractV1,
        submit_token: String,
        lookup_token: String,
    ) -> Result<Self, KernelError> {
        let resource = reqwest::Url::parse(contract.resource.as_str()).map_err(|_| refused())?;
        if resource.scheme() != "https"
            || resource.as_str() != contract.resource.as_str()
            || resource.host_str().is_none()
            || !resource.username().is_empty()
            || resource.password().is_some()
            || resource.fragment().is_some()
            || resource.query().is_some()
            || resource.path().ends_with('/')
            || submit_token.is_empty()
            || lookup_token.is_empty()
            || submit_token.len() > 4096
            || lookup_token.len() > 4096
            || !(1..=65536).contains(&contract.max_response_bytes.get())
            || RecordName::new(&server).is_err()
            || RecordName::new(&tool).is_err()
            || reqwest::header::HeaderValue::from_str(&format!("Bearer {submit_token}")).is_err()
            || reqwest::header::HeaderValue::from_str(&format!("Bearer {lookup_token}")).is_err()
        {
            return Err(refused());
        }
        let client = reqwest::Client::builder()
            .https_only(true)
            .redirect(reqwest::redirect::Policy::none())
            .retry(reqwest::retry::never())
            .connect_timeout(Duration::from_secs(5))
            .timeout(Duration::from_secs(20))
            .pool_max_idle_per_host(4)
            .build()
            .map_err(|_| refused())?;
        Ok(Self {
            server,
            tool,
            contract,
            resource,
            submit_token: zeroize::Zeroizing::new(submit_token),
            lookup_token: zeroize::Zeroizing::new(lookup_token),
            client,
            capacity: Arc::new(Semaphore::new(4)),
        })
    }
    fn submit_request(
        &self,
        operation: &str,
        attempt: &str,
        wire: Vec<u8>,
    ) -> Result<reqwest::Request, KernelError> {
        self.client
            .post(self.resource.clone())
            .bearer_auth(self.submit_token.as_str())
            .header("content-type", "application/json")
            .header("accept", "application/json")
            .header("idempotency-key", operation)
            .header("chio-attempt-id", attempt)
            .body(wire)
            .build()
            .map_err(|_| refused())
    }
    async fn bounded_response(
        &self,
        mut response: reqwest::Response,
    ) -> Result<Vec<u8>, KernelError> {
        let maximum = self.contract.max_response_bytes.get() as usize;
        if !response.status().is_success()
            || response
                .content_length()
                .is_some_and(|length| length > maximum as u64)
        {
            return Err(refused());
        }
        let mut bytes = Vec::with_capacity(maximum.min(4096));
        while let Some(chunk) = response.chunk().await.map_err(|_| refused())? {
            if bytes
                .len()
                .checked_add(chunk.len())
                .is_none_or(|length| length > maximum)
            {
                return Err(refused());
            }
            bytes.extend_from_slice(&chunk);
        }
        Ok(bytes)
    }
    /// Only an affine kernel-selected lookup can use the independent read-only
    /// credential. The original agent's grant and spending budget are irrelevant.
    pub async fn observe_original(
        &self,
        lookup: RecoveryProviderLookup,
    ) -> Result<SignedRecoveryProviderFinalityV1, KernelError> {
        if lookup.deployment().effect_contract != self.contract
            || lookup.workflow().provider_lookups.get() == 0
            || super::materialize::now().map_err(|_| refused())? >= lookup.expires_at_unix_ms()
        {
            return Err(refused());
        }
        let intent = lookup.workflow().admission.as_ref().ok_or_else(refused)?;
        let mut url = self.resource.clone();
        url.path_segments_mut()
            .map_err(|_| refused())?
            .push("operations")
            .push(intent.native_operation_id.as_str());
        let _permit = self.capacity.try_acquire().map_err(|_| refused())?;
        let response = self
            .client
            .get(url)
            .bearer_auth(self.lookup_token.as_str())
            .header("accept", "application/json")
            .send()
            .await
            .map_err(|_| refused())?;
        let bytes = self.bounded_response(response).await?;
        if super::materialize::now().map_err(|_| refused())? >= lookup.expires_at_unix_ms() {
            return Err(refused());
        }
        // Canonical closed provider evidence is verified by the native authority
        // after the await, against current assignment, fence and exact operation.
        decode_contract(&bytes).map_err(|_| refused())
    }
    async fn submit(
        &self,
        context: &ToolInvocationContext,
        arguments: Value,
        nested: Option<&mut dyn NestedFlowBridge>,
    ) -> Result<Value, KernelError> {
        let dispatch = context.dispatch().ok_or_else(refused)?;
        if context.server_id() != self.server
            || context.tool_name() != self.tool
            || nested.is_some()
            || dispatch.caller_capability_sha256() != Some(context.capability_hash())
            || dispatch.request_id() != context.request_id()
        {
            return Err(refused());
        }
        let wire = chio_core_types::canonical_json_bytes(&arguments).map_err(|_| refused())?;
        let _: chio_security_types::recovery::RecoverySupportIssueInputV1 =
            decode_contract(&wire).map_err(|_| refused())?;
        let _permit = self.capacity.try_acquire().map_err(|_| refused())?;
        // One request only. The operation key is correlation, not a claim that
        // the provider implements deduplication. Any ambiguity stays unknown.
        let request = self.submit_request(dispatch.operation_id(), dispatch.attempt_id(), wire)?;
        let response = self.client.execute(request).await.map_err(|_| refused())?;
        let bytes = self.bounded_response(response).await?;
        let created: IssueCreated = decode_contract(&bytes).map_err(|_| refused())?;
        serde_json::to_value(created).map_err(|_| refused())
    }
}

#[async_trait::async_trait]
impl ToolServerConnection for PinnedSupportIssueConnector {
    fn recovery_effect_contract(&self) -> Option<RecoveryEffectContractV1> {
        Some(self.contract.clone())
    }
    fn server_id(&self) -> &str {
        &self.server
    }
    fn tool_names(&self) -> Vec<String> {
        vec![self.tool.clone()]
    }
    async fn invoke(
        &self,
        _: &str,
        _: Value,
        _: Option<&mut dyn NestedFlowBridge>,
    ) -> Result<Value, KernelError> {
        Err(refused())
    }
    async fn invoke_with_context(
        &self,
        context: &ToolInvocationContext,
        arguments: Value,
        nested: Option<&mut dyn NestedFlowBridge>,
    ) -> Result<Value, KernelError> {
        self.submit(context, arguments, nested).await
    }
    async fn invoke_with_cost_and_context(
        &self,
        context: &ToolInvocationContext,
        arguments: Value,
        nested: Option<&mut dyn NestedFlowBridge>,
    ) -> Result<(Value, Option<ToolInvocationCost>), KernelError> {
        Ok((self.submit(context, arguments, nested).await?, None))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    type Result<T = ()> = std::result::Result<T, Box<dyn std::error::Error>>;
    fn contract(resource: &str) -> Result<RecoveryEffectContractV1> {
        use chio_security_types::recovery::*;
        Ok(RecoveryEffectContractV1 {
            schema: chio_kernel::recovery::RecoveryEffectContractSchema::V1,
            provider: RecordName::new("test-provider")?,
            account: RecordName::new("test-account")?,
            resource: ProtectedText::new(resource)?,
            observation_key: chio_core_types::Keypair::from_seed(&[150; 32]).public_key(),
            max_response_bytes: SafeInteger::new(65536)?,
        })
    }
    #[test]
    fn pinned_connector_request_keeps_credentials_and_native_correlation_out_of_input() -> Result {
        let connector = PinnedSupportIssueConnector::new(
            "issues".into(),
            "create".into(),
            contract("https://provider.example/issues")?,
            "submit-canary".into(),
            "lookup-canary".into(),
        )?;
        let wire = br#"{"body":"private-canary","title":"support"}"#.to_vec();
        let request =
            connector.submit_request("original-operation", "original-attempt", wire.clone())?;
        assert_eq!(request.method(), reqwest::Method::POST);
        assert_eq!(request.url().as_str(), "https://provider.example/issues");
        assert_eq!(request.headers()["idempotency-key"], "original-operation");
        assert_eq!(request.headers()["chio-attempt-id"], "original-attempt");
        assert_eq!(request.headers()["authorization"], "Bearer submit-canary");
        assert!(request.headers()["authorization"].is_sensitive());
        assert_eq!(
            request.body().and_then(reqwest::Body::as_bytes),
            Some(wire.as_slice())
        );
        assert!(!format!("{connector:?}").contains("canary"));
        assert!(decode_contract::<IssueCreated>(
            br#"{"issue_reference":"issue-1","outcome":"succeeded"}"#
        )
        .is_ok());
        for bytes in [
            br#"{"outcome":"unknown"}"#.as_slice(),
            br#"{"outcome":"failed_before_effect"}"#,
            br#"{"issue_reference":"issue-1","outcome":"succeeded","retry":true}"#,
            br#"{"issue_reference":null,"outcome":"succeeded"}"#,
        ] {
            assert!(decode_contract::<IssueCreated>(bytes).is_err());
        }
        Ok(())
    }
    #[tokio::test]
    async fn pinned_connector_refuses_unscoped_execution_and_unsafe_configuration() -> Result {
        for resource in [
            "http://provider.example/issues",
            "https://token@provider.example/issues",
            "https://provider.example/issues?auth=canary",
            "https://provider.example/issues#fragment",
            "https://provider.example/issues/",
            "https://PROVIDER.example/issues",
            "https://provider.example/base/../issues",
        ] {
            assert!(PinnedSupportIssueConnector::new(
                "issues".into(),
                "create".into(),
                contract(resource)?,
                "submit".into(),
                "lookup".into()
            )
            .is_err());
        }
        assert!(PinnedSupportIssueConnector::new(
            "issues".into(),
            "create".into(),
            contract("https://provider.example/issues")?,
            "header\r\ncanary".into(),
            "lookup".into()
        )
        .is_err());
        let connector = PinnedSupportIssueConnector::new(
            "issues".into(),
            "create".into(),
            contract("https://provider.example/issues")?,
            "submit".into(),
            "lookup".into(),
        )?;
        let error = connector
            .invoke(
                "create",
                serde_json::json!({"title":"canary","body":"canary"}),
                None,
            )
            .await
            .err()
            .ok_or("bare invoke accepted")?;
        assert!(!error.to_string().contains("canary"));
        Ok(())
    }
}
