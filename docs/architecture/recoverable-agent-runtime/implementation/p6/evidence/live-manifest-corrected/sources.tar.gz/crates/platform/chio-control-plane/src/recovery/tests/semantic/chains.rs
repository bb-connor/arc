use super::*;

pub(super) fn bundle(
    scope: RecoveryScopeV1,
    now: u64,
    mode: &str,
) -> TestResult<(SemanticFixture, Option<SemanticFixture>)> {
    let kind = match mode {
        "read" => SemanticOperationKindV1::SupportRead,
        "project" => SemanticOperationKindV1::FieldProjection,
        _ => SemanticOperationKindV1::IssueWrite,
    };
    let mut primary = native_profile(scope.clone(), now, kind)?;
    if mode == "alternate" {
        let mut body = primary.deployment.body().clone();
        let mut route = body.routes.as_slice()[0].clone();
        let mut alternate = route.destinations.as_slice()[0].clone();
        alternate.destination = SemanticDestinationId::new("tenant-alternate-queue")?;
        alternate.account = ProviderAccountId::new("alternate-account")?;
        alternate.resource = ProviderResourceId::new("alternate-queue")?;
        alternate.endpoint = ProtectedText::new("https://fixture.invalid/alternate")?;
        route.destinations =
            NonEmptyBoundedList::new(vec![route.destinations.as_slice()[0].clone(), alternate])?;
        body.routes = NonEmptyBoundedList::new(vec![route])?;
        primary.deployment = SignedSemanticDeploymentV1::sign(body, &primary.operator)?;
    }
    if !matches!(mode, "transform" | "historical" | "current" | "held") {
        return Ok((primary, None));
    }
    let source_kind = if mode == "transform" {
        SemanticOperationKindV1::FieldProjection
    } else {
        SemanticOperationKindV1::SupportRead
    };
    let mut source = native_profile(scope, now, source_kind)?;
    let mut source_body = source.package.body().clone();
    source_body.package = SemanticPackageId::new("source-package")?;
    let mut source_contract = source_body.operations.as_slice()[0].clone();
    source_contract.operation = SemanticOperationId::new("source-operation")?;
    source_body.operations = NonEmptyBoundedList::new(vec![source_contract.clone()])?;
    source.package = SignedSemanticPackageV1::sign(source_body, &source.publisher)?;
    let mut source_route = source.deployment.body().routes.as_slice()[0].clone();
    source_route.package = semantic_package_digest(source.package.body())?;
    source_route.operation = source_contract.operation.clone();
    source_route.server = ProtectedText::new("semantic-source")?;
    source.exposed.server = source_route.server.clone();
    let mut primary_body = primary.package.body().clone();
    let mut primary_contract = primary_body.operations.as_slice()[0].clone();
    if mode == "transform" {
        primary_contract.input_fields = BoundedList::new(vec![SemanticFieldId::new("title")?])?;
    } else {
        primary_contract.prerequisites =
            BoundedList::new(vec![SemanticPrerequisiteRequirementV1 {
                fact: SemanticFactId::new("resource-reviewed")?,
                kind: prerequisite_kind(mode),
                resource: ProviderResourceId::new("ticket")?,
            }])?;
    }
    primary_body.operations = NonEmptyBoundedList::new(vec![primary_contract])?;
    primary.package = SignedSemanticPackageV1::sign(primary_body, &primary.publisher)?;
    let mut primary_route = primary.deployment.body().routes.as_slice()[0].clone();
    primary_route.package = semantic_package_digest(primary.package.body())?;
    let mut deployment = primary.deployment.body().clone();
    deployment.packages =
        NonEmptyBoundedList::new(vec![primary_route.package, source_route.package])?;
    deployment.routes = NonEmptyBoundedList::new(vec![primary_route, source_route])?;
    primary.deployment = SignedSemanticDeploymentV1::sign(deployment, &primary.operator)?;
    source.deployment = primary.deployment.clone();
    for fixture in [&mut primary, &mut source] {
        fixture.plan.registry = semantic_registry_digest(fixture.deployment.body())?;
        fixture.invocation.action.registry = fixture.plan.registry;
    }
    source.invocation.action.operation = source_contract.operation;
    Ok((primary, Some(source)))
}
fn prerequisite_kind(mode: &str) -> SemanticPrerequisiteKindV1 {
    match mode {
        "current" => SemanticPrerequisiteKindV1::CurrentPredicate,
        "held" => SemanticPrerequisiteKindV1::HeldReservation,
        _ => SemanticPrerequisiteKindV1::HistoricalFact,
    }
}
pub(super) fn attach_endorsement(p: &mut SemanticFixture, evidence: &str) -> TestResult {
    let mut body = p.invocation.endorsements.as_slice()[0].body().clone();
    body.evidence = EvidenceRef::new(evidence)?;
    body.target = SemanticEndorsementTargetV1::ExactAction {
        action: semantic_action_digest(&p.invocation.action)?,
    };
    body.influence = p.invocation.action.influence;
    body.issued_at_unix_ms = p.invocation.action.issued_at_unix_ms;
    body.valid_until_unix_ms = p.invocation.action.valid_until_unix_ms;
    p.invocation.endorsements =
        BoundedList::new(vec![SignedScopedEndorsementV1::sign(body, &p.endorser)?])?;
    Ok(())
}
async fn chain(f: &RecoveryFixture, mode: &str, stale: bool) -> TestResult {
    let withheld_source = mode == "withheld-transform";
    let mode = if withheld_source { "transform" } else { mode };
    let scope = f.runtime.scope.clone();
    let (mut p, source) = bundle(scope.clone(), now_ms()?, mode)?;
    let mut source = source.ok_or("missing source fixture")?;
    pin_deployment(
        &mut p,
        Some(&mut source),
        &f.kernel.recovery_deployment(&scope)?,
    )?;
    let runtime = NativeSemanticRuntime::new(
        f.kernel.clone(),
        Arc::new(f.authority.admission_operation_store()),
        scope,
        f.authority.mutation_fence(),
    );
    let mut source_step = source.plan.steps.as_slice()[0].clone();
    source_step.step = StepId::new("source-a")?;
    source_step.operation = source.invocation.action.operation.clone();
    if withheld_source {
        source_step.output = SemanticOutputDispositionV1::Withhold;
        source.invocation.action.output = SemanticOutputDispositionV1::Withhold;
    }
    let mut primary_step = p.plan.steps.as_slice()[0].clone();
    primary_step.step = StepId::new("dependent-a")?;
    primary_step.dependencies = BoundedList::new(vec![source_step.step.clone()])?;
    if mode == "transform" {
        primary_step.inputs = NonEmptyBoundedList::new(vec![SemanticPlanInputV1::FutureOutput {
            step: source_step.step.clone(),
        }])?;
    }
    let mut selected_steps = vec![primary_step.clone(), source_step];
    if mode == "held" && !stale {
        primary_step.step = StepId::new("dependent-b")?;
        selected_steps.push(primary_step);
    }
    let plan = SemanticPlanV1 {
        steps: NonEmptyBoundedList::new(selected_steps)?,
        ..p.plan.clone()
    };
    let digest = runtime.accept_plan(&f.control, &plan)?;
    source.invocation.action.plan = digest;
    source.invocation.action.step = StepId::new("source-a")?;
    let mut source_request = f.process.tool_request(
        "root",
        "source-a",
        "semantic-source",
        "remedy",
        serde_json::json!({}),
    )?;
    source.invocation.action =
        runtime.frame_action(&source_request, source.invocation.action, &source.payload)?;
    f.authority
        .admission_operation_store()
        .install_semantic_audience(&source.invocation.audience)?;
    source_request.arguments = serde_json::to_value(&source.invocation)?;
    let response = runtime
        .execute_step(&f.process, "root", "source-a", &source_request)
        .await?;
    assert_eq!(response.verdict, Verdict::Allow);
    let operation = response
        .receipt
        .metadata
        .as_ref()
        .and_then(|metadata| metadata.get("admission_operation"))
        .and_then(|metadata| metadata.get("operation_id"))
        .and_then(Value::as_str)
        .ok_or("missing source operation")?
        .to_owned();
    let fresh = now_ms()?;
    p.invocation.action.issued_at_unix_ms = SafeInteger::new(fresh)?;
    p.invocation.action.valid_until_unix_ms = SafeInteger::new(fresh + 50_000)?;
    let mut acl = p.invocation.audience.body().clone();
    acl.observed_at_unix_ms = SafeInteger::new(fresh)?;
    acl.valid_until_unix_ms = p.invocation.action.valid_until_unix_ms;
    p.invocation.audience = SignedSemanticAudienceV1::sign(acl, &p.resolver)?;
    f.authority
        .admission_operation_store()
        .install_semantic_audience(&p.invocation.audience)?;
    p.invocation.action.plan = digest;
    p.invocation.action.step = StepId::new("dependent-a")?;
    let mut request = f.process.tool_request(
        "root",
        "dependent-a",
        "semantic-a",
        "remedy",
        serde_json::json!({}),
    )?;
    if mode == "transform" {
        let Some(chio_kernel::ToolCallOutput::Value(output)) = response.output else {
            return Err("missing projection output".into());
        };
        p.payload = if withheld_source {
            // Even correct private bytes known to a trusted fixture cannot
            // turn a withheld producer into a raw future-output release.
            chio_semantic_contracts::project_semantic_fields(
                &source.payload,
                source.package.body().operations.as_slice()[0]
                    .projection_fields
                    .as_slice(),
                &mut chio_semantic_contracts::VerificationBudget::new(4096)?,
            )?
        } else {
            serde_json::from_value(output)?
        };
        let content = semantic_content_digest(&p.payload)?;
        p.invocation.action.inputs = NonEmptyBoundedList::new(vec![SemanticInputVersionV1 {
            resource: ProviderResourceId::new("issue-queue")?,
            version: ArtifactVersionId::from_bytes(*content.as_bytes()),
            content,
        }])?;
        p.invocation.action.influence = source.invocation.action.influence;
        let body = SemanticTransformationV1 {
            domain_version: VersionV1,
            scope: p.plan.scope.clone(),
            producer: OperationId::new(&operation)?,
            producer_action: semantic_action_digest(&source.invocation.action)?,
            inputs: source.invocation.action.inputs.clone(),
            implementation: source.package.body().operations.as_slice()[0].implementation,
            configuration: semantic_content_digest(
                &source.package.body().operations.as_slice()[0].projection_fields,
            )?,
            output_schema: source.package.body().operations.as_slice()[0].output_schema,
            output: content,
            output_label: restricted_label(),
            influence: source.invocation.action.influence,
            destination: p.invocation.action.destination.clone(),
            purpose: ProtectedText::new("customer-support")?,
            disposition: p.invocation.action.output,
            issued_at_unix_ms: SafeInteger::new(now_ms()?)?,
            valid_until_unix_ms: p.invocation.action.valid_until_unix_ms,
        };
        p.invocation.transformation =
            Some(SignedSemanticTransformationV1::sign(body, &p.transformer)?);
    }
    p.invocation.action = runtime.frame_action(&request, p.invocation.action, &p.payload)?;
    p.invocation.payload = p.payload.clone();
    attach_endorsement(&mut p, "dependent-endorsement")?;
    if mode != "transform" {
        let input = &source.invocation.action.inputs.as_slice()[0];
        let body = SemanticPrerequisiteV1 {
            domain_version: VersionV1,
            evidence: EvidenceRef::new("dependent-prerequisite")?,
            scope: p.plan.scope.clone(),
            action: semantic_action_digest(&p.invocation.action)?,
            fact: SemanticFactId::new("resource-reviewed")?,
            kind: prerequisite_kind(mode),
            resource: input.resource.clone(),
            version: input.version,
            material: input.content,
            producer: OperationId::new(&operation)?,
            lease: if mode == "held" {
                Some(SemanticLeaseId::new("held-lease-a")?)
            } else {
                None
            },
            purpose: ProtectedText::new("customer-support")?,
            issued_at_unix_ms: SafeInteger::new(now_ms()?)?,
            valid_until_unix_ms: p.invocation.action.valid_until_unix_ms,
        };
        let proof = SignedSemanticPrerequisiteV1::sign(body, &p.prerequisite)?;
        if mode != "historical" && !(stale && mode == "held") {
            f.authority
                .admission_operation_store()
                .install_semantic_prerequisite(&proof)?;
        }
        if stale && mode == "current" {
            f.authority
                .admission_operation_store()
                .revoke_semantic_prerequisite(
                    &p.plan.scope,
                    &proof.body().fact,
                    &proof.body().resource,
                )?;
            // Replaying the original signature cannot resurrect revoked state.
            f.authority
                .admission_operation_store()
                .install_semantic_prerequisite(&proof)?;
        }
        p.invocation.prerequisites = BoundedList::new(vec![proof])?;
    }
    if stale && mode == "transform" && !withheld_source {
        let mut body = p
            .invocation
            .transformation
            .as_ref()
            .ok_or("missing transform")?
            .body()
            .clone();
        body.implementation = CanonicalPayloadDigest::from_bytes([99; 32]);
        p.invocation.transformation =
            Some(SignedSemanticTransformationV1::sign(body, &p.transformer)?);
    }
    request.arguments = serde_json::to_value(&p.invocation)?;
    let result = runtime
        .execute_step(&f.process, "root", "dependent-a", &request)
        .await;
    if stale {
        assert!(
            result.is_err()
                || result
                    .as_ref()
                    .is_ok_and(|response| response.verdict == Verdict::Deny)
        );
        assert_eq!(
            f.effects.load(Ordering::SeqCst),
            if mode == "transform" { 0 } else { 1 }
        );
    } else {
        let result = result?;
        assert_eq!(
            result.verdict,
            Verdict::Allow,
            "mode={mode} reason={:?}",
            result.reason
        );
        assert_eq!(
            f.effects.load(Ordering::SeqCst),
            if mode == "transform" { 1 } else { 2 }
        );
        if mode == "held" {
            // A newly signed action and fact cannot transfer a spent lease to
            // a sibling step or reopen the first native effect.
            let fresh = now_ms()?;
            p.invocation.action.step = StepId::new("dependent-b")?;
            p.invocation.action.issued_at_unix_ms = SafeInteger::new(fresh)?;
            p.invocation.action.valid_until_unix_ms = SafeInteger::new(fresh + 50_000)?;
            let mut acl = p.invocation.audience.body().clone();
            acl.observed_at_unix_ms = p.invocation.action.issued_at_unix_ms;
            acl.valid_until_unix_ms = p.invocation.action.valid_until_unix_ms;
            p.invocation.audience = SignedSemanticAudienceV1::sign(acl, &p.resolver)?;
            f.authority
                .admission_operation_store()
                .install_semantic_audience(&p.invocation.audience)?;
            let mut sibling = f.process.tool_request(
                "root",
                "dependent-b",
                "semantic-a",
                "remedy",
                serde_json::json!({}),
            )?;
            p.invocation.action =
                runtime.frame_action(&sibling, p.invocation.action, &p.payload)?;
            attach_endorsement(&mut p, "sibling-endorsement")?;
            let mut proof = p.invocation.prerequisites.as_slice()[0].body().clone();
            proof.evidence = EvidenceRef::new("sibling-prerequisite")?;
            proof.action = semantic_action_digest(&p.invocation.action)?;
            proof.issued_at_unix_ms = p.invocation.action.issued_at_unix_ms;
            proof.valid_until_unix_ms = p.invocation.action.valid_until_unix_ms;
            let proof = SignedSemanticPrerequisiteV1::sign(proof, &p.prerequisite)?;
            f.authority
                .admission_operation_store()
                .install_semantic_prerequisite(&proof)?;
            p.invocation.prerequisites = BoundedList::new(vec![proof])?;
            sibling.arguments = serde_json::to_value(&p.invocation)?;
            let refused = runtime
                .execute_step(&f.process, "root", "dependent-b", &sibling)
                .await;
            assert!(refused.is_err() || refused.as_ref().is_ok_and(|r| r.verdict == Verdict::Deny));
            assert_eq!(f.effects.load(Ordering::SeqCst), 2);
        }
    }
    Ok(())
}
#[tokio::test]
async fn p3_native_derived_bytes_have_a_separate_producer_and_fresh_dependent_authority(
) -> TestResult {
    for stale in [false, true] {
        let f = native_fixture("transform")?;
        chain(&f, "transform", stale).await?;
    }
    let f = native_fixture("transform")?;
    chain(&f, "withheld-transform", true).await?;
    Ok(())
}
#[tokio::test]
async fn p3_native_historical_current_and_held_prerequisites_are_distinct() -> TestResult {
    for mode in ["historical", "current", "held"] {
        let f = native_fixture(mode)?;
        chain(&f, mode, false).await?;
        if mode != "historical" {
            let f = native_fixture(mode)?;
            chain(&f, mode, true).await?;
        }
    }
    Ok(())
}
