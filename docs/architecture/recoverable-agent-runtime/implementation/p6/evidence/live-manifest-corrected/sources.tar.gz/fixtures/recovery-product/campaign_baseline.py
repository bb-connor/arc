"""Competent explicit application supervisor over the same native authorities.

Stable Rust-owned IDs, provider idempotency and authoritative outcome recovery
are supplied by the same P1/P4 native owner in both arms. This deliberately
compares integration mechanisms; it cannot establish a security advantage over
an independent runtime. No separate retry or authority engine is implemented.
"""
from threading import Lock
import httpx
from chio_sdk.recovery import RecoveryClient
from chio_sdk.recovery_host import RecoveryHostOutcome


class SupervisorSession:
    def __init__(self, endpoint, capability, command, *, transport=None):
        self._endpoint = endpoint
        self._capability = capability
        self._command = command
        self._transport = transport
        self._lock = Lock()
        self._attempts = 0

    def __repr__(self): return "SupervisorSession([redacted])"

    @property
    def attempts(self):
        with self._lock:
            return self._attempts

    async def execute(self, choice):
        with self._lock:
            if self._attempts >= 8:
                return RecoveryHostOutcome("budget_exhausted")
            self._attempts += 1
        if choice != "resume":
            return RecoveryHostOutcome("invalid_choice")
        client = None
        outcome = RecoveryHostOutcome("refused")
        try:
            client = RecoveryClient(self._endpoint, transport=self._transport, timeout_seconds=120)
            response = await client.execute(self._capability, self._command)
            status = response.status.model_dump(mode="json", by_alias=True)
            outcome = RecoveryHostOutcome("complete" if status["effect"]["kind"] == "complete" else "pending",
                                          status["command_id"], status["workflow_id"])
        except (RuntimeError, ValueError, httpx.HTTPError):
            outcome = RecoveryHostOutcome("refused")
        finally:
            if client is not None:
                try:
                    await client.aclose()
                except (RuntimeError, ValueError, httpx.HTTPError):
                    outcome = RecoveryHostOutcome("refused")
        return outcome
