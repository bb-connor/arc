//! Actual CLI transport preserves opaque native setup proofs and never follows redirects.
use chio_core_types::{
    canonical_json_bytes,
    capability::{
        scope::{ChioScope, Operation, ToolGrant},
        token::{CapabilityToken, CapabilityTokenBody},
    },
    recovery::*,
    Keypair,
};
use std::{
    io::{Read, Write},
    net::TcpListener,
    process::Command,
    thread,
};

type Result<T = ()> = std::result::Result<T, Box<dyn std::error::Error>>;

fn capability() -> Result<Vec<u8>> {
    let key = Keypair::from_seed(&[31; 32]);
    Ok(canonical_json_bytes(&CapabilityToken::sign(
        CapabilityTokenBody {
            id: "setup-transport-capability".into(),
            issuer: key.public_key(),
            subject: key.public_key(),
            scope: ChioScope {
                grants: vec![ToolGrant {
                    server_id: "chio.recovery".into(),
                    tool_name: "inspect".into(),
                    operations: vec![Operation::Invoke],
                    constraints: vec![],
                    max_invocations: None,
                    max_cost_per_invocation: None,
                    max_total_cost: None,
                    dpop_required: None,
                }],
                ..Default::default()
            },
            issued_at: 1,
            expires_at: 2,
            delegation_chain: vec![],
            aggregate_invocation_budget: None,
        },
        &key,
    )?)?)
}
fn probe() -> Result<SignedRecoverySetupProbeV1> {
    let vectors: serde_json::Value = serde_json::from_str(include_str!(
        "../../../../spec/vectors/recovery/v1/p6-contracts.json"
    ))?;
    let body = vectors["cases"]
        .as_array()
        .ok_or("cases")?
        .iter()
        .find(|case| case["name"] == "recovery-setup-probe.schema.json")
        .ok_or("probe vector")?["body"]
        .clone();
    Ok(SignedRecoverySetupProbeV1::sign(
        serde_json::from_value(body)?,
        &Keypair::from_seed(&[32; 32]),
    )?)
}
fn invoke(
    action: &str,
    status: &str,
    response: Vec<u8>,
) -> Result<(std::process::Output, serde_json::Value)> {
    let directory = tempfile::tempdir()?;
    let cap = capability()?;
    let cap_file = directory.path().join("capability.json");
    std::fs::write(&cap_file, &cap)?;
    let proof = canonical_json_bytes(&probe()?)?;
    let proof_file = directory.path().join("probe.json");
    std::fs::write(&proof_file, &proof)?;
    let listener = TcpListener::bind("127.0.0.1:0")?;
    let endpoint = format!("http://{}", listener.local_addr()?);
    let status = status.to_owned();
    let receiver = thread::spawn(move || -> std::io::Result<Vec<u8>> {
        let (mut stream, _) = listener.accept()?;
        stream.set_read_timeout(Some(std::time::Duration::from_secs(10)))?;
        let mut wire = Vec::new();
        loop {
            let mut part = [0; 4096];
            let length = stream.read(&mut part)?;
            if length == 0 {
                return Err(std::io::Error::other("truncated request"));
            }
            wire.extend_from_slice(&part[..length]);
            if wire.len() > 65536 {
                return Err(std::io::Error::other("request bound"));
            }
            if let Some(header_end) = wire.windows(4).position(|p| p == b"\r\n\r\n") {
                let headers =
                    std::str::from_utf8(&wire[..header_end]).map_err(std::io::Error::other)?;
                let length: usize = headers
                    .lines()
                    .find_map(|line| {
                        line.to_ascii_lowercase()
                            .strip_prefix("content-length: ")
                            .map(str::to_owned)
                    })
                    .ok_or_else(|| std::io::Error::other("content length"))?
                    .parse()
                    .map_err(std::io::Error::other)?;
                if wire.len() >= header_end + 4 + length {
                    break;
                }
            }
        }
        write!(stream,"HTTP/1.1 {status}\r\nContent-Type: application/json\r\nContent-Length: {}\r\nLocation: http://127.0.0.1:1/secret\r\nConnection: close\r\n\r\n",response.len())?;
        stream.write_all(&response)?;
        Ok(wire)
    });
    let mut child = Command::new(env!("CARGO_BIN_EXE_chio"));
    child
        .args([
            "recovery",
            "setup",
            action,
            "--endpoint",
            &endpoint,
            "--capability",
        ])
        .arg(&cap_file);
    if action == "probe" {
        child.args(["--workflow-id", probe()?.body().benign_workflow.as_str()]);
    } else {
        child.arg("--probe").arg(&proof_file);
    }
    let output = child.output()?;
    let wire = receiver.join().map_err(|_| "transport thread")??;
    let start = wire
        .windows(4)
        .position(|p| p == b"\r\n\r\n")
        .ok_or("headers")?
        + 4;
    let request: serde_json::Value = serde_json::from_slice(&wire[start..])?;
    assert_eq!(
        request["capability"]
            .as_str()
            .ok_or("capability")?
            .as_bytes(),
        cap
    );
    if action == "qualify" {
        assert_eq!(request["probe"].as_str().ok_or("proof")?.as_bytes(), proof);
    }
    assert!(wire.starts_with(format!("POST /v1/recovery/setup/{action} ").as_bytes()));
    Ok((output, request))
}

#[test]
fn p6_setup_cli_probe_preserves_native_proof_and_requests_operator_restart() -> Result {
    let (output, _) = invoke("probe", "200 OK", canonical_json_bytes(&probe()?)?)?;
    assert!(
        output.status.success(),
        "{}",
        String::from_utf8_lossy(&output.stderr)
    );
    // The operator must be able to feed these exact bytes to qualify.
    let signed: SignedRecoverySetupProbeV1 = decode_contract(&output.stdout)?;
    assert_eq!(signed, probe()?);
    assert!(String::from_utf8_lossy(&output.stderr).contains("restart"));
    Ok(())
}
#[test]
fn p6_setup_cli_qualify_refuses_wrong_shape_and_redirect_without_retries() -> Result {
    for (status, bytes) in [
        ("200 OK", b"{}".to_vec()),
        ("307 Temporary Redirect", b"{}".to_vec()),
    ] {
        let (output, _) = invoke("qualify", status, bytes)?;
        assert!(!output.status.success());
        assert!(!String::from_utf8_lossy(&output.stderr).contains("secret"));
    }
    Ok(())
}

#[test]
fn p6_setup_cli_reports_only_known_bounded_refusal_categories() -> Result {
    for category in ["recovery.restart_required", "recovery.uncovered_mediation"] {
        let (output, _) = invoke("qualify", "409 Conflict", category.as_bytes().to_vec())?;
        assert!(!output.status.success());
        assert!(String::from_utf8_lossy(&output.stderr).contains(category));
    }
    let (output, _) = invoke(
        "qualify",
        "409 Conflict",
        b"private-error-canary: provider credentials".to_vec(),
    )?;
    assert!(!output.status.success());
    assert!(!String::from_utf8_lossy(&output.stderr).contains("private-error-canary"));
    Ok(())
}
