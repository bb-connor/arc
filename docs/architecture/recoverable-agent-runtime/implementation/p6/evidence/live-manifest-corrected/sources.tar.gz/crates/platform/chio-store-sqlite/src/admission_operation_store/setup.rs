//! Protected readiness is native custody, never an incoming readiness claim.
use super::recovery::storage as protected;
use super::*;
use chio_core::recovery::{SignedRecoverySetupProbeV1, SignedRecoverySetupReportV1};
use chio_core::PublicKey;
use chio_kernel::{recovery::*, SecurityInvocationContext, ToolCallRequest};
use chio_security_types::recovery::*;

#[derive(Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct Selection {
    probe: RecoverySetupProbeV1,
    creation: CanonicalPayloadDigest,
    command: RecoveryCommandV1,
    operator: PublicKey,
    receipt_key: PublicKey,
    previous_fence: SourceDigest,
    evidence: Option<Evidence>,
    report: Option<SignedRecoverySetupReportV1>,
}
#[derive(Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct Evidence {
    probe: SignedRecoverySetupProbeV1,
    operation: OperationId,
    benign_receipt: SourceDigest,
    denied_command: CommandDigest,
}
/// Trusted host preparation; signatures are produced outside native transactions.
#[derive(Clone)]
pub struct NativeSetupPreparationV1 {
    pub probe: RecoverySetupProbeV1,
    pub command: RecoveryCommandV1,
    pub previous_serving_fence: SourceDigest,
    pub signed_probe: Option<SignedRecoverySetupProbeV1>,
    pub report: Option<SignedRecoverySetupReportV1>,
}
/// Exact signed observations from the real kernel self-test, not a readiness claim.
pub struct NativeSetupProbeEvidenceV1<'a> {
    pub probe: &'a SignedRecoverySetupProbeV1,
    pub benign: &'a ChioReceipt,
    pub denied_request: &'a ToolCallRequest,
    pub denied: &'a ChioReceipt,
}
impl core::fmt::Debug for NativeSetupProbeEvidenceV1<'_> {
    fn fmt(&self, f: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        f.write_str("NativeSetupProbeEvidenceV1([redacted])")
    }
}
impl core::fmt::Debug for NativeSetupPreparationV1 {
    fn fmt(&self, f: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        f.write_str("NativeSetupPreparationV1([redacted])")
    }
}
fn refused(_: impl core::fmt::Display) -> AdmissionOperationStoreError {
    invariant("protected recovery setup refused")
}
fn digest<T: Serialize>(domain: &str, value: &T) -> Result<[u8; 32], AdmissionOperationStoreError> {
    recovery_digest(domain, value).map_err(refused)
}
fn fence_digest(fence: &StoreMutationFence) -> Result<SourceDigest, AdmissionOperationStoreError> {
    digest("chio.recovery.serving-fence.v1", fence).map(SourceDigest::from_bytes)
}
fn key(scope: &RecoveryScopeV1) -> Result<String, AdmissionOperationStoreError> {
    Ok(format!(
        "protected-setup:{}",
        sha256_hex(&protected::encode(&(
            &scope.authority_domain,
            &scope.tenant_id,
        ))?)
    ))
}
fn load(
    tx: &Connection,
    scope: &RecoveryScopeV1,
) -> Result<Option<Selection>, AdmissionOperationStoreError> {
    protected::raw(tx, &key(scope)?)?
        .map(|row| protected::decode(&row.payload))
        .transpose()
}
fn save(
    tx: &Transaction<'_>,
    owner: &SqliteServingOwner,
    value: &Selection,
) -> Result<(), AdmissionOperationStoreError> {
    protected::save(
        tx,
        owner,
        &key(&value.probe.scope)?,
        &protected::scope_key(&value.probe.scope)?,
        "command",
        &protected::encode(value)?,
        None,
    )
}
fn creation(
    record: &RecoveryWorkflowRecordV1,
) -> Result<CanonicalPayloadDigest, AdmissionOperationStoreError> {
    digest("chio.recovery.setup.creation.v1", &record.creation_seed)
        .map(CanonicalPayloadDigest::from_bytes)
}
fn profile(
    tx: &Connection,
    scope: &RecoveryScopeV1,
    receipt_key: &PublicKey,
) -> Result<(SourceDigest, DeploymentDigest, SourceDigest, PublicKey), AdmissionOperationStoreError>
{
    let recovery = protected::deployment_tx(tx, scope)?;
    let semantic = super::semantic::installation(tx, scope)?;
    let knowledge = super::knowledge::installation(tx, scope)?;
    if semantic.native_authority != recovery.native_authority
        || knowledge.native_authority != recovery.native_authority
        || semantic.security_context != recovery.security_context
        || knowledge.producer_context != recovery.security_context
    {
        return Err(refused("mediator closure"));
    }
    Ok((
        SourceDigest::from_bytes(digest(
            "chio.recovery.setup.native-authority.v1",
            &recovery.native_authority,
        )?),
        semantic.policy_basis()?.deployment,
        SourceDigest::from_bytes(digest(
            "chio.recovery.setup.source-profile.v1",
            &(&recovery, &semantic, &knowledge, receipt_key),
        )?),
        semantic.operator_root,
    ))
}
fn current(tx: &Connection, value: &Selection) -> Result<(), AdmissionOperationStoreError> {
    let (authority, deployment, source, root) =
        profile(tx, &value.probe.scope, &value.receipt_key)?;
    if authority != value.probe.native_authority
        || deployment != value.probe.deployment
        || source != value.probe.source_profile
        || root != value.operator
    {
        return Err(refused("changed setup profile"));
    }
    Ok(())
}
fn authorized(
    tx: &Transaction<'_>,
    actor: &AuthenticatedRecoveryActor,
    profile: &RecoveryDeploymentV1,
    value: &Selection,
) -> Result<(), AdmissionOperationStoreError> {
    if actor.permission() != RecoveryPermission::Inspect || actor.scope() != &value.probe.scope {
        return Err(refused("setup actor"));
    }
    let record = protected::workflow_tx(tx, actor.scope(), &value.probe.benign_workflow)?;
    super::recovery::verify_status(actor, profile, &record)?;
    current(tx, value)
}
fn completed(
    tx: &Transaction<'_>,
    value: &Selection,
    receipt: &ChioReceipt,
) -> Result<OperationId, AdmissionOperationStoreError> {
    let record = protected::workflow_tx(tx, &value.probe.scope, &value.probe.benign_workflow)?;
    let id = record
        .native_link
        .clone()
        .ok_or_else(|| refused("benign operation absent"))?;
    let operation =
        load_by_operation_id_tx(tx, &AdmissionOperationId::from_persisted(id.as_str())?)?
            .ok_or_else(|| refused("benign operation absent"))?;
    if creation(&record)? != value.creation
        || !record.captured
        || operation.operation.state() != AdmissionOperationState::Completed
        || receipt.kernel_key != value.receipt_key
        || !receipt.is_allowed()
        || !matches!(operation.operation.terminal_replay(), Some(AdmissionTerminalReplay::Receipt { receipt_id, .. }) if receipt_id.as_str() == receipt.id)
    {
        return Err(refused("benign completion custody"));
    }
    Ok(id)
}
fn ready(
    tx: &Connection,
    value: &Selection,
    fence: &StoreMutationFence,
) -> Result<(), AdmissionOperationStoreError> {
    current(tx, value)?;
    let report = value
        .report
        .as_ref()
        .ok_or_else(|| refused("setup required"))?;
    if report.body().probe != value.probe
        || report.body().current_serving_fence != fence_digest(fence)?
    {
        return Err(refused("setup requires fresh writer qualification"));
    }
    Ok(())
}
mod gate;
mod service;
pub(super) use gate::{require_capture, require_command, require_ready};

fn preparation(value: &Selection) -> NativeSetupPreparationV1 {
    NativeSetupPreparationV1 {
        probe: value.probe.clone(),
        command: value.command.clone(),
        previous_serving_fence: value.previous_fence,
        signed_probe: value
            .evidence
            .as_ref()
            .map(|evidence| evidence.probe.clone()),
        report: value.report.clone(),
    }
}
