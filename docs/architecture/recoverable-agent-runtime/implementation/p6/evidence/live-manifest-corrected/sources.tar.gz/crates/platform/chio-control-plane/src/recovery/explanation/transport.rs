//! Independent bounded capacity; explanation work cannot occupy effect or
//! settlement slots. The response is always the separately signed safe view.
use super::RecoveryExplanationService;
use crate::recovery::{RecoveryRuntime, RecoveryRuntimeError};
use axum::{
    body::Bytes,
    extract::{DefaultBodyLimit, State},
    routing::post,
    Router,
};
use chio_core_types::recovery::{
    decode_contract, decode_recovery_capability, SignedRecoveryExplanationViewV1,
};
use chio_security_types::recovery::{ProtectedText, WorkflowId, MAX_RECOVERY_WIRE_BYTES};
use serde::{Deserialize, Serialize};
use std::sync::Arc;
use tokio::sync::Semaphore;

#[derive(Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct ExplanationRequest {
    capability: ProtectedText<32768>,
    workflow_id: WorkflowId,
}
#[derive(Clone)]
struct ExplanationHost {
    runtime: Arc<RecoveryRuntime>,
    service: Arc<RecoveryExplanationService>,
    capacity: Arc<Semaphore>,
}

pub fn recovery_explanation_router(
    runtime: Arc<RecoveryRuntime>,
    service: Arc<RecoveryExplanationService>,
) -> Router {
    Router::new()
        .route("/v1/recovery/explain", post(explain))
        .layer(DefaultBodyLimit::max(MAX_RECOVERY_WIRE_BYTES))
        .with_state(ExplanationHost {
            runtime,
            service,
            capacity: Arc::new(Semaphore::new(2)),
        })
}
async fn explain(State(host): State<ExplanationHost>, bytes: Bytes) -> axum::response::Response {
    let Ok(permit) = host.capacity.try_acquire_owned() else {
        return crate::recovery::transport::response::<SignedRecoveryExplanationViewV1>(Err(
            RecoveryRuntimeError::Unavailable,
        ));
    };
    let result = tokio::task::spawn_blocking(move || {
        let _permit = permit;
        let request: ExplanationRequest =
            decode_contract(&bytes).map_err(|_| RecoveryRuntimeError::InvalidCommand)?;
        let capability = decode_recovery_capability(request.capability.as_str().as_bytes())
            .map_err(|_| RecoveryRuntimeError::InvalidCommand)?;
        host.runtime
            .explain(&capability, &request.workflow_id, &host.service)
    })
    .await
    .unwrap_or(Err(RecoveryRuntimeError::Unavailable));
    crate::recovery::transport::response(result)
}
