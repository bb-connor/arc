use super::{
    BasisDigest, DeploymentDigest, NativeAdmissionDigest, NonEmptyBoundedList, PolicyDigest,
    ProcessRequestDigest, RecoveryObservationV1, SafeInteger, SourceDigest, VersionV1,
};
use serde::{Deserialize, Serialize};

#[derive(Clone, Copy, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub enum RecoveryTrajectorySchema {
    #[serde(rename = "chio.recovery.trajectory.v1")]
    V1,
}

/// Required assertions prevent a decision-only fixture from qualifying safety.
#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct RecoveryAssertionsV1 {
    pub effect_count: SafeInteger,
    pub consumed_authority: SafeInteger,
    pub remaining_budget: SafeInteger,
    pub knowledge_digest: BasisDigest,
    pub native_admission_digest: NativeAdmissionDigest,
    pub process_request_digest: ProcessRequestDigest,
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct RecoveryTrajectoryFrameV1 {
    pub observation: RecoveryObservationV1,
    pub expected: RecoveryAssertionsV1,
}

/// P0 establishes the closed fixture contract. Native cutpoint execution and
/// provider truth are separate P1 harness obligations, never wire assertions.
#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct RecoveryTrajectoryV1 {
    pub schema: RecoveryTrajectorySchema,
    pub version: VersionV1,
    pub source_digest: SourceDigest,
    pub contract_digest: DeploymentDigest,
    pub policy_digest: PolicyDigest,
    pub profile_digest: DeploymentDigest,
    pub deterministic_time: SafeInteger,
    pub frames: NonEmptyBoundedList<RecoveryTrajectoryFrameV1, 32>,
}
