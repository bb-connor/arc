use super::*;
impl NativeKnowledgeRuntime {
    pub fn checkpoint(
        &self,
        capability: &CapabilityToken,
        id: &CheckpointId,
        expected_revision: u64,
        artifacts: &[ArtifactVersionRefV1],
        models: &[ModelContextV1],
    ) -> Result<LabeledCheckpointV1, KernelError> {
        let actor = self.actor(capability, RecoveryPermission::KnowledgeWrite)?;
        self.current(&actor)?;
        self.store
            .save_labeled_checkpoint(
                &actor,
                chio_store_sqlite::admission_operation_store::NativeCheckpointUpdate {
                    checkpoint: id,
                    expected_revision,
                    artifacts,
                    model_contexts: models,
                },
                &self.fence,
                now()?,
            )
            .map_err(unavailable)
    }
}
impl NativeKnowledgeRuntime {
    /// Restoration emits a bounded protected checkpoint envelope and exact bytes into
    /// a host-selected sink only after the native monotone observation commits.
    pub fn restore_into(
        &self,
        capability: &CapabilityToken,
        id: &CheckpointId,
        revision: u64,
        request: &RequestId,
        sink: &dyn ArtifactReleaseSink,
    ) -> Result<ArtifactReleaseIntentV1, KernelError> {
        let actor = self.actor(capability, RecoveryPermission::KnowledgeRead)?;
        let profile = self.current(&actor)?;
        let checkpoint = self
            .store
            .read_labeled_checkpoint(&actor, id, revision, &self.fence, now()?)
            .map_err(unavailable)?;
        let selection = profile
            .recipients
            .as_slice()
            .iter()
            .find(|entry| &entry.recipient == sink.recipient())
            .ok_or_else(|| unavailable("restore recipient"))?;
        self.broker
            .validate_process(&selection.recipient.scope.process_id, &selection.context)?;
        let mut body = Zeroizing::new(Vec::new());
        let envelope = chio_core_types::canonical_json_bytes(&checkpoint).map_err(unavailable)?;
        if envelope.len() > 64 * 1024 {
            return Err(unavailable("restore envelope bound"));
        }
        body.extend_from_slice(
            &u32::try_from(envelope.len())
                .map_err(unavailable)?
                .to_be_bytes(),
        );
        body.extend_from_slice(&envelope);
        let mut material = checkpoint.artifacts.as_slice().to_vec();
        for model in checkpoint.model_contexts.as_slice() {
            for reference in model.side_files.as_slice() {
                if !material.contains(reference) {
                    material.push(reference.clone());
                }
            }
        }
        let mut reads = Vec::new();
        for reference in &material {
            let handle = self.handle(capability, reference, &selection.recipient.recipient)?;
            let prepared = self.prepare_read(capability, &handle)?;
            let next = body
                .len()
                .checked_add(4)
                .and_then(|size| size.checked_add(prepared.bytes.len()))
                .ok_or_else(|| unavailable("restore byte overflow"))?;
            if next > MAX_ARTIFACT_BYTES + 64 * 1024 {
                return Err(unavailable("restore byte bound"));
            }
            body.extend_from_slice(
                &u32::try_from(prepared.bytes.len())
                    .map_err(unavailable)?
                    .to_be_bytes(),
            );
            body.extend_from_slice(&prepared.bytes);
            reads.push(prepared);
        }
        self.current(&actor)?;
        self.broker
            .validate_process(&selection.recipient.scope.process_id, &selection.context)?;
        for prepared in &reads {
            let exact = Zeroizing::new(
                self.broker.read_private(
                    prepared
                        .record
                        .seal
                        .as_ref()
                        .ok_or_else(|| unavailable("restore seal"))?,
                )?,
            );
            if exact.as_slice() != prepared.bytes.as_slice() {
                return Err(unavailable("restore object changed"));
            }
        }
        let intent = self
            .store
            .admit_checkpoint_restore(
                &actor,
                &checkpoint,
                &selection.recipient.recipient,
                request,
                &self.fence,
                now()?,
            )
            .map_err(unavailable)?;
        self.cutpoint(KnowledgeCutpoint::ReleaseCommitted)?;
        self.cutpoint(KnowledgeCutpoint::BeforeDelivery)?;
        sink.deliver(&intent, &body).map_err(unavailable)?;
        Ok(intent)
    }
}
