//! Return admission is an independent native release, never a schema-only permit.
use super::*;

fn metadata(record: &BoundaryRecord) -> Result<&ArtifactVersionV1, AdmissionOperationStoreError> {
    record
        .return_metadata
        .as_ref()
        .ok_or_else(|| refused("return metadata"))
}
fn expected_evidence(
    record: &BoundaryRecord,
    issued: SafeInteger,
    expires: SafeInteger,
    evidence: EvidenceRef,
) -> Result<ConfinedReturnEvidenceV1, AdmissionOperationStoreError> {
    let m = metadata(record)?;
    let b = &record.reservation.boundary;
    Ok(ConfinedReturnEvidenceV1 {
        domain_version: VersionV1,
        evidence,
        boundary: isolation_boundary_digest(b).map_err(refused)?,
        launch: record.launch.ok_or_else(|| refused("launch"))?,
        artifact: artifact_version_reference(m).map_err(refused)?,
        content: m.content,
        size_bytes: m.size_bytes,
        source: m.label.clone(),
        influence: m.influence.clone(),
        parent: b.parent.clone(),
        contract: b.return_contract,
        implementation: record.installation.contract.implementation,
        observation: b.observation.clone(),
        target: record.installation.contract.target.clone(),
        policy: b.policy,
        issued_at_unix_ms: issued,
        expires_at_unix_ms: expires,
    })
}
fn check_evidence(
    record: &BoundaryRecord,
    body: &ConfinedReturnEvidenceV1,
    now: u64,
) -> Result<(), AdmissionOperationStoreError> {
    body.validate().map_err(refused)?;
    if *body
        != expected_evidence(
            record,
            body.issued_at_unix_ms,
            body.expires_at_unix_ms,
            body.evidence.clone(),
        )?
        || now < body.issued_at_unix_ms.get()
        || now >= body.expires_at_unix_ms.get()
    {
        return Err(refused("return authority binding"));
    }
    Ok(())
}
fn spend(
    tx: &Transaction<'_>,
    owner: &SqliteServingOwner,
    scope: &RecoveryScopeV1,
    role: &str,
    root: &PublicKey,
    body: &ConfinedReturnEvidenceV1,
) -> Result<(), AdmissionOperationStoreError> {
    let key = format!(
        "confined-evidence:{role}:{}:{}",
        root.to_hex(),
        body.evidence.as_str()
    );
    let digest = CanonicalPayloadDigest::from_bytes(
        knowledge_digest(b"chio.confined.evidence-binding.v1\0", body).map_err(refused)?,
    );
    if let Some(old) = load::<CanonicalPayloadDigest>(tx, &key)? {
        if old != digest {
            return Err(refused("evidence consumed"));
        }
    } else {
        save(tx, owner, scope, &key, &digest)?;
    }
    Ok(())
}
impl SqliteAdmissionOperationStore {
    /// Classified, current-authority review of a retained staged artifact. A
    /// disappeared host can recover approval data without launching again.
    pub fn confined_return_evidence(
        &self,
        actor: &AuthenticatedRecoveryActor,
        request: &RequestId,
        fence: &StoreMutationFence,
        now: u64,
    ) -> Result<ConfinedReturnEvidenceV1, AdmissionOperationStoreError> {
        if actor.permission() != RecoveryPermission::ConfinedReturn {
            return Err(refused("review authority"));
        }
        mutate(self, actor, fence, now, |tx, profile, now| {
            let record = record(&tx, actor.scope(), request)?;
            validate_current(&tx, &record, profile, now)?;
            if !matches!(
                record.reservation.state,
                IsolationStateV1::ReturnStaged
                    | IsolationStateV1::ReturnAdmitted
                    | IsolationStateV1::Closed
            ) {
                return Err(refused("review unavailable"));
            }
            traversal::ensure_audience(&tx, actor, &metadata(&record)?.label)?;
            let expires = now
                .checked_add(60_000)
                .ok_or_else(|| refused("review deadline"))?
                .min(record.installation.contract.expires_at_unix_ms.get());
            let body = expected_evidence(
                &record,
                SafeInteger::new(now).map_err(refused)?,
                SafeInteger::new(expires).map_err(refused)?,
                EvidenceRef::new(&uuid::Uuid::new_v4().to_string()).map_err(refused)?,
            )?;
            Ok((tx, body))
        })
    }
    /// Only canonical, independently recomputed output becomes a staged return.
    /// The exact immutable seal is retained even if a later permit is withheld.
    pub fn stage_confined_return(
        &self,
        actor: &AuthenticatedRecoveryActor,
        request: &RequestId,
        seal: &ArtifactBlobSealV1,
        bytes: &[u8],
        fence: &StoreMutationFence,
        now: u64,
    ) -> Result<ConfinedReturnEvidenceV1, AdmissionOperationStoreError> {
        if actor.permission() != RecoveryPermission::ConfinedLaunch || bytes.len() > 8 {
            return Err(refused("return staging authority"));
        }
        let boolean: bool = serde_json::from_slice(bytes).map_err(refused)?;
        if chio_core::canonical_json_bytes(&boolean)
            .map_err(refused)?
            .as_slice()
            != bytes
        {
            return Err(refused("return canonical schema"));
        }
        mutate(self, actor, fence, now, |tx, profile, now| {
            let mut record = record(&tx, actor.scope(), request)?;
            validate_current(&tx, &record, profile, now)?;
            let b = &record.reservation.boundary;
            if now >= b.deadline_unix_ms.get()
                || record.observation_release.is_none()
                || record
                    .terminal
                    .as_ref()
                    .and_then(|v| v.exit.as_ref())
                    .and_then(|v| v.exit_code)
                    != Some(0)
                || record.expected_return != Some(knowledge_content_digest(bytes))
                || seal.content != knowledge_content_digest(bytes)
                || seal.bytes.get() != bytes.len() as u64
                || seal.process != b.child
                || seal.runtime != b.parent.runtime
                || !matches!(
                    record.reservation.state,
                    IsolationStateV1::EnforcedRunning | IsolationStateV1::ReturnStaged
                )
            {
                return Err(refused("return producer"));
            }
            if let Some(old) = &record.return_seal {
                if old != seal {
                    return Err(refused("return substitution"));
                }
            } else {
                let mut roots = b.seed_artifacts.as_slice().to_vec();
                roots.push(b.observation.clone());
                let rows = traversal::dependencies(&tx, actor.scope(), &roots)?;
                let label = source(
                    &tx,
                    &profile.native_authority,
                    &record.reservation.child_context,
                )?;
                let influence = traversal::influence(
                    &tx,
                    &profile.native_authority,
                    &record.reservation.child_context,
                    &rows,
                    false,
                )?;
                if influence.unknown
                    || !label.flows_to(&record.installation.contract.source_ceiling)
                {
                    return Err(refused("unknown return provenance"));
                }
                let m = ArtifactVersionV1 {
                    domain_version: VersionV1,
                    scope: actor.scope().clone(),
                    artifact: ArtifactId::new(&uuid::Uuid::new_v4().to_string())
                        .map_err(refused)?,
                    version: ArtifactRevisionId::new(&uuid::Uuid::new_v4().to_string())
                        .map_err(refused)?,
                    content: seal.content,
                    size_bytes: seal.bytes,
                    media_type: ProtectedText::new("application/json").map_err(refused)?,
                    schema: record.installation.contract.schema,
                    producer: ArtifactProducerV1::Derivation {
                        operation: OperationId::new(b.boundary.as_str()).map_err(refused)?,
                    },
                    dependencies: BoundedList::new(roots).map_err(refused)?,
                    label,
                    influence,
                    lineage: b.lineage.clone(),
                    isolation_epoch: b.isolation_epoch.clone(),
                    evidence: BoundedList::new(vec![b.boundary.clone()]).map_err(refused)?,
                    policy: profile.policy,
                    contract: profile.contract,
                    creation_sequence: SafeInteger::new(1).map_err(refused)?,
                    retention: ArtifactRetentionV1::Evidence,
                };
                record.return_artifact = Some(artifact_version_reference(&m).map_err(refused)?);
                record.return_metadata = Some(m);
                record.return_seal = Some(seal.clone());
                record.reservation.state = IsolationStateV1::ReturnStaged;
                retain(&tx, &self.serving_owner, &record)?;
            }
            let expires = now
                .checked_add(60_000)
                .ok_or_else(|| refused("evidence deadline"))?
                .min(record.installation.contract.expires_at_unix_ms.get());
            let evidence = expected_evidence(
                &record,
                SafeInteger::new(now).map_err(refused)?,
                SafeInteger::new(expires).map_err(refused)?,
                EvidenceRef::new(&uuid::Uuid::new_v4().to_string()).map_err(refused)?,
            )?;
            Ok((tx, evidence))
        })
    }

    /// The broker must resolve the exact seal privately. Returning this tuple is
    /// host custody, not an agent/model read or a parent-visible metadata route.
    pub fn prepare_confined_return(
        &self,
        actor: &AuthenticatedRecoveryActor,
        request: &RequestId,
        fence: &StoreMutationFence,
        now: u64,
    ) -> Result<(ArtifactBlobSealV1, ArtifactVersionRefV1), AdmissionOperationStoreError> {
        if actor.permission() != RecoveryPermission::ConfinedReturn {
            return Err(refused("return read authority"));
        }
        mutate(self, actor, fence, now, |tx, profile, now| {
            let record = record(&tx, actor.scope(), request)?;
            validate_current(&tx, &record, profile, now)?;
            if !matches!(
                record.reservation.state,
                IsolationStateV1::ReturnStaged
                    | IsolationStateV1::ReturnAdmitted
                    | IsolationStateV1::Closed
            ) {
                return Err(refused("return unavailable"));
            }
            let result = (
                record.return_seal.ok_or_else(|| refused("return seal"))?,
                record
                    .return_artifact
                    .ok_or_else(|| refused("return artifact"))?,
            );
            Ok((tx, result))
        })
    }
    pub fn admit_confined_return(
        &self,
        actor: &AuthenticatedRecoveryActor,
        input: ConfinedReturnAdmissionInput<'_>,
        fence: &StoreMutationFence,
        now: u64,
    ) -> Result<ReturnAdmissionV1, AdmissionOperationStoreError> {
        let ConfinedReturnAdmissionInput {
            request,
            seal,
            parent,
            disclosure,
            endorsement,
        } = input;
        if actor.permission() != RecoveryPermission::ConfinedReturn {
            return Err(refused("return authority"));
        }
        mutate(self, actor, fence, now, |tx, profile, now| {
            let mut record = record(&tx, actor.scope(), request)?;
            validate_current(&tx, &record, profile, now)?;
            if record.return_seal.as_ref() != Some(seal)
                || *parent != record.installation.contract.parent
                || !profile
                    .recipients
                    .as_slice()
                    .iter()
                    .any(|r| r.recipient == *parent)
                || !matches!(
                    record.reservation.state,
                    IsolationStateV1::ReturnStaged
                        | IsolationStateV1::ReturnAdmitted
                        | IsolationStateV1::Closed
                )
            {
                return Err(refused("exact return recipient"));
            }
            let authority = capability_digest(actor.capability())?;
            if let Some(prior) = record.return_admission {
                if record.return_authority != Some(authority) {
                    return Err(refused("redelivery authority changed"));
                }
                traversal::ensure_audience(&tx, actor, &prior.admitted.admitted_label)?;
                return Ok((tx, prior));
            }
            let m = metadata(&record)?;
            let source = source(
                &tx,
                &profile.native_authority,
                &record.reservation.child_context,
            )?;
            let rows = traversal::dependencies(&tx, actor.scope(), m.dependencies.as_slice())?;
            let influence = traversal::influence(
                &tx,
                &profile.native_authority,
                &record.reservation.child_context,
                &rows,
                false,
            )?;
            if source != m.label
                || influence != m.influence
                || m.influence.unknown
                || now >= record.reservation.boundary.deadline_unix_ms.get()
            {
                return Err(refused("stale child basis"));
            }
            let target = &record.installation.contract.target;
            traversal::ensure_audience(&tx, actor, target)?;
            let mut disclosure_id = None;
            let mut endorsement_id = None;
            if !source.flows_to(target) {
                let signed = disclosure.ok_or_else(|| refused("disclosure required"))?;
                if signed.authority_key() != &record.installation.disclosure_root
                    || !signed.verify_signature().map_err(refused)?
                {
                    return Err(refused("disclosure root"));
                }
                check_evidence(&record, signed.body(), now)?;
                spend(
                    &tx,
                    &self.serving_owner,
                    actor.scope(),
                    "disclosure",
                    signed.authority_key(),
                    signed.body(),
                )?;
                disclosure_id = Some(signed.body().evidence.clone());
            }
            if record.installation.contract.require_integrity {
                let signed = endorsement.ok_or_else(|| refused("endorsement required"))?;
                if signed.authority_key() != &record.installation.endorsement_root
                    || !signed.verify_signature().map_err(refused)?
                {
                    return Err(refused("endorsement root"));
                }
                check_evidence(&record, signed.body(), now)?;
                spend(
                    &tx,
                    &self.serving_owner,
                    actor.scope(),
                    "endorsement",
                    signed.authority_key(),
                    signed.body(),
                )?;
                endorsement_id = Some(signed.body().evidence.clone());
            }
            let release = ArtifactReleaseIntentV1 {
                domain_version: VersionV1,
                release: ReleaseId::new(&uuid::Uuid::new_v4().to_string()).map_err(refused)?,
                kind: ArtifactReleaseKindV1::IndependentlyAdmitted {
                    request: request.clone(),
                },
                artifact: artifact_version_reference(m).map_err(refused)?,
                source_label: target.clone(),
                admitted_label: target.clone(),
                influence: m.influence.clone(),
                recipient: parent.clone(),
                policy: profile.policy,
                authorization: authority,
                observation_transition: EvidenceRef::new(&format!(
                    "confined-return:{}",
                    record.reservation.boundary.boundary.as_str()
                ))
                .map_err(refused)?,
                observation_generation: SafeInteger::new(0).map_err(refused)?,
                state: ArtifactDeliveryStateV1::Admitted,
            };
            let context = profile
                .recipients
                .as_slice()
                .iter()
                .find(|r| r.recipient == *parent)
                .ok_or_else(|| refused("recipient context"))?
                .context
                .clone();
            let (tx, release) = super::super::super::security_participant_state::knowledge::join(
                tx,
                &self.serving_owner,
                super::super::super::security_participant_state::knowledge::KnowledgeJoin {
                    binding: &profile.native_authority,
                    key: &recovery_flow_key(&context),
                    source: target,
                    scope: actor.scope(),
                    release,
                    now,
                },
            )?;
            let admission = ReturnAdmissionV1 {
                domain_version: VersionV1,
                boundary: record.reservation.boundary.boundary.clone(),
                child: record.reservation.boundary.child.clone(),
                launch: record.launch.ok_or_else(|| refused("launch"))?,
                artifact: record
                    .return_artifact
                    .clone()
                    .ok_or_else(|| refused("artifact"))?,
                contract: record.installation.contract.contract,
                observed_source: source,
                admitted: release,
                disclosure: disclosure_id,
                endorsement: endorsement_id,
            };
            let later = schema::authority_validation_time(&tx, now)?;
            for signed in disclosure
                .map(|s| s.body())
                .into_iter()
                .chain(endorsement.map(|s| s.body()))
            {
                check_evidence(&record, signed, later)?;
            }
            if later >= record.reservation.boundary.deadline_unix_ms.get() {
                return Err(refused("return deadline"));
            }
            record.return_admission = Some(admission.clone());
            record.return_authority = Some(authority);
            record.reservation.state = IsolationStateV1::ReturnAdmitted;
            retain(&tx, &self.serving_owner, &record)?;
            Ok((tx, admission))
        })
    }
    pub fn acknowledge_confined_return(
        &self,
        actor: &AuthenticatedRecoveryActor,
        request: &RequestId,
        admission: &ReturnAdmissionV1,
        delivered: bool,
        fence: &StoreMutationFence,
        now: u64,
    ) -> Result<(), AdmissionOperationStoreError> {
        if actor.permission() != RecoveryPermission::ConfinedReturn {
            return Err(refused("return acknowledgement"));
        }
        mutate(self, actor, fence, now, |tx, profile, now| {
            let mut record = record(&tx, actor.scope(), request)?;
            validate_current(&tx, &record, profile, now)?;
            if !matches!(
                record.reservation.state,
                IsolationStateV1::ReturnAdmitted | IsolationStateV1::Closed
            ) {
                return Err(refused("cancelled return acknowledgement"));
            }
            let prior = record
                .return_admission
                .as_mut()
                .ok_or_else(|| refused("return admission"))?;
            let mut compared = admission.clone();
            compared.admitted.state = prior.admitted.state;
            if *prior != compared
                || record.return_authority != Some(capability_digest(actor.capability())?)
            {
                return Err(refused("return acknowledgement binding"));
            }
            if prior.admitted.state != ArtifactDeliveryStateV1::Delivered {
                prior.admitted.state = if delivered {
                    ArtifactDeliveryStateV1::Delivered
                } else {
                    ArtifactDeliveryStateV1::Uncertain
                };
                if delivered {
                    record.reservation.state = IsolationStateV1::Closed;
                }
                retain(&tx, &self.serving_owner, &record)?;
            }
            Ok((tx, ()))
        })
    }
}
