use crate::VerificationBudget;
use alloc::{vec, vec::Vec};
use chio_security_types::recovery::{
    BoundedList, ContractError, NonEmptyBoundedList, SafeInteger, StepId, TemplateId,
};
use serde::{Deserialize, Serialize};

#[derive(Clone, Copy, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub enum DependencyGraphSchema {
    #[serde(rename = "chio.recovery.dependency-graph.v1")]
    V1,
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct DependencyGraphV1 {
    pub schema: DependencyGraphSchema,
    pub version: chio_security_types::recovery::VersionV1,
    pub nodes: NonEmptyBoundedList<DependencyNodeV1, 16>,
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct DependencyNodeV1 {
    pub step_id: StepId,
    pub template_id: TemplateId,
    pub dependencies: BoundedList<StepId, 16>,
    pub estimated_cost_units: SafeInteger,
}

/// A validated symbolic DAG is not a materialized action or an execution permit.
#[derive(Debug, Eq, PartialEq)]
pub struct ValidatedDependencyGraph {
    order: Vec<StepId>,
    total_cost_units: SafeInteger,
}
impl ValidatedDependencyGraph {
    pub fn ordered_steps(&self) -> &[StepId] {
        &self.order
    }
    pub const fn total_cost_units(&self) -> SafeInteger {
        self.total_cost_units
    }
}

/// Stable topological ordering ends in the bytewise opaque step identifier.
/// Every repeated edge and bounded search pass consumes the caller's shared meter.
pub fn validate_dependency_graph(
    nodes: &NonEmptyBoundedList<DependencyNodeV1, 16>,
    budget: &mut VerificationBudget,
) -> Result<ValidatedDependencyGraph, ContractError> {
    let size = nodes.as_slice().len();
    // Conservatively account for bounded sort/comparison work before allocating.
    let sorting_work = size
        .checked_mul(size)
        .and_then(|n| u32::try_from(n).ok())
        .ok_or(ContractError::ArithmeticOverflow)?;
    budget.charge(sorting_work)?;
    let mut sorted: Vec<&DependencyNodeV1> = nodes.as_slice().iter().collect();
    sorted.sort_by(|a, b| a.step_id.cmp(&b.step_id));
    if sorted
        .windows(2)
        .any(|pair| pair[0].step_id == pair[1].step_id)
    {
        return Err(ContractError::DuplicateIdentity);
    }
    let mut total_cost = SafeInteger::ZERO;
    for node in &sorted {
        budget.charge(1)?;
        total_cost = total_cost.checked_add(node.estimated_cost_units)?;
        for (index, dependency) in node.dependencies.as_slice().iter().enumerate() {
            budget.charge(u32::try_from(index).map_err(|_| ContractError::ArithmeticOverflow)?)?;
            if node.dependencies.as_slice()[..index].contains(dependency) {
                return Err(ContractError::DuplicateIdentity);
            }
            budget.charge(u32::try_from(size).map_err(|_| ContractError::ArithmeticOverflow)?)?;
            if sorted
                .iter()
                .all(|candidate| candidate.step_id != *dependency)
            {
                return Err(ContractError::MissingDependency);
            }
        }
    }
    let mut done = vec![false; size];
    let mut order = Vec::with_capacity(size);
    while order.len() < size {
        let mut selected = None;
        for (index, node) in sorted.iter().enumerate() {
            budget.charge(1)?;
            if done[index] {
                continue;
            }
            let mut ready = true;
            for dependency in node.dependencies.as_slice() {
                budget
                    .charge(u32::try_from(size).map_err(|_| ContractError::ArithmeticOverflow)?)?;
                ready &= sorted
                    .iter()
                    .position(|candidate| candidate.step_id == *dependency)
                    .is_some_and(|dependency_index| done[dependency_index]);
            }
            if ready {
                selected = Some(index);
                break;
            }
        }
        let index = selected.ok_or(ContractError::DependencyCycle)?;
        done[index] = true;
        order.push(sorted[index].step_id.clone());
    }
    Ok(ValidatedDependencyGraph {
        order,
        total_cost_units: total_cost,
    })
}
