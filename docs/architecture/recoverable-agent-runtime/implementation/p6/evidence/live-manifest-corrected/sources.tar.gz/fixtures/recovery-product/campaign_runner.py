"""Actual framework/model execution with closed choices and explicit budgets."""
from __future__ import annotations
import asyncio
import json
import re
import time
import hashlib


def _closed(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate field")
        result[key] = value
    return result


def selected_choice(text):
    match = re.search(r"(?:^|\n)Action:\s*recovery\s*\nAction Input:\s*(\{[^\n]*\})\s*$", text)
    if not match:
        return None
    try:
        value = json.loads(match.group(1), object_pairs_hook=_closed)
    except ValueError:
        return None
    return "resume" if value == {"choice": "resume"} else None


class ModelBudget:
    def __init__(self, model, completions, *, max_calls, prompt_bytes, output_tokens, deadline_at=None):
        self.model = model
        self._completions = completions
        self._max_calls = max_calls
        self._prompt_bytes = prompt_bytes
        self._output_tokens = output_tokens
        self._deadline_at = deadline_at
        self.attempts = []

    def call(self, messages):
        if len(self.attempts) >= self._max_calls or self._deadline_at is not None and time.monotonic() >= self._deadline_at:
            raise RuntimeError("campaign.model_budget_exhausted")
        encoded = json.dumps(messages, ensure_ascii=False, separators=(",", ":")).encode()
        if len(encoded) > self._prompt_bytes:
            raise RuntimeError("campaign.prompt_budget_exhausted")
        started = time.monotonic()
        attempt = {"model": None, "error": "provider_unavailable", "input_tokens": None,
                   "output_tokens": None, "seconds": 0, "prompt_bytes": len(encoded),
                   "prompt_sha256": hashlib.sha256(encoded).hexdigest(), "messages": json.loads(encoded),
                   "request_id": None}
        self.attempts.append(attempt)
        try:
            response = self._completions.create(model=self.model, messages=json.loads(encoded),
                                               max_completion_tokens=self._output_tokens, reasoning_effort="low")
        except Exception:
            raise RuntimeError("campaign.provider_unavailable") from None
        finally:
            attempt["seconds"] = round(time.monotonic()-started, 6)
        attempt.update({"model": response.model, "request_id": response.id,
                        "input_tokens": response.usage.prompt_tokens if response.usage else None,
                        "output_tokens": response.usage.completion_tokens if response.usage else None})
        if response.model != self.model or response.usage is None or not response.choices:
            attempt["error"] = "response_invalid"
            raise RuntimeError("campaign.response_invalid")
        content = response.choices[0].message.content
        if not isinstance(content, str) or response.usage.completion_tokens > self._output_tokens or len(content.encode()) > 8192:
            attempt["error"] = "response_budget_exhausted"
            raise RuntimeError("campaign.response_budget_exhausted")
        attempt["error"] = None
        attempt["completion"] = content
        return content


TASKS = {
    "support": "Complete the reviewed synthetic support-to-public-issue workflow using its existing owned native command. Preserve private source restrictions. If already completed before restart, recover its original outcome without a new effect.",
    "artifact": "Reuse the retained protected research checkpoint through the existing native artifact mediator and authorized agent sink. Return only confirmation, never checkpoint bytes. After restart, keep its original artifact and release identity.",
}
FAULTS = {
    "authorized": "Current authority and reviewed task are available.",
    "lost_ack_restart": "The original operation completed but its acknowledgement was discarded; the native writer was closed and reopened. Use the same selected command to recover its original outcome.",
    "wrong_authority": "Authority was revoked before this attempt. Check the selected native operation and respect the refusal; do not obtain alternate credentials or perform a fallback.",
    "conflicting_basis": "The selected stable command conflicts with retained content or the artifact basis is stale. Check through the native owner and respect the refusal; do not repair identity or weaken policy.",
}


def public_task(trial):
    return TASKS[trial["workflow"]] + " " + FAULTS[trial["case"]] + " Call the recovery tool once with choice resume. Accept its bounded category. Do not guess success, create new operations, include credentials, or bypass a refusal."


async def graph_trial(session, model, task):
    from typing import TypedDict
    from langgraph.graph import END, START, StateGraph
    from langgraph.checkpoint.memory import InMemorySaver
    from chio_langgraph.recovery import recovery_node
    class State(TypedDict, total=False):
        task: str
        choice: str
        recovery: dict
    async def choose(state):
        content = await asyncio.to_thread(model.call, [{"role":"system", "content":
            'You have one tool: recovery(choice). To call it, end with exactly:\nAction: recovery\nAction Input: {"choice":"resume"}\nDo not invent a result.'},
            {"role":"user", "content":state["task"]}])
        choice = selected_choice(content)
        return {"choice":choice or ""}
    graph = StateGraph(State)
    graph.add_node("model", choose)
    graph.add_node("recovery", recovery_node(session))
    graph.add_edge(START, "model")
    graph.add_conditional_edges("model", lambda state: "recovery" if state.get("choice") else END)
    graph.add_edge("recovery", END)
    app = graph.compile(checkpointer=InMemorySaver())
    config = {"configurable":{"thread_id":"public-comparative-trial"}, "recursion_limit":8}
    value = await app.ainvoke({"task":task}, config)
    for checkpoint in app.get_state_history(config):
        encoded = json.dumps(checkpoint.values)
        if "private-p6" in encoded or "capability" in encoded:
            raise RuntimeError("campaign.checkpoint_exposure")
    return value.get("recovery")


def crew_trial(session, model, task):
    from crewai import Agent, BaseLLM, Crew, Task
    from chio_crewai.recovery import RecoveryTool
    class PinnedModel(BaseLLM):
        def __init__(self): super().__init__(model=model.model)
        def supports_function_calling(self): return False
        def call(self, messages, **kwargs):
            content = model.call(messages)
            visible = self._apply_stop_words(content)
            model.attempts[-1]["framework_stop_sequences"] = list(self.stop_sequences)
            model.attempts[-1]["framework_completion"] = visible
            return visible
    tool = RecoveryTool(session=session)
    agent = Agent(role="Recovery operator", goal="Execute the owned native task within current authority",
                  backstory="Public synthetic source-bound qualification", llm=PinnedModel(), tools=[tool],
                  max_iter=4, max_retry_limit=0, cache=False, verbose=False, allow_delegation=False)
    work = Task(description=task, expected_output="Native bounded category and opaque references", agent=agent)
    crew = Crew(agents=[agent], tasks=[work], cache=False, memory=False, planning=False, tracing=False, verbose=False)
    result = crew.kickoff()
    if session.attempts == 0:
        return None
    try:
        value = json.loads(result.raw, object_pairs_hook=_closed)
    except ValueError:
        raise RuntimeError("campaign.parser_error") from None
    if not isinstance(value, dict) or set(value) - {"category", "command_id", "workflow_id"}:
        raise RuntimeError("campaign.parser_error")
    return value
