use super::{
    NestedFlowBridge, ToolDispatchContext, ToolInvocationContext, ToolInvocationCost,
    ToolServerEvent, ToolServerStreamResult,
};
use crate::KernelError;

/// Trait representing a connection to a tool server.
///
/// The kernel holds one `ToolServerConnection` per registered server. In
/// production this is an mTLS connection over UDS or TCP. For testing,
/// an in-process implementation can be used.
#[async_trait::async_trait]
pub trait ToolServerConnection: Send + Sync {
    /// Explicit opt-in to the one-submission P1 support issue contract. A
    /// generic server cannot acquire recovery finality from its tool name.
    fn recovery_effect_contract(&self) -> Option<crate::recovery::RecoveryEffectContractV1> {
        None
    }
    /// Receive kernel-selected caller binding for native stateful operations.
    /// Existing connectors retain their invocation behavior by default.
    async fn invoke_with_context(
        &self,
        context: &ToolInvocationContext,
        arguments: serde_json::Value,
        nested_flow_bridge: Option<&mut dyn NestedFlowBridge>,
    ) -> Result<serde_json::Value, KernelError> {
        if let Some(dispatch) = context.dispatch() {
            return self
                .invoke_in_context(dispatch, context.tool_name(), arguments, nested_flow_bridge)
                .await;
        }
        self.invoke(context.tool_name(), arguments, nested_flow_bridge)
            .await
    }

    /// Cost-reporting counterpart preserving existing connector cost overrides.
    async fn invoke_with_cost_and_context(
        &self,
        context: &ToolInvocationContext,
        arguments: serde_json::Value,
        nested_flow_bridge: Option<&mut dyn NestedFlowBridge>,
    ) -> Result<(serde_json::Value, Option<ToolInvocationCost>), KernelError> {
        if let Some(dispatch) = context.dispatch() {
            return self
                .invoke_with_cost_in_context(
                    dispatch,
                    context.tool_name(),
                    arguments,
                    nested_flow_bridge,
                )
                .await;
        }
        self.invoke_with_cost(context.tool_name(), arguments, nested_flow_bridge)
            .await
    }

    /// Streaming counterpart preserving existing connector stream overrides.
    async fn invoke_stream_with_context(
        &self,
        context: &ToolInvocationContext,
        arguments: serde_json::Value,
        nested_flow_bridge: Option<&mut dyn NestedFlowBridge>,
    ) -> Result<Option<ToolServerStreamResult>, KernelError> {
        if let Some(dispatch) = context.dispatch() {
            return self
                .invoke_stream_in_context(
                    dispatch,
                    context.tool_name(),
                    arguments,
                    nested_flow_bridge,
                )
                .await;
        }
        self.invoke_stream(context.tool_name(), arguments, nested_flow_bridge)
            .await
    }

    /// The server's unique identifier.
    fn server_id(&self) -> &str;

    /// List the tool names available on this server.
    fn tool_names(&self) -> Vec<String>;

    /// Return whether the registered tool is explicitly declared read-only.
    ///
    /// The conservative default keeps unannotated tools side-effecting for
    /// durable admission. Implementations should return `true` only from
    /// authenticated manifest metadata owned by the registered connection.
    fn tool_is_read_only(&self, _tool_name: &str) -> bool {
        false
    }

    /// Invoke a tool on this server. The kernel has already validated the
    /// capability and run guards before calling this.
    async fn invoke(
        &self,
        tool_name: &str,
        arguments: serde_json::Value,
        nested_flow_bridge: Option<&mut dyn NestedFlowBridge>,
    ) -> Result<serde_json::Value, KernelError>;

    /// Invoke a tool and optionally report the actual cost of the invocation.
    ///
    /// Tool servers that track monetary costs should override this method.
    /// The default implementation delegates to `invoke` and returns `None`
    /// cost, meaning the kernel will charge `max_cost_per_invocation` as
    /// the worst-case debit.
    async fn invoke_with_cost(
        &self,
        tool_name: &str,
        arguments: serde_json::Value,
        nested_flow_bridge: Option<&mut dyn NestedFlowBridge>,
    ) -> Result<(serde_json::Value, Option<ToolInvocationCost>), KernelError> {
        let value = self
            .invoke(tool_name, arguments, nested_flow_bridge)
            .await?;
        Ok((value, None))
    }

    /// Whether this server measures the realized cost of an invocation it
    /// dispatches.
    ///
    /// The default is `true`: a server that returns `None` cost from
    /// `invoke_with_cost` is asserting that the realized cost equals the
    /// authorized ceiling, and the kernel reconciles and settles that as a
    /// completed spend.
    ///
    /// A server that returns `false` does not execute the target tool and
    /// cannot measure a realized cost (for example a pre-execution
    /// authorization gate that dispatches a pass-through while the real tool
    /// runs elsewhere). For such a server the kernel reverses the
    /// pre-execution hold and signs a provisional, unreconciled receipt
    /// instead of a settled authoritative spend, since no cost was realized on
    /// this path. Real reconciliation happens at the execution site.
    fn measures_realized_cost(&self) -> bool {
        true
    }

    /// Invoke a tool that can emit multiple streamed chunks before its final terminal state.
    ///
    /// Servers that do not support streaming can ignore this and rely on `invoke`.
    async fn invoke_stream(
        &self,
        tool_name: &str,
        arguments: serde_json::Value,
        nested_flow_bridge: Option<&mut dyn NestedFlowBridge>,
    ) -> Result<Option<ToolServerStreamResult>, KernelError> {
        let _ = (tool_name, arguments, nested_flow_bridge);
        Ok(None)
    }

    /// Drain asynchronous events emitted after a tool invocation has already returned.
    ///
    /// Native tool servers can use this to surface late URL-elicitation completions and
    /// catalog/resource notifications without depending on a still-live request-local bridge.
    async fn drain_events(&self) -> Result<Vec<ToolServerEvent>, KernelError> {
        Ok(vec![])
    }
    /// Prove the server can accept a durable dispatch before the kernel
    /// commits it. A failure here is a pre-dispatch denial with no side
    /// effect; remote transports use it to check reachability.
    /// This runs under reversible admission ownership, before final mutable
    /// authorization checks and the security dispatch commitment. It must not
    /// execute a tool or deliver arguments to an effectful tool endpoint, even
    /// if it returns an error. A trusted admission participant may prepare its
    /// already registered request over its authenticated control port, without
    /// performing external provider effects.
    async fn prepare_delivery(&self, context: &ToolDispatchContext) -> Result<(), KernelError> {
        let _ = context;
        Ok(())
    }

    /// Prepare an invocation-owned connection for this original dispatch.
    ///
    /// The returned connection has already completed `prepare_delivery`. The
    /// kernel retains it through revalidation and dispatch, and drops it on
    /// cancellation or denial. A host can therefore register a long-lived
    /// factory while a confined child and its descriptors belong to one call.
    /// Preparation must obey the same no-effect contract as `prepare_delivery`.
    async fn prepare_invocation_connection(
        &self,
        context: &ToolDispatchContext,
    ) -> Result<Option<std::sync::Arc<dyn ToolServerConnection>>, KernelError> {
        self.prepare_delivery(context).await?;
        Ok(None)
    }

    /// The exact persisted enforcement receipt for the prepared invocation.
    /// This is trusted transport evidence, never caller-provided metadata.
    fn prepared_native_launch_receipt(&self) -> Option<chio_core::receipt::body::ChioReceipt> {
        None
    }

    /// Invoke with the dispatch identity. Remote transports forward the
    /// idempotency key and attempt so the server can deduplicate.
    async fn invoke_in_context(
        &self,
        context: &ToolDispatchContext,
        tool_name: &str,
        arguments: serde_json::Value,
        nested_flow_bridge: Option<&mut dyn NestedFlowBridge>,
    ) -> Result<serde_json::Value, KernelError> {
        let _ = context;
        self.invoke(tool_name, arguments, nested_flow_bridge).await
    }

    async fn invoke_with_cost_in_context(
        &self,
        context: &ToolDispatchContext,
        tool_name: &str,
        arguments: serde_json::Value,
        nested_flow_bridge: Option<&mut dyn NestedFlowBridge>,
    ) -> Result<(serde_json::Value, Option<ToolInvocationCost>), KernelError> {
        let _ = context;
        self.invoke_with_cost(tool_name, arguments, nested_flow_bridge)
            .await
    }

    async fn invoke_stream_in_context(
        &self,
        context: &ToolDispatchContext,
        tool_name: &str,
        arguments: serde_json::Value,
        nested_flow_bridge: Option<&mut dyn NestedFlowBridge>,
    ) -> Result<Option<ToolServerStreamResult>, KernelError> {
        let _ = context;
        self.invoke_stream(tool_name, arguments, nested_flow_bridge)
            .await
    }
}
