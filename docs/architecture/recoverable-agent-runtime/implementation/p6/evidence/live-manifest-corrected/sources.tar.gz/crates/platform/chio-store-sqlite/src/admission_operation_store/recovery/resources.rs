//! Physical headroom is checked before a recovery transaction. Record/event
//! quotas independently bound recovery-owned growth. Existing ownership is
//! retained if the filesystem or a pinned reader prevents further progress.
use super::*;

const MIB: u64 = 1024 * 1024;

#[derive(Clone, Copy)]
struct PhysicalUsage {
    database: u64,
    wal: u64,
    available: u64,
}
fn admits(usage: PhysicalUsage, intake: bool) -> bool {
    let (database, wal, reserve) = if intake {
        (1024 * MIB, 64 * MIB, 128 * MIB)
    } else {
        (2048 * MIB, 128 * MIB, 16 * MIB)
    };
    usage.database < database && usage.wal < wal && usage.available >= reserve
}

pub(super) fn check(
    connection: &Connection,
    intake: bool,
) -> Result<(), AdmissionOperationStoreError> {
    check_usage(connection, intake, true)
}

/// Native capture calls this inside its writer. Never checkpoint in a writer.
pub(super) fn check_committing(
    connection: &Connection,
) -> Result<(), AdmissionOperationStoreError> {
    check_usage(connection, false, false)
}

fn check_usage(
    connection: &Connection,
    intake: bool,
    checkpoint: bool,
) -> Result<(), AdmissionOperationStoreError> {
    let path = connection
        .path()
        .ok_or_else(|| invariant("recovery requires a persistent authority"))?;
    let database = std::fs::metadata(path)
        .map_err(|_| invariant("recovery disk is unavailable"))?
        .len();
    let wal = std::fs::metadata(format!("{path}-wal")).map_or_else(
        |error| {
            if error.kind() == std::io::ErrorKind::NotFound {
                Ok(0)
            } else {
                Err(invariant("recovery WAL is unavailable"))
            }
        },
        |metadata| Ok(metadata.len()),
    )?;
    // PASSIVE never waits for a reader or writer. A busy reader cannot induce an
    // unbounded WAL; the hard ceiling below refuses new recovery mutations.
    if checkpoint && wal >= 32 * MIB {
        let _: (i64, i64, i64) = connection
            .query_row("PRAGMA wal_checkpoint(PASSIVE)", [], |row| {
                Ok((row.get(0)?, row.get(1)?, row.get(2)?))
            })
            .map_err(sqlite_error)?;
    }
    #[cfg(unix)]
    let available = {
        let stat = rustix::fs::statvfs(path)
            .map_err(|_| invariant("recovery disk capacity is unavailable"))?;
        stat.f_bavail
            .checked_mul(stat.f_frsize)
            .ok_or_else(|| invariant("recovery disk capacity refused"))?
    };
    #[cfg(not(unix))]
    let available = {
        return Err(invariant("recovery disk capacity profile is unsupported"));
    };
    if !admits(
        PhysicalUsage {
            database,
            wal,
            available,
        },
        intake,
    ) {
        return Err(invariant("recovery disk headroom exhausted"));
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn intake_stops_before_settlement_and_disk_exhaustion() {
        let usage = PhysicalUsage {
            database: 1024 * MIB,
            wal: 64 * MIB,
            available: 127 * MIB,
        };
        assert!(!admits(usage, true));
        assert!(admits(usage, false));
        assert!(!admits(
            PhysicalUsage {
                available: 16 * MIB - 1,
                ..usage
            },
            false
        ));
        assert!(!admits(
            PhysicalUsage {
                wal: 128 * MIB,
                ..usage
            },
            false
        ));
        assert!(!admits(
            PhysicalUsage {
                database: 2048 * MIB,
                ..usage
            },
            false
        ));
    }

    #[cfg(unix)]
    #[test]
    fn recovery_p1_pinned_reader_wal_headroom_refuses_intake_and_preserves_committed_data(
    ) -> Result<(), Box<dyn std::error::Error>> {
        let directory = tempfile::tempdir()?;
        let path = directory.path().join("wal.db");
        let writer = Connection::open(&path)?;
        writer.pragma_update(None, "journal_mode", "WAL")?;
        writer.pragma_update(None, "wal_autocheckpoint", 0)?;
        writer.execute_batch("CREATE TABLE retained(id INTEGER PRIMARY KEY, payload BLOB NOT NULL); INSERT INTO retained VALUES(1,X'010203'); PRAGMA wal_checkpoint(TRUNCATE);")?;
        let reader = Connection::open(&path)?;
        reader.execute_batch("BEGIN;")?;
        assert_eq!(
            reader.query_row("SELECT payload FROM retained WHERE id=1", [], |row| row
                .get::<_, Vec<u8>>(0))?,
            [1, 2, 3]
        );
        for _ in 0..17 {
            writer.execute(
                "INSERT INTO retained(payload) VALUES(zeroblob(4194304))",
                [],
            )?;
        }
        assert!(std::fs::metadata(format!("{}-wal", path.display()))?.len() >= 64 * MIB);
        assert!(check(&writer, true).is_err());
        check(&writer, false)?;
        assert_eq!(
            writer.query_row("SELECT count(*) FROM retained", [], |row| row
                .get::<_, i64>(0))?,
            18
        );
        assert_eq!(
            reader.query_row("SELECT count(*) FROM retained", [], |row| row
                .get::<_, i64>(0))?,
            1
        );
        reader.execute_batch("ROLLBACK;")?;
        writer.execute_batch("PRAGMA wal_checkpoint(TRUNCATE);")?;
        check(&writer, true)?;
        assert_eq!(
            writer.query_row("SELECT payload FROM retained WHERE id=1", [], |row| row
                .get::<_, Vec<u8>>(0))?,
            [1, 2, 3]
        );
        Ok(())
    }
}
