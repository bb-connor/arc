"""CrewAI transport to the native recovery owner, without local tool fallback."""
from __future__ import annotations
import asyncio
import json
from typing import Annotated
from crewai.tools import BaseTool
from pydantic import BaseModel, ConfigDict, PrivateAttr, StringConstraints
from chio_sdk.recovery_host import RecoveryHostSession


class RecoveryChoice(BaseModel):
    model_config = ConfigDict(extra="forbid")
    choice: Annotated[str, StringConstraints(min_length=1, max_length=64, pattern=r"^[A-Za-z0-9._:-]+$")]


class RecoveryTool(BaseTool):
    """Use with Crew(cache=False, memory=False, planning=False, tracing=False).

    Stable native command bytes and capability remain private. The model selects
    a task-owned choice; it cannot approve a report or issue new authority.
    """
    name: str = "recovery"
    description: str = "Submit one selected native recovery command. Input: choice. Return: bounded category and opaque references."
    args_schema: type[BaseModel] = RecoveryChoice
    _session: RecoveryHostSession = PrivateAttr()

    def __init__(self, *, session: RecoveryHostSession):
        super().__init__(cache_function=lambda *_: False, max_usage_count=8, result_as_answer=True)
        self._session = session

    def _run(self, choice: str):
        pending = self._arun(choice)
        try:
            asyncio.get_running_loop()
        except RuntimeError:
            return asyncio.run(pending)
        return pending

    async def _arun(self, choice: str) -> str:
        outcome = await self._session.execute(choice)
        return json.dumps(outcome.as_dict(), sort_keys=True, separators=(",", ":"))
