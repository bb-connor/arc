//! Collection crosses databases only after a protected retirement barrier.
use super::*;
#[derive(Clone, Copy, Eq, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
enum SweepState {
    Sweeping,
    Collected,
}
#[derive(Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct SweepRecord {
    seal: ArtifactBlobSealV1,
    state: SweepState,
}
fn sweep_key(
    scope: &RecoveryScopeV1,
    context: &SecurityInvocationContext,
    content: CanonicalPayloadDigest,
) -> Result<String, AdmissionOperationStoreError> {
    Ok(format!(
        "knowledge-sweep:{}",
        sha256_hex(&protected::encode(&(
            scope.authority_domain.clone(),
            scope.tenant_id.clone(),
            scope.process_id.clone(),
            context.as_v1().session_id(),
            content
        ))?)
    ))
}
pub(super) fn require_not_sweeping(
    tx: &Connection,
    scope: &RecoveryScopeV1,
    context: &SecurityInvocationContext,
    content: CanonicalPayloadDigest,
) -> Result<(), AdmissionOperationStoreError> {
    if load::<SweepRecord>(tx, &sweep_key(scope, context, content)?)?
        .is_some_and(|record| record.state == SweepState::Sweeping)
    {
        return Err(refused("collection in progress"));
    }
    Ok(())
}
fn publications(
    tx: &Connection,
) -> Result<Vec<NativeArtifactRecordV1>, AdmissionOperationStoreError> {
    let mut statement=tx.prepare("SELECT record_key FROM admission_operation_recovery_records WHERE record_key GLOB 'knowledge-publication:*' ORDER BY record_key LIMIT 513").map_err(sqlite_error)?;
    let keys = statement
        .query_map([], |row| row.get::<_, String>(0))
        .map_err(sqlite_error)?
        .collect::<Result<Vec<_>, _>>()
        .map_err(sqlite_error)?;
    if keys.len() > 512 {
        return Err(refused("publication inventory overflow"));
    }
    keys.into_iter()
        .map(|key| load(tx, &key)?.ok_or_else(|| refused("publication inventory")))
        .collect()
}
fn pinned(
    tx: &Transaction<'_>,
    reference: &ArtifactVersionRefV1,
) -> Result<bool, AdmissionOperationStoreError> {
    // Dependencies include reserved/staged versions, so publication cannot lose
    // a required input between independent blob and metadata commits.
    for record in publications(tx)? {
        if record.state != ArtifactPublicationStateV1::Retired
            && record.input.dependencies.as_slice().contains(reference)
        {
            return Ok(true);
        }
    }
    let mut statement=tx.prepare("SELECT record_key FROM admission_operation_recovery_records WHERE record_key GLOB 'knowledge-checkpoint:*' OR record_key GLOB 'knowledge-pin:*' OR record_key GLOB 'knowledge-release:*' LIMIT 4097").map_err(sqlite_error)?;
    let keys = statement
        .query_map([], |row| row.get::<_, String>(0))
        .map_err(sqlite_error)?
        .collect::<Result<Vec<_>, _>>()
        .map_err(sqlite_error)?;
    if keys.len() > 4096 {
        return Err(refused("pin inventory overflow"));
    }
    for key in keys {
        if key.starts_with("knowledge-checkpoint:") {
            let checkpoint: LabeledCheckpointV1 =
                load(tx, &key)?.ok_or_else(|| refused("checkpoint pin"))?;
            if checkpoint.artifacts.as_slice().contains(reference)
                || checkpoint
                    .model_contexts
                    .as_slice()
                    .iter()
                    .any(|model| model.side_files.as_slice().contains(reference))
            {
                return Ok(true);
            }
        } else if key.starts_with("knowledge-pin:") {
            let pinned: Option<ArtifactVersionRefV1> =
                load(tx, &key)?.ok_or_else(|| refused("pin record"))?;
            if pinned.as_ref() == Some(reference) {
                return Ok(true);
            }
        } else if super::release::pins(tx, &key, reference)? {
            return Ok(true);
        }
    }
    Ok(false)
}
impl SqliteAdmissionOperationStore {
    /// Stable evidence pin. This profile retains every pin permanently and
    /// refuses to rebind its identity to a different artifact version.
    pub fn pin_artifact(
        &self,
        actor: &AuthenticatedRecoveryActor,
        reference: &ArtifactVersionRefV1,
        pin: &EvidenceRef,
        fence: &StoreMutationFence,
        now: u64,
    ) -> Result<(), AdmissionOperationStoreError> {
        if actor.permission() != RecoveryPermission::KnowledgeAdmin
            || reference.scope != *actor.scope()
        {
            return Err(refused("pin authority"));
        }
        mutate(self, actor, fence, now, |tx, _, _| {
            artifact(&tx, reference)?;
            let key = format!(
                "knowledge-pin:{}:{}",
                scope_key(actor.scope())?,
                pin.as_str()
            );
            if let Some(old) = load::<Option<ArtifactVersionRefV1>>(&tx, &key)? {
                if old.as_ref() != Some(reference) {
                    return Err(refused("pin identity reused"));
                }
                return Ok((tx, ()));
            }
            save(
                &tx,
                &self.serving_owner,
                actor.scope(),
                &key,
                &Some(reference.clone()),
            )?;
            Ok((tx, ()))
        })
    }
    pub fn move_artifact(
        &self,
        actor: &AuthenticatedRecoveryActor,
        reference: &ArtifactVersionRefV1,
        location: &ProtectedText<128>,
        fence: &StoreMutationFence,
        now: u64,
    ) -> Result<(), AdmissionOperationStoreError> {
        if actor.permission() != RecoveryPermission::KnowledgeWrite
            || reference.scope != *actor.scope()
        {
            return Err(refused("move authority"));
        }
        mutate(self, actor, fence, now, |tx, _, _| {
            let mut record = artifact(&tx, reference)?;
            record.location = location.clone();
            save(
                &tx,
                &self.serving_owner,
                actor.scope(),
                &publication_key(&record.metadata.scope, &record.input.publication)?,
                &record,
            )?;
            Ok((tx, ()))
        })
    }
    /// Uncertain releases, dependencies, checkpoints, evidence and operations
    /// prevent collection. Sweep ownership bars new reservations of equal bytes.
    pub fn retire_artifact(
        &self,
        actor: &AuthenticatedRecoveryActor,
        reference: &ArtifactVersionRefV1,
        fence: &StoreMutationFence,
        now: u64,
    ) -> Result<Option<ArtifactBlobSealV1>, AdmissionOperationStoreError> {
        if actor.permission() != RecoveryPermission::KnowledgeAdmin
            || reference.scope != *actor.scope()
        {
            return Err(refused("retention authority"));
        }
        mutate(self, actor, fence, now, |tx, profile, _| {
            let key: String = load(&tx, &version_key(reference)?)?
                .ok_or_else(|| refused("retirement version"))?;
            let mut record: NativeArtifactRecordV1 =
                load(&tx, &key)?.ok_or_else(|| refused("retirement record"))?;
            traversal::ensure_audience(&tx, actor, &record.metadata.label)?;
            if artifact_version_reference(&record.metadata).map_err(refused)? != *reference
                || record.metadata.retention != ArtifactRetentionV1::Ephemeral
                || pinned(&tx, reference)?
            {
                return Err(refused("retention pin"));
            }
            if matches!(
                record.metadata.producer,
                ArtifactProducerV1::NativeOperation { .. }
            ) {
                return Err(refused("native receipt pin"));
            }
            if record.state != ArtifactPublicationStateV1::Retired {
                record.state = ArtifactPublicationStateV1::Retired;
                save(&tx, &self.serving_owner, actor.scope(), &key, &record)?;
            }
            let result = schedule_collection(&tx, &self.serving_owner, profile, &record)?;
            Ok((tx, result))
        })
    }
    pub fn finish_artifact_collection(
        &self,
        actor: &AuthenticatedRecoveryActor,
        seal: &ArtifactBlobSealV1,
        fence: &StoreMutationFence,
        now: u64,
    ) -> Result<(), AdmissionOperationStoreError> {
        if actor.permission() != RecoveryPermission::KnowledgeAdmin {
            return Err(refused("collection authority"));
        }
        mutate(self, actor, fence, now, |tx, profile, _| {
            let key = sweep_key(actor.scope(), &profile.producer_context, seal.content)?;
            let mut record: SweepRecord =
                load(&tx, &key)?.ok_or_else(|| refused("sweep absent"))?;
            if record.seal != *seal {
                return Err(refused("sweep identity"));
            }
            if record.state == SweepState::Sweeping {
                record.state = SweepState::Collected;
                save(&tx, &self.serving_owner, actor.scope(), &key, &record)?;
            }
            Ok((tx, ()))
        })
    }
}

fn schedule_collection(
    tx: &Transaction<'_>,
    owner: &SqliteServingOwner,
    profile: &NativeKnowledgeInstallationV1,
    record: &NativeArtifactRecordV1,
) -> Result<Option<ArtifactBlobSealV1>, AdmissionOperationStoreError> {
    let Some(seal) = &record.seal else {
        return Ok(None);
    };
    let key = sweep_key(
        &record.metadata.scope,
        &profile.producer_context,
        record.metadata.content,
    )?;
    if let Some(old) = load::<SweepRecord>(tx, &key)? {
        if old.seal == *seal {
            return Ok(if old.state == SweepState::Collected {
                None
            } else {
                Some(seal.clone())
            });
        }
        if old.state == SweepState::Sweeping {
            return Err(refused("another collection owns bytes"));
        }
    }
    let shared = publications(tx)?.iter().any(|other| {
        other.state != ArtifactPublicationStateV1::Retired
            && other.metadata.scope == record.metadata.scope
            && other.metadata.content == record.metadata.content
    });
    if shared {
        return Ok(None);
    }
    save(
        tx,
        owner,
        &record.metadata.scope,
        &key,
        &SweepRecord {
            seal: seal.clone(),
            state: SweepState::Sweeping,
        },
    )?;
    Ok(Some(seal.clone()))
}
impl SqliteAdmissionOperationStore {
    pub fn artifact_publication_for_collection(
        &self,
        actor: &AuthenticatedRecoveryActor,
        input: &ArtifactPublicationInputV1,
        fence: &StoreMutationFence,
        now: u64,
    ) -> Result<NativeArtifactRecordV1, AdmissionOperationStoreError> {
        if actor.permission() != RecoveryPermission::KnowledgeAdmin {
            return Err(refused("collection inspect authority"));
        }
        mutate(self, actor, fence, now, |tx, _, _| {
            let record: NativeArtifactRecordV1 =
                load(&tx, &publication_key(actor.scope(), &input.publication)?)?
                    .ok_or_else(|| refused("collection absent"))?;
            if record.input != *input || record.metadata.scope != *actor.scope() {
                return Err(refused("collection input changed"));
            }
            traversal::ensure_audience(&tx, actor, &record.metadata.label)?;
            Ok((tx, record))
        })
    }
    /// Abort unreachable staging explicitly. Its original publication identity
    /// stays retired, including orphan cleanup after an acknowledgement loss.
    pub fn abort_artifact_publication(
        &self,
        actor: &AuthenticatedRecoveryActor,
        input: &ArtifactPublicationInputV1,
        orphan: Option<&ArtifactBlobSealV1>,
        fence: &StoreMutationFence,
        now: u64,
    ) -> Result<Option<ArtifactBlobSealV1>, AdmissionOperationStoreError> {
        if actor.permission() != RecoveryPermission::KnowledgeAdmin {
            return Err(refused("abort authority"));
        }
        mutate(self, actor, fence, now, |tx, profile, _| {
            let key = publication_key(actor.scope(), &input.publication)?;
            let mut record: NativeArtifactRecordV1 =
                load(&tx, &key)?.ok_or_else(|| refused("abort absent"))?;
            traversal::ensure_audience(&tx, actor, &record.metadata.label)?;
            if record.input != *input
                || record.metadata.scope != *actor.scope()
                || record.state == ArtifactPublicationStateV1::Available
                || matches!(input.producer, ArtifactProducerV1::NativeOperation { .. })
            {
                return Err(refused("abort identity"));
            }
            record.state = ArtifactPublicationStateV1::Retired;
            save(&tx, &self.serving_owner, actor.scope(), &key, &record)?;
            if let Some(seal) = orphan {
                if seal.object != record.object
                    || seal.process != actor.scope().process_id
                    || seal.content != input.content
                    || seal.bytes != input.size_bytes
                    || seal.runtime.as_str()
                        != profile.producer_context.as_v1().session_id().as_str()
                {
                    return Err(refused("orphan identity"));
                }
                if record.seal.as_ref().is_some_and(|prior| prior != seal) {
                    return Err(refused("orphan generation changed"));
                }
                record.seal = Some(seal.clone());
                save(&tx, &self.serving_owner, actor.scope(), &key, &record)?;
            }
            let result = schedule_collection(&tx, &self.serving_owner, profile, &record)?;
            Ok((tx, result))
        })
    }
    /// The host connects actual captured/unknown native custody to retention.
    /// This profile keeps pins permanently; unknown custody cannot unpin itself.
    pub fn pin_native_artifact_operation(
        &self,
        actor: &AuthenticatedRecoveryActor,
        reference: &ArtifactVersionRefV1,
        operation: &OperationId,
        fence: &StoreMutationFence,
        now: u64,
    ) -> Result<(), AdmissionOperationStoreError> {
        if actor.permission() != RecoveryPermission::KnowledgeAdmin
            || reference.scope != *actor.scope()
        {
            return Err(refused("native pin authority"));
        }
        mutate(self, actor, fence, now, |tx, profile, _| {
            artifact(&tx, reference)?;
            let native = load_operation_for_participant_tx(
                &tx,
                &AdmissionOperationId::from_persisted(operation.as_str()).map_err(refused)?,
            )?
            .ok_or_else(|| refused("native pin absent"))?;
            if native.native_dispatch_ledger_digest().is_none() {
                return Err(refused("native pin uncaptured"));
            }
            let request = super::super::retained_request::load_retained_request_tx(&tx, &native)?
                .ok_or_else(|| refused("native pin request"))?;
            request.validate_native_security_authority(&profile.native_authority)?;
            request.validate_native_security_context(&profile.producer_context)?;
            let key = format!(
                "knowledge-pin:{}:operation:{}",
                scope_key(actor.scope())?,
                operation.as_str()
            );
            if let Some(old) = load::<Option<ArtifactVersionRefV1>>(&tx, &key)? {
                if old.as_ref() != Some(reference) {
                    return Err(refused("native pin rebound"));
                }
                return Ok((tx, ()));
            }
            save(
                &tx,
                &self.serving_owner,
                actor.scope(),
                &key,
                &Some(reference.clone()),
            )?;
            Ok((tx, ()))
        })
    }
    pub fn pin_pending_artifact_approval(
        &self,
        actor: &AuthenticatedRecoveryActor,
        reference: &ArtifactVersionRefV1,
        workflow: &WorkflowId,
        fence: &StoreMutationFence,
        now: u64,
    ) -> Result<(), AdmissionOperationStoreError> {
        if actor.permission() != RecoveryPermission::KnowledgeAdmin
            || reference.scope != *actor.scope()
        {
            return Err(refused("approval pin authority"));
        }
        mutate(self, actor, fence, now, |tx, _, _| {
            artifact(&tx, reference)?;
            let pending = protected::workflow_tx(&tx, actor.scope(), workflow)?;
            if pending.review.is_none() || pending.approval.is_some() || pending.captured {
                return Err(refused("approval not pending"));
            }
            let key = format!(
                "knowledge-pin:{}:approval:{}",
                scope_key(actor.scope())?,
                workflow.as_str()
            );
            if let Some(old) = load::<Option<ArtifactVersionRefV1>>(&tx, &key)? {
                if old.as_ref() != Some(reference) {
                    return Err(refused("approval pin rebound"));
                }
                return Ok((tx, ()));
            }
            save(
                &tx,
                &self.serving_owner,
                actor.scope(),
                &key,
                &Some(reference.clone()),
            )?;
            Ok((tx, ()))
        })
    }
}
