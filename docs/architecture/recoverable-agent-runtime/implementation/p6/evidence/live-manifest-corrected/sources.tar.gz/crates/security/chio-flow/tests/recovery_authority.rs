use chio_core_types::recovery::SignedAuthorityCoverageAttestationV1 as Signed;
use chio_core_types::{canonical_json_bytes, sha256, Keypair};
use chio_flow::*;
use chio_security_types::flow::{DeclassificationPurpose, InformationLabel, PrincipalId};
use chio_security_types::ports::DestinationId;
use chio_security_types::recovery::*;
use std::collections::BTreeMap;

type Result<T = ()> = std::result::Result<T, Box<dyn std::error::Error>>;
struct Fixture {
    approval: ApprovalIntentV1,
    requirements: AuthorizationRequirementsV1,
    basis: BasisDigest,
    proofs: Vec<Signed>,
    assignments: BTreeMap<IssuerId, RecoveryAuthorityAssignment>,
    keys: Vec<Keypair>,
}
impl Fixture {
    fn new() -> Result<Self> {
        let scope = RecoveryScopeV1 {
            authority_domain: AuthorityDomainId::new("authority")?,
            tenant_id: RecoveryTenantId::new("tenant")?,
            process_id: ProcessId::new("process")?,
        };
        let source: InformationLabel = serde_json::from_value(
            serde_json::json!({"kind":"known","owners":{"alice":["alice"],"bob":["bob"]},"compartments":["restricted"]}),
        )?;
        let requirements = AuthorizationRequirementsV1 {
            schema: AuthorizationRequirementsSchema::V1,
            version: VersionV1,
            scope: scope.clone(),
            source_label: source.clone(),
            admitted_target: InformationLabel::bottom(),
            source_join: SourceDigest::from_bytes([1; 32]),
            influence_basis: SourceDigest::from_bytes([2; 32]),
            recipient: DestinationId::new("issues")?,
            purpose: DeclassificationPurpose::new("approved-disclosure")?,
            obligations: required_recovery_disclosure_obligations(
                &source,
                &InformationLabel::bottom(),
            )?,
            issuer_scope: AuthorityScopeDigest::from_bytes([3; 32]),
            validity_ceiling_unix_ms: SafeInteger::new(200_000)?,
            attachment_profile: RecoveryAttachmentProfile::Ordinary,
        };
        let mut preimage = b"chio.recovery.authorization-requirements.v1\0".to_vec();
        preimage.extend_from_slice(&canonical_json_bytes(&requirements)?);
        let approval = ApprovalIntentV1 {
            schema: ApprovalIntentSchema::V1,
            version: VersionV1,
            scope,
            approval_intent: ApprovalIntentRef::new("approval")?,
            challenge: ChallengeId::new("challenge")?,
            action_intent: IntentDigest::from_bytes([4; 32]),
            authorization_requirements: AuthorizationRequirementsDigest::from_bytes(
                *sha256(&preimage).as_bytes(),
            ),
            offer: OfferDigest::from_bytes([5; 32]),
            plan: PlanDigest::from_bytes([6; 32]),
            preview: ReviewDigest::from_bytes([7; 32]),
            recipient: requirements.recipient.clone(),
            purpose: requirements.purpose.clone(),
            obligations: requirements.obligations.clone(),
            reviewer: PrincipalId::new("reviewer")?,
            issued_at_unix_ms: SafeInteger::new(100_000)?,
            expires_at_unix_ms: SafeInteger::new(200_000)?,
        };
        let basis = BasisDigest::from_bytes([8; 32]);
        let mut proofs = Vec::new();
        let mut assignments = BTreeMap::new();
        let mut keys = Vec::new();
        for (index, name) in ["alice", "bob", "ops"].into_iter().enumerate() {
            let key = Keypair::from_seed(&[index as u8 + 11; 32]);
            let obligation = requirements.obligations.as_slice()[index].clone();
            let body = AuthorityCoverageAttestationV1 {
                schema: AuthorityCoverageSchema::V1,
                version: VersionV1,
                scope: approval.scope.clone(),
                approval_intent: approval.approval_intent.clone(),
                challenge: approval.challenge.clone(),
                action_intent: approval.action_intent,
                authorization_requirements: approval.authorization_requirements,
                source_basis: basis,
                issuer_id: IssuerId::new(&format!("issuer-{name}"))?,
                principal: PrincipalId::new(name)?,
                obligations: NonEmptyBoundedList::new(vec![obligation.clone()])?,
                issued_at_unix_ms: approval.issued_at_unix_ms,
                expires_at_unix_ms: approval.expires_at_unix_ms,
            };
            assignments.insert(
                body.issuer_id.clone(),
                RecoveryAuthorityAssignment {
                    principal: body.principal.clone(),
                    key: key.public_key(),
                    obligations: [obligation].into_iter().collect(),
                },
            );
            proofs.push(Signed::sign(body, &key)?);
            keys.push(key);
        }
        Ok(Self {
            approval,
            requirements,
            basis,
            proofs,
            assignments,
            keys,
        })
    }
    fn verify(
        &self,
        proofs: Vec<Signed>,
        now: u64,
    ) -> std::result::Result<VerifiedRecoveryCoverage, DeclassificationError> {
        let proofs =
            NonEmptyBoundedList::new(proofs).map_err(|_| DeclassificationError::InvalidGrant)?;
        verify_recovery_coverage(
            &self.approval,
            &self.requirements,
            self.basis,
            &proofs,
            &self.assignments,
            now,
        )
    }
}
#[test]
fn recovery_multiple_owners_require_conjunctive_scoped_coverage() -> Result {
    let f = Fixture::new()?;
    let positive = f.verify(f.proofs.clone(), 150_000)?;
    let mut reverse = f.proofs.clone();
    reverse.reverse();
    assert_eq!(positive.digest(), f.verify(reverse, 150_000)?.digest());
    assert_eq!(positive.obligations().len(), 3);
    for omitted in 0..3 {
        let mut proofs = f.proofs.clone();
        proofs.remove(omitted);
        assert_eq!(
            f.verify(proofs, 150_000).err(),
            Some(DeclassificationError::UntrustedAuthority)
        );
    }
    let mut duplicates = f.proofs.clone();
    duplicates.push(f.proofs[0].clone());
    assert_eq!(
        f.verify(duplicates, 150_000).err(),
        Some(DeclassificationError::BindingMismatch)
    );
    assert_eq!(
        f.verify(f.proofs.clone(), 99_999).err(),
        Some(DeclassificationError::NotYetValid)
    );
    assert_eq!(
        f.verify(f.proofs.clone(), 200_000).err(),
        Some(DeclassificationError::Expired)
    );
    Ok(())
}
#[test]
fn recovery_resigned_context_substitutions_fail_the_intended_binding() -> Result {
    let f = Fixture::new()?;
    for field in [
        "scope",
        "approval_intent",
        "challenge",
        "action_intent",
        "authorization_requirements",
        "source_basis",
        "principal",
        "obligations",
    ] {
        let mut body = serde_json::to_value(f.proofs[0].body())?;
        match field {
            "scope" => body[field]["tenant_id"] = serde_json::json!("foreign-tenant"),
            "action_intent" | "authorization_requirements" | "source_basis" => {
                body[field] = serde_json::to_value(vec![9; 32])?
            }
            "obligations" => {
                body[field] = serde_json::to_value(f.proofs[2].body().obligations.clone())?
            }
            _ => body[field] = serde_json::json!("foreign"),
        }
        let signed = Signed::sign(serde_json::from_value(body)?, &f.keys[0])?;
        assert!(
            signed.verify_signature()?,
            "mutation must retain valid crypto: {field}"
        );
        let mut proofs = f.proofs.clone();
        proofs[0] = signed;
        let expected = if matches!(field, "principal" | "obligations") {
            DeclassificationError::UntrustedAuthority
        } else {
            DeclassificationError::BindingMismatch
        };
        assert_eq!(f.verify(proofs, 150_000).err(), Some(expected), "{field}");
    }
    let mut changed = Fixture::new()?;
    changed.requirements.issuer_scope = AuthorityScopeDigest::from_bytes([99; 32]);
    assert_eq!(
        changed.verify(changed.proofs.clone(), 150_000).err(),
        Some(DeclassificationError::BindingMismatch)
    );
    Ok(())
}
#[test]
fn recovery_alias_rotation_and_integrity_powers_cannot_manufacture_coverage() -> Result {
    let mut f = Fixture::new()?;
    let mut body = f.proofs[0].body().clone();
    body.issuer_id = IssuerId::new("rotated-alias")?;
    let rotated = Keypair::from_seed(&[40; 32]);
    f.assignments.insert(
        body.issuer_id.clone(),
        RecoveryAuthorityAssignment {
            principal: body.principal.clone(),
            key: rotated.public_key(),
            obligations: body.obligations.as_slice().iter().cloned().collect(),
        },
    );
    let mut proofs = f.proofs.clone();
    proofs.push(Signed::sign(body, &rotated)?);
    assert_eq!(
        f.verify(proofs, 150_000).err(),
        Some(DeclassificationError::BindingMismatch)
    );
    let mut body = f.proofs[0].body().clone();
    body.obligations =
        NonEmptyBoundedList::new(vec![AuthorityObligationV1::IntegrityEndorsement {
            principal: PrincipalId::new("alice")?,
        }])?;
    let mut proofs = f.proofs.clone();
    proofs[0] = Signed::sign(body, &f.keys[0])?;
    assert_eq!(
        f.verify(proofs, 150_000).err(),
        Some(DeclassificationError::UntrustedAuthority)
    );
    let mut proofs = f.proofs.clone();
    proofs[0] = Signed::sign(f.proofs[0].body().clone(), &rotated)?;
    assert_eq!(
        f.verify(proofs, 150_000).err(),
        Some(DeclassificationError::UntrustedAuthority)
    );
    Ok(())
}

#[test]
fn recovery_all_resigned_grant_binding_fields_refuse_foreign_contexts() -> Result {
    use chio_core_types::recovery::SignedRecoveryGrantV2;
    use chio_security_types::ports::{CanonicalBody, RecordId};
    let fixture: serde_json::Value = serde_json::from_str(include_str!(
        "../../../../spec/vectors/recovery/v1/p1-positive.json"
    ))?;
    let grant: SignedRecoveryGrantV2 = serde_json::from_value(fixture["grant"].clone())?;
    let requirements: AuthorizationRequirementsV1 =
        serde_json::from_value(fixture["requirements"].clone())?;
    let approval: ApprovalIntentV1 = serde_json::from_value(fixture["approval_intent"].clone())?;
    let action: ActionIntentV1 = serde_json::from_value(fixture["action"].clone())?;
    let proof: Signed = serde_json::from_value(fixture["coverage"][0].clone())?;
    let assignments = BTreeMap::from([(
        proof.body().issuer_id.clone(),
        RecoveryAuthorityAssignment {
            principal: proof.body().principal.clone(),
            key: proof.authority_key().clone(),
            obligations: proof
                .body()
                .obligations
                .as_slice()
                .iter()
                .cloned()
                .collect(),
        },
    )]);
    let coverage = verify_recovery_coverage(
        &approval,
        &requirements,
        action.basis,
        &NonEmptyBoundedList::new(vec![proof])?,
        &assignments,
        approval.issued_at_unix_ms.get() + 1,
    )?;
    let claims = &grant.body().claims;
    let request = DeclassificationVerificationRequest {
        capability_id: claims.capability_id().clone(),
        tenant_id: claims.tenant_id().clone(),
        subject_id: claims.subject_id().clone(),
        agent_id: claims.agent_id().clone(),
        session_id: claims.session_id().clone(),
        source_label: requirements.source_label,
        destination_id: claims.destination_id().clone(),
        tool_name: claims.tool_name().clone(),
        purpose: claims.purpose().clone(),
        policy_purposes: [claims.purpose().clone()].into_iter().collect(),
        manifest_purposes: [claims.purpose().clone()].into_iter().collect(),
        canonical_request: CanonicalBody::new(canonical_json_bytes(
            &fixture["request"]["arguments"],
        )?)?,
        now_unix_ms: claims.issued_at_unix_seconds() * 1000 + 1,
        trusted_authorities: BTreeMap::from([(
            claims.authority_key_id().clone(),
            grant.authority_key().clone(),
        )]),
    };
    let expected = grant.body().recovery.clone();
    assert!(verify_recovery_declassification(&grant, &request, &expected, &coverage).is_ok());
    let key = Keypair::from_seed(&[143; 32]);
    for (name, original) in fixture["grant"]["body"]["recovery"]
        .as_object()
        .ok_or("binding")?
    {
        if matches!(name.as_str(), "schema" | "version") {
            continue;
        }
        let mut body = fixture["grant"]["body"].clone();
        body["recovery"][name] = match original {
            serde_json::Value::Array(_) => serde_json::to_value(vec![99; 32])?,
            serde_json::Value::Number(_) => serde_json::json!(999),
            _ => serde_json::json!("foreign-context"),
        };
        let changed = SignedRecoveryGrantV2::sign(serde_json::from_value(body)?, &key)?;
        assert!(
            changed.verify_signature()?,
            "resigned mutation lost crypto: {name}"
        );
        assert_eq!(
            verify_recovery_declassification(&changed, &request, &expected, &coverage).err(),
            Some(DeclassificationError::BindingMismatch),
            "wrong invariant: {name}"
        );
    }
    let mut other = request.clone();
    other.destination_id = DestinationId::new("foreign-recipient")?;
    assert_eq!(
        verify_recovery_declassification(&grant, &other, &expected, &coverage).err(),
        Some(DeclassificationError::BindingMismatch)
    );
    let mut other = request.clone();
    other.trusted_authorities = BTreeMap::from([(
        RecordId::new(claims.authority_key_id().as_str())?,
        Keypair::from_seed(&[99; 32]).public_key(),
    )]);
    assert_eq!(
        verify_recovery_declassification(&grant, &other, &expected, &coverage).err(),
        Some(DeclassificationError::UntrustedAuthority)
    );
    let mut expired = request;
    expired.now_unix_ms = claims.expires_at_unix_seconds() * 1000;
    assert_eq!(
        verify_recovery_declassification(&grant, &expired, &expected, &coverage).err(),
        Some(DeclassificationError::Expired)
    );
    Ok(())
}
