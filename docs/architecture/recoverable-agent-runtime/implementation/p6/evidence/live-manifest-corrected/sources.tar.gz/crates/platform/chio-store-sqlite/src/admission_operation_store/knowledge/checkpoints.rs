use super::*;
fn checkpoint_key(
    scope: &RecoveryScopeV1,
    id: &CheckpointId,
) -> Result<String, AdmissionOperationStoreError> {
    Ok(format!(
        "knowledge-checkpoint:{}:{}",
        scope_key(scope)?,
        id.as_str()
    ))
}
impl SqliteAdmissionOperationStore {
    pub fn save_labeled_checkpoint(
        &self,
        actor: &AuthenticatedRecoveryActor,
        update: NativeCheckpointUpdate<'_>,
        fence: &StoreMutationFence,
        now: u64,
    ) -> Result<LabeledCheckpointV1, AdmissionOperationStoreError> {
        let NativeCheckpointUpdate {
            checkpoint: id,
            expected_revision: expected,
            artifacts,
            model_contexts: models,
        } = update;
        if actor.permission() != RecoveryPermission::KnowledgeWrite {
            return Err(refused("checkpoint authority"));
        }
        mutate(self, actor, fence, now, |tx, profile, _| {
            let key = checkpoint_key(actor.scope(), id)?;
            let old: Option<LabeledCheckpointV1> = load(&tx, &key)?;
            if old.as_ref().map_or(0, |old| old.revision.get()) != expected {
                return Err(refused("checkpoint CAS"));
            }
            let roots = NonEmptyBoundedList::new(artifacts.to_vec()).map_err(refused)?;
            let models = BoundedList::new(models.to_vec()).map_err(refused)?;
            for context in models.as_slice() {
                if !profile.recipients.as_slice().iter().any(|selection| {
                    selection.recipient.sink
                        == (ArtifactSinkV1::Model {
                            context: context.clone(),
                        })
                }) {
                    return Err(refused("unselected model context"));
                }
            }
            let mut deps = artifacts.to_vec();
            for model in models.as_slice() {
                deps.extend_from_slice(model.side_files.as_slice());
            }
            let records = traversal::dependencies(&tx, actor.scope(), &deps)?;
            let label = traversal::join_metadata(
                source(&tx, &profile.native_authority, &profile.producer_context)?,
                &records,
            )?;
            let native_evidence: i64 = tx
                .query_row(
                    "SELECT COALESCE(max(commit_sequence),0) FROM authority_global_commits",
                    [],
                    |row| row.get(0),
                )
                .map_err(sqlite_error)?;
            let checkpoint = LabeledCheckpointV1 {
                domain_version: VersionV1,
                checkpoint: id.clone(),
                revision: SafeInteger::new(
                    expected
                        .checked_add(1)
                        .ok_or_else(|| refused("revision overflow"))?,
                )
                .map_err(refused)?,
                scope: actor.scope().clone(),
                runtime: ProtectedText::new(profile.producer_context.as_v1().session_id().as_str())
                    .map_err(refused)?,
                artifacts: roots,
                model_contexts: models,
                label,
                influence: traversal::influence(
                    &tx,
                    &profile.native_authority,
                    &profile.producer_context,
                    &records,
                    false,
                )?,
                lineage: IsolationLineageId::new(
                    profile.producer_context.as_v1().lineage_root_id().as_str(),
                )
                .map_err(refused)?,
                isolation_epoch: ProtectedText::new(
                    profile
                        .producer_context
                        .as_v1()
                        .isolation_epoch_id()
                        .as_str(),
                )
                .map_err(refused)?,
                native_evidence_sequence: SafeInteger::new(
                    u64::try_from(native_evidence).map_err(refused)?,
                )
                .map_err(refused)?,
                policy: profile.policy,
            };
            checkpoint.validate().map_err(refused)?;
            traversal::ensure_audience(&tx, actor, &checkpoint.label)?;
            save(&tx, &self.serving_owner, actor.scope(), &key, &checkpoint)?;
            // Revisions remain individually pinned and restorable. GC cannot
            // discard references required by an older retained checkpoint.
            save(
                &tx,
                &self.serving_owner,
                actor.scope(),
                &format!("{key}:{}", checkpoint.revision.get()),
                &checkpoint,
            )?;
            Ok((tx, checkpoint))
        })
    }
    /// Returns only a current audience-checked labeled envelope, never bytes.
    pub fn read_labeled_checkpoint(
        &self,
        actor: &AuthenticatedRecoveryActor,
        id: &CheckpointId,
        revision: u64,
        fence: &StoreMutationFence,
        now: u64,
    ) -> Result<LabeledCheckpointV1, AdmissionOperationStoreError> {
        if actor.permission() != RecoveryPermission::KnowledgeRead {
            return Err(refused("checkpoint read authority"));
        }
        mutate(self, actor, fence, now, |tx, profile, _| {
            let key = if revision == 0 {
                checkpoint_key(actor.scope(), id)?
            } else {
                format!("{}:{revision}", checkpoint_key(actor.scope(), id)?)
            };
            let checkpoint: LabeledCheckpointV1 =
                load(&tx, &key)?.ok_or_else(|| refused("checkpoint absent"))?;
            checkpoint.validate().map_err(refused)?;
            if checkpoint.scope != *actor.scope()
                || checkpoint.runtime.as_str()
                    != profile.producer_context.as_v1().session_id().as_str()
                || checkpoint.lineage.as_str()
                    != profile.producer_context.as_v1().lineage_root_id().as_str()
                || checkpoint.isolation_epoch.as_str()
                    != profile
                        .producer_context
                        .as_v1()
                        .isolation_epoch_id()
                        .as_str()
                || checkpoint.policy != profile.policy
            {
                return Err(refused("checkpoint identity"));
            }
            traversal::ensure_audience(&tx, actor, &checkpoint.label)?;
            for context in checkpoint.model_contexts.as_slice() {
                if !profile.recipients.as_slice().iter().any(|entry| {
                    entry.recipient.sink
                        == (ArtifactSinkV1::Model {
                            context: context.clone(),
                        })
                }) {
                    return Err(refused("provider context changed"));
                }
            }
            traversal::dependencies(&tx, actor.scope(), checkpoint.artifacts.as_slice())?;
            Ok((tx, checkpoint))
        })
    }
}

#[derive(Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct RestoreRecord {
    checkpoint: LabeledCheckpointV1,
    recipient: ArtifactRecipientV1,
    intent: ArtifactReleaseIntentV1,
}
impl SqliteAdmissionOperationStore {
    /// One durable restore observation covers the entire checkpoint and remote
    /// context envelope before reconstruction or any artifact byte delivery.
    pub fn admit_checkpoint_restore(
        &self,
        actor: &AuthenticatedRecoveryActor,
        checkpoint: &LabeledCheckpointV1,
        recipient: &ArtifactRecipientId,
        request: &RequestId,
        fence: &StoreMutationFence,
        now: u64,
    ) -> Result<ArtifactReleaseIntentV1, AdmissionOperationStoreError> {
        if actor.permission() != RecoveryPermission::KnowledgeRead {
            return Err(refused("restore authority"));
        }
        mutate(self, actor, fence, now, |tx, profile, now| {
            let retained: LabeledCheckpointV1 = load(
                &tx,
                &format!(
                    "{}:{}",
                    checkpoint_key(actor.scope(), &checkpoint.checkpoint)?,
                    checkpoint.revision.get()
                ),
            )?
            .ok_or_else(|| refused("restore checkpoint"))?;
            if retained != *checkpoint
                || checkpoint.scope != *actor.scope()
                || checkpoint.policy != profile.policy
                || checkpoint.runtime.as_str()
                    != profile.producer_context.as_v1().session_id().as_str()
                || checkpoint.lineage.as_str()
                    != profile.producer_context.as_v1().lineage_root_id().as_str()
                || checkpoint.isolation_epoch.as_str()
                    != profile
                        .producer_context
                        .as_v1()
                        .isolation_epoch_id()
                        .as_str()
            {
                return Err(refused("restore envelope changed"));
            }
            let entry = profile
                .recipients
                .as_slice()
                .iter()
                .find(|entry| &entry.recipient.recipient == recipient)
                .ok_or_else(|| refused("restore recipient"))?;
            let mut roots = checkpoint.artifacts.as_slice().to_vec();
            for model in checkpoint.model_contexts.as_slice() {
                if !profile.recipients.as_slice().iter().any(|entry| {
                    entry.recipient.sink
                        == (ArtifactSinkV1::Model {
                            context: model.clone(),
                        })
                }) {
                    return Err(refused("remote context changed"));
                }
                roots.extend_from_slice(model.side_files.as_slice());
            }
            if let ArtifactSinkV1::Model { context } = &entry.recipient.sink {
                roots.extend_from_slice(context.side_files.as_slice());
            }
            let dependencies = traversal::dependencies(&tx, actor.scope(), &roots)?;
            let label = traversal::join_metadata(checkpoint.label.clone(), &dependencies)?;
            traversal::ensure_audience(&tx, actor, &label)?;
            if !label.flows_to(&entry.recipient.clearance) {
                return Err(refused("restore audience"));
            }
            let key = format!(
                "knowledge-restore:{}:{}",
                scope_key(actor.scope())?,
                request.as_str()
            );
            let authorization = CapabilityBodyDigest::from_bytes(
                knowledge_digest(b"chio.knowledge.read-authority.v1\0", actor.capability())
                    .map_err(refused)?,
            );
            if let Some(old) = load::<RestoreRecord>(&tx, &key)? {
                if old.checkpoint != *checkpoint
                    || old.recipient != entry.recipient
                    || old.intent.authorization != authorization
                {
                    return Err(refused("restore identity changed"));
                }
                return Ok((tx, old.intent));
            }
            let id = ReleaseId::new(&uuid::Uuid::new_v4().to_string()).map_err(refused)?;
            let intent = ArtifactReleaseIntentV1 {
                domain_version: VersionV1,
                release: id.clone(),
                kind: ArtifactReleaseKindV1::IndependentlyAdmitted {
                    request: request.clone(),
                },
                artifact: checkpoint.artifacts.as_slice()[0].clone(),
                influence: traversal::influence(
                    &tx,
                    &profile.native_authority,
                    &entry.context,
                    &dependencies,
                    checkpoint.influence.unknown,
                )?,
                source_label: label.clone(),
                admitted_label: label.clone(),
                recipient: entry.recipient.clone(),
                policy: profile.policy,
                authorization,
                observation_transition: EvidenceRef::new(&format!("knowledge:{}", id.as_str()))
                    .map_err(refused)?,
                observation_generation: SafeInteger::new(0).map_err(refused)?,
                state: ArtifactDeliveryStateV1::Admitted,
            };
            let (tx, intent) = super::super::security_participant_state::knowledge::join(
                tx,
                &self.serving_owner,
                super::super::security_participant_state::knowledge::KnowledgeJoin {
                    binding: &profile.native_authority,
                    key: &recovery_flow_key(&entry.context),
                    source: &label,
                    scope: actor.scope(),
                    release: intent,
                    now,
                },
            )?;
            save(
                &tx,
                &self.serving_owner,
                actor.scope(),
                &key,
                &RestoreRecord {
                    checkpoint: checkpoint.clone(),
                    recipient: entry.recipient.clone(),
                    intent: intent.clone(),
                },
            )?;
            Ok((tx, intent))
        })
    }
}
