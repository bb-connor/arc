"""Explicit supervisor must preserve original identity and fresh refusal."""
import asyncio
import unittest
import httpx
from campaign_baseline import SupervisorSession


class BaselineTest(unittest.TestCase):
    def test_no_fallback_or_hidden_retry_after_authoritative_refusal(self):
        requests = []
        def endpoint(request):
            requests.append(request.content)
            return httpx.Response(403, content=b"private-provider-canary")
        session = SupervisorSession("http://127.0.0.1:20096", "private-credential-canary", b'{"owned":"native"}',
                                    transport=httpx.MockTransport(endpoint))
        for _ in range(2):
            outcome = asyncio.run(session.execute("resume"))
            self.assertEqual(outcome.as_dict(), {"category":"refused"})
        self.assertEqual(len(requests), 2)
        self.assertEqual(requests[0], requests[1])
        self.assertEqual(session.attempts, 2)
        self.assertNotIn("canary", repr(session))


if __name__ == "__main__": unittest.main()
