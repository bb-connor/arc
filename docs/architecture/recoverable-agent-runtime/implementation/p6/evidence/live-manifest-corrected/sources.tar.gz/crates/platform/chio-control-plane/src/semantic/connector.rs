use super::transport::canonical_endpoint;
use super::*;
use chio_kernel::{
    NestedFlowBridge, ToolInvocationContext, ToolInvocationCost, ToolServerConnection,
};
use chio_semantic_contracts::{project_semantic_fields, VerificationBudget};
use serde_json::Value;

/// A single native submission, constructed only after the protected dispatch
/// check. Wire data and cloned request descriptions cannot construct this owner.
/// It is Send for the supervised kernel task and deliberately not Sync.
/// ```compile_fail
/// use chio_control_plane::semantic::CapturedSemanticSubmissionV1;
/// fn requires_sync<T: Sync>() {}
/// requires_sync::<CapturedSemanticSubmissionV1>();
/// ```
/// ```compile_fail
/// use chio_control_plane::semantic::CapturedSemanticSubmissionV1;
/// fn duplicate(value: CapturedSemanticSubmissionV1) { let _ = value.clone(); }
/// ```
/// ```compile_fail
/// use chio_control_plane::semantic::CapturedSemanticSubmissionV1;
/// fn parse() -> Result<CapturedSemanticSubmissionV1, serde_json::Error> { serde_json::from_str("{}") }
/// ```
pub struct CapturedSemanticSubmissionV1 {
    request: SemanticTransportRequestV1,
    _exclusive: core::marker::PhantomData<core::cell::Cell<()>>,
}
impl CapturedSemanticSubmissionV1 {
    fn new(request: SemanticTransportRequestV1) -> Self {
        Self {
            request,
            _exclusive: core::marker::PhantomData,
        }
    }
    pub fn request(&self) -> &SemanticTransportRequestV1 {
        &self.request
    }
    pub fn into_request(self) -> SemanticTransportRequestV1 {
        self.request
    }
}
impl std::fmt::Debug for CapturedSemanticSubmissionV1 {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str("CapturedSemanticSubmissionV1([redacted])")
    }
}

pub struct PinnedSemanticConnector {
    route: SemanticRouteV1,
    contract: SemanticOperationContractV1,
    store: Arc<SqliteAdmissionOperationStore>,
    transport: Arc<dyn SemanticTransport>,
    capacity: Arc<tokio::sync::Semaphore>,
}
impl std::fmt::Debug for PinnedSemanticConnector {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str("PinnedSemanticConnector([redacted])")
    }
}
impl PinnedSemanticConnector {
    pub fn new(
        route: SemanticRouteV1,
        contract: SemanticOperationContractV1,
        store: Arc<SqliteAdmissionOperationStore>,
        transport: Arc<dyn SemanticTransport>,
    ) -> Result<Self, KernelError> {
        chio_semantic_contracts::validate_semantic_channels(
            contract.channels.as_slice(),
            &mut VerificationBudget::new(4096).map_err(|_| refused())?,
        )
        .map_err(|_| refused())?;
        if route.operation != contract.operation
            || route.implementation != contract.implementation
            || route.input_schema != contract.input_schema
            || route.output_schema != contract.output_schema
        {
            return Err(refused());
        }
        for destination in route.destinations.as_slice() {
            canonical_endpoint(destination.endpoint.as_str())?;
            if destination.require_provider_precondition
                && contract.kind != SemanticOperationKindV1::FieldProjection
                && transport.precondition_guarantee()
                    != ProviderPreconditionGuaranteeV1::AtomicIfMatch
            {
                return Err(refused());
            }
        }
        Ok(Self {
            route,
            contract,
            store,
            transport,
            capacity: Arc::new(tokio::sync::Semaphore::new(8)),
        })
    }
    async fn invoke_native(
        &self,
        context: &ToolInvocationContext,
        arguments: Value,
        nested: Option<&mut dyn NestedFlowBridge>,
    ) -> Result<Value, KernelError> {
        if nested.is_some()
            || context.server_id() != self.route.server.as_str()
            || context.tool_name() != self.route.tool.as_str()
        {
            return Err(refused());
        }
        let dispatch = context.dispatch().ok_or_else(refused)?;
        // Reserve before spawning, and keep capacity owned by the worker if its
        // waiter is cancelled. The kernel supervises this native dispatch task.
        let slot = self
            .capacity
            .clone()
            .try_acquire_owned()
            .map_err(|_| refused())?;
        let store = self.store.clone();
        let operation = dispatch.operation_id().to_owned();
        let request_id = dispatch.request_id().to_owned();
        let capability = dispatch
            .caller_capability_sha256()
            .ok_or_else(refused)?
            .to_owned();
        let (captured, _slot) = tokio::task::spawn_blocking(move || {
            store
                .semantic_dispatch_capture(&operation, &request_id, &capability)
                .map(|captured| (captured, slot))
                .map_err(|_| refused())
        })
        .await
        .map_err(|_| refused())??;
        if captured.route != self.route
            || captured.contract != self.contract
            || serde_json::to_value(&captured.invocation).map_err(|_| refused())? != arguments
        {
            return Err(refused());
        }
        let output = if self.contract.kind == SemanticOperationKindV1::FieldProjection {
            project_semantic_fields(
                &captured.invocation.payload,
                self.contract.projection_fields.as_slice(),
                &mut VerificationBudget::new(4096).map_err(|_| refused())?,
            )
            .map_err(|_| refused())?
        } else {
            let destination = self
                .route
                .destinations
                .as_slice()
                .iter()
                .find(|dest| dest.destination == captured.invocation.action.destination)
                .ok_or_else(refused)?
                .clone();
            self.transport
                .submit(CapturedSemanticSubmissionV1::new(
                    SemanticTransportRequestV1 {
                        kind: self.contract.kind,
                        destination,
                        provider_version: captured
                            .invocation
                            .audience
                            .body()
                            .provider_version
                            .clone(),
                        operation: captured.operation_id,
                        attempt: ProtectedText::new(dispatch.attempt_id())
                            .map_err(|_| refused())?,
                        payload: captured.invocation.payload,
                    },
                ))
                .await
                .map_err(|_| refused())?
        };
        let bytes = chio_core_types::canonical_json_bytes(&output).map_err(|_| refused())?;
        if bytes.len() > MAX_RECOVERY_WIRE_BYTES {
            return Err(refused());
        }
        serde_json::to_value(output).map_err(|_| refused())
    }
}
#[async_trait::async_trait]
impl ToolServerConnection for PinnedSemanticConnector {
    fn server_id(&self) -> &str {
        self.route.server.as_str()
    }
    fn tool_names(&self) -> Vec<String> {
        vec![self.route.tool.as_str().into()]
    }
    fn tool_is_read_only(&self, tool: &str) -> bool {
        tool == self.route.tool.as_str()
            && self.contract.kind != SemanticOperationKindV1::IssueWrite
    }
    async fn invoke(
        &self,
        _: &str,
        _: Value,
        _: Option<&mut dyn NestedFlowBridge>,
    ) -> Result<Value, KernelError> {
        Err(refused())
    }
    async fn invoke_with_context(
        &self,
        context: &ToolInvocationContext,
        arguments: Value,
        nested: Option<&mut dyn NestedFlowBridge>,
    ) -> Result<Value, KernelError> {
        self.invoke_native(context, arguments, nested).await
    }
    async fn invoke_with_cost_and_context(
        &self,
        context: &ToolInvocationContext,
        arguments: Value,
        nested: Option<&mut dyn NestedFlowBridge>,
    ) -> Result<(Value, Option<ToolInvocationCost>), KernelError> {
        Ok((self.invoke_native(context, arguments, nested).await?, None))
    }
}
