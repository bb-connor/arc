"""Source archives must preserve every byte, identity and complete inventory."""
import hashlib
import io
import tarfile
import tempfile
import unittest
from pathlib import Path

from package_sources import audit_archive


class SourceArchiveTest(unittest.TestCase):
    def test_changed_missing_duplicate_extra_and_link_members_refuse(self):
        content = b"actual source\n"
        expected = [{"path": "crate/src.rs", "sha256": hashlib.sha256(content).hexdigest()}]
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "sources.tar.gz"
            for mutation in [None, "changed", "missing", "duplicate", "extra", "link"]:
                with tarfile.open(path, "w:gz") as archive:
                    if mutation != "missing":
                        entry = tarfile.TarInfo("crate/src.rs")
                        payload = b"altered source\n" if mutation == "changed" else content
                        if mutation == "link":
                            entry.type = tarfile.SYMTYPE
                            entry.linkname = "outside"
                        else:
                            entry.size = len(payload)
                        archive.addfile(entry, io.BytesIO(payload))
                        if mutation == "duplicate":
                            archive.addfile(entry, io.BytesIO(payload))
                    if mutation == "extra":
                        entry = tarfile.TarInfo("undeclared.rs")
                        entry.size = len(content)
                        archive.addfile(entry, io.BytesIO(content))
                if mutation is None:
                    self.assertEqual(audit_archive(path, expected), 1)
                else:
                    with self.assertRaises(ValueError, msg=mutation):
                        audit_archive(path, expected)


if __name__ == "__main__":
    unittest.main()
