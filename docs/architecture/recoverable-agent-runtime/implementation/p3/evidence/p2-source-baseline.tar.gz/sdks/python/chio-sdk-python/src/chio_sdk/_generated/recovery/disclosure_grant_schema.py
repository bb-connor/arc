# DO NOT EDIT - regenerate via 'cargo xtask codegen --lang python'.
#
# Source: spec/schemas/chio-wire/v1/**/*.schema.json
# Tool:   datamodel-code-generator==0.34.0 (see xtask/codegen-tools.lock.toml)
# Schema sha256: 2b639a02128e052166171fa92c3cd625bcbe4a23e9a2f3d7136ee50411b7288c
#
# Manual edits will be overwritten by the next regeneration; the
# spec-drift CI lane enforces this header on every file
# under sdks/python/chio-sdk-python/src/chio_sdk/_generated/.


from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, RootModel

from ..security import declassification_grant_schema
from . import signed_grant_v2_schema


class VersionSelectedDisclosureGrant1(BaseModel):
    model_config = ConfigDict(
        extra="forbid",
    )
    kind: Literal["recovery_v2"]
    grant: signed_grant_v2_schema.SignedRecoveryDeclassificationGrantV2


class VersionSelectedDisclosureGrant(
    RootModel[
        declassification_grant_schema.SignedDeclassificationGrant
        | VersionSelectedDisclosureGrant1
    ]
):
    root: (
        declassification_grant_schema.SignedDeclassificationGrant
        | VersionSelectedDisclosureGrant1
    ) = Field(..., title="Version selected disclosure grant")
