# DO NOT EDIT - regenerate via 'cargo xtask codegen --lang python'.
#
# Source: spec/schemas/chio-wire/v1/**/*.schema.json
# Tool:   datamodel-code-generator==0.34.0 (see xtask/codegen-tools.lock.toml)
# Schema sha256: 2b639a02128e052166171fa92c3cd625bcbe4a23e9a2f3d7136ee50411b7288c
#
# Manual edits will be overwritten by the next regeneration; the
# spec-drift CI lane enforces this header on every file
# under sdks/python/chio-sdk-python/src/chio_sdk/_generated/.


from __future__ import annotations

from enum import Enum

from pydantic import BaseModel, ConfigDict, Field, RootModel, constr

from . import key_log_event_body_v1_schema


class Hash(RootModel[constr(pattern=r"^0x[0-9a-f]{64}$")]):
    root: constr(pattern=r"^0x[0-9a-f]{64}$")


class Algorithm(Enum):
    ed25519 = "ed25519"
    p256 = "p256"
    p384 = "p384"
    hybrid = "hybrid"


class Signature(
    RootModel[
        constr(
            pattern=r"^([0-9a-f]{128}|p256:[0-9a-f]+|p384:[0-9a-f]+|hybrid:([0-9a-f]{128}|p256:[0-9a-f]+|p384:[0-9a-f]+):[0-9a-f]{6618}:(ed25519|p256|p384)\+mldsa65)$"
        )
    ]
):
    root: constr(
        pattern=r"^([0-9a-f]{128}|p256:[0-9a-f]+|p384:[0-9a-f]+|hybrid:([0-9a-f]{128}|p256:[0-9a-f]+|p384:[0-9a-f]+):[0-9a-f]{6618}:(ed25519|p256|p384)\+mldsa65)$"
    )


class KeyLogIdentifier(
    RootModel[constr(pattern=r"^[A-Za-z0-9._:/-]+$", min_length=1, max_length=128)]
):
    root: constr(pattern=r"^[A-Za-z0-9._:/-]+$", min_length=1, max_length=128)


class KeyAuthorization(BaseModel):
    model_config = ConfigDict(
        extra="forbid",
    )
    key_id: Hash
    algorithm: Algorithm
    signature: Signature


class RecoveryAuthorization(BaseModel):
    model_config = ConfigDict(
        extra="forbid",
    )
    authorizer_id: KeyLogIdentifier
    algorithm: Algorithm
    signature: Signature


class Authorizations(BaseModel):
    model_config = ConfigDict(
        extra="forbid",
    )
    bootstrap: KeyAuthorization | None = None
    old_key: KeyAuthorization | None = None
    new_key: KeyAuthorization | None = None
    recovery: list[RecoveryAuthorization] | None = Field(None, max_length=64)


class ChioSignedKeyLogEventEnvelopeV1(BaseModel):
    model_config = ConfigDict(
        extra="forbid",
    )
    body: key_log_event_body_v1_schema.ChioKeyLogEventBodyV1
    authorizations: Authorizations
