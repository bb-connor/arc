"""Thin transport for the Rust recovery host. No local authority decisions."""
from __future__ import annotations

import json
from urllib.parse import urlsplit
import httpx
from ._generated.recovery.command_schema import RecoveryCommandV1
from ._generated.recovery.command_result_schema import RecoveryCommandResultV1
from ._generated.recovery.command_response_schema import RecoveryCommandResponseV1
from ._generated.recovery.review_document_schema import RecoveryReviewDocumentV1
from ._generated.recovery.signed_explanation_view_schema import RecoverySignedExplanationViewV1
from pydantic import BaseModel, ValidationError
from typing import TypeVar

ResponseModel = TypeVar("ResponseModel", bound=BaseModel)


class RecoveryClient:
    def __init__(self, endpoint: str, *, transport: httpx.AsyncBaseTransport | None = None):
        try:
            url = urlsplit(endpoint)
            # Accessing the port also validates a malformed authority.
            _ = url.port
        except ValueError:
            raise ValueError("recovery.invalid_endpoint") from None
        local = url.hostname in {"localhost", "127.0.0.1", "::1"}
        if not url.hostname or (url.scheme != "https" and not (url.scheme == "http" and local)) or url.username or url.password or url.query or url.fragment:
            raise ValueError("recovery.invalid_endpoint")
        # Match the CLI and TypeScript client: protocol routes start at the
        # selected origin, independently of a presentation path in the URL.
        origin = url._replace(path="", query="", fragment="").geturl()
        self._http = httpx.AsyncClient(base_url=origin, transport=transport, timeout=20, follow_redirects=False)

    async def aclose(self) -> None:
        await self._http.aclose()

    async def execute(self, capability: str, command: RecoveryCommandV1 | bytes) -> RecoveryCommandResultV1:
        # Callers may supply the canonical Rust-produced command bytes directly.
        if isinstance(command, bytes):
            try:
                canonical = command.decode("utf-8")
            except UnicodeError:
                raise ValueError("recovery.invalid_command") from None
        else:
            data = command.model_dump(mode="json", by_alias=True)
            # All command object keys are ASCII and numeric fields are safe
            # integers. The embedded seed/approval is an exact canonical string.
            canonical = json.dumps(data, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False)
        return await self._post("commands", {"capability": capability, "command": canonical}, RecoveryCommandResultV1)

    async def review(self, capability: str, workflow_id: str) -> RecoveryReviewDocumentV1:
        return await self._post("review", {"capability": capability, "workflow_id": workflow_id}, RecoveryReviewDocumentV1)

    async def explain(self, capability: str, workflow_id: str) -> RecoverySignedExplanationViewV1:
        """Retrieve signed audience-safe advice; the host rechecks authority on resume."""
        return await self._post("explain", {"capability": capability, "workflow_id": workflow_id}, RecoverySignedExplanationViewV1)

    async def settle(self, capability: str, workflow_id: str) -> RecoveryCommandResponseV1:
        return await self._post("settle", {"capability": capability, "workflow_id": workflow_id}, RecoveryCommandResponseV1)

    async def _post(self, path: str, envelope: dict[str, str], model: type[ResponseModel]) -> ResponseModel:
        wire = json.dumps(envelope, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False).encode("utf-8")
        if len(wire) > 65536:
            raise ValueError("recovery.resource_exhausted")
        # The default HTTPX transport has no retries. Caller-provided transports
        # must retain this contract; the SDK itself never resubmits an operation.
        try:
            async with self._http.stream("POST", f"/v1/recovery/{path}", content=wire, headers={"content-type": "application/json"}) as response:
                if not response.is_success:
                    raise RuntimeError("recovery.refused_or_unavailable")
                data = bytearray()
                async for chunk in response.aiter_bytes():
                    if len(data) + len(chunk) > 262144:
                        raise ValueError("recovery.resource_exhausted")
                    data.extend(chunk)
                try:
                    return model.model_validate_json(data, strict=True)
                except (ValueError, UnicodeError, ValidationError):
                    raise RuntimeError("recovery.invalid_response") from None
        except httpx.HTTPError:
            raise RuntimeError("recovery.unavailable") from None
