//! Shared bounded HTTP transport. Rust alone owns recovery transitions.
use super::{RecoveryCommandResultV1, RecoveryRuntime, RecoveryRuntimeError};
use axum::{
    body::Bytes,
    extract::{DefaultBodyLimit, State},
    http::StatusCode,
    response::IntoResponse,
    routing::post,
    Router,
};
use chio_core_types::recovery::{decode_contract, decode_recovery_capability};
use chio_security_types::recovery::{ProtectedText, WorkflowId, MAX_RECOVERY_WIRE_BYTES};
use serde::{Deserialize, Serialize};
use std::sync::Arc;
use tokio::sync::Semaphore;

#[derive(Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct RecoveryTransportRequestV1 {
    pub capability: ProtectedText<32768>,
    pub command: ProtectedText<32768>,
}
#[derive(Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct RecoveryReviewRequestV1 {
    capability: ProtectedText<32768>,
    workflow_id: WorkflowId,
}
impl core::fmt::Debug for RecoveryTransportRequestV1 {
    fn fmt(&self, f: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        f.write_str("RecoveryTransportRequestV1([redacted])")
    }
}
/// Mount only on the host's authenticated private control listener. The scoped
/// signed capability is reverified inside every handler and owning mutation.
#[derive(Clone)]
struct RecoveryHost {
    runtime: Arc<RecoveryRuntime>,
    intake: Arc<Semaphore>,
    settlement: Arc<Semaphore>,
}

pub fn recovery_router(runtime: Arc<RecoveryRuntime>) -> Router {
    let host = RecoveryHost {
        runtime,
        intake: Arc::new(Semaphore::new(4)),
        settlement: Arc::new(Semaphore::new(2)),
    };
    Router::new()
        .route("/v1/recovery/commands", post(command))
        .route("/v1/recovery/review", post(review))
        .route("/v1/recovery/settle", post(settle))
        .layer(DefaultBodyLimit::max(MAX_RECOVERY_WIRE_BYTES))
        .with_state(host)
}
pub(super) fn response<T: Serialize>(
    result: Result<T, RecoveryRuntimeError>,
) -> axum::response::Response {
    match result {
        Ok(value) => match chio_core_types::canonical_json_bytes(&value) {
            Ok(bytes) if bytes.len() <= 262144 => (
                StatusCode::OK,
                [("content-type", "application/json")],
                bytes,
            )
                .into_response(),
            _ => (StatusCode::SERVICE_UNAVAILABLE, "recovery.unavailable").into_response(),
        },
        Err(error) => {
            let (status, category) = match error {
                RecoveryRuntimeError::InvalidCommand => {
                    (StatusCode::BAD_REQUEST, "recovery.invalid_command")
                }
                RecoveryRuntimeError::AuthorityDenied => {
                    (StatusCode::FORBIDDEN, "recovery.authority_denied")
                }
                RecoveryRuntimeError::Conflict => (StatusCode::CONFLICT, "recovery.conflict"),
                RecoveryRuntimeError::UnsupportedProfile => {
                    (StatusCode::CONFLICT, "recovery.unsupported_profile")
                }
                RecoveryRuntimeError::UnknownEffect => {
                    (StatusCode::CONFLICT, "recovery.unknown_effect")
                }
                RecoveryRuntimeError::Unavailable => {
                    (StatusCode::SERVICE_UNAVAILABLE, "recovery.unavailable")
                }
            };
            (status, category).into_response()
        }
    }
}
// No unbounded blocking work queue: reserve capacity before spawning. A
// disconnected HTTP caller cannot cancel a captured effect or cause resubmission.
// Independent settlement capacity remains available when intake is saturated.
async fn command(State(host): State<RecoveryHost>, bytes: Bytes) -> axum::response::Response {
    let Ok(permit) = host.intake.try_acquire_owned() else {
        return response::<RecoveryCommandResultV1>(Err(RecoveryRuntimeError::Unavailable));
    };
    let handle = tokio::runtime::Handle::current();
    let result = tokio::task::spawn_blocking(move || {
        let _permit = permit;
        handle.block_on(async {
            let request: RecoveryTransportRequestV1 =
                decode_contract(&bytes).map_err(|_| RecoveryRuntimeError::InvalidCommand)?;
            let capability = decode_recovery_capability(request.capability.as_str().as_bytes())
                .map_err(|_| RecoveryRuntimeError::InvalidCommand)?;
            host.runtime
                .execute(&capability, request.command.as_str().as_bytes())
                .await
        })
    })
    .await
    .unwrap_or(Err(RecoveryRuntimeError::Unavailable));
    response(result)
}
async fn review(State(host): State<RecoveryHost>, bytes: Bytes) -> axum::response::Response {
    let Ok(permit) = host.intake.try_acquire_owned() else {
        return response::<chio_kernel::recovery::RecoveryReviewDocumentV1>(Err(
            RecoveryRuntimeError::Unavailable,
        ));
    };
    let result = tokio::task::spawn_blocking(move || {
        let _permit = permit;
        let request: RecoveryReviewRequestV1 =
            decode_contract(&bytes).map_err(|_| RecoveryRuntimeError::InvalidCommand)?;
        let capability = decode_recovery_capability(request.capability.as_str().as_bytes())
            .map_err(|_| RecoveryRuntimeError::InvalidCommand)?;
        host.runtime
            .review_document(&capability, &request.workflow_id)
    })
    .await
    .unwrap_or(Err(RecoveryRuntimeError::Unavailable));
    response(result)
}
async fn settle(State(host): State<RecoveryHost>, bytes: Bytes) -> axum::response::Response {
    let Ok(permit) = host.settlement.try_acquire_owned() else {
        return response::<chio_kernel::recovery::RecoveryCommandResponseV1>(Err(
            RecoveryRuntimeError::Unavailable,
        ));
    };
    let result = tokio::task::spawn_blocking(move || {
        let _permit = permit;
        let request: RecoveryReviewRequestV1 =
            decode_contract(&bytes).map_err(|_| RecoveryRuntimeError::InvalidCommand)?;
        let capability = decode_recovery_capability(request.capability.as_str().as_bytes())
            .map_err(|_| RecoveryRuntimeError::InvalidCommand)?;
        host.runtime.settle(&capability, &request.workflow_id)
    })
    .await
    .unwrap_or(Err(RecoveryRuntimeError::Unavailable));
    response(result)
}
