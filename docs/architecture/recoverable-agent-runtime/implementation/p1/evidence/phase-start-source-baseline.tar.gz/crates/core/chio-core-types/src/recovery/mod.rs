//! Recovery's canonical intake and domain framing. No runtime or execution owner.
#![forbid(unsafe_code)]

mod decode;
mod domains;
mod preflight;

pub use decode::{decode_contract, decode_contract_with_limits, RecoveryDecodeLimits};
pub use domains::{RecoveryDigestDomain, RECOVERY_DIGEST_DOMAINS};
