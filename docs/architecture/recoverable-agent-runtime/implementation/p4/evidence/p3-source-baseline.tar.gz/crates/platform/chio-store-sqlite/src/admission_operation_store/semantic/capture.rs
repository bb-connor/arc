use super::*;
use materialization::{step_key, verify_current_prerequisites, verify_materialized_plan};

/// Private, transaction-borrowed semantic evidence cannot be decoded or reused.
pub(in crate::admission_operation_store) struct SemanticCaptureWitness {
    pub(super) record: NativeSemanticCaptureRecordV1,
    pub(super) verified: VerifiedSemanticInvocationV1,
}
impl SemanticCaptureWitness {
    pub(in crate::admission_operation_store) fn valid_until(&self) -> u64 {
        self.verified.valid_until_unix_ms
    }
}
fn spent_key(
    scope: &RecoveryScopeV1,
    evidence: &EvidenceRef,
) -> Result<String, AdmissionOperationStoreError> {
    Ok(format!(
        "semantic-spent:{}:{}",
        scope_key(scope)?,
        evidence.as_str()
    ))
}
pub(in crate::admission_operation_store) fn verify_capture_tx(
    tx: &Transaction<'_>,
    operation: &AdmissionOperationV1,
    request: &ToolCallRequest,
    binding: &NativeSecurityAuthorityBindingV1,
    context: &SecurityInvocationContext,
    now: u64,
) -> Result<Option<SemanticCaptureWitness>, AdmissionOperationStoreError> {
    let selected: Option<RecoveryScopeV1> = load(
        tx,
        &route_key(binding, context, &request.server_id, &request.tool_name)?,
    )?;
    let Some(scope) = selected else {
        if request
            .arguments
            .get("schema")
            .and_then(serde_json::Value::as_str)
            == Some("chio.semantic.invocation.v1")
        {
            return Err(refused("unconfigured semantic route"));
        }
        return Ok(None);
    };
    if stopped(tx, &scope)? {
        return Err(refused("semantic emergency stop"));
    }
    let installed = installation(tx, &scope)?;
    if installed.native_authority != *binding
        || recovery_flow_key(&installed.security_context) != recovery_flow_key(context)
        || installed.security_context.as_v1().context_generation()
            != context.as_v1().context_generation()
    {
        return Err(refused("native mapping"));
    }
    let mut budget = VerificationBudget::new(4096).map_err(refused)?;
    let registry = installed.compile_with_budget(&mut budget)?;
    let invocation: SemanticInvocationV1 =
        decode_contract(&canonical_json_bytes(&request.arguments).map_err(refused)?)
            .map_err(refused)?;
    let (route, contract) = registry
        .resolve(&request.server_id, &request.tool_name)
        .map_err(refused)?;
    let (state, _) = crate::security_state::observe_native_flow_state(
        tx,
        binding.security_authority_id().as_str(),
        &recovery_flow_key(context),
    )
    .map_err(refused)?;
    let state = state.ok_or_else(|| refused("native source absent"))?;
    let framed = &invocation.action.native_source;
    if framed.key != semantic_content_digest(&state.key).map_err(refused)? {
        return Err(refused("native source key"));
    }
    let mut original = state.clone();
    original.context_generation = framed.generation.get();
    original.principal_label = framed.principal_label.clone();
    original.lineage_label = framed.lineage_label.clone();
    original.session_label = framed.session_label.clone();
    if !super::super::security_participant_state::prove_semantic_source_history(
        tx,
        binding,
        operation.binding().operation_id(),
        &original,
        &state,
    )? {
        return Err(refused("foreign source generation"));
    }
    let source = state
        .principal_label
        .join_restrictions(&state.lineage_label)
        .and_then(|source| source.join_restrictions(&state.session_label))
        .map_err(refused)?;
    let (influence, externally_influenced) = materialization::materialized_influence(
        tx,
        &invocation,
        contract.external_influence,
        request.model_metadata.as_ref(),
        &mut budget,
    )?;
    let namespace: [u8; 32] = hex::decode(operation.binding().request_namespace_digest().as_str())
        .map_err(refused)?
        .try_into()
        .map_err(|_| refused("namespace"))?;
    let verified = verify_semantic_invocation(
        &registry,
        &invocation,
        &SemanticInvocationExpectationV1 {
            server: &request.server_id,
            tool: &request.tool_name,
            request_id: &request.request_id,
            request_namespace: RequestNamespaceDigest::from_bytes(namespace),
            capability: CapabilityBodyDigest::from_bytes(
                *semantic_content_digest(&request.capability.signing_body())
                    .map_err(refused)?
                    .as_bytes(),
            ),
            request_semantics: chio_kernel::recovery::semantic_request_semantics(request)
                .map_err(refused)?,
            source_label: &source,
            externally_influenced,
            influence,
            native_disclosure_target: request
                .declassification_grant
                .as_ref()
                .map(|grant| grant.body().target_label()),
            now_unix_ms: now,
        },
        &mut budget,
    )
    .map_err(refused)?;
    let acl = invocation.audience.body();
    let current: SignedSemanticAudienceV1 = load(
        tx,
        &audience_key(&scope, &acl.provider, &acl.account, &acl.resource)?,
    )?
    .ok_or_else(|| refused("current ACL absent"))?;
    if current != invocation.audience {
        return Err(refused("ACL changed"));
    }
    verify_materialized_plan(tx, &invocation, &mut budget)?;
    verify_current_prerequisites(tx, &invocation, now, &mut budget)?;
    if load::<NativeSemanticCaptureRecordV1>(
        tx,
        &step_key(&scope, &invocation.action.plan, &invocation.action.step)?,
    )?
    .is_some()
    {
        return Err(refused("plan step already captured"));
    }
    for evidence in verified
        .endorsement_evidence
        .iter()
        .chain(&verified.held_evidence)
    {
        if load::<OperationId>(tx, &spent_key(&scope, evidence)?)?.is_some() {
            return Err(refused("semantic evidence already consumed"));
        }
    }
    Ok(Some(SemanticCaptureWitness {
        record: NativeSemanticCaptureRecordV1 {
            operation_id: OperationId::new(operation.binding().operation_id().as_str())
                .map_err(refused)?,
            invocation,
            contract: contract.clone(),
            route: route.clone(),
            native_authority: binding.clone(),
            security_context: context.clone(),
            captured_at_unix_ms: SafeInteger::new(now).map_err(refused)?,
            valid_until_unix_ms: SafeInteger::new(verified.valid_until_unix_ms).map_err(refused)?,
        },
        verified,
    }))
}
pub(in crate::admission_operation_store) fn capture_tx(
    tx: &Transaction<'_>,
    owner: &SqliteServingOwner,
    witness: &SemanticCaptureWitness,
    operation: &AdmissionOperationV1,
) -> Result<(), AdmissionOperationStoreError> {
    let record = &witness.record;
    let scope = &record.invocation.action.scope;
    if record.operation_id.as_str() != operation.binding().operation_id().as_str()
        || operation.state() != AdmissionOperationState::DispatchCommitted
    {
        return Err(refused("capture successor"));
    }
    for evidence in witness
        .verified
        .endorsement_evidence
        .iter()
        .chain(&witness.verified.held_evidence)
    {
        save(
            tx,
            owner,
            scope,
            &spent_key(scope, evidence)?,
            "command",
            &record.operation_id,
        )?;
    }
    for prerequisite in record.invocation.prerequisites.as_slice() {
        if let Some(lease) = &prerequisite.body().lease {
            save(
                tx,
                owner,
                scope,
                &format!(
                    "semantic-lease-spent:{}:{}",
                    scope_key(scope)?,
                    lease.as_str()
                ),
                "command",
                &record.operation_id,
            )?;
        }
    }
    save(
        tx,
        owner,
        scope,
        &capture_key(record.operation_id.as_str()),
        "command",
        record,
    )?;
    save(
        tx,
        owner,
        scope,
        &step_key(
            scope,
            &record.invocation.action.plan,
            &record.invocation.action.step,
        )?,
        "command",
        record,
    )
}

impl SqliteAdmissionOperationStore {
    pub(in crate::admission_operation_store) fn captured_semantic_output_disposition(
        &self,
        operation: &AdmissionOperationV1,
        request: &ToolCallRequest,
        fence: &StoreMutationFence,
        now: u64,
    ) -> Result<Option<SemanticOutputDispositionV1>, AdmissionOperationStoreError> {
        let mut connection = self.connection()?;
        let tx = self.begin_read(&mut connection)?;
        schema::verify_active_owner(&tx, &self.serving_owner, Some(fence))?;
        schema::authority_validation_time(&tx, now)?;
        let captured: Option<NativeSemanticCaptureRecordV1> = load(
            &tx,
            &capture_key(operation.binding().operation_id().as_str()),
        )?;
        let Some(captured) = captured else {
            if request
                .arguments
                .get("schema")
                .and_then(serde_json::Value::as_str)
                == Some("chio.semantic.invocation.v1")
            {
                return Err(refused("missing semantic output custody"));
            }
            return Ok(None);
        };
        let original = retained_request::load_retained_request_tx(&tx, operation)?
            .ok_or_else(|| refused("missing retained output request"))?;
        if original.request_for_revalidation().arguments != request.arguments
            || serde_json::to_value(&captured.invocation).map_err(refused)? != request.arguments
            || canonical_json_bytes(&original.request_for_revalidation().capability)
                .map_err(refused)?
                != canonical_json_bytes(&request.capability).map_err(refused)?
            || captured.operation_id.as_str() != operation.binding().operation_id().as_str()
            || !matches!(
                operation.state(),
                AdmissionOperationState::Finalizing
                    | AdmissionOperationState::Completed
                    | AdmissionOperationState::DeniedAfterDelivery
            )
        {
            return Err(refused("output custody changed"));
        }
        super::super::security_participant_state::dispatch_ledger::verify_capture_attachment(
            &tx, operation,
        )?;
        let disposition = captured.invocation.action.output;
        if disposition == SemanticOutputDispositionV1::ReturnValue
            && stopped(&tx, &captured.invocation.action.scope)?
        {
            return Err(refused("output emergency stop"));
        }
        tx.commit().map_err(sqlite_error)?;
        Ok(Some(disposition))
    }

    /// Last local dispatch check. The original capture remains spent on refusal.
    /// Only a connection with an actual native dispatch identity may submit.
    pub fn semantic_dispatch_capture(
        &self,
        operation: &str,
        request_id: &str,
        signed_capability_hash: &str,
    ) -> Result<NativeSemanticCaptureRecordV1, AdmissionOperationStoreError> {
        let mut connection = self.connection()?;
        let tx = self.begin_write(&mut connection, None)?;
        let id = AdmissionOperationId::from_persisted(operation).map_err(refused)?;
        let stored =
            load_by_operation_id_tx(&tx, &id)?.ok_or_else(|| refused("operation absent"))?;
        if !matches!(
            stored.operation.state(),
            AdmissionOperationState::DispatchCommitted
        ) {
            return Err(refused("dispatch state"));
        }
        let record: NativeSemanticCaptureRecordV1 = load(&tx, &capture_key(operation))?
            .ok_or_else(|| refused("semantic capture absent"))?;
        let original = retained_request::load_retained_request_tx(&tx, &stored.operation)?
            .ok_or_else(|| refused("original request absent"))?;
        if record.invocation.action.request_id.as_str() != request_id
            || original.request_for_revalidation().request_id != request_id
            || sha256_hex(
                &canonical_json_bytes(&original.request_for_revalidation().capability)
                    .map_err(refused)?,
            ) != signed_capability_hash
        {
            return Err(refused("dispatch caller"));
        }
        let now = schema::observe_authority_time(&tx)?;
        let installed = installation(&tx, &record.invocation.action.scope)?;
        if stopped(&tx, &record.invocation.action.scope)?
            || installed.compile()?.digest() != record.invocation.action.registry
            || now >= record.valid_until_unix_ms.get()
        {
            return Err(refused("dispatch basis stale"));
        }
        let capability = &original.request_for_revalidation().capability;
        if now / 1000 >= capability.expires_at {
            return Err(refused("dispatch capability expired"));
        }
        for id in std::iter::once(capability.id.as_str()).chain(
            capability
                .delegation_chain
                .iter()
                .map(|link| link.capability_id.as_str()),
        ) {
            let revoked: bool = tx
                .query_row(
                    "SELECT EXISTS(SELECT 1 FROM revoked_capabilities WHERE capability_id=?1)",
                    [id],
                    |row| row.get(0),
                )
                .map_err(sqlite_error)?;
            if revoked {
                return Err(refused("dispatch capability revoked"));
            }
        }
        super::super::security_participant_state::dispatch_ledger::verify_semantic_dispatch_policy(
            &tx,
            &stored.operation,
            now,
        )?;
        materialization::verify_dispatch_prerequisites(&tx, &record, now)?;
        let acl = record.invocation.audience.body();
        let current: SignedSemanticAudienceV1 = load(
            &tx,
            &audience_key(&acl.scope, &acl.provider, &acl.account, &acl.resource)?,
        )?
        .ok_or_else(|| refused("ACL absent"))?;
        if current != record.invocation.audience || now >= acl.valid_until_unix_ms.get() {
            return Err(refused("dispatch ACL stale"));
        }
        let submitted = format!("semantic-submission:{operation}");
        if load::<OperationId>(&tx, &submitted)?.is_some() {
            return Err(refused("native submission already consumed"));
        }
        save(
            &tx,
            &self.serving_owner,
            &record.invocation.action.scope,
            &submitted,
            "command",
            &record.operation_id,
        )?;
        let final_now = schema::observe_authority_time(&tx)?;
        if final_now >= record.valid_until_unix_ms.get()
            || final_now / 1000 >= capability.expires_at
        {
            return Err(refused("submission authority expired before commit"));
        }
        super::super::security_participant_state::dispatch_ledger::verify_semantic_dispatch_policy(
            &tx,
            &stored.operation,
            final_now,
        )?;
        self.commit_write(tx)?;
        self.sync_after_write(&connection)?;
        Ok(record)
    }
}
