//! Host-only immutable blob broker. Activation disables legacy release routes.
use crate::{ProcessError, ProcessRuntime};
use chio_core_types::recovery::knowledge_content_digest;
use chio_kernel::{knowledge::*, KernelError, SecurityInvocationContext};
use chio_security_types::{knowledge::MAX_ARTIFACT_BYTES, recovery::*};

/// Trusted host implementation of the private blob staging port. Workers receive
/// only the native mediated runtime, never this broker.
#[derive(Clone)]
pub struct ProcessArtifactBroker {
    runtime: ProcessRuntime,
}
impl ProcessRuntime {
    pub(crate) fn require_raw_knowledge(&self) -> Result<(), ProcessError> {
        if self.kernel.durable_knowledge_enforced(&self.namespace)? {
            return Err(ProcessError::Configuration(
                "durable knowledge requires mediated release",
            ));
        }
        Ok(())
    }
    pub fn enable_durable_knowledge(&self) -> Result<ProcessArtifactBroker, ProcessError> {
        if self.security_profile.is_none() {
            return Err(ProcessError::Configuration(
                "native information flow is required",
            ));
        }
        self.with_store(|store| store.enable_knowledge())?;
        Ok(ProcessArtifactBroker {
            runtime: self.clone(),
        })
    }
}
fn refused(_error: impl std::fmt::Display) -> KernelError {
    KernelError::DurableAdmission("durable knowledge unavailable".into())
}
fn hex(bytes: &[u8; 32]) -> String {
    bytes.iter().map(|byte| format!("{byte:02x}")).collect()
}
impl ArtifactBlobPort for ProcessArtifactBroker {
    fn runtime_id(&self) -> &str {
        self.runtime.runtime_id()
    }
    fn validate_process(
        &self,
        process: &ProcessId,
        context: &SecurityInvocationContext,
    ) -> Result<(), KernelError> {
        self.runtime
            .with_store(|store| store.require_enforced_knowledge())
            .map_err(refused)?;
        let current = self
            .runtime
            .recovery_security_context(process.as_str())
            .map_err(refused)?;
        if current.as_v1().tenant_id() != context.as_v1().tenant_id()
            || current.as_v1().session_id() != context.as_v1().session_id()
            || current.as_v1().principal_id() != context.as_v1().principal_id()
            || current.as_v1().lineage_root_id() != context.as_v1().lineage_root_id()
            || current.as_v1().isolation_epoch_id() != context.as_v1().isolation_epoch_id()
            || current.as_v1().context_generation() != context.as_v1().context_generation()
        {
            return Err(refused("process identity"));
        }
        let lineage = self
            .runtime
            .with_store(|store| store.lineage(process.as_str()))
            .map_err(refused)?;
        for capability in &lineage {
            self.runtime
                .kernel
                .verify_retained_capability_liveness(&capability.id, &capability.subject)
                .map_err(refused)?;
        }
        Ok(())
    }
    fn stage(
        &self,
        object: &ArtifactObjectId,
        process: &ProcessId,
        bytes: &[u8],
    ) -> Result<ArtifactBlobSealV1, KernelError> {
        if bytes.len() > MAX_ARTIFACT_BYTES {
            return Err(refused("byte bound"));
        }
        let generation = self
            .runtime
            .with_store(|store| {
                store.put_mediated_blob(process.as_str(), bytes)?;
                store.knowledge_generation(
                    process.as_str(),
                    &hex(knowledge_content_digest(bytes).as_bytes()),
                )
            })
            .map_err(refused)?;
        Ok(ArtifactBlobSealV1 {
            object: object.clone(),
            runtime: ProtectedText::new(self.runtime_id()).map_err(refused)?,
            process: process.clone(),
            content: knowledge_content_digest(bytes),
            bytes: SafeInteger::new(bytes.len() as u64).map_err(refused)?,
            generation: ProtectedText::new(&generation).map_err(refused)?,
        })
    }
    fn resolve_private(
        &self,
        object: &ArtifactObjectId,
        process: &ProcessId,
        content: CanonicalPayloadDigest,
        bytes: SafeInteger,
    ) -> Result<ArtifactBlobSealV1, KernelError> {
        let generation = self
            .runtime
            .with_store(|store| {
                store.knowledge_generation(process.as_str(), &hex(content.as_bytes()))
            })
            .map_err(refused)?;
        let seal = ArtifactBlobSealV1 {
            object: object.clone(),
            runtime: ProtectedText::new(self.runtime_id()).map_err(refused)?,
            process: process.clone(),
            content,
            bytes,
            generation: ProtectedText::new(&generation).map_err(refused)?,
        };
        self.read_private(&seal)?;
        Ok(seal)
    }
    fn read_private(&self, seal: &ArtifactBlobSealV1) -> Result<Vec<u8>, KernelError> {
        if seal.runtime.as_str() != self.runtime_id()
            || seal.bytes.get() > MAX_ARTIFACT_BYTES as u64
        {
            return Err(refused("seal"));
        }
        let bytes = self
            .runtime
            .with_store(|store| {
                store.require_enforced_knowledge()?;
                store.read_knowledge_blob(
                    seal.process.as_str(),
                    &hex(seal.content.as_bytes()),
                    seal.generation.as_str(),
                )
            })
            .map_err(refused)?;
        if bytes.len() as u64 != seal.bytes.get()
            || knowledge_content_digest(&bytes) != seal.content
        {
            return Err(refused("immutable bytes"));
        }
        Ok(bytes)
    }
    fn collect_private(&self, seal: &ArtifactBlobSealV1) -> Result<(), KernelError> {
        if seal.runtime.as_str() != self.runtime_id() {
            return Err(refused("runtime"));
        }
        self.runtime
            .with_store(|store| {
                store.collect_blob(
                    seal.process.as_str(),
                    &hex(seal.content.as_bytes()),
                    seal.generation.as_str(),
                )
            })
            .map_err(refused)
    }
}
