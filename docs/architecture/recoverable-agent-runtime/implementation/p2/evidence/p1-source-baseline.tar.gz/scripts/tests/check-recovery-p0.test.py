#!/usr/bin/env python3
"""Mutation controls for the dependency guard, without altering the checkout."""

import copy
import importlib.util
import tomllib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SPEC = importlib.util.spec_from_file_location("recovery_p0", ROOT / "scripts/check-recovery-p0.py")
GUARD = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(GUARD)
NAME = "chio-recovery"
BASE = tomllib.loads((ROOT / "crates/security" / NAME / "Cargo.toml").read_text())
GUARD.validate_manifest(NAME, BASE)

for mutation in ["effect_dependency", "default_std", "enabled_defaults", "workspace_inheritance", "msrv", "std_forwarding"]:
    manifest = copy.deepcopy(BASE)
    if mutation == "effect_dependency":
        manifest["dependencies"]["chio-process"] = {"path": "../../kernel/chio-process", "default-features": False}
    elif mutation == "default_std":
        manifest["features"]["default"] = ["std"]
    elif mutation == "enabled_defaults":
        manifest["dependencies"]["chio-security-types"]["default-features"] = True
    elif mutation == "workspace_inheritance":
        manifest["dependencies"]["chio-security-types"]["workspace"] = True
    elif mutation == "msrv":
        manifest["package"]["rust-version"] = "1.94"
    else:
        manifest["features"]["std"] = []
    try:
        GUARD.validate_manifest(NAME, manifest)
    except ValueError:
        continue
    raise AssertionError(f"mutation accepted: {mutation}")
print("PASS recovery dependency guard: baseline and six rejected mutations")
