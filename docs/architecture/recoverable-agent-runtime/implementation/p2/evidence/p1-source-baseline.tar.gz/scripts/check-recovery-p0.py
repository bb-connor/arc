#!/usr/bin/env python3
"""Guard recovery dependency direction and independently resolved feature contracts.

These structural checks complement compiler, semantic tests and manual call-graph
review. They do not qualify a live recovery runtime or establish effect truth.
"""

import argparse
import json
import re
import subprocess
import tomllib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PURE = {"chio-recovery", "chio-semantic-contracts"}
PORTABLE = PURE | {"chio-core-types", "chio-security-types"}
ALLOWED = {"chio-core-types", "chio-security-types", "chio-flow", "serde"}
AMBIENT = re.compile(
    r"\b(?:std|tokio)::(?:fs|net|env|time)\b|\b(?:SystemTime|Instant|OsRng|ThreadRng)\b"
    r"|\b(?:thread_rng|random|generate_keypair|sign|now)\s*\("
)


def require(condition, message):
    if not condition:
        raise ValueError(message)


def validate_manifest(name, manifest):
    require(manifest["package"]["rust-version"] == "1.93", f"MSRV changed: {name}")
    require(manifest["features"]["default"] == [], f"pure default feature changed: {name}")
    dependencies = manifest.get("dependencies", {})
    require(set(dependencies) <= ALLOWED, f"effectful/unreviewed dependency: {name}")
    require(manifest["features"].get("std"), f"missing additive std feature: {name}")
    for dependency, declaration in dependencies.items():
        require(isinstance(declaration, dict), f"uncontrolled defaults: {name}/{dependency}")
        require(declaration.get("default-features") is False,
                f"dependency defaults enabled: {name}/{dependency}")
        require(not declaration.get("workspace"),
                f"workspace feature inheritance needs explicit review: {name}/{dependency}")
        require(f"{dependency}/std" in manifest["features"]["std"],
                f"std feature does not forward to {name}/{dependency}")


def resolved_features(std, offline):
    command = ["cargo", "metadata", "--format-version", "1", "--locked",
               "--manifest-path", "fixtures/recovery-portable-consumer/Cargo.toml",
               "--no-default-features"]
    if offline:
        command += ["--offline"]
    if std:
        command += ["--features", "std"]
    metadata = json.loads(subprocess.check_output(command, cwd=ROOT))
    packages = {package["id"]: package["name"] for package in metadata["packages"]}
    features = {packages[node["id"]]: node["features"] for node in metadata["resolve"]["nodes"]}
    for name in PORTABLE:
        require(name in features, f"isolated consumer does not include {name}")
        require(("std" in features[name]) == std, f"isolated feature drift: {name}")
    if not std:
        for name in ["serde", "serde_json", "sha2"]:
            require("std" not in features.get(name, []), f"alloc dependency enabled std: {name}")
    return {name: features[name] for name in sorted(PORTABLE)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--offline", action="store_true")
    args = parser.parse_args()
    reviewed_sources = []
    for name in sorted(PURE):
        crate = ROOT / "crates/security" / name
        manifest = tomllib.loads((crate / "Cargo.toml").read_text())
        validate_manifest(name, manifest)
        facade = (crate / "src/lib.rs").read_text()
        require('#![cfg_attr(not(feature = "std"), no_std)]' in facade,
                f"missing alloc-only facade: {name}")
        require("#![forbid(unsafe_code)]" in facade, f"unsafe baseline relaxed: {name}")
        for path in sorted((crate / "src").rglob("*.rs")):
            # Ignore prose; the production modules remain small enough for full review.
            code = "\n".join(line.split("//", 1)[0] for line in path.read_text().splitlines())
            require(not AMBIENT.search(code), f"ambient/effectful call needs review: {path}")
            reviewed_sources.append(str(path.relative_to(ROOT)))
    for name, group in [("chio-core-types", "core"), ("chio-security-types", "security")]:
        manifest = tomllib.loads((ROOT / "crates" / group / name / "Cargo.toml").read_text())
        require(manifest["package"]["rust-version"] == "1.93", f"substrate MSRV changed: {name}")
    fixture = tomllib.loads((ROOT / "fixtures/recovery-portable-consumer/Cargo.toml").read_text())
    require(set(fixture["dependencies"]) == PORTABLE, "isolated consumer inventory drift")
    require(all(item.get("default-features") is False for item in fixture["dependencies"].values()),
            "isolated consumer enabled dependency defaults")
    print(json.dumps({"status": "passed", "pure_sources": reviewed_sources,
                      "isolated_alloc_features": resolved_features(False, args.offline),
                      "isolated_std_features": resolved_features(True, args.offline)}, indent=2))


if __name__ == "__main__":
    main()
