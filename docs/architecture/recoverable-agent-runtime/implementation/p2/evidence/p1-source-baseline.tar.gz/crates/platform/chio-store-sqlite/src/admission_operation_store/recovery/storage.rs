use super::*;
use serde::{de::DeserializeOwned, Serialize};

pub(super) struct RawRecord {
    pub version: u64,
    pub payload: Vec<u8>,
}
pub(super) fn encode<T: Serialize>(value: &T) -> Result<Vec<u8>, AdmissionOperationStoreError> {
    let bytes = canonical_json_bytes(value).map_err(|_| invariant("recovery encoding refused"))?;
    if bytes.is_empty() || bytes.len() > MAX_RECOVERY_RECORD_BYTES {
        return Err(invariant("recovery resource exhausted"));
    }
    Ok(bytes)
}
pub(super) fn decode<T: DeserializeOwned + Serialize>(
    bytes: &[u8],
) -> Result<T, AdmissionOperationStoreError> {
    if bytes.is_empty() || bytes.len() > MAX_RECOVERY_RECORD_BYTES {
        return Err(invariant("recovery resource exhausted"));
    }
    let value: T =
        serde_json::from_slice(bytes).map_err(|_| invariant("recovery record is corrupt"))?;
    if encode(&value)? != bytes {
        return Err(invariant("recovery record is not exact canonical data"));
    }
    Ok(value)
}
pub(super) fn scope_key(scope: &RecoveryScopeV1) -> Result<String, AdmissionOperationStoreError> {
    Ok(sha256_hex(&encode(scope)?))
}
pub(super) fn workflow_key(
    scope: &RecoveryScopeV1,
    id: &WorkflowId,
) -> Result<String, AdmissionOperationStoreError> {
    Ok(format!("workflow:{}:{}", scope_key(scope)?, id.as_str()))
}
pub(super) fn raw(
    tx: &Connection,
    key: &str,
) -> Result<Option<RawRecord>, AdmissionOperationStoreError> {
    let row = tx.query_row(
        "SELECT version,length(payload),CASE WHEN length(payload) BETWEEN 1 AND 262144 THEN payload END,scope_key,kind,native_namespace,native_request FROM admission_operation_recovery_records WHERE record_key=?1", [key],
        |row| Ok((row.get::<_,i64>(0)?, row.get::<_,i64>(1)?, row.get::<_,Option<Vec<u8>>>(2)?,
            row.get::<_,String>(3)?, row.get::<_,String>(4)?, row.get::<_,Option<String>>(5)?, row.get::<_,Option<String>>(6)?)))
        .optional().map_err(sqlite_error)?;
    row.map(|(version,length,payload,scope,kind,namespace,request)| {
        let payload = payload.filter(|bytes| i64::try_from(bytes.len()).ok() == Some(length))
            .ok_or_else(|| invariant("recovery record exceeds its bound"))?;
        let version = stored_u64(version,"recovery version")?;
        let digest = record_digest(key, &scope, &kind, version, &payload, namespace.as_deref(), request.as_deref())?;
        let event: Option<String> = tx.query_row(
            "SELECT record_digest FROM admission_operation_recovery_events WHERE record_key=?1 AND record_version=?2",
            params![key,i64::try_from(version).map_err(|_| invariant("recovery version exhausted"))?], |row| row.get(0))
            .optional().map_err(sqlite_error)?;
        if event.as_deref() != Some(&digest) {
            return Err(invariant("recovery projection lost its event"));
        }
        Ok(RawRecord {version,payload})
    }).transpose()
}
fn record_digest(
    key: &str,
    scope: &str,
    kind: &str,
    version: u64,
    payload: &[u8],
    namespace: Option<&str>,
    request: Option<&str>,
) -> Result<String, AdmissionOperationStoreError> {
    Ok(sha256_hex(&encode(&(
        "chio.recovery.protected-record.v1",
        key,
        scope,
        kind,
        version,
        sha256_hex(payload),
        namespace,
        request,
    ))?))
}

pub(super) fn deployment_tx(
    tx: &Connection,
    scope: &RecoveryScopeV1,
) -> Result<RecoveryDeploymentV1, AdmissionOperationStoreError> {
    let row = raw(tx, &format!("deployment:{}", scope_key(scope)?))?
        .ok_or_else(|| invariant("recovery profile is unsupported"))?;
    let deployment: RecoveryDeploymentV1 = decode(&row.payload)?;
    if deployment.scope != *scope {
        return Err(invariant("recovery scope changed"));
    }
    Ok(deployment)
}
pub(super) fn workflow_tx(
    tx: &Connection,
    scope: &RecoveryScopeV1,
    id: &WorkflowId,
) -> Result<RecoveryWorkflowRecordV1, AdmissionOperationStoreError> {
    let row = raw(tx, &workflow_key(scope, id)?)?.ok_or(AdmissionOperationStoreError::NotFound)?;
    let record: RecoveryWorkflowRecordV1 = decode(&row.payload)?;
    if record.scope != *scope || record.workflow_id != *id || record.revision.get() != row.version {
        return Err(invariant("recovery scope or version changed"));
    }
    Ok(record)
}
pub(super) fn save_workflow(
    tx: &Transaction<'_>,
    owner: &SqliteServingOwner,
    record: &mut RecoveryWorkflowRecordV1,
) -> Result<(), AdmissionOperationStoreError> {
    let key = workflow_key(&record.scope, &record.workflow_id)?;
    let next = raw(tx, &key)?.map_or(Ok(1), |row| {
        row.version
            .checked_add(1)
            .ok_or_else(|| invariant("recovery version exhausted"))
    })?;
    record.revision =
        SafeInteger::new(next).map_err(|_| invariant("recovery version exhausted"))?;
    let native = record
        .admission
        .as_ref()
        .map(|intent| AdmissionOperationBindingV1::from_persisted(intent.native_binding.clone()))
        .transpose()?;
    let initial = record.action.as_ref().map(|action| {
        (
            hex(action.request_namespace.as_bytes()),
            action.request_id.as_str(),
        )
    });
    let binding = native
        .as_ref()
        .map(|binding| {
            (
                binding.request_namespace_digest().as_str(),
                binding.request_id().as_str(),
            )
        })
        .or_else(|| {
            initial
                .as_ref()
                .map(|(namespace, request)| (namespace.as_str(), *request))
        });
    save(
        tx,
        owner,
        &key,
        &scope_key(&record.scope)?,
        "workflow",
        &encode(record)?,
        binding,
    )
}
pub(super) fn save(
    tx: &Transaction<'_>,
    owner: &SqliteServingOwner,
    key: &str,
    scope: &str,
    kind: &str,
    payload: &[u8],
    native: Option<(&str, &str)>,
) -> Result<(), AdmissionOperationStoreError> {
    if payload.len() > MAX_RECOVERY_RECORD_BYTES {
        return Err(invariant("recovery record quota exhausted"));
    }
    let existing = raw(tx, key)?;
    let settlement = kind == "workflow"
        && decode::<RecoveryWorkflowRecordV1>(payload).is_ok_and(|record| {
            record.admission.is_some() || record.control != WorkflowControlV1::Active
        });
    let (retained_bytes, events): (i64, i64) = tx.query_row(
        "SELECT COALESCE(sum(length(payload)),0),(SELECT count(*) FROM admission_operation_recovery_events) FROM admission_operation_recovery_records",
        [], |row| Ok((row.get(0)?,row.get(1)?))).map_err(sqlite_error)?;
    let next_bytes = retained_bytes
        .checked_sub(existing.as_ref().map_or(0, |row| row.payload.len() as i64))
        .and_then(|bytes| bytes.checked_add(payload.len() as i64))
        .ok_or_else(|| invariant("recovery bytes exhausted"))?;
    let ceiling = if settlement {
        64 * 1024 * 1024
    } else {
        48 * 1024 * 1024
    };
    let event_ceiling = if settlement { 65536 } else { 57344 };
    if next_bytes > ceiling || events >= event_ceiling {
        return Err(invariant("recovery retained resource exhausted"));
    }
    let version = raw(tx, key)?.map_or(Ok(1), |row| {
        row.version
            .checked_add(1)
            .ok_or_else(|| invariant("recovery version exhausted"))
    })?;
    let (namespace, request) = native.map_or((None, None), |(namespace, request)| {
        (Some(namespace), Some(request))
    });
    tx.execute("INSERT INTO admission_operation_recovery_records(record_key,scope_key,kind,version,payload,native_namespace,native_request) VALUES (?1,?2,?3,?4,?5,?6,?7) ON CONFLICT(record_key) DO UPDATE SET version=excluded.version,payload=excluded.payload,native_namespace=excluded.native_namespace,native_request=excluded.native_request",params![key,scope,kind,i64::try_from(version).map_err(|_|invariant("recovery version exhausted"))?,payload,namespace,request]).map_err(sqlite_error)?;
    let head:Option<(i64,String)>=tx.query_row("SELECT sequence,event_digest FROM admission_operation_recovery_events ORDER BY sequence DESC LIMIT 1",[],|row|Ok((row.get(0)?,row.get(1)?))).optional().map_err(sqlite_error)?;
    let (sequence, previous) = head.map_or((1, "0".repeat(64)), |(sequence, digest)| {
        (sequence + 1, digest)
    });
    let sequence =
        u64::try_from(sequence).map_err(|_| invariant("recovery sequence is corrupt"))?;
    if sequence > 9007199254740991 {
        return Err(invariant("recovery history exhausted"));
    }
    let digest = record_digest(key, scope, kind, version, payload, namespace, request)?;
    let observed = super::super::schema::observe_authority_time(tx)?;
    let event = event_digest(sequence, key, version, &digest, &previous, observed)?;
    tx.execute("INSERT INTO admission_operation_recovery_events(sequence,record_key,record_version,record_digest,previous_digest,event_digest,observed_at) VALUES (?1,?2,?3,?4,?5,?6,?7)",params![i64::try_from(sequence).map_err(|_|invariant("recovery sequence exhausted"))?,key,i64::try_from(version).map_err(|_|invariant("recovery version exhausted"))?,digest,previous,event,i64::try_from(observed).map_err(|_|invariant("recovery time exhausted"))?]).map_err(sqlite_error)?;
    owner
        .append_global_commit(tx, "recovery_transition", "recovery", key, version)
        .map_err(map_owner_error)
}
fn event_digest(
    sequence: u64,
    key: &str,
    version: u64,
    digest: &str,
    previous: &str,
    observed: u64,
) -> Result<String, AdmissionOperationStoreError> {
    Ok(sha256_hex(&encode(&(
        "chio.recovery.store-event.v1",
        sequence,
        key,
        version,
        digest,
        previous,
        observed,
    ))?))
}
pub(crate) fn projection_reference(
    tx: &Connection,
    key: &str,
    version: u64,
) -> Result<String, crate::SqliteServingOwnerError> {
    tx.query_row("SELECT event_digest FROM admission_operation_recovery_events WHERE record_key=?1 AND record_version=?2",params![key,i64::try_from(version).map_err(|_|crate::SqliteServingOwnerError::Invalid("recovery version exhausted".into()))?],|row|row.get(0)).optional()?.ok_or_else(||crate::SqliteServingOwnerError::Invalid("recovery event is absent".into()))
}
pub(crate) fn verify_all(tx: &Connection) -> Result<(), AdmissionOperationStoreError> {
    let exists:bool=tx.query_row("SELECT EXISTS(SELECT 1 FROM sqlite_schema WHERE name='admission_operation_recovery_events')",[],|row|row.get(0)).map_err(sqlite_error)?;
    if !exists {
        return Ok(());
    }
    let mut previous = "0".repeat(64);
    let mut expected = 1;
    let mut high_water = 0;
    let mut statement=tx.prepare("SELECT sequence,record_key,record_version,record_digest,previous_digest,event_digest,observed_at FROM admission_operation_recovery_events ORDER BY sequence").map_err(sqlite_error)?;
    let rows = statement
        .query_map([], |row| {
            Ok((
                row.get::<_, i64>(0)?,
                row.get::<_, String>(1)?,
                row.get::<_, i64>(2)?,
                row.get::<_, String>(3)?,
                row.get::<_, String>(4)?,
                row.get::<_, String>(5)?,
                row.get::<_, i64>(6)?,
            ))
        })
        .map_err(sqlite_error)?;
    for row in rows {
        let (sequence, key, version, digest, parent, event, observed) =
            row.map_err(sqlite_error)?;
        let observed = stored_u64(observed, "recovery observed time")?;
        let sequence = stored_u64(sequence, "recovery sequence")?;
        let version = stored_u64(version, "recovery version")?;
        if observed < high_water
            || sequence != expected
            || parent != previous
            || event != event_digest(sequence, &key, version, &digest, &parent, observed)?
        {
            return Err(invariant("recovery history is corrupt"));
        }
        high_water = observed;
        previous = event;
        expected += 1;
    }
    let invalid:bool=tx.query_row("SELECT EXISTS(SELECT 1 FROM admission_operation_recovery_records r WHERE (SELECT count(*) FROM admission_operation_recovery_events e WHERE e.record_key=r.record_key)<>r.version OR (SELECT max(record_version) FROM admission_operation_recovery_events e WHERE e.record_key=r.record_key)<>r.version) OR EXISTS(SELECT 1 FROM admission_operation_recovery_events e WHERE NOT EXISTS(SELECT 1 FROM admission_operation_recovery_records r WHERE r.record_key=e.record_key))",[],|row|row.get(0)).map_err(sqlite_error)?;
    if invalid {
        return Err(invariant("recovery history coverage is incomplete"));
    }
    let mut statement = tx
        .prepare("SELECT record_key FROM admission_operation_recovery_records ORDER BY record_key")
        .map_err(sqlite_error)?;
    for key in statement
        .query_map([], |row| row.get::<_, String>(0))
        .map_err(sqlite_error)?
    {
        raw(tx, &key.map_err(sqlite_error)?)?
            .ok_or_else(|| invariant("recovery row disappeared"))?;
    }
    Ok(())
}
