//! Native admission, capture and closure use the same physical transaction.
use super::*;
use chio_security_types::ports::FlowStateSnapshot;

fn located(
    tx: &Connection,
    operation: &AdmissionOperationBindingV1,
) -> Result<Option<RecoveryWorkflowRecordV1>, AdmissionOperationStoreError> {
    let key:Option<String>=tx.query_row("SELECT record_key FROM admission_operation_recovery_records WHERE native_namespace=?1 AND native_request=?2",
        params![operation.request_namespace_digest().as_str(),operation.request_id().as_str()],|row|row.get(0)).optional().map_err(sqlite_error)?;
    key.map(|key| {
        let row = raw(tx, &key)?.ok_or_else(|| invariant("recovery ownership disappeared"))?;
        decode(&row.payload)
    })
    .transpose()
}
fn operation_ref(
    operation: &AdmissionOperationV1,
) -> Result<OperationRef, AdmissionOperationStoreError> {
    let digest = operation.binding().request_binding_hash().as_str();
    let bytes = decode_hex(digest)?;
    OperationRef::new(
        OperationId::new(operation.binding().operation_id().as_str())
            .map_err(|_| invariant("recovery operation refused"))?,
        NativeAdmissionDigest::from_bytes(bytes),
        SafeInteger::new(operation.version()).map_err(|_| invariant("recovery version refused"))?,
    )
    .map_err(|_| invariant("recovery operation refused"))
}
fn decode_hex(value: &str) -> Result<[u8; 32], AdmissionOperationStoreError> {
    if value.len() != 64 {
        return Err(invariant("recovery digest refused"));
    }
    let mut bytes = [0; 32];
    for (index, pair) in value.as_bytes().chunks_exact(2).enumerate() {
        fn nibble(byte: u8) -> Option<u8> {
            match byte {
                b'0'..=b'9' => Some(byte - b'0'),
                b'a'..=b'f' => Some(byte - b'a' + 10),
                _ => None,
            }
        }
        bytes[index] = nibble(pair[0])
            .and_then(|high| nibble(pair[1]).map(|low| (high << 4) | low))
            .ok_or_else(|| invariant("recovery digest refused"))?;
    }
    Ok(bytes)
}
pub(crate) fn begin_tx(
    tx: &Transaction<'_>,
    owner: &SqliteServingOwner,
    operation: &AdmissionOperationV1,
    now: u64,
) -> Result<(), AdmissionOperationStoreError> {
    let Some(mut record) = located(tx, operation.binding())? else {
        return Ok(());
    };
    let intent = record
        .admission
        .as_ref()
        .ok_or_else(|| invariant("recovery admission intent is absent"))?;
    if intent.native_binding != operation.binding().to_persisted() {
        return Err(invariant("recovery native admission binding changed"));
    }
    let original = load_by_operation_id_tx(tx, operation.binding().operation_id())?;
    if original.is_none() {
        require_active(&record)?;
        let profile = deployment_tx(tx, &record.scope)?;
        fresh_basis(tx, &profile, &record, now)?;
        let grant = record
            .signed_grant
            .as_ref()
            .ok_or_else(|| invariant("recovery grant is absent"))?;
        validate_body(&record, grant.body(), &profile, now)?;
    }
    let linked = OperationId::new(operation.binding().operation_id().as_str())
        .map_err(|_| invariant("recovery operation refused"))?;
    match &record.native_link {
        Some(existing) if *existing == linked => Ok(()),
        Some(_) => Err(invariant("recovery original operation changed")),
        None => {
            record.native_link = Some(linked);
            save_workflow(tx, owner, &mut record)
        }
    }
}
pub(super) fn context(
    tx: &Transaction<'_>,
    id: &AdmissionOperationId,
    now: u64,
) -> Result<Option<RecoveryVerificationContextV1>, AdmissionOperationStoreError> {
    let Some(operation) = load_by_operation_id_tx(tx, id)? else {
        return Ok(None);
    };
    let Some(record) = located(tx, operation.operation.binding())? else {
        return Ok(None);
    };
    let deployment = deployment_tx(tx, &record.scope)?;
    require_active(&record)?;
    fresh_basis(tx, &deployment, &record, now)?;
    let grant = record
        .signed_grant
        .clone()
        .ok_or_else(|| invariant("recovery grant is absent"))?;
    validate_body(&record, grant.body(), &deployment, now)?;
    Ok(Some(RecoveryVerificationContextV1 {
        action: record
            .action
            .ok_or_else(|| invariant("recovery action is absent"))?,
        approval: record
            .approval
            .ok_or_else(|| invariant("recovery approval is absent"))?,
        grant,
        deployment,
        original_flow: record
            .original_flow
            .ok_or_else(|| invariant("recovery basis is absent"))?,
    }))
}
pub(super) fn historical_release(
    tx: &Transaction<'_>,
    id: &AdmissionOperationId,
) -> Result<Option<RecoveryWorkflowRecordV1>, AdmissionOperationStoreError> {
    let Some(native) = load_by_operation_id_tx(tx, id)? else {
        return Ok(None);
    };
    let Some(record) = located(tx, native.operation.binding())? else {
        return Ok(None);
    };
    let deployment = deployment_tx(tx, &record.scope)?;
    let intent = record
        .admission
        .as_ref()
        .ok_or_else(|| invariant("recovery original intent is absent"))?;
    if !record.captured
        || record.admission_closed
        || native.operation.state() != AdmissionOperationState::Finalizing
        || intent.native_binding != native.operation.binding().to_persisted()
        || record.native_link.as_ref().map(OperationId::as_str) != Some(id.as_str())
        || record.deployment_digest
            != DeploymentDigest::from_bytes(hash("chio.recovery.deployment.v1", &deployment)?)
        || record.envelope.is_none()
        || record.original_flow.is_none()
        || record.signed_grant.as_ref().map(|grant| grant.body()) != record.issuance.as_ref()
    {
        return Err(invariant("recovery historical release custody refused"));
    }
    Ok(Some(record))
}
pub(crate) fn verify_capture_tx(
    tx: &Transaction<'_>,
    operation: &AdmissionOperationV1,
    request: &ToolCallRequest,
    now: u64,
) -> Result<Option<u64>, AdmissionOperationStoreError> {
    let Some(record) = located(tx, operation.binding())? else {
        if request
            .declassification_grant
            .as_ref()
            .is_some_and(|grant| grant.recovery_v2().is_some())
        {
            return Err(invariant("recovery v2 has no retained admission intent"));
        }
        return Ok(None);
    };
    super::resources::check_committing(tx)?;
    require_active(&record)?;
    let profile = deployment_tx(tx, &record.scope)?;
    fresh_basis(tx, &profile, &record, now)?;
    let intent = record
        .admission
        .as_ref()
        .ok_or_else(|| invariant("recovery intent is absent"))?;
    let grant = record
        .signed_grant
        .as_ref()
        .ok_or_else(|| invariant("recovery grant is absent"))?;
    validate_body(&record, grant.body(), &profile, now)?;
    if grant.authority_key() != &profile.aggregate_issuer
        || !grant
            .verify_signature()
            .map_err(|_| invariant("recovery signature refused"))?
    {
        return Err(invariant("recovery aggregate issuer changed"));
    }
    if intent.native_binding != operation.binding().to_persisted()
        || record.captured
        || record.native_link.as_ref().map(OperationId::as_str)
            != Some(operation.binding().operation_id().as_str())
        || request
            .declassification_grant
            .as_ref()
            .and_then(|grant| grant.recovery_v2())
            != Some(grant)
    {
        return Err(invariant("recovery capture ownership changed"));
    }
    let mut initial = request.clone();
    initial.execution_nonce = None;
    let envelope = record
        .envelope
        .as_ref()
        .ok_or_else(|| invariant("recovery caller custody is absent"))?;
    if encode(&initial)? != envelope.request.as_str().as_bytes() {
        return Err(invariant("recovery caller envelope changed"));
    }
    let approval = record
        .approval
        .as_ref()
        .ok_or_else(|| invariant("recovery approval is absent"))?;
    let mut deadline = grant.body().claims.expires_at_unix_seconds() * 1000;
    deadline = deadline.min(approval.intent.expires_at_unix_ms.get());
    for contributor in approval.coverage.as_slice() {
        deadline = deadline.min(contributor.body().expires_at_unix_ms.get());
    }
    Ok(Some(deadline))
}
pub(crate) fn capture_tx(
    tx: &Transaction<'_>,
    owner: &SqliteServingOwner,
    operation: &AdmissionOperationV1,
) -> Result<(), AdmissionOperationStoreError> {
    let Some(mut record) = located(tx, operation.binding())? else {
        return Ok(());
    };
    require_active(&record)?;
    if record.captured {
        return Err(invariant("recovery continuation is already captured"));
    }
    record.captured = true;
    record.effect = EffectObservationV1::InFlight {
        operation: operation_ref(operation)?,
    };
    save_workflow(tx, owner, &mut record)
}
pub(super) fn proves_same_call_basis(
    tx: &Connection,
    record: &RecoveryWorkflowRecordV1,
    profile: &RecoveryDeploymentV1,
    original: &FlowStateSnapshot,
    current: &FlowStateSnapshot,
) -> Result<bool, AdmissionOperationStoreError> {
    let Some(intent) = &record.admission else {
        return Ok(false);
    };
    let operation = AdmissionOperationId::from_persisted(intent.native_operation_id.as_str())?;
    let source = &record
        .action
        .as_ref()
        .ok_or_else(|| invariant("recovery action is absent"))?
        .authorization_requirements
        .source_label;
    super::super::security_participant_state::prove_recovery_source_history(
        tx,
        &profile.native_authority,
        &operation,
        original,
        current,
        source,
    )
}
pub(super) fn settle(
    tx: &Transaction<'_>,
    owner: &SqliteServingOwner,
    actor: &AuthenticatedRecoveryActor,
    id: &WorkflowId,
    profile: &RecoveryDeploymentV1,
    _now: u64,
) -> Result<RecoveryWorkflowRecordV1, AdmissionOperationStoreError> {
    if !matches!(
        actor.permission(),
        RecoveryPermission::Settle | RecoveryPermission::Resume
    ) {
        return Err(invariant("recovery settlement scope refused"));
    }
    let mut record = workflow_tx(tx, actor.scope(), id)?;
    verify_status(actor, profile, &record)?;
    if record.provider_finality.is_some() && record.effect.is_settled() {
        return Ok(record);
    }
    let Some(intent) = &record.admission else {
        return Ok(record);
    };
    let binding = AdmissionOperationBindingV1::from_persisted(intent.native_binding.clone())?;
    let operation = load_by_operation_id_tx(tx, binding.operation_id())?;
    let next = match operation {
        None => {
            // The tombstone and authoritative lookup share this writer. Both
            // begin and capture consult it, fencing delayed original submissions.
            if record.control != WorkflowControlV1::Active {
                record.admission_closed = true;
                record.control = WorkflowControlV1::Cancelled;
                EffectObservationV1::NeverAdmitted
            } else {
                record.effect.clone()
            }
        }
        Some(stored) => {
            if stored.operation.binding() != &binding {
                return Err(invariant(
                    "recovery lookup returned another original operation",
                ));
            }
            let operation = &stored.operation;
            let reference = operation_ref(operation)?;
            if operation.state().is_terminal() {
                super::super::projection::verify_stored_terminal_projection(tx, &stored)?;
            }
            match operation.state() {
                AdmissionOperationState::ApprovalRequired => {
                    EffectObservationV1::AwaitingApproval {
                        operation: reference,
                    }
                }
                AdmissionOperationState::AwaitingCallerReport => {
                    EffectObservationV1::AwaitingCallerReport {
                        operation: reference,
                    }
                }
                AdmissionOperationState::OutcomeUnknownAfterDispatch
                | AdmissionOperationState::DeniedAfterDelivery
                | AdmissionOperationState::NotAcceptedAfterDispatchCommit => {
                    EffectObservationV1::Unknown {
                        operation: reference,
                    }
                }
                AdmissionOperationState::Completed => {
                    record.admission_closed = true;
                    if !matches!(record.release, ReleaseDispositionV1::Released { .. }) {
                        record.release = ReleaseDispositionV1::Withheld {
                            evidence: EvidenceRef::new(&format!(
                                "output:{}",
                                binding.operation_id().as_str()
                            ))
                            .map_err(|_| invariant("recovery identity refused"))?,
                        };
                    }
                    EffectObservationV1::Complete {
                        operation: reference,
                        effect_count: record.effect_cardinality,
                    }
                }
                AdmissionOperationState::CompensatedBeforeDispatch if !record.captured => {
                    record.admission_closed = true;
                    EffectObservationV1::ClosedBeforeEffect {
                        operation: reference,
                        closure: EvidenceRef::new(&format!(
                            "closure:{}",
                            binding.operation_id().as_str()
                        ))
                        .map_err(|_| invariant("recovery identity refused"))?,
                    }
                }
                _ => EffectObservationV1::InFlight {
                    operation: reference,
                },
            }
        }
    };
    if record.effect.is_settled() && record.effect != next {
        return Err(invariant("recovery settlement is immutable"));
    }
    if record.effect != next {
        record.effect = next;
        save_workflow(tx, owner, &mut record)?;
    }
    Ok(record)
}

pub(super) fn attach_provider_finality(
    tx: &Transaction<'_>,
    owner: &SqliteServingOwner,
    actor: &AuthenticatedRecoveryActor,
    id: &WorkflowId,
    finality: &chio_core_types::recovery::SignedRecoveryProviderFinalityV1,
    profile: &RecoveryDeploymentV1,
    now: u64,
) -> Result<RecoveryWorkflowRecordV1, AdmissionOperationStoreError> {
    if actor.permission() != RecoveryPermission::Settle {
        return Err(invariant("recovery provider settlement scope refused"));
    }
    let mut record = workflow_tx(tx, actor.scope(), id)?;
    verify_status(actor, profile, &record)?;
    if let Some(existing) = &record.provider_finality {
        if existing == finality {
            return Ok(record);
        }
        return Err(invariant("recovery provider finality conflict"));
    }
    if !record.captured || record.provider_lookups.get() == 0 {
        return Err(invariant("recovery provider observation was not reserved"));
    }
    let intent = record
        .admission
        .as_ref()
        .ok_or_else(|| invariant("recovery original intent absent"))?;
    let binding = AdmissionOperationBindingV1::from_persisted(intent.native_binding.clone())?;
    let stored = load_by_operation_id_tx(tx, binding.operation_id())?
        .ok_or(AdmissionOperationStoreError::NotFound)?;
    let operation = &stored.operation;
    if operation.binding() != &binding
        || !operation.state().is_terminal()
        || operation.dispatch_commit().is_none()
    {
        return Err(invariant("recovery native participants are not closed"));
    }
    super::super::projection::verify_stored_terminal_projection(tx, &stored)?;
    let body = finality.body();
    let provider = operation
        .provider_attempt()
        .ok_or_else(|| invariant("recovery original provider attempt absent"))?;
    if body.scope != record.scope
        || body.workflow_id != record.workflow_id
        || body.continuation_id != record.continuation_id
        || body.operation_id.as_str() != binding.operation_id().as_str()
        || body.native_admission_digest.as_bytes()
            != &decode_hex(binding.request_binding_hash().as_str())?
        || body.attempt_id.as_str() != provider.attempt_id
        || body.provider != profile.effect_contract.provider
        || body.account != profile.effect_contract.account
        || body.resource_digest
            != DeploymentDigest::from_bytes(hash(
                "chio.recovery.provider-resource.v1",
                &profile.effect_contract.resource,
            )?)
        || body.contract_digest
            != record
                .action
                .as_ref()
                .ok_or_else(|| invariant("recovery action absent"))?
                .contract_digest
        || body.contract_digest != profile.contract_digest
        || body.observed_at_unix_ms.get() > now
        || body.expires_at_unix_ms.get() <= now
        || body.applied_effects != record.effect_cardinality
        || finality.authority_key() != &profile.effect_contract.observation_key
        || !finality
            .verify_signature()
            .map_err(|_| invariant("recovery provider signature refused"))?
    {
        return Err(invariant("recovery provider finality refused"));
    }
    let reference = operation_ref(operation)?;
    let effect = match body.disposition {
        RecoveryEffectDisposition::Succeeded => EffectObservationV1::Complete {
            operation: reference,
            effect_count: body.applied_effects,
        },
        RecoveryEffectDisposition::PartiallyApplied => EffectObservationV1::Partial {
            operation: reference,
            applied_effects: body.applied_effects,
        },
        RecoveryEffectDisposition::FailedAfterEffect => EffectObservationV1::FailedAfterEffect {
            operation: reference,
            applied_effects: body.applied_effects,
        },
    };
    if record.effect.is_settled() && record.effect != effect {
        return Err(invariant("recovery immutable effect conflict"));
    }
    record.effect = effect;
    record.provider_finality = Some(finality.clone());
    record.admission_closed = true;
    record.release = ReleaseDispositionV1::NotAvailable;
    save_workflow(tx, owner, &mut record)?;
    Ok(record)
}
