//! Protected recovery records are physical participants of native admission.
use super::*;
use chio_core as chio_core_types;
use chio_kernel::admission_operation::{
    AdmissionOperationBindingV1, NativeSecurityFlowObservationV1,
};
use chio_kernel::recovery::*;
use chio_kernel::ToolCallRequest;
use chio_security_types::recovery::*;

mod commands;
mod issuance;
pub(super) mod native;
mod resources;
mod storage;
mod validation;
use storage::*;
use validation::*;

pub(crate) const SQL: &str = include_str!("../admission_operation_recovery.sql");
pub(crate) use native::{begin_tx, capture_tx};
pub(crate) use storage::{projection_reference, verify_all};

impl SqliteAdmissionOperationStore {
    /// Trusted operator setup installs or rotates a scoped deployment. Every
    /// pending action revalidates the current assignment and profile digest.
    pub fn configure_recovery_deployment(
        &self,
        deployment: &RecoveryDeploymentV1,
    ) -> Result<(), AdmissionOperationStoreError> {
        validate_deployment(deployment, &self.serving_owner.fence)?;
        let mut connection = self.connection()?;
        resources::check(&connection, true)?;
        let tx = self.begin_write(&mut connection, None)?;
        super::security_participant_state::verify_recovery_initialization(
            &tx,
            &deployment.native_authority,
        )?;
        let scope = scope_key(&deployment.scope)?;
        let key = format!("deployment:{scope}");
        let encoded = encode(deployment)?;
        if raw(&tx, &key)?
            .as_ref()
            .is_some_and(|current| current.payload == encoded)
        {
            tx.commit().map_err(sqlite_error)?;
            return Ok(());
        }
        save(
            &tx,
            &self.serving_owner,
            &key,
            &scope,
            "deployment",
            &encoded,
            None,
        )?;
        self.commit_write(tx)?;
        self.sync_after_write(&connection)
    }
    fn recovery_mutation<T, E: From<AdmissionOperationStoreError>>(
        &self,
        actor: &AuthenticatedRecoveryActor,
        fence: &StoreMutationFence,
        now: u64,
        apply: impl FnOnce(&Transaction<'_>, &RecoveryDeploymentV1, u64) -> Result<T, E>,
    ) -> Result<T, E> {
        let mut connection = self.connection()?;
        let intake = matches!(
            actor.permission(),
            RecoveryPermission::Create | RecoveryPermission::Select | RecoveryPermission::Approve
        );
        resources::check(&connection, intake)?;
        let tx = self.begin_write(&mut connection, Some(fence))?;
        let now = schema::authority_validation_time(&tx, now)?;
        let deployment = deployment_tx(&tx, actor.scope())?;
        verify_actor(&tx, actor, &deployment, now)?;
        let result = apply(&tx, &deployment, now)?;
        self.commit_write(tx)?;
        self.sync_after_write(&connection)?;
        Ok(result)
    }
}

impl RecoveryAuthorityPort for SqliteAdmissionOperationStore {
    fn reserve_provider_lookup(
        &self,
        actor: &AuthenticatedRecoveryActor,
        workflow: &WorkflowId,
        fence: &StoreMutationFence,
        now: u64,
    ) -> Result<RecoveryWorkflowRecordV1, AdmissionOperationStoreError> {
        self.recovery_mutation(actor, fence, now, |tx, profile, now| {
            let mut record =
                native::settle(tx, &self.serving_owner, actor, workflow, profile, now)?;
            if actor.permission() != RecoveryPermission::Settle
                || !matches!(record.effect, EffectObservationV1::Unknown { .. })
                || record.provider_lookups.get() >= 32
            {
                return Err(invariant("recovery provider observation refused"));
            }
            record.provider_lookups = SafeInteger::new(record.provider_lookups.get() + 1)
                .map_err(|_| invariant("recovery lookup quota exhausted"))?;
            save_workflow(tx, &self.serving_owner, &mut record)?;
            Ok(record)
        })
    }
    fn attach_provider_finality(
        &self,
        actor: &AuthenticatedRecoveryActor,
        workflow: &WorkflowId,
        finality: &chio_core_types::recovery::SignedRecoveryProviderFinalityV1,
        fence: &StoreMutationFence,
        now: u64,
    ) -> Result<RecoveryWorkflowRecordV1, AdmissionOperationStoreError> {
        self.recovery_mutation(actor, fence, now, |tx, profile, now| {
            native::attach_provider_finality(
                tx,
                &self.serving_owner,
                actor,
                workflow,
                finality,
                profile,
                now,
            )
        })
    }

    fn release_result(
        &self,
        actor: &AuthenticatedRecoveryActor,
        workflow: &WorkflowId,
        fence: &StoreMutationFence,
        now: u64,
    ) -> Result<(), AdmissionOperationStoreError> {
        self.recovery_mutation(actor, fence, now, |tx, profile, _now| {
            if !matches!(
                actor.permission(),
                RecoveryPermission::Resume | RecoveryPermission::Inspect
            ) {
                return Err(invariant("recovery result scope refused"));
            }
            let mut record = workflow_tx(tx, actor.scope(), workflow)?;
            verify_preview(actor, profile, &record)?;
            let original = record
                .original_flow
                .as_ref()
                .ok_or_else(|| invariant("recovery source is absent"))?;
            let (current, _) = crate::security_state::observe_native_flow_state(
                tx,
                profile.native_authority.security_authority_id().as_str(),
                &original.key,
            )
            .map_err(|_| invariant("recovery current source unavailable"))?;
            let current = current.ok_or_else(|| invariant("recovery current source is absent"))?;
            let source = current
                .principal_label
                .join_restrictions(&current.lineage_label)
                .and_then(|source| source.join_restrictions(&current.session_label))
                .map_err(|_| invariant("recovery current source refused"))?;
            let assignment = profile
                .actors
                .as_slice()
                .iter()
                .find(|a| a.principal == *actor.principal())
                .ok_or_else(|| invariant("recovery audience revoked"))?;
            if !source.flows_to(&assignment.preview_clearance) {
                return Err(invariant("recovery result audience refused"));
            }
            let intent = record
                .admission
                .as_ref()
                .ok_or_else(|| invariant("recovery original operation is absent"))?;
            let binding =
                AdmissionOperationBindingV1::from_persisted(intent.native_binding.clone())?;
            let stored = load_by_operation_id_tx(tx, binding.operation_id())?
                .ok_or(AdmissionOperationStoreError::NotFound)?;
            if stored.operation.binding() != &binding
                || stored.operation.state() != AdmissionOperationState::Completed
            {
                return Err(invariant("recovery original result is not complete"));
            }
            super::projection::verify_stored_terminal_projection(tx, &stored)?;
            let release = ReleaseDispositionV1::Released {
                release_id: ReleaseId::new(&format!("output:{}", binding.operation_id().as_str()))
                    .map_err(|_| invariant("recovery reference refused"))?,
            };
            if record.release != release {
                record.release = release;
                save_workflow(tx, &self.serving_owner, &mut record)?;
            }
            Ok(())
        })
    }

    fn acknowledge_reservation(
        &self,
        actor: &AuthenticatedRecoveryActor,
        workflow: &WorkflowId,
        reservation: &RecoveryProcessReservationV1,
        fence: &StoreMutationFence,
        now: u64,
    ) -> Result<(), AdmissionOperationStoreError> {
        self.recovery_mutation(actor, fence, now, |tx, profile, now| {
            if !matches!(
                actor.permission(),
                RecoveryPermission::Create
                    | RecoveryPermission::Select
                    | RecoveryPermission::Resume
            ) {
                return Err(invariant("recovery reservation scope refused"));
            }
            let mut record = workflow_tx(tx, actor.scope(), workflow)?;
            let action = record
                .action
                .as_ref()
                .ok_or_else(|| invariant("recovery action is absent"))?;
            let encoded = ProtectedText::new(
                &String::from_utf8(encode(reservation)?)
                    .map_err(|_| invariant("recovery reservation encoding refused"))?,
            )
            .map_err(|_| invariant("recovery reservation bound exceeded"))?;
            if reservation.runtime_id != profile.security_context.as_v1().session_id().as_str()
                || reservation.process_id != record.scope.process_id.as_str()
                || reservation.continuation_id != record.continuation_id
                || reservation.operation_key
                    != format!("recovery:{}", record.continuation_id.as_str())
                || reservation.request_id != action.request_id.as_str()
                || reservation.capability_digest != sha256_hex(&encode(&record.seed.capability)?)
                || reservation.unsigned_intent
                    != IntentDigest::from_bytes(hash("chio.recovery.action-intent.v1", action)?)
                || reservation.server_id != profile.server_id.as_str()
            {
                return Err(invariant("recovery reservation binding refused"));
            }
            if let Some(existing) = &record.process_reservation {
                if existing != &encoded {
                    return Err(invariant("recovery reservation changed"));
                }
                return Ok(());
            }
            require_active(&record)?;
            fresh_basis(tx, profile, &record, now)?;
            record.process_reservation = Some(encoded);
            save_workflow(tx, &self.serving_owner, &mut record)
        })
    }

    fn reserve_review(
        &self,
        actor: &AuthenticatedRecoveryActor,
        workflow: &WorkflowId,
        review: &ApprovalIntentV1,
        fence: &StoreMutationFence,
        now: u64,
    ) -> Result<ApprovalIntentV1, AdmissionOperationStoreError> {
        self.recovery_mutation(actor, fence, now, |tx, profile, now| {
            if actor.permission() != RecoveryPermission::Approve {
                return Err(invariant("recovery review scope refused"));
            }
            let mut record = workflow_tx(tx, actor.scope(), workflow)?;
            verify_preview(actor, profile, &record)?;
            if let Some(existing) = record.review {
                return Ok(existing);
            }
            require_active(&record)?;
            if !record.selected {
                return Err(invariant("recovery identity is not reserved"));
            }
            if review.reviewer != *actor.principal() {
                return Err(invariant("recovery reviewer changed"));
            }
            validate_review(&record, review, now)?;
            fresh_basis(tx, profile, &record, now)?;
            record.review = Some(review.clone());
            save_workflow(tx, &self.serving_owner, &mut record)?;
            Ok(review.clone())
        })
    }
    fn deployment(
        &self,
        scope: &RecoveryScopeV1,
        fence: &StoreMutationFence,
        now: u64,
    ) -> Result<RecoveryDeploymentV1, AdmissionOperationStoreError> {
        let mut connection = self.connection()?;
        let tx = self.begin_read(&mut connection)?;
        verify_active_owner(&tx, &self.serving_owner, Some(fence))?;
        schema::authority_validation_time(&tx, now)?;
        let result = deployment_tx(&tx, scope)?;
        tx.commit().map_err(sqlite_error)?;
        Ok(result)
    }
    fn load_workflow(
        &self,
        actor: &AuthenticatedRecoveryActor,
        workflow: &WorkflowId,
        fence: &StoreMutationFence,
        now: u64,
    ) -> Result<RecoveryWorkflowRecordV1, AdmissionOperationStoreError> {
        let mut connection = self.connection()?;
        let tx = self.begin_read(&mut connection)?;
        verify_active_owner(&tx, &self.serving_owner, Some(fence))?;
        let now = schema::authority_validation_time(&tx, now)?;
        let deployment = deployment_tx(&tx, actor.scope())?;
        verify_actor(&tx, actor, &deployment, now)?;
        let record = workflow_tx(&tx, actor.scope(), workflow)?;
        verify_preview(actor, &deployment, &record)?;
        tx.commit().map_err(sqlite_error)?;
        Ok(record)
    }
    fn command(
        &self,
        actor: &AuthenticatedRecoveryActor,
        command: &RecoveryCommandV1,
        fence: &StoreMutationFence,
        now: u64,
    ) -> Result<RecoveryCommandResponseV1, RecoveryCommandPortError> {
        self.recovery_mutation(actor, fence, now, |tx, deployment, now| {
            commands::apply(tx, &self.serving_owner, actor, command, deployment, now)
        })
    }
    fn materialize(
        &self,
        actor: &AuthenticatedRecoveryActor,
        workflow: &WorkflowId,
        action: &ActionIntentV1,
        observation: &NativeSecurityFlowObservationV1,
        fence: &StoreMutationFence,
        now: u64,
    ) -> Result<RecoveryWorkflowRecordV1, AdmissionOperationStoreError> {
        self.recovery_mutation(actor, fence, now, |tx, deployment, now| {
            issuance::materialize(
                tx,
                &self.serving_owner,
                actor,
                workflow,
                issuance::Materialization {
                    action,
                    observation,
                },
                deployment,
                now,
            )
        })
    }
    fn reserve_issuance(
        &self,
        actor: &AuthenticatedRecoveryActor,
        workflow: &WorkflowId,
        body: &chio_core_types::recovery::RecoveryGrantBodyV2,
        fence: &StoreMutationFence,
        now: u64,
    ) -> Result<chio_core_types::recovery::RecoveryGrantBodyV2, AdmissionOperationStoreError> {
        self.recovery_mutation(actor, fence, now, |tx, deployment, now| {
            issuance::reserve(
                tx,
                &self.serving_owner,
                actor,
                workflow,
                body,
                deployment,
                now,
            )
        })
    }
    fn attach_signature(
        &self,
        actor: &AuthenticatedRecoveryActor,
        workflow: &WorkflowId,
        grant: &chio_core_types::recovery::SignedRecoveryGrantV2,
        fence: &StoreMutationFence,
        now: u64,
    ) -> Result<(), AdmissionOperationStoreError> {
        self.recovery_mutation(actor, fence, now, |tx, deployment, now| {
            issuance::attach(
                tx,
                &self.serving_owner,
                actor,
                workflow,
                grant,
                deployment,
                now,
            )
        })
    }
    fn finalize_envelope(
        &self,
        actor: &AuthenticatedRecoveryActor,
        workflow: &WorkflowId,
        envelope: &FinalizedRequestEnvelopeV1,
        identity: &RecoveryNativeIdentity,
        fence: &StoreMutationFence,
        now: u64,
    ) -> Result<(), AdmissionOperationStoreError> {
        self.recovery_mutation(actor, fence, now, |tx, deployment, now| {
            issuance::finalize(
                tx,
                &self.serving_owner,
                actor,
                workflow,
                issuance::Finalization { envelope, identity },
                deployment,
                now,
            )
        })
    }
    fn verification_context(
        &self,
        operation: &AdmissionOperationId,
        fence: &StoreMutationFence,
        now: u64,
    ) -> Result<Option<RecoveryVerificationContextV1>, AdmissionOperationStoreError> {
        let mut connection = self.connection()?;
        let tx = self.begin_read(&mut connection)?;
        verify_active_owner(&tx, &self.serving_owner, Some(fence))?;
        let now = schema::authority_validation_time(&tx, now)?;
        let result = native::context(&tx, operation, now)?;
        tx.commit().map_err(sqlite_error)?;
        Ok(result)
    }
    fn historical_release(
        &self,
        operation: &AdmissionOperationId,
        fence: &StoreMutationFence,
        now: u64,
    ) -> Result<Option<RecoveryWorkflowRecordV1>, AdmissionOperationStoreError> {
        let mut connection = self.connection()?;
        let tx = self.begin_read(&mut connection)?;
        verify_active_owner(&tx, &self.serving_owner, Some(fence))?;
        schema::authority_validation_time(&tx, now)?;
        let result = native::historical_release(&tx, operation)?;
        tx.commit().map_err(sqlite_error)?;
        Ok(result)
    }
    fn settle(
        &self,
        actor: &AuthenticatedRecoveryActor,
        workflow: &WorkflowId,
        fence: &StoreMutationFence,
        now: u64,
    ) -> Result<RecoveryWorkflowRecordV1, AdmissionOperationStoreError> {
        self.recovery_mutation(actor, fence, now, |tx, deployment, now| {
            native::settle(tx, &self.serving_owner, actor, workflow, deployment, now)
        })
    }
}
