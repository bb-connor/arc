//! Thin transport to the trusted Rust recovery host, with no local decisions.
use crate::CliError;
use clap::Subcommand;
use serde_json::Value;
use std::{
    fs::File,
    io::Read,
    path::{Path, PathBuf},
    time::Duration,
};

#[derive(Debug, Subcommand)]
pub(crate) enum RecoveryCommands {
    /// Submit or replay one exact canonical command. Retain its ID on ambiguity.
    Command {
        #[arg(long)]
        endpoint: String,
        #[arg(long)]
        capability: PathBuf,
        #[arg(long)]
        command: PathBuf,
    },
    /// Read the full exact preview under current approval authority.
    Review {
        #[arg(long)]
        endpoint: String,
        #[arg(long)]
        capability: PathBuf,
        #[arg(long)]
        workflow_id: String,
    },
    /// Reconcile the original operation under current settlement authority.
    Settle {
        #[arg(long)]
        endpoint: String,
        #[arg(long)]
        capability: PathBuf,
        #[arg(long)]
        workflow_id: String,
    },
}
fn refused() -> CliError {
    CliError::cli_other_error(
        "recovery transport refused or unavailable; retain the original command identity",
    )
}
fn bounded(path: &Path, limit: usize) -> Result<String, CliError> {
    let mut bytes = Vec::new();
    File::open(path)?
        .take((limit + 1) as u64)
        .read_to_end(&mut bytes)?;
    if bytes.len() > limit {
        return Err(refused());
    }
    String::from_utf8(bytes).map_err(|_| refused())
}
pub(crate) fn run(command: RecoveryCommands) -> Result<(), CliError> {
    let (endpoint, capability, path, body) = match command {
        RecoveryCommands::Command {
            endpoint,
            capability,
            command,
        } => (
            endpoint,
            capability,
            "commands",
            ("command", bounded(&command, 65536)?),
        ),
        RecoveryCommands::Review {
            endpoint,
            capability,
            workflow_id,
        } => (endpoint, capability, "review", ("workflow_id", workflow_id)),
        RecoveryCommands::Settle {
            endpoint,
            capability,
            workflow_id,
        } => (endpoint, capability, "settle", ("workflow_id", workflow_id)),
    };
    let mut url = reqwest::Url::parse(&endpoint).map_err(|_| refused())?;
    let local = matches!(
        url.host_str(),
        Some("localhost" | "127.0.0.1" | "[::1]" | "::1")
    );
    if (url.scheme() != "https" && !(url.scheme() == "http" && local))
        || !url.username().is_empty()
        || url.password().is_some()
        || url.query().is_some()
        || url.fragment().is_some()
    {
        return Err(refused());
    }
    url.set_path(&format!("/v1/recovery/{path}"));
    let capability = bounded(&capability, 32768)?;
    chio_core_types::recovery::decode_recovery_capability(capability.as_bytes())
        .map_err(|_| refused())?;
    let wire: Value = serde_json::json!({"capability":capability,body.0:body.1});
    let bytes = chio_core_types::canonical_json_bytes(&wire).map_err(|_| refused())?;
    if bytes.len() > 65536 {
        return Err(refused());
    }
    let client = reqwest::blocking::Client::builder()
        .timeout(Duration::from_secs(20))
        .redirect(reqwest::redirect::Policy::none())
        .retry(reqwest::retry::never())
        .build()
        .map_err(|_| refused())?;
    let response = client
        .post(url)
        .header("content-type", "application/json")
        .body(bytes)
        .send()
        .map_err(|_| refused())?;
    if !response.status().is_success() {
        return Err(refused());
    }
    let mut bytes = Vec::new();
    response
        .take(262145)
        .read_to_end(&mut bytes)
        .map_err(|_| refused())?;
    if bytes.len() > 262144 {
        return Err(refused());
    }
    let value: Value = serde_json::from_slice(&bytes).map_err(|_| refused())?;
    println!("{}", serde_json::to_string_pretty(&value)?);
    Ok(())
}
