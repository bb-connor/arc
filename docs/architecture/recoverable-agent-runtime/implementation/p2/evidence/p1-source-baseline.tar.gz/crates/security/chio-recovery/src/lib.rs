//! Pure recovery advice. Inputs remain untrusted until the owning authority
//! verifies them. A directive cannot execute, close, settle, sign or release.
#![cfg_attr(not(feature = "std"), no_std)]
#![forbid(unsafe_code)]

extern crate alloc;
mod decision;
mod workflow;
pub use decision::{PlanDecision, WorkflowDirective};
pub use workflow::advise_workflow;
