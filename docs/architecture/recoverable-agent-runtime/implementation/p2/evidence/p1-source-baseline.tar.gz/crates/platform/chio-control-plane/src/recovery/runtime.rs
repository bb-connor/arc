use crate::security::adapters::NativeFlowResolver;
use chio_core_types::recovery::decode_contract;
use chio_core_types::{capability::token::CapabilityToken, Ed25519Backend, SigningBackend};
use chio_kernel::recovery::{
    AuthenticatedRecoveryActor, RecoveryCommandError, RecoveryCommandResponseV1, RecoveryPermission,
};
use chio_kernel::ChioKernel;
use chio_process::ProcessRuntime;
use chio_security_types::recovery::*;
use std::sync::Arc;

#[derive(Clone, Copy, Debug, Eq, PartialEq, thiserror::Error)]
pub enum RecoveryRuntimeError {
    #[error("invalid recovery command")]
    InvalidCommand,
    #[error("recovery authority refused")]
    AuthorityDenied,
    #[error("recovery command conflicted or is stale")]
    Conflict,
    #[error("recovery profile is unsupported")]
    UnsupportedProfile,
    #[error("recovery effect is unresolved")]
    UnknownEffect,
    #[error("recovery authority is unavailable; retain the original command identity")]
    Unavailable,
}

#[derive(serde::Serialize)]
#[serde(deny_unknown_fields)]
pub struct RecoveryCommandResultV1 {
    pub status: RecoveryCommandResponseV1,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub original_response: Option<RecoveryResultProjectionV1>,
}
#[derive(serde::Serialize)]
#[serde(deny_unknown_fields)]
pub struct RecoveryResultProjectionV1 {
    pub receipt: chio_core_types::receipt::body::ChioReceipt,
    pub result: Option<serde_json::Value>,
}
impl core::fmt::Debug for RecoveryCommandResultV1 {
    fn fmt(&self, f: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        f.write_str("RecoveryCommandResultV1([redacted])")
    }
}
impl core::fmt::Debug for RecoveryResultProjectionV1 {
    fn fmt(&self, f: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        f.write_str("RecoveryResultProjectionV1([redacted])")
    }
}

/// Trusted host composition with one pinned, native disclosure deployment.
/// Signing happens outside all store transactions. No background model,
/// command notification or generic retry middleware can start another effect.
pub struct RecoveryRuntime {
    pub(super) kernel: Arc<ChioKernel>,
    pub(super) process: ProcessRuntime,
    pub(super) flow: Arc<NativeFlowResolver>,
    pub(super) scope: RecoveryScopeV1,
    pub(super) signer: Arc<Ed25519Backend>,
}
impl core::fmt::Debug for RecoveryRuntime {
    fn fmt(&self, f: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        f.write_str("RecoveryRuntime([redacted])")
    }
}
impl RecoveryRuntime {
    pub fn new(
        kernel: Arc<ChioKernel>,
        process: ProcessRuntime,
        flow: Arc<NativeFlowResolver>,
        scope: RecoveryScopeV1,
        signer: Arc<Ed25519Backend>,
    ) -> Result<Self, RecoveryRuntimeError> {
        let profile = kernel
            .recovery_deployment(&scope)
            .map_err(|_| RecoveryRuntimeError::UnsupportedProfile)?;
        let context = process
            .recovery_security_context(scope.process_id.as_str())
            .map_err(|_| RecoveryRuntimeError::UnsupportedProfile)?;
        if !flow.supports_recovery(&profile.native_authority)
            || context != profile.security_context
            || signer.public_key() != profile.aggregate_issuer
            || kernel.execution_nonce_required()
                != (profile.attachment_profile == RecoveryAttachmentProfile::OperationOwnedNonce)
        {
            return Err(RecoveryRuntimeError::UnsupportedProfile);
        }
        Ok(Self {
            kernel,
            process,
            flow,
            scope,
            signer,
        })
    }
    pub fn scope(&self) -> &RecoveryScopeV1 {
        &self.scope
    }

    /// A canonical request and stable command ID are shared by CLI and SDKs.
    /// Successful command replay is freshly authorized before every projection.
    pub async fn execute(
        &self,
        capability: &CapabilityToken,
        bytes: &[u8],
    ) -> Result<RecoveryCommandResultV1, RecoveryRuntimeError> {
        let command: RecoveryCommandV1 =
            decode_contract(bytes).map_err(|_| RecoveryRuntimeError::InvalidCommand)?;
        self.execute_command(capability, &command).await
    }
    pub fn execute_command<'a>(
        &'a self,
        capability: &'a CapabilityToken,
        command: &'a RecoveryCommandV1,
    ) -> std::pin::Pin<
        Box<
            dyn std::future::Future<Output = Result<RecoveryCommandResultV1, RecoveryRuntimeError>>
                + Send
                + 'a,
        >,
    > {
        Box::pin(self.execute_command_inner(capability, command))
    }
    async fn execute_command_inner(
        &self,
        capability: &CapabilityToken,
        command: &RecoveryCommandV1,
    ) -> Result<RecoveryCommandResultV1, RecoveryRuntimeError> {
        let wire = chio_core_types::canonical_json_bytes(command)
            .map_err(|_| RecoveryRuntimeError::InvalidCommand)?;
        let _: RecoveryCommandV1 =
            decode_contract(&wire).map_err(|_| RecoveryRuntimeError::InvalidCommand)?;
        let permission = permission(&command.command);
        let actor = self
            .kernel
            .authenticate_recovery_actor(&self.scope, capability, permission)
            .map_err(|_| RecoveryRuntimeError::AuthorityDenied)?;
        let status = self
            .kernel
            .execute_recovery_command(&actor, command)
            .map_err(|error| match error {
                RecoveryCommandError::AuthorityDenied => RecoveryRuntimeError::AuthorityDenied,
                RecoveryCommandError::Conflict => RecoveryRuntimeError::Conflict,
                RecoveryCommandError::Unavailable => RecoveryRuntimeError::Unavailable,
            })?;
        let mut original_response = None;
        #[cfg(test)]
        match &command.command {
            RecoveryCommandBodyV1::CreateWorkflow { .. } => super::test_cutpoint("creation"),
            RecoveryCommandBodyV1::SelectOffer { .. } => super::test_cutpoint("selection"),
            RecoveryCommandBodyV1::SubmitApproval { .. } => super::test_cutpoint("approval"),
            _ => {}
        }
        match &command.command {
            RecoveryCommandBodyV1::CreateWorkflow { .. } => {
                self.materialize(&actor, &status.workflow_id)?;
            }
            RecoveryCommandBodyV1::ResumeWorkflow { workflow_id, .. } => {
                let mut record = self
                    .kernel
                    .read_recovery_workflow(&actor, workflow_id)
                    .map_err(|_| RecoveryRuntimeError::AuthorityDenied)?;
                if record.admission.is_some() {
                    record = self
                        .kernel
                        .reconcile_recovery_continuation(&actor, workflow_id)
                        .map_err(|_| RecoveryRuntimeError::Unavailable)?;
                }
                if record.control == WorkflowControlV1::Active
                    && !record.admission_closed
                    && !record.effect.is_settled()
                    && !record.captured
                    && !matches!(
                        record.effect,
                        EffectObservationV1::Unknown { .. }
                            | EffectObservationV1::AwaitingApproval { .. }
                            | EffectObservationV1::AwaitingCallerReport { .. }
                    )
                {
                    let reservation = self.prepare_original(&actor, workflow_id)?;
                    let custody = self
                        .kernel
                        .load_recovery_request_custody(&actor, workflow_id)
                        .map_err(|_| RecoveryRuntimeError::Unavailable)?;
                    self.process
                        .finalize_recovery_call(&reservation, &custody)
                        .map_err(|_| RecoveryRuntimeError::Conflict)?;
                    #[cfg(test)]
                    super::test_cutpoint("process-finalized");
                    let response = Box::pin(self.process.invoke_known_only(
                        self.scope.process_id.as_str(),
                        reservation.operation_key(),
                        custody.request(),
                    ))
                    .await
                    .map_err(|_| RecoveryRuntimeError::Unavailable)?;
                    #[cfg(test)]
                    {
                        super::test_cutpoint("returned-response");
                    }
                    // Fresh control identity, assignment, revocation and source
                    // clearance gate every return, including a native replay.
                    let current = self
                        .kernel
                        .authenticate_recovery_actor(&self.scope, capability, permission)
                        .map_err(|_| RecoveryRuntimeError::AuthorityDenied)?;
                    self.authorize_return(&current, workflow_id)?;
                    self.kernel
                        .observe_recovery_completion(&current, workflow_id)
                        .map_err(|_| RecoveryRuntimeError::Unavailable)?;
                    // A preflight receipt has no result and remains owned by the
                    // original operation. It is never represented as completion.
                    if response.output.is_some() {
                        let response = self
                            .kernel
                            .replay_recovery_result(&current, workflow_id)
                            .map_err(|_| RecoveryRuntimeError::AuthorityDenied)?;
                        original_response = Some(project_response(response)?);
                    }
                } else if record.effect.is_settled() {
                    self.authorize_return(&actor, workflow_id)?;
                    if matches!(record.effect, EffectObservationV1::Complete { .. })
                        && record.provider_finality.is_none()
                    {
                        let response = self
                            .kernel
                            .replay_recovery_result(&actor, workflow_id)
                            .map_err(|_| RecoveryRuntimeError::AuthorityDenied)?;
                        original_response = Some(project_response(response)?);
                    }
                }
            }
            _ => {}
        }
        #[cfg(test)]
        if matches!(
            command.command,
            RecoveryCommandBodyV1::ResumeWorkflow { .. }
        ) {
            super::test_cutpoint("projection");
        }
        let current = self
            .kernel
            .authenticate_recovery_actor(&self.scope, capability, permission)
            .map_err(|_| RecoveryRuntimeError::AuthorityDenied)?;
        let record = self
            .kernel
            .read_recovery_workflow(&current, &status.workflow_id)
            .map_err(|_| RecoveryRuntimeError::AuthorityDenied)?;
        Ok(RecoveryCommandResultV1 {
            status: RecoveryCommandResponseV1 {
                command_id: command.command_id.clone(),
                workflow_id: record.workflow_id,
                revision: record.revision,
                control: record.control,
                effect: record.effect,
                release: record.release,
            },
            original_response,
        })
    }
    /// Current settlement control is independent of the initiating token and
    /// cannot authorize invoke. It only inspects/settles the retained original.
    pub fn settle(
        &self,
        capability: &CapabilityToken,
        workflow: &WorkflowId,
    ) -> Result<RecoveryCommandResponseV1, RecoveryRuntimeError> {
        let actor = self
            .kernel
            .authenticate_recovery_actor(&self.scope, capability, RecoveryPermission::Settle)
            .map_err(|_| RecoveryRuntimeError::AuthorityDenied)?;
        let record = self
            .kernel
            .settle_recovery_workflow(&actor, workflow)
            .map_err(|_| RecoveryRuntimeError::Unavailable)?;
        Ok(RecoveryCommandResponseV1 {
            command_id: CommandId::new("settlement-observation")
                .map_err(|_| RecoveryRuntimeError::InvalidCommand)?,
            workflow_id: record.workflow_id,
            revision: record.revision,
            control: record.control,
            effect: record.effect,
            release: record.release,
        })
    }
    /// Reserve a bounded original-operation lookup under current control,
    /// observe outside transactions, then reauthenticate before attaching proof.
    pub async fn settle_from_provider(
        &self,
        capability: &CapabilityToken,
        workflow: &WorkflowId,
        connector: &super::PinnedSupportIssueConnector,
    ) -> Result<RecoveryCommandResponseV1, RecoveryRuntimeError> {
        let actor = self
            .kernel
            .authenticate_recovery_actor(&self.scope, capability, RecoveryPermission::Settle)
            .map_err(|_| RecoveryRuntimeError::AuthorityDenied)?;
        let lookup = self
            .kernel
            .reserve_recovery_provider_lookup(&actor, workflow)
            .map_err(|_| RecoveryRuntimeError::Unavailable)?;
        let observation = connector
            .observe_original(lookup)
            .await
            .map_err(|_| RecoveryRuntimeError::UnknownEffect)?;
        let current = self
            .kernel
            .authenticate_recovery_actor(&self.scope, capability, RecoveryPermission::Settle)
            .map_err(|_| RecoveryRuntimeError::AuthorityDenied)?;
        self.kernel
            .attach_recovery_provider_finality(&current, workflow, &observation)
            .map_err(|_| RecoveryRuntimeError::AuthorityDenied)?;
        self.settle(capability, workflow)
    }
    fn authorize_return(
        &self,
        actor: &AuthenticatedRecoveryActor,
        workflow: &WorkflowId,
    ) -> Result<(), RecoveryRuntimeError> {
        self.kernel
            .read_recovery_workflow(actor, workflow)
            .map_err(|_| RecoveryRuntimeError::AuthorityDenied)?;
        let profile = self
            .kernel
            .recovery_deployment(&self.scope)
            .map_err(|_| RecoveryRuntimeError::AuthorityDenied)?;
        let assignment = profile
            .actors
            .as_slice()
            .iter()
            .find(|assignment| assignment.principal == *actor.principal())
            .ok_or(RecoveryRuntimeError::AuthorityDenied)?;
        let observation = self
            .kernel
            .observe_recovery_source(&self.scope)
            .map_err(|_| RecoveryRuntimeError::AuthorityDenied)?;
        let state = observation
            .snapshot()
            .ok_or(RecoveryRuntimeError::AuthorityDenied)?;
        let source = state
            .principal_label
            .join_restrictions(&state.lineage_label)
            .and_then(|source| source.join_restrictions(&state.session_label))
            .map_err(|_| RecoveryRuntimeError::AuthorityDenied)?;
        if !source.flows_to(&assignment.preview_clearance) {
            return Err(RecoveryRuntimeError::AuthorityDenied);
        }
        Ok(())
    }
}
fn permission(body: &RecoveryCommandBodyV1) -> RecoveryPermission {
    match body {
        RecoveryCommandBodyV1::CreateWorkflow { .. } => RecoveryPermission::Create,
        RecoveryCommandBodyV1::InspectWorkflow { .. } => RecoveryPermission::Inspect,
        RecoveryCommandBodyV1::SelectOffer { .. } => RecoveryPermission::Select,
        RecoveryCommandBodyV1::SubmitApproval { .. } => RecoveryPermission::Approve,
        RecoveryCommandBodyV1::ResumeWorkflow { .. } => RecoveryPermission::Resume,
        RecoveryCommandBodyV1::CancelWorkflow { .. } => RecoveryPermission::Cancel,
        RecoveryCommandBodyV1::ReportDecision { .. } => RecoveryPermission::Report,
    }
}

fn project_response(
    response: chio_kernel::ToolCallResponse,
) -> Result<RecoveryResultProjectionV1, RecoveryRuntimeError> {
    let result = match response.output {
        Some(chio_kernel::ToolCallOutput::Value(value)) => Some(value),
        None => None,
        _ => return Err(RecoveryRuntimeError::UnsupportedProfile),
    };
    Ok(RecoveryResultProjectionV1 {
        receipt: response.receipt,
        result,
    })
}
