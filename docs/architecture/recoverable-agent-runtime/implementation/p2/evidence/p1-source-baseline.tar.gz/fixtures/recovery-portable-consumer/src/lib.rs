//! Independent feature-resolution fixture for portable recovery consumers.
#![cfg_attr(not(feature = "std"), no_std)]
#![forbid(unsafe_code)]

use chio_recovery::{advise_workflow, WorkflowDirective};
use chio_security_types::recovery::{ContractError, RecoveryObservationV1};

pub fn decode_advice(bytes: &[u8]) -> Result<WorkflowDirective, ContractError> {
    let observation: RecoveryObservationV1 = chio_core_types::recovery::decode_contract(bytes)?;
    Ok(advise_workflow(&observation))
}

pub fn verify_budget_is_portable() -> Result<(), ContractError> {
    chio_semantic_contracts::VerificationBudget::new(1)?.charge(1)
}
