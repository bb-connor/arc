/** Transport only. The Rust host owns identity, approval and native recovery. */
import { canonicalJsonString } from "./canonical.js";
import type { Recovery_Command, Recovery_CommandResult, Recovery_CommandResponse, Recovery_ReviewDocument } from "./_generated/index.js";
import { recoveryWireSchemas } from "./_generated/recovery-schemas.js";
import { createWireSchemaValidator } from "./wire-schema.js";

const schemaBase = "https://chio.world/schemas/chio-wire/v1/recovery/";
let validateWire: ReturnType<typeof createWireSchemaValidator> | undefined;
function validates(schema: string, value: unknown): boolean {
  validateWire ??= createWireSchemaValidator(recoveryWireSchemas);
  return validateWire(schemaBase + schema + ".schema.json", value);
}

export class RecoveryClient {
  private readonly endpoint: URL;
  constructor(endpoint: string, private readonly transport: typeof fetch = fetch) {
    try { this.endpoint = new URL(endpoint); }
    catch { throw new Error("recovery.invalid_endpoint"); }
    const local = ["localhost", "127.0.0.1", "[::1]"].includes(this.endpoint.hostname);
    if (!(this.endpoint.protocol === "https:" || (this.endpoint.protocol === "http:" && local)) ||
        this.endpoint.username || this.endpoint.password || this.endpoint.search || this.endpoint.hash) {
      throw new Error("recovery.invalid_endpoint");
    }
  }
  execute(capability: string, command: Recovery_Command.RecoveryCommandV1): Promise<Recovery_CommandResult.RecoveryCommandResultV1> {
    if (!validates("command", command)) throw new Error("recovery.invalid_command");
    return this.post("commands", "command-result", { capability, command: canonicalJsonString(command) });
  }
  review(capability: string, workflowId: string): Promise<Recovery_ReviewDocument.RecoveryReviewDocumentV1> {
    return this.post("review", "review-document", { capability, workflow_id: workflowId });
  }
  settle(capability: string, workflowId: string): Promise<Recovery_CommandResponse.RecoveryCommandResponseV1> {
    return this.post("settle", "command-response", { capability, workflow_id: workflowId });
  }
  private async post<T>(path: string, schema: string, envelope: object): Promise<T> {
    const bytes = new TextEncoder().encode(canonicalJsonString(envelope));
    if (bytes.length > 65536) throw new Error("recovery.resource_exhausted");
    const url = new URL(`/v1/recovery/${path}`, this.endpoint);
    // There is exactly one request. A timeout must retain the same command ID.
    let response: Response;
    try {
      response = await this.transport(url, { method: "POST", redirect: "error",
        headers: { "content-type": "application/json" }, body: bytes, signal: AbortSignal.timeout(20000) });
    } catch { throw new Error("recovery.unavailable"); }
    if (!response.ok || !response.body) throw new Error("recovery.refused_or_unavailable");
    const reader = response.body.getReader();
    const chunks: Uint8Array[] = [];
    let size = 0;
    let exhausted = false;
    try {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        size += value.length;
        if (size > 262144) { exhausted = true; await reader.cancel(); throw new Error("response too large"); }
        chunks.push(value);
      }
    } catch { throw new Error(exhausted ? "recovery.resource_exhausted" : "recovery.unavailable"); }
    finally { reader.releaseLock(); }
    const output = new Uint8Array(size);
    let offset = 0;
    for (const chunk of chunks) { output.set(chunk, offset); offset += chunk.length; }
    try {
      const value: unknown = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(output));
      if (!validates(schema, value)) throw new Error("invalid shape");
      return value as T;
    } catch { throw new Error("recovery.invalid_response"); }
  }
}
