# DO NOT EDIT - regenerate via 'cargo xtask codegen --lang python'.
#
# Source: spec/schemas/chio-wire/v1/**/*.schema.json
# Tool:   datamodel-code-generator==0.34.0 (see xtask/codegen-tools.lock.toml)
# Schema sha256: c618c87a8481fbf811b52cce1b42dd299f0800b0522f5870fa7cdf2249d17b93
#
# Manual edits will be overwritten by the next regeneration; the
# spec-drift CI lane enforces this header on every file
# under sdks/python/chio-sdk-python/src/chio_sdk/_generated/.

from __future__ import annotations

from .action_intent_schema import OpaqueId, RecoveryDigest32, RecoveryDigest32Item, RecoveryExactActionIntentV1, SafeInteger, Scope
from .approval_intent_schema import Obligations, Obligations1, Obligations2, Obligations3, OpaqueId, RecoveryApprovalIntentV1, RecoveryDigest32, RecoveryDigest32Item, SafeInteger, Scope
from .approval_submission_schema import OpaqueId, RecoveryApprovalSubmissionV1, RecoveryDigest32, RecoveryDigest32Item, SafeInteger, Scope
from .authority_coverage_schema import Obligations, Obligations5, Obligations6, Obligations7, OpaqueId, RecoveryAuthorityCoverageBodyV1, RecoveryDigest32, RecoveryDigest32Item, SafeInteger, Scope
from .authorization_requirements_schema import AttachmentProfile, Obligations, Obligations10, Obligations11, Obligations9, OpaqueId, RecoveryAuthorizationRequirementsV1, RecoveryDigest32, RecoveryDigest32Item, SafeInteger, Scope
from .command_response_schema import Control, OpaqueId, Operation, RecoveryCommandResponseV1, RecoveryDigest32, RecoveryDigest32Item, RecoveryEffectAdmissionUnresolvedV1, RecoveryEffectAwaitingApprovalV1, RecoveryEffectAwaitingCallerReportV1, RecoveryEffectClosedBeforeEffectV1, RecoveryEffectCompleteV1, RecoveryEffectFailedAfterEffectV1, RecoveryEffectInFlightV1, RecoveryEffectNeverAdmittedV1, RecoveryEffectPartialV1, RecoveryEffectUnknownV1, RefusalCode, Release, Release1, Release2, Release3, Release4, SafeInteger, Scope
from .command_result_schema import OpaqueId, Operation, OriginalResponse, RecoveryCommandResultV1, RecoveryDigest32, RecoveryDigest32Item, RecoveryEffectAdmissionUnresolvedV1, RecoveryEffectAwaitingApprovalV1, RecoveryEffectAwaitingCallerReportV1, RecoveryEffectClosedBeforeEffectV1, RecoveryEffectCompleteV1, RecoveryEffectFailedAfterEffectV1, RecoveryEffectInFlightV1, RecoveryEffectNeverAdmittedV1, RecoveryEffectPartialV1, RecoveryEffectUnknownV1, RefusalCode, SafeInteger, Scope
from .command_schema import Command, Command1, Command2, Command3, Command4, Command5, Command6, Decision, OpaqueId, RecoveryCommandV1, RecoveryDigest32, RecoveryDigest32Item, SafeInteger, Scope, Template
from .dependency_graph_schema import Node, RecoveryDependencyGraphV1
from .disclosure_grant_schema import VersionSelectedDisclosureGrant, VersionSelectedDisclosureGrant1
from .effect_contract_schema import LookupFinality, SemanticEffectContractV1
from .grant_binding_schema import OpaqueId, RecoveryDigest32, RecoveryDigest32Item, RecoveryMandatoryGrantBindingV1, SafeInteger, Scope
from .observation_schema import Control, OpaqueId, Operation, RecoveryDigest32, RecoveryDigest32Item, RecoveryEffectAdmissionUnresolvedV1, RecoveryEffectAwaitingApprovalV1, RecoveryEffectAwaitingCallerReportV1, RecoveryEffectClosedBeforeEffectV1, RecoveryEffectCompleteV1, RecoveryEffectFailedAfterEffectV1, RecoveryEffectInFlightV1, RecoveryEffectNeverAdmittedV1, RecoveryEffectPartialV1, RecoveryEffectUnknownV1, RecoveryObservationV1, RefusalCode, Release, Release6, Release7, Release8, Release9, SafeInteger, Scope
from .profile_requirements_schema import AttachmentProfile, RecoveryProfileRequirementsV1, RequiredFeature
from .provider_finality_schema import Disposition, OpaqueId, RecoveryDigest32, RecoveryDigest32Item, RecoveryProviderPositiveFinalityV1, SafeInteger, Scope
from .review_document_schema import OpaqueId, Operation, RecoveryDigest32, RecoveryDigest32Item, RecoveryEffectAdmissionUnresolvedV1, RecoveryEffectAwaitingApprovalV1, RecoveryEffectAwaitingCallerReportV1, RecoveryEffectClosedBeforeEffectV1, RecoveryEffectCompleteV1, RecoveryEffectFailedAfterEffectV1, RecoveryEffectInFlightV1, RecoveryEffectNeverAdmittedV1, RecoveryEffectPartialV1, RecoveryEffectUnknownV1, RecoveryReviewDocumentV1, RefusalCode, SafeInteger, Scope
from .review_request_schema import OpaqueId, Operation, RecoveryDigest32, RecoveryDigest32Item, RecoveryEffectAdmissionUnresolvedV1, RecoveryEffectAwaitingApprovalV1, RecoveryEffectAwaitingCallerReportV1, RecoveryEffectClosedBeforeEffectV1, RecoveryEffectCompleteV1, RecoveryEffectFailedAfterEffectV1, RecoveryEffectInFlightV1, RecoveryEffectNeverAdmittedV1, RecoveryEffectPartialV1, RecoveryEffectUnknownV1, RecoveryReviewRequestV1, RefusalCode, SafeInteger, Scope
from .signed_authority_coverage_schema import Algorithm, OpaqueId, RecoveryDigest32, RecoveryDigest32Item, SafeInteger, Scope, SignedRecoveryAuthorityCoverageV1
from .signed_grant_v2_schema import Algorithm, Body, OpaqueId, RecoveryDigest32, RecoveryDigest32Item, SafeInteger, Scope, SignedRecoveryDeclassificationGrantV2
from .signed_provider_finality_schema import Algorithm, OpaqueId, RecoveryDigest32, RecoveryDigest32Item, SafeInteger, Scope, SignedRecoveryProviderFinalityV1
from .support_issue_effect_schema import OpaqueId, Operation, RecoveryDigest32, RecoveryDigest32Item, RecoveryEffectAdmissionUnresolvedV1, RecoveryEffectAwaitingApprovalV1, RecoveryEffectAwaitingCallerReportV1, RecoveryEffectClosedBeforeEffectV1, RecoveryEffectCompleteV1, RecoveryEffectFailedAfterEffectV1, RecoveryEffectInFlightV1, RecoveryEffectNeverAdmittedV1, RecoveryEffectPartialV1, RecoveryEffectUnknownV1, RecoverySupportIssueEffectContractV1, RefusalCode, SafeInteger, Scope
from .support_issue_input_schema import OpaqueId, Operation, RecoveryDigest32, RecoveryDigest32Item, RecoveryEffectAdmissionUnresolvedV1, RecoveryEffectAwaitingApprovalV1, RecoveryEffectAwaitingCallerReportV1, RecoveryEffectClosedBeforeEffectV1, RecoveryEffectCompleteV1, RecoveryEffectFailedAfterEffectV1, RecoveryEffectInFlightV1, RecoveryEffectNeverAdmittedV1, RecoveryEffectPartialV1, RecoveryEffectUnknownV1, RecoverySupportIssueInputV1, RefusalCode, SafeInteger, Scope
from .trajectory_schema import Expected, Frame, RecoveryTrajectoryV1
from .transport_request_schema import OpaqueId, Operation, RecoveryDigest32, RecoveryDigest32Item, RecoveryEffectAdmissionUnresolvedV1, RecoveryEffectAwaitingApprovalV1, RecoveryEffectAwaitingCallerReportV1, RecoveryEffectClosedBeforeEffectV1, RecoveryEffectCompleteV1, RecoveryEffectFailedAfterEffectV1, RecoveryEffectInFlightV1, RecoveryEffectNeverAdmittedV1, RecoveryEffectPartialV1, RecoveryEffectUnknownV1, RecoveryTransportRequestV1, RefusalCode, SafeInteger, Scope

__all__ = [
    "Algorithm",
    "AttachmentProfile",
    "Body",
    "Command",
    "Command1",
    "Command2",
    "Command3",
    "Command4",
    "Command5",
    "Command6",
    "Control",
    "Decision",
    "Disposition",
    "Expected",
    "Frame",
    "LookupFinality",
    "Node",
    "Obligations",
    "Obligations1",
    "Obligations10",
    "Obligations11",
    "Obligations2",
    "Obligations3",
    "Obligations5",
    "Obligations6",
    "Obligations7",
    "Obligations9",
    "OpaqueId",
    "Operation",
    "OriginalResponse",
    "RecoveryApprovalIntentV1",
    "RecoveryApprovalSubmissionV1",
    "RecoveryAuthorityCoverageBodyV1",
    "RecoveryAuthorizationRequirementsV1",
    "RecoveryCommandResponseV1",
    "RecoveryCommandResultV1",
    "RecoveryCommandV1",
    "RecoveryDependencyGraphV1",
    "RecoveryDigest32",
    "RecoveryDigest32Item",
    "RecoveryEffectAdmissionUnresolvedV1",
    "RecoveryEffectAwaitingApprovalV1",
    "RecoveryEffectAwaitingCallerReportV1",
    "RecoveryEffectClosedBeforeEffectV1",
    "RecoveryEffectCompleteV1",
    "RecoveryEffectFailedAfterEffectV1",
    "RecoveryEffectInFlightV1",
    "RecoveryEffectNeverAdmittedV1",
    "RecoveryEffectPartialV1",
    "RecoveryEffectUnknownV1",
    "RecoveryExactActionIntentV1",
    "RecoveryMandatoryGrantBindingV1",
    "RecoveryObservationV1",
    "RecoveryProfileRequirementsV1",
    "RecoveryProviderPositiveFinalityV1",
    "RecoveryReviewDocumentV1",
    "RecoveryReviewRequestV1",
    "RecoverySupportIssueEffectContractV1",
    "RecoverySupportIssueInputV1",
    "RecoveryTrajectoryV1",
    "RecoveryTransportRequestV1",
    "RefusalCode",
    "Release",
    "Release1",
    "Release2",
    "Release3",
    "Release4",
    "Release6",
    "Release7",
    "Release8",
    "Release9",
    "RequiredFeature",
    "SafeInteger",
    "Scope",
    "SemanticEffectContractV1",
    "SignedRecoveryAuthorityCoverageV1",
    "SignedRecoveryDeclassificationGrantV2",
    "SignedRecoveryProviderFinalityV1",
    "Template",
    "VersionSelectedDisclosureGrant",
    "VersionSelectedDisclosureGrant1",
]
