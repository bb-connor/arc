Hosted PostgreSQL qualification at 3ca011d103c82ddaba88dc829680f248bafe28d6.
Run 34287003137 succeeded. Ownership/recovery group: 14 receipts. Committed-claim response loss: 9 receipts.
This validates pure-result finalization on Linux. It predates the recorded-response binding fix.
