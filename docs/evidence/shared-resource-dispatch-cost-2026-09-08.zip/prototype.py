import hashlib
import json
import os
import statistics
import subprocess
import sys
import time
from pathlib import Path
from types import SimpleNamespace

repo = Path.cwd()
sys.path.insert(0, str(repo / "examples/shared-resource-swarm"))
import run
import store
from mcp_client import McpClient
from chio_process import ProcessClient
from chio_process.invocation import invoke_recorded
from chio_process.launch import demo_python

os.umask(0o077)
root = Path(__file__).resolve().parent
directory = root / "p1"
directory.mkdir(mode=0o700)
(directory / "benchmark").mkdir(mode=0o700)
seed = json.loads((run.HERE / "seed.json").read_text())
store.initialize(directory / "resource.db", seed)
store.initialize(directory / "baseline.db", seed)
started = time.perf_counter()
binary, key = run.prepare_host(SimpleNamespace(chio=root / "chio"), directory, roles=("benchmark",))
setup_seconds = time.perf_counter() - started
connection = json.loads((directory / "benchmark/connection.json").read_text())
client = ProcessClient(connection["socket_path"], connection["credential"])
samples, receipts, originals = [], [], {}
arguments = {"document": "release-board"}

def native(operation):
    response = client.invoke(operation, "board", "snapshot", arguments, known_outcome_only=True)
    assert response["verdict"] == "allow"
    assert response["output"]["value"]["isError"] is False
    receipts.append(response["receipt_json"])
    if operation in originals:
        assert originals[operation] == response["receipt_json"]
    else:
        originals[operation] = response["receipt_json"]
    return response["output"]["value"]

command = [demo_python(),str(run.HERE / "server.py"),"--database",str(directory / "baseline.db"),"--connection-caller",connection["caller_capability_sha256"]]
started = time.perf_counter()
baseline = McpClient(command)
baseline_start_seconds = time.perf_counter() - started
started = time.perf_counter()
try:
    with run.host(binary, key, directory):
        host_start_seconds = time.perf_counter() - started
        assert native("warmup") == baseline.invoke("warmup", "snapshot", arguments)
        for phase in ("fresh", "replay"):
            for index in range(20):
                returned = []
                for backend in (("baseline", "chio") if index % 2 == 0 else ("chio", "baseline")):
                    before = time.perf_counter_ns()
                    operation = f"probe-{index}"
                    response = native(operation) if backend == "chio" else baseline.invoke(operation, "snapshot", arguments)
                    elapsed_ns = time.perf_counter_ns() - before
                    returned.append(response)
                    samples.append({"phase":phase,"backend":backend,"round":index,"elapsed_ns":elapsed_ns})
                assert returned[0] == returned[1]
        for phase in ("fresh", "replay"):
            for index in range(5):
                operation = f"recorded-{index}"
                before = time.perf_counter_ns()
                response = invoke_recorded(binary,connection,key+"\n",{"operation_key":operation,"server_id":"board","tool_name":"snapshot","arguments":arguments},directory/f"{phase}-{index}")
                elapsed_ns = time.perf_counter_ns() - before
                assert response["verdict"] == "allow"
                assert response["output"]["value"]["isError"] is False
                receipts.append(response["receipt_json"])
                if operation in originals:
                    assert originals[operation] == response["receipt_json"]
                else:
                    originals[operation] = response["receipt_json"]
                samples.append({"phase":phase,"backend":"chio_recorded_verified","round":index,"elapsed_ns":elapsed_ns})
finally:
    baseline.close()
resources = {name:store.inspect(directory/file) for name,file in [("baseline","baseline.db"),("chio","resource.db")]}
assert all(len(r["mutations"]) == 0 for r in resources.values())
for backend,resource in resources.items():
    deliveries = [o["deliveries"] for o in resource["operations"]]
    assert len(deliveries) == (21 if backend == "baseline" else 26)
    assert sorted(deliveries) == ([1]+[2]*20 if backend == "baseline" else [1]*26)
(directory / "receipts.ndjson").write_text("\n".join(dict.fromkeys(receipts))+"\n")
started = time.perf_counter()
subprocess.run([str(binary),"receipt","verify","--input",str(directory / "receipts.ndjson"),"--trusted-kernel-pubkey",str(directory / "kernel.pub")],check=True)
verification_seconds = time.perf_counter()-started
groups=[]
for backend in ["baseline","chio","chio_recorded_verified"]:
    for phase in ["fresh","replay"]:
        values=[s["elapsed_ns"]/1e6 for s in samples if s["backend"]==backend and s["phase"]==phase]
        groups.append({"backend":backend,"phase":phase,"count":len(values),"median_ms":statistics.median(values),"minimum_ms":min(values),"maximum_ms":max(values)})
report={"schema":"chio.shared-resource.dispatch-probe.v1","source_commit":subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip(),"binary_sha256":hashlib.sha256(binary.read_bytes()).hexdigest(),"build_profile":"dev_debug_0_unoptimized","task":"unchanged document snapshot with durable resource operation retention","live_model":False,"chio_operator_provisioning_seconds":setup_seconds,"chio_host_start_seconds":host_start_seconds,"baseline_server_start_seconds":baseline_start_seconds,"batch_verification_seconds":verification_seconds,"verified_unique_receipts":len(set(receipts)),"samples":samples,"groups":groups,"resource_operation_counts":{k:len(v["operations"]) for k,v in resources.items()},"limits":["Development build screening, not release throughput or end-to-end agent performance.","Baseline has persistent resource request identity and deduplication but no Chio authority mediation or signed kernel receipts.","Known completed replay measured, not uncertain redispatch.","No installation time, model latency or human setup effort is included."]}
(directory/"report.json").write_text(json.dumps(report,indent=2)+"\n")
print(json.dumps({k:report[k] for k in ["chio_operator_provisioning_seconds","chio_host_start_seconds","baseline_server_start_seconds","batch_verification_seconds","groups"]}))
