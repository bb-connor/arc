import hashlib
import json
import sqlite3
import sys
from pathlib import Path

sys.path.insert(0, str(Path.cwd() / 'examples/shared-resource-swarm'))
import probe_dispatch
from chio_process import ProcessClient

output = Path(sys.argv[sys.argv.index('--output') + 1]).resolve()
counts = []
original = ProcessClient.invoke


def snapshot():
    files = list((output / 'host/authority.db.locks').glob('*.lock'))
    assert len(files) == 1
    data = files[0].read_bytes()
    assert len(data) == 2048
    anchors = []
    for offset in (0, 1024):
        slot = data[offset:offset+1024]
        assert slot[:8] == b'CHIOA1OK'
        length = int.from_bytes(slot[8:12], 'big')
        assert 0 < length <= 948
        payload = slot[76:76+length]
        assert slot[12:76] == hashlib.sha256(payload).hexdigest().encode()
        assert slot[76+length:] == bytes(1024-76-length)
        anchors.append(json.loads(payload))
    latest = max(anchors, key=lambda a: a['generation'])
    with sqlite3.connect((output/'host/authority.db').as_uri()+'?mode=ro', uri=True) as c:
        head = c.execute('select head_sequence,head_chain_digest from authority_global_commit_meta').fetchone()
        assert head == (latest['global_commit_head'], latest['global_commit_chain_digest'])
    return {key: latest[key] for key in ('generation', 'admission_commit_head', 'global_commit_head')}


def counted(self, operation_key, *args, **kwargs):
    before = snapshot()
    response = original(self, operation_key, *args, **kwargs)
    after = snapshot()
    with sqlite3.connect((output/'host/authority.db').as_uri()+'?mode=ro', uri=True) as c:
        rows = c.execute('select mutation_kind,projection_kind from authority_global_commits where commit_sequence > ? and commit_sequence <= ? order by commit_sequence', (before['global_commit_head'], after['global_commit_head'])).fetchall()
    counts.append({'operation_key': operation_key, 'before': before, 'after': after, 'delta': {key: after[key]-before[key] for key in before}, 'global_mutations': rows})
    return response


ProcessClient.invoke = counted
try:
    probe_dispatch.main()
finally:
    if output.exists():
        (output/'transition-counts.json').write_text(json.dumps({'schema':'chio.shared-resource.authority-transition-counts.v1','source_commit':probe_dispatch.subprocess.check_output(['git','rev-parse','HEAD'], text=True).strip(),'observations':counts,'limits':['Single owned quiescent host. Anchor and SQLite reads bracket each in-process invocation. Timing from this instrumented run is excluded from performance comparisons.','Generation deltas count completed anchor slot installations, not all filesystem synchronization calls.']},indent=2)+'\n')
print(json.dumps([{'operation':r['operation_key'],'delta':r['delta']} for r in counts]))
