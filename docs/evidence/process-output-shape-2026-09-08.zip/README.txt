Output-shape correction at 7716292a34dccc580a18df3c8d6513e925c6d9cd.
A native regression first reproduced successful JSON null output being replaced with absent output while verification still reported success.
Decision-specific shape checks now preserve completed values, withheld results, cancellation, incomplete streams and nonce preflight. Four binding regression functions plus original receipt verification pass; scoped Clippy and formatting pass.
The new native verifier reproduces all 34 expected outcomes on the previously archived SQLite/PostgreSQL responses: 23 accepted, 11 rejected. This is verification of retained responses, not a new live-host or model run.
The source-only lifecycle assessment does not establish a renewal requirement or adoption advantage; no consumer or authority-policy implementation was changed.
