use std::{io::{Read, Write}, net::{TcpListener, TcpStream}, sync::mpsc, thread, time::{Duration, Instant}};
fn main() -> std::io::Result<()> {
    for normalize in [false, true] {
        let listener = TcpListener::bind("127.0.0.1:0")?;
        listener.set_nonblocking(true)?;
        let address = listener.local_addr()?;
        let (sender, receiver) = mpsc::channel();
        let client = thread::spawn(move || {
            let mut stream = TcpStream::connect(address).unwrap();
            receiver.recv().unwrap();
            thread::sleep(Duration::from_millis(25));
            stream.write_all(b"x")
        });
        let mut stream = loop {
            match listener.accept() {
                Ok((stream, _)) => break stream,
                Err(e) if e.kind() == std::io::ErrorKind::WouldBlock => thread::yield_now(),
                Err(e) => return Err(e),
            }
        };
        if normalize { stream.set_nonblocking(false)?; }
        stream.set_read_timeout(Some(Duration::from_secs(1)))?;
        sender.send(()).unwrap();
        let before = Instant::now();
        let mut byte = [0];
        let result = stream.read_exact(&mut byte);
        println!("normalize={normalize} result={result:?} elapsed_ms={:.3}", before.elapsed().as_secs_f64()*1000.0);
        let _ = client.join().unwrap();
    }
    Ok(())
}
