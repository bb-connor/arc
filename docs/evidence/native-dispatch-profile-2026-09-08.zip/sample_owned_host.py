import contextlib
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path.cwd() / "examples/shared-resource-swarm"))
import probe_dispatch
import run

original = run.host


@contextlib.contextmanager
def sampled_host(binary, key, directory, socket_path=None):
    with original(binary, key, directory, socket_path) as process:
        with (directory / "sample.log").open("x") as log:
            sampler = subprocess.Popen(
                ["sample", str(process.pid), "3", "1", "-file", str(directory / "host.sample.txt")],
                stdout=log, stderr=log,
            )
            try:
                yield process
            finally:
                if sampler.wait(timeout=10) != 0:
                    raise RuntimeError("owned host sampling failed; inspect sample.log")


run.host = sampled_host
probe_dispatch.main()
