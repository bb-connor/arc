
<private-run-root>/chio-optimized:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100000c00 <__text>:
104c6fe90: 52808018    	mov	w24, #0x400             ; =1024
104c6fe94: 12b00013    	mov	w19, #0x7fffffff        ; =2147483647
104c6fe98: b94102b9    	ldr	w25, [x21, #0x100]
104c6fe9c: eb13031f    	cmp	x24, x19
104c6fea0: 9a933302    	csel	x2, x24, x19, lo
104c6fea4: aa1903e0    	mov	x0, x25
104c6fea8: aa1703e1    	mov	x1, x23
104c6feac: aa1603e3    	mov	x3, x22
104c6feb0: 9464c8d4    	bl	0x1065a2200 <dyld_stub_binder+0x1065a2200>
104c6feb4: b100041f    	cmn	x0, #0x1
104c6feb8: 54000400    	b.eq	0x104c6ff38 <__text+0x4c6f338>
104c6febc: b4000300    	cbz	x0, 0x104c6ff1c <__text+0x4c6f31c>
104c6fec0: eb000308    	subs	x8, x24, x0
104c6fec4: 540016e3    	b.lo	0x104c701a0 <__text+0x4c6f5a0>
104c6fec8: 8b160016    	add	x22, x0, x22
104c6fecc: 8b0002f7    	add	x23, x23, x0
104c6fed0: aa0803f8    	mov	x24, x8
104c6fed4: 54fffe41    	b.ne	0x104c6fe9c <__text+0x4c6f29c>
104c6fed8: b94102b6    	ldr	w22, [x21, #0x100]
104c6fedc: a9414ff7    	ldp	x23, x19, [sp, #0x10]
104c6fee0: aa1603e0    	mov	x0, x22
104c6fee4: 52800661    	mov	w1, #0x33               ; =51
104c6fee8: 9464c75b    	bl	0x1065a1c54 <dyld_stub_binder+0x1065a1c54>
104c6feec: 3100041f    	cmn	w0, #0x1
104c6fef0: 54000761    	b.ne	0x104c6ffdc <__text+0x4c6f3dc>
104c6fef4: 9464c6b0    	bl	0x1065a19b4 <dyld_stub_binder+0x1065a19b4>
104c6fef8: b9800008    	ldrsw	x8, [x0]
104c6fefc: 7100111f    	cmp	w8, #0x4
104c6ff00: 54ffff00    	b.eq	0x104c6fee0 <__text+0x4c6f2e0>
104c6ff04: 52800049    	mov	w9, #0x2                ; =2
104c6ff08: aa088128    	orr	x8, x9, x8, lsl #32
104c6ff0c: d1001f69    	sub	x9, x27, #0x7
104c6ff10: a9002289    	stp	x9, x8, [x20]
104c6ff14: b5000237    	cbnz	x23, 0x104c6ff58 <__text+0x4c6f358>
104c6ff18: 14000012    	b	0x104c6ff60 <__text+0x4c6f360>
104c6ff1c: d2800068    	mov	x8, #0x3                ; =3
