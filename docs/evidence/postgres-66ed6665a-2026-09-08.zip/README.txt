Hosted PostgreSQL qualification at PR #1154 head 66ed6665a11aa4debf2e7b92b359b8bfbd5eaa0a passed in run 34292035414.
The 14- and 9-receipt groups verify again locally. This predates the output-shape correction.
