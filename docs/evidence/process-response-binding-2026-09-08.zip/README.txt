Recorded-response binding candidate be0cf0d381ea69a02b317f51edb0d8660971f366.
The private native dev binary was built before commit; changed source hashes match that commit.
The earlier installed helper accepted a changed output, verdict and operation key paired with an original receipt. Transport was mocked; native signature verification was real. This is not a demonstrated socket compromise.
The corrected installed helper accepts the positive and rejects ten mismatches, invoking once per case with no automatic retry.
Real SQLite ownership/restart and PostgreSQL ownership/restart/committed-claim-loss qualifiers pass, using the installed process wheel and native host.
Rust CLI verification tests pass (three binding tests and one original-receipt test); Python reports 22 tests, three skipped.
Broad local Clippy stops at an unchanged control-plane unused import; no-deps CLI Clippy passes. The separate host test passes with TMPDIR=/private/tmp; the initial default macOS path exceeded the Unix socket limit.
Execution nonces are explicitly outside these receipt checks. No live model calls or adoption claim.
