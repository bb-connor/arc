Hosted Linux standard-release qualification at e470d05f3b2c04dd3a09178df0612346c17fa9e1.
Run 34286554448 succeeded. Both dispatch groups contain 26 original verified receipts.
Build-before and build-after are equal. Fresh and replay timings compare this full Chio path to direct resource access, not equivalent guarantees.
The upstream comparison source_commit identifies its coding fixture; the Chio build commit is in build provenance. Decisions are controlled; no live model or adoption claim.
Recorded invocation timings predate the response-binding fix and cover signature verification only.
