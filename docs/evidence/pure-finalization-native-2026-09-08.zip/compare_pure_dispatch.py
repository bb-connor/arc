"""Fixed old/new/new/old serial comparison; no adaptive timing selection."""
import argparse
import hashlib
import json
import statistics
import subprocess
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--root', type=Path, required=True)
parser.add_argument('--candidate', type=Path, required=True)
parser.add_argument('--candidate-source', required=True)
args = parser.parse_args()
root = args.root.resolve(strict=True)
base = root / 'chio-optimized'
python = root / 'venv/bin/python'
assert len(args.candidate_source) == 40
candidate = args.candidate.resolve(strict=True)
assert hashlib.sha256(base.read_bytes()).hexdigest() == 'dbfe31559a4da22c7e098f4c357d3f188f277cc0380ef3e11179675f632d3097'
plan = [('b7', 'before', base, 'd763ad5de92a429b5028c62964a9ee313be3f8a7'),
        ('n7', 'after', candidate, args.candidate_source),
        ('n8', 'after', candidate, args.candidate_source),
        ('b8', 'before', base, 'd763ad5de92a429b5028c62964a9ee313be3f8a7')]
assert all(not (root / name).exists() for name, *_ in plan)
plan_file = root / 'pure-comparison-plan.json'
with plan_file.open('x') as output:
    json.dump({'runs': [{'directory': n, 'variant': v, 'source': s, 'binary_sha256': hashlib.sha256(b.read_bytes()).hexdigest()} for n, v, b, s in plan], 'rounds': 20, 'live_model': False, 'timing_selection': 'all four predetermined runs; no adaptive rerun or outlier exclusion'}, output, indent=2)
reports = []
for name, variant, binary, source in plan:
    with (root / (name + '.log')).open('x') as log:
        subprocess.run([str(python), 'examples/shared-resource-swarm/probe_dispatch.py', '--chio', str(binary), '--output', str(root / name), '--build-profile', 'docker-release', '--binary-source-commit', source, '--rounds', '20'], check=True, stdout=log, stderr=log)
    data = (root / name / 'report.json').read_bytes()
    report = json.loads(data)
    assert report['verified_unique_receipts'] == 26
    assert len(report['resource_deliveries']['chio']) == 26
    assert set(report['resource_deliveries']['chio'].values()) == {1}
    reports.append({'directory': name, 'variant': variant, 'report_sha256': hashlib.sha256(data).hexdigest(), 'report': report})
    print(json.dumps({'run': name, 'variant': variant, 'groups': report['groups']}), flush=True)
summary = []
for backend in ('baseline', 'chio', 'chio_recorded_verified'):
    for phase in ('fresh', 'replay'):
        medians = {}
        for variant in ('before', 'after'):
            medians[variant] = [next(g['median_ms'] for g in r['report']['groups'] if g['backend'] == backend and g['phase'] == phase) for r in reports if r['variant'] == variant]
        before, after = statistics.mean(medians['before']), statistics.mean(medians['after'])
        summary.append({'backend': backend, 'phase': phase, 'run_medians_ms': medians, 'mean_run_median_before_ms': before, 'mean_run_median_after_ms': after, 'relative_change': after / before - 1})
with (root / 'pure-dispatch-comparison.json').open('x') as output:
    json.dump({'schema': 'chio.shared-resource.pure-finalization-comparison.v1', 'reports': reports, 'summary': summary, 'limits': ['Single-host serial local diagnostic; these timing samples do not establish end-to-end agent performance or Linux throughput.', 'The direct MCP resource baseline omits kernel authority mediation and signed receipts.', 'Mean of the two run medians is descriptive, not a significance test. All four predetermined runs are retained.']}, output, indent=2)
print(json.dumps(summary, indent=2), flush=True)
