"""Exercise production prerequisite provisioning in an empty rustup home."""
import importlib.util
import os
from pathlib import Path
import subprocess
import tempfile

root = Path('/home/connor/backbay/arc-agentic-work-plan')
spec = importlib.util.spec_from_file_location('kani_toolchain', root / 'scripts/kani-toolchain.py')
kani = importlib.util.module_from_spec(spec)
spec.loader.exec_module(kani)
with tempfile.TemporaryDirectory(prefix='chio-pr1173-cold-rustup-') as scratch:
    directory = Path(scratch)
    os.environ['RUSTUP_HOME'] = str(directory / 'rustup')
    os.environ['RUSTUP_TOOLCHAIN'] = kani.TOOLCHAIN
    assert not Path(os.environ['RUSTUP_HOME']).exists()
    print('Cold provisioning: RUSTUP_HOME does not exist', flush=True)
    kani.install_build_toolchain()
    subprocess.run(['rustup', 'component', 'list', '--toolchain', kani.TOOLCHAIN, '--installed'], check=True)
    subprocess.run(['rustc', '-Vv'], check=True)
    source = directory / 'compiler_private_probe.rs'
    source.write_text('#![feature(rustc_private)]\nextern crate rustc_abi;\nextern crate rustc_driver;\nextern crate rustc_public_bridge;\nextern crate tempfile;\nfn main() {}\n')
    subprocess.run(['rustc', '--emit=metadata', str(source), '-o', str(directory / 'probe.rmeta')], check=True)
    print('PASS: compiler-private dependencies resolved after cold provisioning', flush=True)
