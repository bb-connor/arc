import json
from pathlib import Path
import subprocess
import tempfile

root = Path(tempfile.mkdtemp(prefix='chio-init-budget-', dir='/tmp/chio-pr1173-readiness'))
key = 'd75a980182b10ab7d54bfed3c964073a0ee172f3daa62325af021a68f707511a'
policy = root / 'policy.yaml'
policy.write_text('BROKER_BUDGET_PROBE: intentionally_invalid\n')
launch = root / 'launch.json'
launch.write_text('{}\n')
public = {'kind':'known', 'owners':{}, 'compartments':[]}
servers=[]
routes=[]
for i,tool in enumerate(('task','complete','renew','assign','release','inspect')):
    server=('jobs-' if i < 3 else 'jobs-admin-') + tool
    servers.append({'id':server, 'command':['/bin/false'], 'request_timeout_seconds':60,
                    'launch_policy':str(launch), 'launch_policy_signer':key})
    routes.append({'quota':{'issuer':key,'audience':f'consumer-broker-{i}',
                           'server_id':server,'tool_name':tool,'provider_adapter_id':'test-https',
                           'provider_adapter_version':1,'credential_placement':'bearer_authorization'},
                   'broker_identity':key,'revocation_authority_domain':'test-authority',
                   'ipc_timeout_ms':3000,'authority_socket_name':f'authority-{i}.sock',
                   'preparation':None})
config={'schema':'chio.process.host.v1','policy':str(policy),'servers':servers,
        'execution_nonces':True,'limits':{'max_calls':100,'max_processes':3,'max_depth':1},
        'children':[{'id':name,'parent':'root','budget_share_bps':4000,
                     'tools':[{'server_id':'jobs-'+t,'tool_name':t} for t in ('task','complete','renew')]}
                    for name in ('superseded','replacement')],
        'native_broker':{'keyring':None,'security':{'tenant_id':'test-tenant','isolation_epoch_id':'consumer-epoch','generation':1},
                         'routes':routes, 'authority_seed_file':str(root/'authority.seed'),
                         'authority_public_key':key,'fence_ttl_ms':10000,'operator_input_floor':public,
                         'classifier':{'id':'consumer-rules','version':'1',
                                       'rules':[{'category':'private','expression':'PRIVATE_INPUT','confidence_basis_points':10000}],
                                       'category_labels':{'private':{**public,'compartments':['private']}}}}}
path=root/'config.json'
path.write_text(json.dumps(config))
base=['/home/connor/chio-pr1173-target/debug/chio','process','init','--config',str(path),'--state',str(root/'host')]
for arguments, expected in (([], 'native broker hosts require an explicit aggregate invocation budget'),
                            (['--aggregate-invocations','100'], 'BROKER_BUDGET_PROBE')):
    result=subprocess.run(base+arguments, capture_output=True, text=True, timeout=30)
    print('arguments',arguments,'exit',result.returncode)
    print(result.stderr,end='')
    assert result.returncode != 0 and expected in result.stderr
    assert not (root/'host').exists()
print('Real CLI: missing budget rejects; explicit budget reaches the deliberately invalid policy. No host is provisioned.')
import sys
checkout = Path('/home/connor/backbay/arc-agentic-work-plan')
sys.path[:0] = [str(checkout/'examples/postgres-job-swarm'), str(checkout/'sdks/python/chio-process/src')]
import host
try:
    host.initialize(Path(base[0]), None, root, path)
except RuntimeError:
    error = (root/'host-errors.log').read_text()
    print('Actual PostgreSQL host.initialize diagnostic:')
    print(error, end='')
    expected = 'BROKER_BUDGET_PROBE' if '--repaired' in sys.argv else 'native broker hosts require an explicit aggregate invocation budget'
    assert expected in error
else:
    raise AssertionError('Deliberately invalid policy must reject initialization')
assert not (root/'host').exists()
