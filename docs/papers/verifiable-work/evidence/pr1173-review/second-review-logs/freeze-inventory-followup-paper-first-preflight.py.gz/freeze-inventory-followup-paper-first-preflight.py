"""Renew derived artifacts after the qualified production-readiness follow-ups."""
import argparse
import datetime
import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/home/connor/backbay/arc-agentic-work-plan')
PAPER = ROOT / 'docs/papers/verifiable-work'
SCRATCH = Path('/tmp/chio-pr1173-readiness')
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--sha', required=True)
args = parser.parse_args()
assert len(args.sha) == 40 and all(c in '0123456789abcdef' for c in args.sha)
status = SCRATCH / ('paper-inventory-' + args.sha[:10] + '.status.json')
assert not status.exists(), 'preserve previous attempts'
record = {'pid': os.getpid(), 'source_head': args.sha, 'state': 'waiting-for-native',
          'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'commands': []}


def save():
    temporary = status.with_suffix('.tmp')
    temporary.write_text(json.dumps(record, indent=2) + '\n')
    temporary.replace(status)


save()
try:
    native_path = SCRATCH / ('qualification-' + args.sha[:10] + '.status.json')
    while True:
        assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == args.sha
        if native_path.exists():
            native = json.loads(native_path.read_text())
            assert native['source_head'] == args.sha
            if native['state'] != 'running':
                break
        time.sleep(10)
    assert native['state'] == 'completed' and native['exit_code'] == 0
    sys.path.insert(0, str(PAPER / 'tools'))
    from provenance import verify_qualification
    q = json.loads((ROOT / 'docs/research/dynamic-delegation/evidence/qualification.json').read_text())
    assert not verify_qualification(ROOT, q)
    assert len(q['commands']) == 21 and all(c['exit_code'] == 0 for c in q['commands'].values())
    assert len(q['outputs']) == 48
    assert 'Ran 20 tests' in (ROOT / 'docs/research/dynamic-delegation/evidence/qualified-artifact-tests.stderr').read_text()
    previous = json.loads(subprocess.check_output([
        'git', 'show', '3b6b2ba447c57162374e725f5d3bf49328fe7f54:docs/research/dynamic-delegation/evidence/qualification.json',
    ], cwd=ROOT, text=True))
    rust_paths = {p for p in previous['source_files'] | q['source_files'] if p.endswith('.rs')}
    changed = {p for p in rust_paths if previous['source_files'].get(p) != q['source_files'].get(p)}
    assert changed == {
        'crates/protocol/chio-a2a-edge/src/v1.rs',
        'crates/tooling/chio-conformance/tests/consumer_boundary.rs',
        'crates/tooling/chio-conformance/tests/consumer_boundary/support.rs',
        'crates/tooling/chio-conformance/tests/consumer_boundary/a2a_v1.rs',
        'crates/kernel/chio-kernel/src/kernel/evaluation/delivery_preparation.rs',
        'crates/kernel/chio-kernel/src/kernel/tests/durable_admission/delivery_revalidation.rs',
        'crates/kernel/chio-kernel/src/kernel/tests/durable_admission/delivery_revalidation/launch_receipt.rs',
        'crates/products/chio-cli/tests/certify.rs',
        'crates/products/chio-cli/tests/certify/generic_registry.rs',
        'crates/kernel/chio-kernel/src/delegated_work.rs',
        'crates/kernel/chio-kernel/tests/dynamic_delegation.rs',
        'crates/trust/chio-federation-transport-iroh/src/lanes/revocation.rs',
        'crates/trust/chio-federation-transport-iroh/src/lanes/revocation/tests.rs',
    }, changed
    a2a = json.loads((SCRATCH / 'a2a-nonterminal-final.status.json').read_text())
    assert a2a['state'] == 'completed' and a2a['exit_code'] == 0 and len(a2a['commands']) == 5
    assert all(c['exit_code'] == 0 for c in a2a['commands'])
    for name, count in [('consumer-boundary', 10), ('edge', 116), ('http-interop', 3)]:
        assert f'test result: ok. {count} passed; 0 failed; 0 ignored;' in (SCRATCH / ('a2a-nonterminal-final-' + name + '.log')).read_text()
    structural = json.loads((SCRATCH / 'a2a-nonterminal-structural-final.status.json').read_text())
    assert len(structural) == 6 and all(c['exit_code'] == 0 for c in structural)
    cli = json.loads((SCRATCH / 'cli-authority-qualification.status.json').read_text())
    for name, digest in cli['fixture_sources'].items():
        assert q['source_files'][name] == digest
    def verified_campaign(prefix, names, log_template=None):
        entry = json.loads((SCRATCH / (prefix + '.status.json')).read_text())
        assert entry['state'] == 'completed' and entry['exit_code'] == 0, prefix
        assert [c['name'] for c in entry['commands']] == names, prefix
        assert all(c['exit_code'] == 0 for c in entry['commands']), prefix
        for name, digest in entry.get('source_files', {}).items():
            assert q['source_files'][name] == digest, (prefix, name)
        for command in entry['commands']:
            fallback = (log_template.format(name=command['name']) if log_template
                        else prefix + '-' + command['name'] + '.log')
            log = Path(command.get('log', SCRATCH / fallback))
            assert hashlib.sha256(log.read_bytes()).hexdigest() == command['log_sha256'], log
        return entry

    flow = verified_campaign('flow-security-composed-final', ['gate'])
    import re
    flow_text = (SCRATCH / 'flow-security-composed-final-gate.log').read_text()
    passed = re.findall(r'^(.+) passed \(\d+ exact tests\)$', flow_text, re.MULTILINE)
    flow_labels = re.findall(r'^run_exact_target --label "([^"]+)"',
                             (ROOT / 'scripts/check-flow-security.sh').read_text(), re.MULTILINE)
    assert len(passed) == 71 and passed == flow_labels and 'Flow security gate passed' in flow_text
    assert 'security types library passed (26 exact tests)' in flow_text
    assert 'operator-owned manifest migration passed (8 exact tests)' in flow_text
    assert 'transport preparation provenance passed (10 exact tests)' in flow_text
    controls = verified_campaign('inventory-controls-final', ['flow', 'consumer', 'diff'])
    consumer = json.loads((SCRATCH / 'consumer-boundaries-composed-final.status.json').read_text())
    assert consumer['state'] == 'completed' and consumer['exit_code'] == 101
    assert len(consumer['commands']) == 1 and consumer['commands'][0]['exit_code'] == 101
    consumer_text = (SCRATCH / 'consumer-boundaries-composed-final-gate.log').read_text()
    consumer_labels = ['durable consumer boundaries'] + re.findall(
        r'^run_(?:case|target) "([^"]+)"',
        (ROOT / 'scripts/check-consumer-boundaries.sh').read_text(), re.MULTILINE)
    peer_labels = re.findall(r'^  run_tests "([^"]+)"',
                            (ROOT / 'scripts/check-protocol-peer-negotiation.sh').read_text(), re.MULTILINE)
    consumer_passed = re.findall(r'^(.+) passed \(\d+ exact tests\)$', consumer_text, re.MULTILINE)
    assert len(consumer_labels) == 26 and len(peer_labels) == 12
    assert consumer_passed == consumer_labels[:6]
    assert 'durable consumer boundaries passed (10 exact tests)' in consumer_text
    assert 'native MCP integration requires a qualified Linux x86_64 enforcing host' in consumer_text
    assert 'test result: FAILED. 0 passed; 1 failed; 0 ignored;' in consumer_text
    assert hashlib.sha256(consumer_text.encode()).hexdigest() == consumer['commands'][0]['log_sha256']
    for name, digest in consumer['source_files'].items():
        assert q['source_files'][name] == digest, name
    kernel = verified_campaign('kernel-legacy-receipt-green', ['format', 'delivery', 'clippy'],
                               'kernel-legacy-receipt-{name}-green.log')
    assert 'test result: ok. 10 passed; 0 failed; 0 ignored;' in (
        SCRATCH / 'kernel-legacy-receipt-delivery-green.log').read_text()
    verified_campaign('stub-surfaces-qualified-final', ['contract', 'repository'])
    verified_campaign('mini-swe-native-python-final', ['environment', 'capabilities', 'sdk', 'lint', 'format'])
    assert '414 passed' in (SCRATCH / 'mini-swe-native-python-final-sdk.log').read_text()
    review_names = ['delegated', 'revocation', 'delegated-clippy', 'revocation-clippy',
                    'proof-refresh', 'proof-check', 'hygiene', 'negative', 'clock', 'format', 'diff']
    verified_campaign('review-epoch-ceilings-final-green', review_names)
    assert 'test result: ok. 14 passed; 0 failed; 0 ignored;' in (
        SCRATCH / 'review-epoch-ceilings-final-green-delegated.log').read_text()
    revocation_text = (SCRATCH / 'review-epoch-ceilings-final-green-revocation.log').read_text()
    conflict_cases = re.findall(r'^fn (view_sink_epoch_contract_\w+)\(', (
        ROOT / 'crates/trust/chio-federation-transport-iroh/src/lanes/revocation/tests.rs').read_text(), re.MULTILINE)
    assert len(conflict_cases) == 6
    for case in conflict_cases:
        assert re.search(r'^test \S+::' + re.escape(case) + r' \.\.\. ok$', revocation_text, re.MULTILINE), case
    revocation_totals = re.findall(
        r'^test result: ok\. (\d+) passed; 0 failed; (\d+) ignored;', revocation_text, re.MULTILINE)
    assert revocation_totals and not re.search(r'^test result: FAILED', revocation_text, re.MULTILINE)
    revocation_passes = sum(int(passed) for passed, _ in revocation_totals)
    revocation_ignored = sum(int(ignored) for _, ignored in revocation_totals)
    red_review = json.loads((SCRATCH / 'review-epoch-ceilings-behavior-red.status.json').read_text())
    assert red_review['state'] == 'completed' and red_review['exit_code'] == 1
    assert red_review['expected_regressions_reproduced'] is True
    assert len(red_review['commands']) == 2 and all(
        c['exit_code'] == 101 and c['expected_behavioral_failure_observed']
        for c in red_review['commands'])
    for command in red_review['commands']:
        assert hashlib.sha256(Path(command['log']).read_bytes()).hexdigest() == command['log_sha256']
    graph_environment = json.loads((SCRATCH / 'graph-native-environment.status.json').read_text())
    assert graph_environment['state'] == 'completed' and graph_environment['exit_code'] == 0
    assert all(c['exit_code'] == 0 for c in graph_environment['commands'])
    assert graph_environment['lock_sha256'] == q['source_files']['sdks/python/chio-langgraph/uv.lock']
    for command in graph_environment['commands']:
        assert hashlib.sha256(Path(command['log']).read_bytes()).hexdigest() == command['log_sha256']
    workspace = verified_campaign('workspace-readiness-portable-final',
                                  ['certify', 'certify-clippy', 'workspace-compile', 'workspace-clippy'])
    assert 'test result: ok. 13 passed; 0 failed; 1 ignored;' in (
        SCRATCH / 'workspace-readiness-portable-final-certify.log').read_text()
    assert workspace['hosted_acceptance_required'] == ['full-workspace-execution', 'full-consumer-boundaries']
    fixture_review = json.loads((SCRATCH / 'certify-fixture-inline-review.json').read_text())
    assert fixture_review['state'] == 'completed' and fixture_review['exit_code'] == 0
    assert fixture_review['changed_database_pairs'] == 5
    assert fixture_review['byte_exact_outside_private_directory_creation_and_module_boundary'] is True
    assert fixture_review['test_assertions_deadlines_and_ignore_unchanged'] is True
    for key, path in [('parent_sha256', 'crates/products/chio-cli/tests/certify.rs'),
                      ('child_sha256', 'crates/products/chio-cli/tests/certify/generic_registry.rs')]:
        assert fixture_review[key] == q['source_files'][path]
    diagnostic = json.loads((SCRATCH / 'diagnostic-native-4b7480c686.status.json').read_text())
    diagnostic_latest = json.loads((SCRATCH / 'diagnostic-native-4b7480c686.latest.json').read_text())
    assert diagnostic['state'] == 'completed' and diagnostic['exit_code'] == 0
    assert diagnostic['final_qualification'] is False
    assert diagnostic_latest['headSha'] == '4b7480c6861a6f85d97a63cc3918997c16c2c522'
    assert diagnostic_latest['status'] == 'completed' and diagnostic_latest['conclusion'] == 'success'
    assert sum(j['conclusion'] == 'success' for j in diagnostic_latest['jobs']) == 5
    assert [(j['name'], j['conclusion']) for j in diagnostic_latest['jobs'] if j['conclusion'] != 'success'] == [
        ('Optimized native session and shared-resource dispatch', 'skipped')]
    assert len(diagnostic['retained_jobs']) == 2
    for job in diagnostic['retained_jobs']:
        assert job['conclusion'] == 'success' and job['download_exit_code'] == 0
        assert hashlib.sha256(Path(job['log']).read_bytes()).hexdigest() == job['log_sha256']
    diagnostic_archive = json.loads((SCRATCH / 'diagnostic-native-4b7480c686-artifact.json').read_text())
    assert diagnostic_archive['archive_retained'] is False and diagnostic_archive['final_qualification'] is False
    assert diagnostic_archive['workflow_run']['head_sha'] == diagnostic_latest['headSha']
    assert diagnostic_archive['observed_conclusion'] == 'success' and diagnostic_archive['public_file'] is None
    snapshot = SCRATCH / 'native-5276181468-snapshot'
    older = json.loads((snapshot / 'qualification.json').read_text())
    metadata = json.loads((snapshot / 'snapshot.json').read_text())
    assert metadata['state'] == 'completed' and metadata['source_head'] == '52761814683f8915d4c9fae47aa0c58d92191d84'
    assert len(older['commands']) == 21 and all(c['exit_code'] == 0 for c in older['commands'].values())
    assert len(older['outputs']) == 48
    assert len({Path(relative).name for relative in older['outputs']}) == 48
    for relative, digest in older['outputs'].items():
        original = snapshot / relative
        assert hashlib.sha256(original.read_bytes()).hexdigest() == digest
    sources, outputs = len(q['source_files']), len(q['outputs'])
    directory = PAPER / 'evidence/pr1173-review/second-review-logs'
    index_path = directory / 'logs.json'
    index = json.loads(index_path.read_text())
    known = {item['log'] for item in index['logs']}
    logs = {
        'a2a-nonterminal-red.log': 'two actual signed pending-approval tasks are lost on the original implementation',
        'a2a-nonterminal-red.status.json': 'terminal original two-failure regression, exit 101',
        'a2a-nonterminal-consumer-boundary.log': 'first broader run: two repaired regressions pass; four stale approval fixtures fail',
        'a2a-nonterminal-green.status.json': 'failed first broader campaign; no aggregate pass',
        'a2a-nonterminal-final.status.json': 'all five actual tests and strict Clippy commands pass',
        'a2a-nonterminal-structural.status.json': 'initial proof inventory check reports stale source digest',
        'a2a-nonterminal-proof-coverage.log': 'initial stale inventory failure retained separately',
        'a2a-nonterminal-structural-final.status.json': 'all six final structural and inventory checks pass',
        '3b6b2ba447-advisory-success.log': 'preceding candidate passes all eight Rust scans, unfiltered OSV and six real regressions',
        '3b6b2ba447-advisory.zip': 'authenticated twelve-member public successful scanner archive for preceding candidate',
        '3b6b2ba447-advisory-artifact.json': 'archive authentication metadata for preceding candidate',
        '3b6b2ba447-advisory-job.json': 'terminal successful preceding-candidate advisory job metadata',
        '3b6b2ba447-advisory-verification.json': 'independent archive checks; zero vulnerabilities, known warnings retained',
        '3b6b2ba447-composite-audit-success.log': 'preceding-candidate complete standalone locked audit and default/FIPS regressions pass',
        '3b6b2ba447-vet-run-current.json': 'preceding-candidate terminal standalone audit metadata',
        '3b6b2ba447-vet-jobs-current.json': 'preceding-candidate terminal standalone audit job metadata',
        '3b6b2ba447-reviews-refresh.json': 'review identifies the additional nonterminal task-custody P2',
        'qualification-' + args.sha[:10] + '.status.json': 'all 21 native commands pass on the repaired source',
        'review-native-qualification-' + args.sha[:10] + '.log': 'terminal source-bound native qualification',
    }
    logs.update({
        'qualification-5276181468.status.json': 'preceding source passes all 21 native commands; independently preserved snapshot',
        'review-native-qualification-5276181468.log': 'terminal preceding-source native package, 21 commands and 48 outputs',
        'paper-nonterminal-5276181468.status.json': 'dependent waiter interrupted before any commands after new owned CI failure',
        'receipt-verifier-5276181468.status.json': 'verifier waiter interrupted before build after new owned CI failure',
        'flow-security-inventory-contract-red.log': 'updated contract rejects stale twenty-name inventory',
        'flow-security-inventory-contract-red.status.json': 'terminal actual contract failure before gate repair',
        'flow-security-inventory-compiled-red.log': 'all 26 actual tests pass; old inventory rejects six additional cases',
        'flow-security-inventory-compiled-red.status.json': 'terminal actual compiled-inventory failure before repair',
        'flow-security-inventory-controls-green.status.json': 'earlier bounded clock inventory calibration passes; later full controls retained separately',
        'flow-security-composed-final.status.json': 'complete actual composed flow gate is terminal passing',
        'flow-security-composed-final-gate.log': 'positive and negative formal controls, WASM checks and all 71 actual inventories pass',
        '3b6b2ba447-postgres-failure.log': 'both confined worker trajectories pass; actual runtime retirement fails its original receipt binding assertion',
        '3b6b2ba447-postgres-failure-job.json': 'authenticated terminal failed PostgreSQL job; failure scope is actual launch receipt binding',
        '3b6b2ba447-kani-success.log': 'preceding head completes all 53 actual Kani harnesses with the repaired compiler',
        '3b6b2ba447-kani-success-job.json': 'authenticated preceding-head terminal Kani success',
        '3b6b2ba447-kani-success.verification.json': 'independent proof block and harness identity verification',
        '3b6b2ba447-security-authorities-refresh.json': 'repository-owned source and definition; signed package and policy absent',
        '3b6b2ba447-security-authorities-final.json': 'later repository authority refresh; committed package and policy still absent',
        '3b6b2ba447-build-failure.log': 'main CI fails the original stub scanner before workspace build and tests',
        '3b6b2ba447-build-failure-job.json': 'authenticated preceding-head main CI failure metadata',
        '3b6b2ba447-msrv-failure.log': 'MSRV reaches nine passing certification tests, four authority-parent fixture failures and one existing ignore',
        '3b6b2ba447-msrv-failure-job.json': 'authenticated preceding-head MSRV failure metadata',
        'certify-fixture-extraction.json': 'original fixture hash, five private database pairs and unchanged assertions; normal modules replace obsolete size cap',
        'certify-fixture-inline-review.json': 'fresh byte-exact comparison proves all five moved test bodies, assertions, deadlines and the existing ignore are unchanged outside private database parents',
        'security-authorities-20261006T060739.json': 'later read-only check of actual authority variables; source/definition unchanged and signed Linux evidence commit and policy still absent',
        'security-authorities-20261006T053218.json': 'fresh read-only authority check; original security owner source/definition remain pinned and Linux evidence SHA and policy remain absent',
        '3b6b2ba447-installed-consumer-failure.log': 'installed repository operator fails its original first native run with request timeout',
        '3b6b2ba447-installed-consumer-failure-job.json': 'authenticated preceding-head installed-consumer failure metadata',
        '3b6b2ba447-mcp-process-failure.log': 'native host aggregate refuses installed-consumer failure despite other successful participants',
        '3b6b2ba447-mcp-process-failure-job.json': 'authenticated preceding-head native host aggregate failure',
        '3b6b2ba447-mini-swe-operator-failure.json': 'only bounded public failure classes and original incomplete run report are retained',
        '3b6b2ba447-mini-swe-artifact.json': 'authenticated archive metadata; private worker logs and credentials are not retained',
        '3b6b2ba447-security-aggregate-failure.log': 'security aggregate rejects unsuccessful prerequisites and absent protected committed evidence',
        '3b6b2ba447-security-aggregate-failure-job.json': 'authenticated preceding-head security aggregate failure metadata',
        '3b6b2ba447-fuzz-success.log': 'preceding head completes every actual ASan target without crashes',
        '3b6b2ba447-fuzz-success-job.json': 'authenticated terminal preceding-head 34-target fuzz success',
        '3b6b2ba447-fuzz-success.verification.json': 'independent exact 34 build/start/end identities verified',
        'flow-security-composed-initial.status.json': 'first full flow run stops at the stale response inventory, not a passing aggregate',
        'flow-security-composed-initial.log': 'actual initial full-flow inventory failure retained',
        'flow-security-compiled-preflight.status.json': 'all 69 original selections compile; eleven remaining exact inventories mismatch',
        'flow-security-compiled-preflight-logs.tar.gz': 'all 69 authenticated original compile/list raw outputs; no behavioral gate pass',
        'flow-security-compiled-preflight-archive.json': 'archive member hashes and explicit compiled-only scope',
        'flow-security-inventory-repair.json': 'reviewed compiled identity additions, provenance of two renames and removed converter cases',
        'flow-security-complete-contract-red.log': 'updated complete contract rejects the original stale inventories',
        'flow-security-complete-contract-red.status.json': 'terminal actual complete-inventory contract failure before repair',
        'flow-manifest-migration.log': 'all eight existing operator migration cases pass, including authentic-v1 refusal',
        'flow-manifest-migration.status.json': 'terminal existing operator-owned migration qualification',
        'consumer-inventory-contract-red.log': 'updated ten-name consumer contract rejects original eight-name inventory',
        'consumer-inventory-contract-red.status.json': 'terminal original consumer contract failure',
        'consumer-inventory-compiled-red.log': 'ten actual consumer tests pass before the original wrapper rejects the two added identities',
        'consumer-inventory-compiled-red.status.json': 'terminal exact consumer-inventory failure, not a behavior pass for the gate',
        'kernel-legacy-receipt-compile-failed.log': 'first portable fixture fails compilation on a test enum typo; no behavioral reproduction follows',
        'kernel-legacy-receipt-compile-failed.status.json': 'separately retained compile failure before correcting the fixture',
        'kernel-legacy-receipt-red.log': 'corrected real signed-receipt regression fails the original missing launch binding',
        'kernel-legacy-receipt-red.status.json': 'terminal actual receipt-binding behavioral failure',
        'kernel-legacy-receipt-green.status.json': 'all ten delivery cases, strict kernel Clippy and format pass with exact source hashes',
        'stub-surfaces-red.status.json': 'original scanner rejects the real repository and updated checker controls',
        'stub-surfaces-green.status.json': 'initial scanner repair passes before further macro calibration is added',
        'stub-surfaces-macro-whitespace-red.log': 'first scanner repair falsely admits a whitespace-separated qualified executable TODO',
        'stub-surfaces-macro-whitespace-red.status.json': 'terminal actual whitespace-macro control failure',
        'stub-surfaces-final.status.json': 'earlier whole scanner and controls pass; later qualified-comment calibration finds another gap',
        'stub-surfaces-qualified-comments-red.log': 'first added control rejects the macro on its unqualified import but falsely admits the qualified unfinished comment',
        'stub-surfaces-qualified-comments-red.status.json': 'initial calibration failure retained with its original scope; corrected isolated macro control follows',
        'stub-surfaces-qualified-macro-red.log': 'valid standard-library alias macro with intervening Rust comments is falsely admitted by the old exception',
        'stub-surfaces-qualified-macro-red.status.json': 'actual isolated macro control fails after its source compiles as real Rust',
        'stub-surfaces-qualified-final.status.json': 'complete current scanner and every checker control pass with unchanged source hashes',
        'mini-swe-diagnostics-launch-error.log': 'missing virtual-environment launch; behavioral test was not executed',
        'mini-swe-diagnostics-launch-error.status.json': 'explicit not-executed diagnostic launch record',
        'mini-swe-diagnostics-red.log': 'actual secret-seeded public method/deadline diagnostic is absent before the repair',
        'mini-swe-diagnostics-red.status.json': 'terminal actual diagnostic regression failure',
        'mini-swe-diagnostics-initial.status.json': 'diagnostic and lint pass; first formatting check fails on test call wrapping',
        'mini-swe-diagnostics-final.status.json': 'diagnostic/lint/format pass; full SDK has seven missing-pidfd API failures in the selected interpreter',
        'mini-swe-native-python-final.status.json': 'same locked dependencies under pidfd-capable system CPython: all 414 SDK/recovery tests and lint/format pass',
        'installed-native-diagnostic-checkpoint.json': 'tested diagnostic-only source checkpoint; final source and hosted acceptance remain required',
        'diagnostic-4b7480c686-ci-selection.json': 'unrelated investigative checks are cancelled; native diagnosis remains selected; no aggregate qualification',
        'inventory-controls-final.status.json': 'whole 71-inventory and consumer contracts plus whitespace check pass',
        'consumer-boundaries-composed-final.status.json': 'six inventories and fifteen tests pass; first native MCP case then exits 101 on the unavailable Linux x86 host; no gate acceptance',
        'consumer-boundaries-composed-final-gate.log': 'actual ARM consumer failure retained; enforcing-host assertion stays mandatory for final x86 qualification',
        'workspace-readiness-initial.status.json': 'pending workspace waiter interrupted before any commands after two additional review findings',
        'workspace-readiness-portable-final.status.json': 'certification target, selected strict Clippy, complete workspace test compilation and workspace library/binary/example Clippy pass; full execution requires x86',
        '4b7480c686-reviews-current.json': 'authenticated live review adds delegated cost ceiling and same-epoch revocation conflict findings',
        'v1-custody-thread-resolution-4b7480c686.json': 'qualified and pushed v1 custody finding resolved; native and new findings remain separate',
        'review-epoch-ceilings-behavior-red.status.json': 'two real targeted regressions reproduce the larger-cap refusal and same-epoch conflict acknowledgement, actual exits 101',
        'review-epoch-ceilings-behavior-red-delegated.log': 'actual signed SQLite 20/100 admission is incorrectly denied before the minimum-cap repair',
        'review-epoch-ceilings-behavior-red-revocation.log': 'five authentic conflict and handler regressions fail while identical/stale delivery remains a passing positive control',
        'review-epoch-ceilings-red.status.json': 'first launch: fixture compilation and incorrectly scoped feature fail; no behavioral reproduction',
        'review-epoch-ceilings-red-delegated.log': 'first fixture compilation rejects missing MonetaryAmount import and unsupported unsigned SQLite decoding',
        'review-epoch-ceilings-red-revocation.log': 'first transport command fails before compilation because typestate belongs to federation, not its adapter',
        'review-epoch-ceilings-green.status.json': 'initial repaired campaign: fourteen delegation tests and kernel Clippy pass; transport fails compilation on missing collection import; actual subsequent results retained',
        'review-epoch-ceilings-final-green.status.json': 'both complete repaired suites, strict affected Clippy and renewed structural checks pass against captured Rust source',
        'graph-native-environment.status.json': 'separate locked system-CPython environment supplies both required Linux pidfd APIs; source lock unchanged',
        'security-authorities-20261006T0430.json': 'read-only later authority refresh; signed package and policy still absent',
        'diagnostic-native-4b7480c686.status.json': 'investigative native run completes five successful jobs and one legitimate conditional skip; not final repaired-head qualification',
        'diagnostic-native-4b7480c686.latest.json': 'authenticated terminal diagnostic-only source and complete hosted job/step metadata',
        'diagnostic-native-4b7480c686-artifact.json': 'successful mini-SWE archive authenticated in memory; archive/private worker files not retained and no operator-failure diagnostic exists',
    })
    for job in diagnostic['retained_jobs']:
        stem = 'diagnostic-native-4b7480c686-' + str(job['job_id'])
        logs[stem + '.log'] = 'actual successful installed native consumer or native aggregate job on the investigative source; final source must be renewed'
        logs[stem + '.job.json'] = 'authenticated successful investigative native job metadata'
    for prefix, names in [
        ('inventory-controls-final', ['flow', 'consumer', 'diff']),
        ('workspace-readiness-portable-final', ['certify', 'certify-clippy', 'workspace-compile', 'workspace-clippy']),
        ('stub-surfaces-qualified-final', ['contract', 'repository']),
        ('mini-swe-native-python-final', ['environment', 'capabilities', 'sdk', 'lint', 'format']),
        ('review-epoch-ceilings-final-green', review_names),
        ('graph-native-environment', ['sync', 'capabilities', 'packages']),
    ]:
        for name in names:
            logs[prefix + '-' + name + '.log'] = 'terminal actual current-source verification; scope bound by companion status and hashes'
    for name in review_names:
        logs['review-epoch-ceilings-green-' + name + '.log'] = 'initial repaired campaign; actual command result retained, including missing-import transport failures'
    for name in ['format', 'delivery', 'clippy']:
        logs['kernel-legacy-receipt-' + name + '-green.log'] = 'terminal actual legacy preparation signed-binding regression or strict lint'
    for phase in ['red', 'green', 'final']:
        for name in ['contract', 'repository']:
            logs['stub-surfaces-' + name + '-' + phase + '.log'] = 'historical scanner campaign; actual result and source retained in companion status'
    for phase in ['green', 'final']:
        for name in ['diagnostics', 'lint', 'format']:
            logs['mini-swe-diagnostics-' + name + '-' + phase + '.log'] = 'actual preceding public diagnostics/style command; failed first formatting check remains failed'
    logs['mini-swe-diagnostics-sdk-final.log'] = 'first full SDK run: 407 pass and seven missing Linux pidfd API failures; no SDK aggregate pass'
    missing = [name for name in logs if not (SCRATCH / name).is_file()]
    assert not missing, missing
    for name in ['contract', 'exact-runner-controls', 'diff']:
        logs['flow-security-inventory-' + name + '-green.log'] = 'terminal flow calibration check passes'
    for kind in ['portable', 'native', 'adversarial', 'active']:
        logs['3b6b2ba447-enterprise-' + kind + '-failure.log'] = 'preceding hosted failure retained; supporting source/package handoff or owned stale inventory'
        logs['3b6b2ba447-enterprise-' + kind + '-failure-job.json'] = 'authenticated terminal preceding-head failed job metadata'
    for name in ['consumer-boundary', 'edge', 'http-interop', 'edge-clippy', 'consumer-clippy']:
        logs['a2a-nonterminal-final-' + name + '.log'] = 'terminal repaired-source tests or Clippy pass'
    for name in ['proof-refresh', 'proof-final', 'format-final', 'hygiene-final', 'negative-final', 'diff-final']:
        logs['a2a-nonterminal-' + name + '.log'] = 'terminal repaired-source structural check passes'
    assert not known.intersection(name + '.gz' for name in logs), 'log record already retained'
    payloads = {name: (SCRATCH / name).read_bytes() for name in logs}
    history = ROOT / 'docs/research/dynamic-delegation/evidence/history' / metadata['source_head']
    assert not history.exists(), 'previous source snapshot already retained'
    history.mkdir()
    import shutil
    for relative in older['outputs']:
        original = snapshot / relative
        shutil.copy2(original, history / original.name)
    shutil.copy2(snapshot / 'qualification.json', history / 'qualification.json')
    shutil.copy2(snapshot / 'snapshot.json', history / 'snapshot.json')
    for name, result in logs.items():
        compressed = name + '.gz'
        assert compressed not in known, name
        data = payloads[name]
        with (directory / compressed).open('xb') as stream:
            stream.write(gzip.compress(data, mtime=0))
        index['logs'].append({'log': compressed, 'observed_result': result, 'bytes': len(data),
                              'sha256': hashlib.sha256(data).hexdigest()})
    index_path.write_text(json.dumps(index, indent=2) + '\n')
    second = PAPER / 'evidence/pr1173-review/SECOND-REVIEW.md'
    text = second.read_text()
    before, remainder = text.split('## Local qualification\n', 1)
    _, after = remainder.split('Follow-up platform and structural repairs', 1)
    quote = chr(96)
    local = (f'\nSource {quote}{args.sha}{quote} passes all 21 terminal native commands against\n'
             f'{sources:,} unchanged source files and {outputs} retained outputs. Actual parent\n'
             'SIGKILL, evolving funded work, all four earned-child payment cases and all 20\n'
             'artifact-tool tests pass. Earlier complete, failed and interrupted campaigns\n'
             'retain their original source and scope.\n\n')
    note = (f'\n\n## Nonterminal v1 task custody\n\nSource {quote}{args.sha}{quote} retains successful nonterminal v1 tasks after blocking\n'
            'SendMessage while releasing terminal results and execution/projection failures.\n'
            'Existing caller quotas, authority deadlines and output modes govern retained\n'
            'custody. V1 GetTask remains observational. Two real SQLite-backed cumulative\n'
            'approval regressions fail against the original removal, then pass with signed\n'
            'proposal and receipt authority, stable JSON/text task projections, caller\n'
            'isolation, cancellation and no dispatch or additional receipts.\n\n'
            'The full consumer run also finds four stale threshold fixtures. Bind their exact\n'
            'tool invocation using the public approval context and install their explicit\n'
            'approver roster. All successful capture and restart assertions are retained;\n'
            'production approval validation is unchanged. All ten consumer tests, 116 edge\n'
            'tests, three live HTTP tests, both strict Clippy commands and structural checks\n'
            'pass. Formal selection remains 66 rows and 182 artifacts, with its input digest\n'
            'renewed. Original failures and the preceding candidate\'s authenticated successful\n'
            'advisory archive remain historical. Final-head hosted acceptance and the\n'
            'security owner\'s coherent source and signed Linux package remain separate.\n')
    note += (
        '\nThe preceding hosted flow job passes all 26 default security-type library tests,\n'
        'then fails its stale twenty-name inventory. The repaired gate includes every\n'
        'compiled clock and bounded-reader case, preserves the exact default library\n'
        'target, and rejects each identity substitution through its actual validator.\n'
        'Positive and negative information-flow models, both portable WASM checks and\n'
        'all 71 composed test inventories pass in the preceding local campaign.\n'
        'Its source scope precedes the final delegated-ceiling and revocation repairs;\n'
        'fresh final-head hosted flow acceptance remains mandatory. Earlier failed checks retain\n'
        'their actual outcomes. The security owner must still supply the coherent\n'
        'closed-shard source closure and a fresh caught-only signed Linux package.\n'
    )
    note += (
        '\n## Delegated cost and revocation epoch boundaries\n\n'
        'An exact one-invocation dispatch binds the smaller of its signed per-call\n'
        'and total ceilings. Both ceilings and their currency remain mandatory.\n'
        'Actual SQLite execution admits the 20/100 and 20/20 grants for the same\n'
        '20-unit offer, signs the result, captures exactly one 20-unit hold and\n'
        'replays observationally. A 100/20 grant retains the ordinary worst-case\n'
        'budget refusal before payment or dispatch. The original maximum rejects\n'
        'the admissible 20/100 case; all 14 repaired delegation tests pass.\n\n'
        'The pinned-origin revocation sink retains the kernel-core strict epoch\n'
        'compare-and-swap. Identical projected snapshots and older roots remain\n'
        'idempotent; conflicting installed-epoch hashes, issue times or locally\n'
        'materialized subjects receive typed rejection without changing the view.\n'
        'Conflicting signed root bodies inside a batch are rejected before its\n'
        'single install, including conflicts below a valid highest epoch. Six\n'
        'authentic-signature controls cover these cases, actual handler rejection\n'
        'and concurrent duplicate/conflicting writers. Five controls fail against\n'
        'the original acknowledgement while the replay/stale positive control\n'
        f'passes. The complete typestate-enabled transport campaign records {revocation_passes}\n'
        f'passes and {revocation_ignored} ignored tests. Both affected strict Clippy commands and\n'
        'the renewed structural controls pass. No second authority registry or\n'
        'same-epoch update protocol is introduced.\n\n'
        'Legacy in-place preparation now retains its effective connection for\n'
        'signed launch attribution. All ten delivery-revalidation cases and\n'
        'strict kernel Clippy pass; actual x86 confinement and runtime retirement\n'
        'remain a separate final-head hosted requirement. The certification\n'
        'fixtures create private authority parents and live in normal modules\n'
        'below 2,000 lines. All thirteen certification cases pass with the one\n'
        'existing timing-sensitive ignore preserved. Complete workspace test compilation\n'
        'and strict library/binary/example Clippy pass with unchanged captured\n'
        'Rust/build inputs. The local consumer gate passes six inventories and\n'
        'fifteen tests, then correctly refuses its first native MCP case on ARM.\n'
        'That exit-101 campaign remains failed. Complete consumer and workspace\n'
        'execution require the qualified final-head Linux x86 enforcing host.\n\n'
        'The stub scanner distinguishes lint tokens from executable unfinished\n'
        'macros and comments, admits only the three reviewed exact domain lines,\n'
        'and removes stale exceptions. The whole repository and every contract\n'
        'control pass. All 414 SDK/recovery tests pass under system CPython with\n'
        'both Linux pidfd APIs. The original failed interpreter run is retained;\n'
        'subsequent workspace/native qualification uses a separately prepared\n'
        'locked system-CPython environment without changing the dependency lock.\n'
    )
    note += (
        '\nThe investigative x86 run at 4b7480c686 completes all five selected native\n'
        'jobs successfully, including both installed operators, the original\n'
        '65-second repository command, coding sessions, installed packages,\n'
        'adaptive review, AI SDK 6/7 and the swarm benchmark. The conditionally\n'
        'disabled optimized comparison is skipped. Its successful archive is\n'
        'authenticated in memory; private worker files are not retained. The\n'
        'earlier request timeout does not reproduce, and retains its failed\n'
        'source scope. This investigative source precedes the final Rust repairs;\n'
        'fresh final-head native, PostgreSQL retirement, complete consumer and\n'
        'workspace qualification remain mandatory.\n'
    )
    second.write_text(before + '## Local qualification\n' + local + 'Follow-up platform and structural repairs' + after + note)
    with (PAPER / 'evidence/pr1173-review/REVIEW.md').open('a') as stream:
        stream.write(note)
    publication = PAPER / 'PUBLICATION.json'
    release = json.loads(publication.read_text())
    assert release['publish_ready'] is False and release['breakthrough_established'] is False
    gate = next(g for g in release['gates'] if g['id'] == 'artifact')
    gate.update(status='passed', result=f'All 21 terminal native commands pass against {sources:,} unchanged inputs and {outputs} outputs, including all 20 artifact-tool tests. Actual nonterminal v1 custody, all ten consumer cases, 116 edge tests and three live HTTP scenarios pass with strict Clippy. The preceding local campaign completes all 71 actual composed flow inventories, including every default security-type case, with formal and mutation controls; final-head hosted flow remains required after the last review repairs. Original failures and preceding hosted qualification retain their original scope. Derived results, reproducible PDF and source/evidence inventory agree. Hosted production and independent publication gates remain separate.')
    publication.write_text(json.dumps(release, indent=2) + '\n')
    environment = os.environ.copy()
    environment['PATH'] = '/home/connor/chio-pr1173-tools/python-graph-native/bin:' + environment['PATH']
    record['state'] = 'running'
    save()
    for name, argv, expected in [
        ('refresh', ['python3', 'tools/check.py', '--refresh'], 0),
        ('render', ['make', 'render'], 0),
        ('freeze', ['python3', 'tools/check.py', '--freeze'], 0),
        ('rebuild', ['make', 'build'], 0),
        ('publication', ['python3', 'tools/check.py', '--publication'], 1),
    ]:
        log = SCRATCH / ('paper-inventory-' + args.sha[:10] + '-' + name + '.log')
        with log.open('x') as stream:
            result = subprocess.run(argv, cwd=PAPER, env=environment, stdin=subprocess.DEVNULL,
                                    stdout=stream, stderr=subprocess.STDOUT)
        record['commands'].append({'name': name, 'command': argv, 'exit_code': result.returncode})
        save()
        assert result.returncode == expected, (name, result.returncode)
        if name == 'render':
            first_pdf = (PAPER / 'paper.pdf').read_bytes()
        if name == 'rebuild':
            assert (PAPER / 'paper.pdf').read_bytes() == first_pdf
    failures = {line for line in log.read_text().splitlines() if line.startswith('FAIL:')}
    assert failures == {'FAIL: publication gate open: ' + name for name in [
        'independent-operation', 'useful-work-economics', 'integration-advantage', 'foundational-claim',
    ]} | {'FAIL: publish_ready is not true', 'FAIL: breakthrough_established is not true'}
    record.update(state='completed', exit_code=0, source_files=sources, outputs=outputs,
                  retained_logs=len(index['logs']), pdf_sha256=hashlib.sha256(first_pdf).hexdigest(),
                  publication_result='four open research gates and two false readiness flags')
except BaseException as error:
    record.update(state='failed', exit_code=1, error=repr(error))
    raise
finally:
    record['completed_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    save()
