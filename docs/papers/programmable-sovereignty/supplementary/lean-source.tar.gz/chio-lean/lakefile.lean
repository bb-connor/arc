import Lake
open Lake DSL

package chioPaper where
  leanOptions := #[
    ⟨`autoImplicit, false⟩
  ]

@[default_target]
lean_lib Chio where
  srcDir := "."
