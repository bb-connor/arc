# Chio Lean artifact

Paper: Receiver-Owned Bilateral Admission for Cross-Organization Agent Tool Calls
Snapshot date: 2026-09-11

Build from this directory:

```sh
lake build
```

The paper claims only bounded model theorems. It does not claim that this
project verifies the Rust runtime.

To reproduce the recorded axiom lists:

```lean
import Chio.Treaty.ReceiptPredicate
#print axioms Chio.Treaty.ReceiptPredicate.finite_refinement_sound
#print axioms Chio.Treaty.ReceiptPredicate.finite_refinement_exact
```
