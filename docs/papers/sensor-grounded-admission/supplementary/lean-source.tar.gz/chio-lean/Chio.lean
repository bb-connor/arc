-- Substrate modules the paper-local sensor-grounded model sits beside.

import Chio.Treaty.PredicateLang
import Chio.Treaty.IntersectionSyntactic
import Chio.Treaty.Intersection
