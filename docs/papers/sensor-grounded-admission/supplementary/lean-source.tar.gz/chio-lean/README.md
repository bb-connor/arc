# Chio Lean substrate (sensor-grounded-admission companion)

This tarball contains the Lean 4 sources needed to check the four theorems
named in the paper "Sensor-Grounded Admission: Polity Receipts with
Attested Substrate State".

`Chio/Treaty/SensorGroundedAdmission.lean` is a byte-identical copy of the
paper-local module `docs/papers/sensor-grounded-admission/lean/SensorGroundedAdmission.lean`
in the Chio repository. It is paper-local with respect to the substrate:
the substrate's proof root does not import it, does not build it, and does
not list it in `formal/theorem-inventory.json`. The other three modules are
copies of the substrate's Treaty modules at the same revision, which is the
full import closure of the sensor-grounded module.

## Layout

```
chio-lean/
  lean-toolchain         Pinned Lean release (read by elan)
  lakefile.lean          Lake build definition, no external dependencies
  lake-manifest.json     Lake dependency manifest (empty)
  Chio.lean              Root module: the substrate Treaty modules
  Chio/Treaty/PredicateLang.lean
  Chio/Treaty/IntersectionSyntactic.lean
  Chio/Treaty/Intersection.lean
                         Substrate modules the paper-local model sits beside
  Chio/Treaty/SensorGroundedAdmission.lean
                         The four sensor-grounded theorems
```

The four theorems live under the `Chio.Treaty.SensorAttestation` namespace:

1. `admission_predicate_separates_healthy_and_degraded_witnesses`
2. `partition_contingency_mode_iff_degraded_subset`
3. `healthy_attestation_required_for_destructive_admission`
4. `degraded_sensor_admission_requires_re_admission_witness`

## Building

Install `elan` (the Lean version manager) if it is not already present:

```
curl https://raw.githubusercontent.com/leanprover/elan/master/elan-init.sh -sSf | sh
```

The `lean-toolchain` file pins the exact Lean release; elan installs it on
first invocation. Then, from the tarball root:

```
cd chio-lean
lake build
lake env lean Chio/Treaty/SensorGroundedAdmission.lean
```

The first command builds the three substrate Treaty modules; it prints the
`#eval` information lines those modules carry and reports no warnings or
errors. The second command elaborates the paper-local module against them
and exits 0 with no output. Two commands rather than one, because the
paper-local module is checked exactly as it is in the repository: from
outside the root module, never registered in it. A cold toolchain install
dominates the wall time; the build itself takes a few seconds.

The sources contain no `sorry` and no project-local `axiom`.

## Verifying the four theorems

To inspect the axiom set each theorem depends on, append the four
`#print axioms` lines below to a scratch copy of
`Chio/Treaty/SensorGroundedAdmission.lean` and run `lake env lean` on the
copy:

```
#print axioms Chio.Treaty.SensorAttestation.admission_predicate_separates_healthy_and_degraded_witnesses
#print axioms Chio.Treaty.SensorAttestation.partition_contingency_mode_iff_degraded_subset
#print axioms Chio.Treaty.SensorAttestation.healthy_attestation_required_for_destructive_admission
#print axioms Chio.Treaty.SensorAttestation.degraded_sensor_admission_requires_re_admission_witness
```

The reported sets are recorded in `proof-manifest.toml` and
`theorem-inventory.json` shipped alongside this tarball. Only standard Lean
kernel axioms appear (`propext`, `Classical.choice`, `Quot.sound`); no
project-specific axioms are introduced.
